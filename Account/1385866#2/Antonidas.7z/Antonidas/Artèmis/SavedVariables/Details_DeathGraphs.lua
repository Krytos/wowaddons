
DeathGraphsDBDeaths = {
	["233515"] = {
		["hash"] = "233515",
		["type"] = "deaths",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2272,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["encounter"] = "King Rastakhan",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Ariaelth-BurningLegion"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ariaelth-BurningLegion",
				["class"] = "PALADIN",
			},
			["Râân"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Râân",
				["class"] = "DEMONHUNTER",
			},
			["Lilania"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Lilania",
				["overall"] = {
				},
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Härridk",
				["overall"] = {
				},
			},
			["Soely"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Soely",
				["overall"] = {
				},
			},
			["Hotarou-Alleria"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Hotarou-Alleria",
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Lokiboy"] = {
				["name"] = "Lokiboy",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Viste-ZirkeldesCenarius"] = {
				["name"] = "Viste-ZirkeldesCenarius",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ragæ-GrimBatol"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ragæ-GrimBatol",
				["class"] = "DEATHKNIGHT",
			},
			["Nakkor-Medivh"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Nakkor-Medivh",
				["class"] = "MAGE",
			},
			["Mêphis"] = {
				["name"] = "Mêphis",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chentis"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Chentis",
				["class"] = "MAGE",
			},
			["Coffinlove"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Coffinlove",
				["overall"] = {
				},
			},
			["Larnoon-Ravencrest"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Larnoon-Ravencrest",
				["class"] = "SHAMAN",
			},
			["Narfnarf"] = {
				["name"] = "Narfnarf",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kindralia"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kindralia",
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kirgit",
				["class"] = "PRIEST",
			},
			["Làika"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Làika",
				["class"] = "DEMONHUNTER",
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Salanâ"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Salanâ",
				["overall"] = {
				},
			},
			["Rusell"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Rusell",
				["class"] = "WARLOCK",
			},
			["Seyden"] = {
				["name"] = "Seyden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Daddysenpai"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Daddysenpai",
				["overall"] = {
				},
			},
			["Slyre"] = {
				["name"] = "Slyre",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Yanaizu",
				["overall"] = {
				},
			},
			["Nayven"] = {
				["name"] = "Nayven",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Sukuo-Ravencrest"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Sukuo-Ravencrest",
				["class"] = "DRUID",
			},
			["Ventex"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ventex",
				["class"] = "SHAMAN",
			},
			["Chántý"] = {
				["name"] = "Chántý",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Darkladyii-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Darkladyii-Silvermoon",
				["class"] = "DEMONHUNTER",
			},
			["Arameh"] = {
				["name"] = "Arameh",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["name"] = "Môdox",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Tyrellan",
				["overall"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Slapgodx-Sen'jin"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Slapgodx-Sen'jin",
				["class"] = "MONK",
			},
			["Vave-Blackmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Vave-Blackmoore",
				["class"] = "DRUID",
			},
			["Julietté"] = {
				["name"] = "Julietté",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["name"] = "Yesiam",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kmii"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kmii",
				["class"] = "WARRIOR",
			},
		},
	},
	["233016"] = {
		["hash"] = "233016",
		["type"] = "deaths",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Conclave of the Chosen",
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Daddysenpai",
			},
			["Aspern"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Aspern",
				["overall"] = {
				},
			},
			["Andromaché"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Andromaché",
				["overall"] = {
				},
			},
			["Nelwyn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nelwyn",
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Inánná"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Inánná",
				["overall"] = {
				},
			},
			["Dovomir"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dovomir",
			},
			["Almîna"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Almîna",
				["overall"] = {
				},
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Samîsu"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Samîsu",
			},
			["Hornpubmonk"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hornpubmonk",
			},
			["Neferupitou"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Neferupitou",
				["overall"] = {
				},
			},
			["Tyrellan"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tyrellan",
			},
			["Artèmis"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Artèmis",
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
			["Qyix"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Qyix",
				["overall"] = {
				},
			},
			["Salanâ"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Salanâ",
				["overall"] = {
				},
			},
		},
		["diff"] = 16,
	},
	["233714"] = {
		["hash"] = "233714",
		["type"] = "deaths",
		["name"] = "Stormwall Blockade",
		["id"] = 2337,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 8,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2280,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Stormwall Blockade",
			["diff"] = 14,
			["ej_instance_id"] = 1176,
			["encounter"] = "Stormwall Blockade",
		},
		["player_db"] = {
			["Unholyed-Blackmoore"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Unholyed-Blackmoore",
			},
			["Vergo-Khaz'goroth"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Vergo-Khaz'goroth",
			},
			["Frêyár-Blackmoore"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Frêyár-Blackmoore",
			},
			["Alynja-Blackmoore"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alynja-Blackmoore",
			},
			["Ráyna"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ráyna",
			},
			["Acnosa-Blackmoore"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Acnosa-Blackmoore",
			},
			["Zettler"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Zettler",
			},
			["Qookie-Blackmoore"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Qookie-Blackmoore",
			},
			["Wildemaus-Blackmoore"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Wildemaus-Blackmoore",
			},
			["Emyniâ-Blackmoore"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Emyniâ-Blackmoore",
			},
			["Môrrtis-Blackmoore"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Môrrtis-Blackmoore",
			},
			["Artèmis"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Artèmis",
			},
			["Ehnie"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ehnie",
			},
			["Roulin-Blackmoore"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Roulin-Blackmoore",
			},
			["Demoniq"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Demoniq",
			},
			["Mzai-Blackmoore"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Mzai-Blackmoore",
			},
		},
		["diff"] = 14,
	},
	["233315"] = {
		["hash"] = "233315",
		["type"] = "deaths",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2265,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["encounter"] = "Champion of the Light",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Daddysenpai",
				["overall"] = {
				},
			},
			["Aethalia-Silvermoon"] = {
				["name"] = "Aethalia-Silvermoon",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Singus-ChamberofAspects"] = {
				["name"] = "Singus-ChamberofAspects",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Lilania"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Lilania",
				["overall"] = {
				},
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Soely"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Soely",
				["overall"] = {
				},
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Ðaisuke",
				["overall"] = {
				},
			},
			["Kaberekon"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kaberekon",
			},
			["Viste-ZirkeldesCenarius"] = {
				["name"] = "Viste-ZirkeldesCenarius",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Wahreseele-Nethersturm"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Wahreseele-Nethersturm",
			},
			["Guldàníel"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Guldàníel",
				["overall"] = {
				},
			},
			["Kamine-Arathor"] = {
				["name"] = "Kamine-Arathor",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Artèmis",
			},
			["Ristaâ"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ristaâ",
			},
			["Aspern"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Aspern",
				["overall"] = {
				},
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Avoidwyaatt-DefiasBrotherhood"] = {
				["name"] = "Avoidwyaatt-DefiasBrotherhood",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Djano-Blackmoore"] = {
				["name"] = "Djano-Blackmoore",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Salzstange-Wrathbringer"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Salzstange-Wrathbringer",
			},
			["Aruwion-Silvermoon"] = {
				["name"] = "Aruwion-Silvermoon",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Kalissta",
				["overall"] = {
				},
			},
			["Seyden"] = {
				["name"] = "Seyden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Telora"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Telora",
			},
			["Melaesa-ChamberofAspects"] = {
				["name"] = "Melaesa-ChamberofAspects",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Slyre"] = {
				["name"] = "Slyre",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Arameh",
				["class"] = "SHAMAN",
			},
			["Wolfly-Silvermoon"] = {
				["name"] = "Wolfly-Silvermoon",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chántý"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Chántý",
				["class"] = "DRUID",
			},
			["Holystêve-ChamberofAspects"] = {
				["name"] = "Holystêve-ChamberofAspects",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Xaru"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Xaru",
				["overall"] = {
				},
			},
			["Härridk"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Härridk",
				["overall"] = {
				},
			},
			["Mupsy"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Mupsy",
			},
			["Lockary"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Lockary",
			},
			["Supersunny"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Supersunny",
				["overall"] = {
				},
			},
			["Piffpâff"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Piffpâff",
			},
			["Mêphis"] = {
				["name"] = "Mêphis",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Thalee-Shadowsong"] = {
				["name"] = "Thalee-Shadowsong",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Avasera-Silvermoon"] = {
				["name"] = "Avasera-Silvermoon",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Shanxi-Aszune"] = {
				["name"] = "Shanxi-Aszune",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Zayross-Quel'Thalas"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Zayross-Quel'Thalas",
			},
			["Golithor"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Golithor",
			},
			["Wystra"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Wystra",
				["overall"] = {
				},
			},
			["Metó"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Metó",
				["overall"] = {
				},
			},
			["Tempole"] = {
				["name"] = "Tempole",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chaotic-Shadowsong"] = {
				["name"] = "Chaotic-Shadowsong",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["name"] = "Môdox",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Tyrellan",
				["overall"] = {
				},
			},
			["Angraem-DarkmoonFaire"] = {
				["name"] = "Angraem-DarkmoonFaire",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tuathla"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tuathla",
			},
			["Andromaché"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Andromaché",
				["overall"] = {
				},
			},
			["Lyrasiella"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Lyrasiella",
			},
			["Norå-Nagrand"] = {
				["name"] = "Norå-Nagrand",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Wellorie-Aegwynn"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Wellorie-Aegwynn",
			},
			["Lindórië-Azuremyst"] = {
				["name"] = "Lindórië-Azuremyst",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Yanaizu",
				["overall"] = {
				},
			},
			["Devastatia-Aszune"] = {
				["name"] = "Devastatia-Aszune",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Káily"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Káily",
			},
			["Phenòmena"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Phenòmena",
			},
			["Moncatzie"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Moncatzie",
			},
			["Julietté"] = {
				["name"] = "Julietté",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["name"] = "Yesiam",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Shivas-Malorne"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Shivas-Malorne",
			},
		},
	},
	["233416"] = {
		["hash"] = "233416",
		["type"] = "deaths",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 6,
			["name"] = "Mekkatorque",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Mekkatorque",
		},
		["player_db"] = {
			["Xaru"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Xaru",
			},
			["Aspern"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Aspern",
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Nelwyn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nelwyn",
			},
			["Härridk"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Härridk",
			},
			["Alleycut"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alleycut",
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Ðaisuke"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ðaisuke",
			},
			["Inánná"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Inánná",
			},
			["Almîna"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Almîna",
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Samîsu"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Samîsu",
			},
			["Hornpubmonk"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hornpubmonk",
			},
			["Neferupitou"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Neferupitou",
			},
			["Tyrellan"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tyrellan",
			},
			["Daddysenpai"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Daddysenpai",
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Artèmis"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Artèmis",
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
			["Salanâ"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Salanâ",
			},
			["Qyix"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Qyix",
			},
			["Isery"] = {
				["name"] = "Isery",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["diff"] = 16,
	},
	["233015"] = {
		["hash"] = "233015",
		["type"] = "deaths",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["encounter"] = "Conclave of the Chosen",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Gonblex-Stormrage"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Gonblex-Stormrage",
				["class"] = "DEMONHUNTER",
			},
			["Râân"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Râân",
				["class"] = "DEMONHUNTER",
			},
			["Thunder-Outland"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Thunder-Outland",
				["class"] = "SHAMAN",
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hotarou-Alleria"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Hotarou-Alleria",
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Lokiboy"] = {
				["name"] = "Lokiboy",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Supersunny",
				["overall"] = {
				},
			},
			["Márvino-Magtheridon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Márvino-Magtheridon",
				["class"] = "MAGE",
			},
			["Grigones-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Grigones-Silvermoon",
				["class"] = "PRIEST",
			},
			["Mêphis"] = {
				["name"] = "Mêphis",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chentis"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Chentis",
				["class"] = "MAGE",
			},
			["Artèmis"] = {
				["name"] = "Artèmis",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["name"] = "Narfnarf",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kindralia"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kindralia",
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kirgit",
				["class"] = "PRIEST",
			},
			["Làika"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Làika",
				["class"] = "DEMONHUNTER",
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Rexc-Stormscale"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Rexc-Stormscale",
				["class"] = "HUNTER",
			},
			["Rusell"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Rusell",
				["class"] = "WARLOCK",
			},
			["Bry-Azuremyst"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Bry-Azuremyst",
				["class"] = "WARRIOR",
			},
			["Seyden"] = {
				["name"] = "Seyden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Viste-ZirkeldesCenarius"] = {
				["name"] = "Viste-ZirkeldesCenarius",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Slyre"] = {
				["name"] = "Slyre",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Raineth-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Raineth-Silvermoon",
				["class"] = "DEMONHUNTER",
			},
			["Nayven"] = {
				["name"] = "Nayven",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Borntoteemo-Sylvanas"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Borntoteemo-Sylvanas",
				["class"] = "DRUID",
			},
			["Ventex"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ventex",
				["class"] = "SHAMAN",
			},
			["Schliizîî"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Schliizîî",
				["overall"] = {
				},
			},
			["Chántý"] = {
				["name"] = "Chántý",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["name"] = "Arameh",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Voidhunteer-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Voidhunteer-Silvermoon",
				["class"] = "HUNTER",
			},
			["Grodav-Vol'jin"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Grodav-Vol'jin",
				["class"] = "WARRIOR",
			},
			["Môdox"] = {
				["name"] = "Môdox",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Thelyssa-Ravencrest"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Thelyssa-Ravencrest",
				["class"] = "PRIEST",
			},
			["Overnatural-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Overnatural-Silvermoon",
				["class"] = "DRUID",
			},
			["Julietté"] = {
				["name"] = "Julietté",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["name"] = "Yesiam",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Antistit-Shadowsong"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Antistit-Shadowsong",
				["class"] = "PRIEST",
			},
		},
	},
	["233415"] = {
		["hash"] = "233415",
		["type"] = "deaths",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Mekkatorque",
			["encounter"] = "Mekkatorque",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Daddysenpai",
				["overall"] = {
				},
			},
			["Râân"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Râân",
				["class"] = "DEMONHUNTER",
			},
			["Lilania"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Lilania",
				["overall"] = {
				},
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hotarou-Alleria"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Hotarou-Alleria",
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Ðaisuke",
				["overall"] = {
				},
			},
			["Lokiboy"] = {
				["name"] = "Lokiboy",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Almîna",
				["overall"] = {
				},
			},
			["Supersunny"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Supersunny",
				["overall"] = {
				},
			},
			["Guldàníel"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Guldàníel",
				["overall"] = {
				},
			},
			["Morfeeas-Darksorrow"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Morfeeas-Darksorrow",
				["overall"] = {
				},
			},
			["Tyrellan"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Tyrellan",
				["overall"] = {
				},
			},
			["Chentis"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Chentis",
				["class"] = "MAGE",
			},
			["Shárf-Outland"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Shárf-Outland",
				["overall"] = {
				},
			},
			["Artèmis"] = {
				["name"] = "Artèmis",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["name"] = "Narfnarf",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Laki"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Laki",
				["overall"] = {
				},
			},
			["Xaru"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Xaru",
				["overall"] = {
				},
			},
			["Kirgit"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kirgit",
				["class"] = "PRIEST",
			},
			["Aspern"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Aspern",
				["overall"] = {
				},
			},
			["Làika"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Làika",
				["class"] = "DEMONHUNTER",
			},
			["Verbathius-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Verbathius-Silvermoon",
				["overall"] = {
				},
			},
			["Andromaché"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Andromaché",
				["overall"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Slinki-Ravencrest"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Slinki-Ravencrest",
				["overall"] = {
				},
			},
			["Salanâ"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Salanâ",
				["overall"] = {
				},
			},
			["Metó"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Metó",
				["overall"] = {
				},
			},
			["Rusell"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Rusell",
				["class"] = "WARLOCK",
			},
			["Kalissta"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Kalissta",
				["overall"] = {
				},
			},
			["Schwoop"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Schwoop",
				["overall"] = {
				},
			},
			["Môdox"] = {
				["name"] = "Môdox",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Slyre"] = {
				["name"] = "Slyre",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Apoktalipto-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Apoktalipto-Silvermoon",
				["overall"] = {
				},
			},
			["Nayven"] = {
				["name"] = "Nayven",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Seyden"] = {
				["name"] = "Seyden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Neferupitou"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Neferupitou",
				["overall"] = {
				},
			},
			["Schliizîî"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Schliizîî",
				["overall"] = {
				},
			},
			["Qyix"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Qyix",
				["overall"] = {
				},
			},
			["Arameh"] = {
				["name"] = "Arameh",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hawtystep-Ravencrest"] = {
				["deaths"] = {
				},
				["class"] = "ROGUE",
				["name"] = "Hawtystep-Ravencrest",
				["overall"] = {
				},
			},
			["Aprofis-DieAldor"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Aprofis-DieAldor",
				["overall"] = {
				},
			},
			["Pritamonkas-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Pritamonkas-Silvermoon",
				["overall"] = {
				},
			},
			["Chántý"] = {
				["name"] = "Chántý",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ventex"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ventex",
				["class"] = "SHAMAN",
			},
			["Julietté"] = {
				["name"] = "Julietté",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["name"] = "Yesiam",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Viste-ZirkeldesCenarius"] = {
				["name"] = "Viste-ZirkeldesCenarius",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["233314"] = {
		["hash"] = "233314",
		["type"] = "deaths",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["diff"] = 14,
		["player_db"] = {
			["Charliefk-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Charliefk-Silvermoon",
				["class"] = "PALADIN",
			},
			["Лавкравт-Дракономор"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Лавкравт-Дракономор",
				["class"] = "DEATHKNIGHT",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Champion of the Light",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["diff"] = 14,
			["id"] = 2265,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
	},
	["234216"] = {
		["hash"] = "234216",
		["type"] = "deaths",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 16,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["encounter"] = "Opulence",
			["ej_instance_id"] = 1176,
			["diff"] = 16,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Daddysenpai",
			},
			["Râân"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Râân",
				["class"] = "DEMONHUNTER",
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Härridk",
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ðaisuke",
			},
			["Avaqt"] = {
				["name"] = "Avaqt",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Almîna",
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Hornpubmonk"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hornpubmonk",
			},
			["Mêphis"] = {
				["name"] = "Mêphis",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chentis"] = {
				["name"] = "Chentis",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Viste"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Viste",
				["class"] = "HUNTER",
			},
			["Artèmis"] = {
				["name"] = "Artèmis",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["name"] = "Narfnarf",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kindralia"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kindralia",
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Kirgit",
				["overall"] = {
				},
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alleycut",
			},
			["Rusell"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Rusell",
				["overall"] = {
				},
			},
			["Nelwyn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nelwyn",
			},
			["Môdox"] = {
				["name"] = "Môdox",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Slyre"] = {
				["name"] = "Slyre",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Julietté"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Julietté",
				["class"] = "WARRIOR",
			},
			["Nayven"] = {
				["name"] = "Nayven",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Xaru"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Xaru",
			},
			["Neferupitou"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Neferupitou",
			},
			["Dovomir"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dovomir",
			},
			["Qyix"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Qyix",
			},
			["Arameh"] = {
				["name"] = "Arameh",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tyrellan",
			},
			["Xenadia"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Xenadia",
			},
			["Lokiboy"] = {
				["name"] = "Lokiboy",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chántý"] = {
				["name"] = "Chántý",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Seyden"] = {
				["name"] = "Seyden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Bensolo"] = {
				["name"] = "Bensolo",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["name"] = "Yesiam",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
		},
	},
	["234215"] = {
		["hash"] = "234215",
		["type"] = "deaths",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Opulence",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["diff"] = 15,
			["id"] = 2271,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Isrysa-Ravencrest"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Isrysa-Ravencrest",
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Rusell"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Rusell",
				["class"] = "WARLOCK",
			},
			["Bhaírava"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Bhaírava",
				["class"] = "DRUID",
			},
			["Lokiboy"] = {
				["name"] = "Lokiboy",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Faye-Dalaran"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Faye-Dalaran",
				["class"] = "MAGE",
			},
			["Slyre"] = {
				["name"] = "Slyre",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Keya-Magtheridon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Keya-Magtheridon",
				["class"] = "MAGE",
			},
			["Guldàníel"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Guldàníel",
				["overall"] = {
				},
			},
			["Ragæ-GrimBatol"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ragæ-GrimBatol",
			},
			["Viste-ZirkeldesCenarius"] = {
				["name"] = "Viste-ZirkeldesCenarius",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Janissen-Nagrand"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Janissen-Nagrand",
				["class"] = "PRIEST",
			},
			["Илюфа-Разувий"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Илюфа-Разувий",
				["class"] = "DEMONHUNTER",
			},
			["Arameh"] = {
				["name"] = "Arameh",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Chántý"] = {
				["name"] = "Chántý",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Sefa-Blade'sEdge"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Sefa-Blade'sEdge",
				["class"] = "DEMONHUNTER",
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Artèmis",
				["class"] = "HUNTER",
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Vanadín-Magtheridon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Vanadín-Magtheridon",
				["class"] = "WARLOCK",
			},
			["Narfnarf"] = {
				["name"] = "Narfnarf",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Obídos"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Obídos",
				["class"] = "MAGE",
			},
		},
	},
	["233516"] = {
		["hash"] = "233516",
		["type"] = "deaths",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2272,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "King Rastakhan",
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Daddysenpai",
			},
			["Aspern"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Aspern",
				["overall"] = {
				},
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Nelwyn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nelwyn",
			},
			["Härridk"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Härridk",
				["overall"] = {
				},
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
			["Ðaisuke"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ðaisuke",
			},
			["Yanaizu"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Yanaizu",
				["overall"] = {
				},
			},
			["Inánná"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Inánná",
			},
			["Almîna"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Almîna",
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Samîsu"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Samîsu",
				["overall"] = {
				},
			},
			["Hornpubmonk"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hornpubmonk",
			},
			["Neferupitou"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Neferupitou",
				["overall"] = {
				},
			},
			["Tyrellan"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tyrellan",
			},
			["Andromaché"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Andromaché",
				["overall"] = {
				},
			},
			["Xaru"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Xaru",
			},
			["Alleycut"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alleycut",
			},
			["Artèmis"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Artèmis",
			},
			["Isery"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Isery",
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Qyix"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Qyix",
			},
			["Salanâ"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Salanâ",
			},
		},
		["diff"] = 16,
	},
	["233316"] = {
		["hash"] = "233316",
		["type"] = "deaths",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["player_db"] = {
			["Daddysenpai"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Daddysenpai",
			},
			["Râân"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Râân",
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Yuzurihâ"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Yuzurihâ",
				["overall"] = {
				},
			},
			["Whyalwaysme"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Whyalwaysme",
				["overall"] = {
				},
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Shìnigami"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Shìnigami",
				["overall"] = {
				},
			},
			["Ðaisuke"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Ðaisuke",
				["overall"] = {
				},
			},
			["Avaqt"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Avaqt",
				["overall"] = {
				},
			},
			["Inánná"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Inánná",
				["overall"] = {
				},
			},
			["Almîna"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Almîna",
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Mêphis"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Mêphis",
				["overall"] = {
				},
			},
			["Chentis"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Chentis",
			},
			["Viste"] = {
				["name"] = "Viste",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Artèmis",
				["overall"] = {
				},
			},
			["Narfnarf"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Narfnarf",
				["overall"] = {
				},
			},
			["Aspern"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Aspern",
			},
			["Schifti"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Schifti",
				["overall"] = {
				},
			},
			["Andromaché"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Andromaché",
			},
			["Jinjewel"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Jinjewel",
				["overall"] = {
				},
			},
			["Alleycut"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alleycut",
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
			["Yanaizu"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Yanaizu",
				["overall"] = {
				},
			},
			["Môdox"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Môdox",
				["overall"] = {
				},
			},
			["Khromatian"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Khromatian",
				["overall"] = {
				},
			},
			["Qyix"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Qyix",
			},
			["Slyre"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Slyre",
				["overall"] = {
				},
			},
			["Bensolo"] = {
				["name"] = "Bensolo",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Samîsu"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Samîsu",
				["overall"] = {
				},
			},
			["Härridk"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Härridk",
			},
			["Neferupitou"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Neferupitou",
			},
			["Nayven"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Nayven",
				["overall"] = {
				},
			},
			["Dovomir"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dovomir",
			},
			["Arameh"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Arameh",
				["overall"] = {
				},
			},
			["Salanâ"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Salanâ",
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Lokiboy"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Lokiboy",
				["overall"] = {
				},
			},
			["Chántý"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Chántý",
				["overall"] = {
				},
			},
			["Seyden"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Seyden",
				["overall"] = {
				},
			},
			["Julietté"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Julietté",
				["overall"] = {
				},
			},
			["Yesiam"] = {
				["deaths"] = {
				},
				["class"] = "ROGUE",
				["name"] = "Yesiam",
				["overall"] = {
				},
			},
			["Tyrellan"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tyrellan",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2265,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Champion of the Light",
		},
		["diff"] = 16,
	},
	["234315"] = {
		["hash"] = "234315",
		["type"] = "deaths",
		["name"] = "Lady Jaina Proudmoore",
		["id"] = 2343,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 9,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2281,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Lady Jaina Proudmoore",
			["encounter"] = "Lady Jaina Proudmoore",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Daddysenpai",
				["overall"] = {
				},
			},
			["Laki"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Laki",
				["overall"] = {
				},
			},
			["Yuzurihâ"] = {
				["name"] = "Yuzurihâ",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Härridk",
				["overall"] = {
				},
			},
			["Soely"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Soely",
				["overall"] = {
				},
			},
			["Shìnigami"] = {
				["name"] = "Shìnigami",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Ðaisuke",
				["overall"] = {
				},
			},
			["Yanaizu"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Yanaizu",
				["overall"] = {
				},
			},
			["Inánná"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Inánná",
				["class"] = "PALADIN",
			},
			["Almîna"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Almîna",
				["overall"] = {
				},
			},
			["Supersunny"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Supersunny",
				["overall"] = {
				},
			},
			["Fudgeless-Silvermoon"] = {
				["name"] = "Fudgeless-Silvermoon",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Mêphis"] = {
				["name"] = "Mêphis",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Viste"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Viste",
				["class"] = "HUNTER",
			},
			["Artèmis"] = {
				["name"] = "Artèmis",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Narfnarf",
				["class"] = "HUNTER",
			},
			["Lyoli"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Lyoli",
				["class"] = "PALADIN",
			},
			["Aspern"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Aspern",
				["overall"] = {
				},
			},
			["Schifti"] = {
				["name"] = "Schifti",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Andromaché"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Andromaché",
				["overall"] = {
				},
			},
			["Jinjewel"] = {
				["name"] = "Jinjewel",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Alleycut",
				["overall"] = {
				},
			},
			["Seyden"] = {
				["name"] = "Seyden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["name"] = "Khromatian",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Nayven"] = {
				["name"] = "Nayven",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Schwoop"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Schwoop",
				["overall"] = {
				},
			},
			["Salanâ"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Salanâ",
				["overall"] = {
				},
			},
			["Schliizîî"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Schliizîî",
				["overall"] = {
				},
			},
			["Môdox"] = {
				["name"] = "Môdox",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Arameh",
				["class"] = "SHAMAN",
			},
			["Lokiboy"] = {
				["name"] = "Lokiboy",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Qyix"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Qyix",
				["overall"] = {
				},
			},
			["Guldàníel"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Guldàníel",
				["overall"] = {
				},
			},
			["Chántý"] = {
				["name"] = "Chántý",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Tyrellan",
				["overall"] = {
				},
			},
			["Julietté"] = {
				["name"] = "Julietté",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["name"] = "Yesiam",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Coffinlove",
				["overall"] = {
				},
			},
		},
	},
	["233715"] = {
		["hash"] = "233715",
		["type"] = "deaths",
		["name"] = "Stormwall Blockade",
		["id"] = 2337,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 8,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2280,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Stormwall Blockade",
			["diff"] = 15,
			["ej_instance_id"] = 1176,
			["encounter"] = "Stormwall Blockade",
		},
		["player_db"] = {
			["Schifti"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Schifti",
			},
			["Andromaché"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Andromaché",
				["overall"] = {
				},
			},
			["Jinjewel"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Jinjewel",
			},
			["Alleycut"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Alleycut",
				["overall"] = {
				},
			},
			["Shìnigami"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Shìnigami",
			},
			["Lokiboy"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Lokiboy",
			},
			["Inánná"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Inánná",
			},
			["Khromatian"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Khromatian",
			},
			["Nayven"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nayven",
			},
			["Salanâ"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Salanâ",
				["overall"] = {
				},
			},
			["Schliizîî"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Schliizîî",
				["overall"] = {
				},
			},
			["Mêphis"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Mêphis",
			},
			["Arameh"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Arameh",
			},
			["Yesiam"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Yesiam",
			},
			["Tyrellan"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Tyrellan",
				["overall"] = {
				},
			},
			["Wystra"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Wystra",
				["overall"] = {
				},
			},
			["Chántý"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Chántý",
			},
			["Guldàníel"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Guldàníel",
				["overall"] = {
				},
			},
			["Yuzurihâ"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Yuzurihâ",
			},
			["Narfnarf"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Narfnarf",
			},
			["Môdox"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Môdox",
			},
		},
		["diff"] = 15,
	},
	["234314"] = {
		["hash"] = "234314",
		["type"] = "deaths",
		["name"] = "Lady Jaina Proudmoore",
		["id"] = 2343,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 9,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2281,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Lady Jaina Proudmoore",
			["diff"] = 14,
			["ej_instance_id"] = 1176,
			["encounter"] = "Lady Jaina Proudmoore",
		},
		["player_db"] = {
			["Кракапузик-ВечнаяПесня"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Кракапузик-ВечнаяПесня",
				["overall"] = {
				},
			},
			["Cenny-Blackmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Cenny-Blackmoore",
				["class"] = "HUNTER",
			},
			["Эльвенель-Гордунни"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Эльвенель-Гордунни",
				["overall"] = {
				},
			},
			["Zandak-Hyjal"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Zandak-Hyjal",
			},
			["Shaj-Arygos"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Shaj-Arygos",
				["class"] = "WARLOCK",
			},
			["Geekasaurus-AzjolNerub"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Geekasaurus-AzjolNerub",
			},
			["Inánná"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Inánná",
				["class"] = "PALADIN",
			},
			["Leonidás-Anachronos"] = {
				["name"] = "Leonidás-Anachronos",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Shortynice"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Shortynice",
				["class"] = "WARRIOR",
			},
			["Feralla-Ravencrest"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Feralla-Ravencrest",
				["class"] = "DRUID",
			},
			["Shandaries-Aman'thul"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Shandaries-Aman'thul",
				["class"] = "MONK",
			},
			["Phenominah-Alleria"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Phenominah-Alleria",
				["class"] = "DEMONHUNTER",
			},
			["Fudgeytwo-SteamwheedleCartel"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Fudgeytwo-SteamwheedleCartel",
				["class"] = "MONK",
			},
			["Mischtorius-Blackmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Mischtorius-Blackmoore",
				["class"] = "WARLOCK",
			},
			["Amriah"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Amriah",
			},
			["Wojtasas-BurningLegion"] = {
				["name"] = "Wojtasas-BurningLegion",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Whitepearl-Aggramar"] = {
				["name"] = "Whitepearl-Aggramar",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Artega-Medivh"] = {
				["name"] = "Artega-Medivh",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Imtammala-EarthenRing"] = {
				["name"] = "Imtammala-EarthenRing",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Berberechô-DunModr"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Berberechô-DunModr",
				["overall"] = {
				},
			},
			["Trün-Ysera"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Trün-Ysera",
				["class"] = "MONK",
			},
			["Gabbita-DunModr"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Gabbita-DunModr",
			},
			["Grixxina"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Grixxina",
				["class"] = "PRIEST",
			},
			["Vulpinia-ChamberofAspects"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Vulpinia-ChamberofAspects",
				["class"] = "DRUID",
			},
			["Насфиратуу-ВечнаяПесня"] = {
				["name"] = "Насфиратуу-ВечнаяПесня",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Zhandruna-Ragnaros"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Zhandruna-Ragnaros",
				["class"] = "WARLOCK",
			},
			["Blackangelww"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Blackangelww",
				["class"] = "MAGE",
			},
			["Kerohun-Ragnaros"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kerohun-Ragnaros",
				["class"] = "HUNTER",
			},
			["Zhari-Drak'thul"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Zhari-Drak'thul",
			},
			["Kazahr-Hyjal"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kazahr-Hyjal",
				["class"] = "DEATHKNIGHT",
			},
			["Privian-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Privian-Silvermoon",
				["class"] = "DRUID",
			},
			["Hellslider-Aegwynn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Hellslider-Aegwynn",
				["class"] = "PRIEST",
			},
			["Mäkiverem-Ragnaros"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Mäkiverem-Ragnaros",
				["class"] = "MONK",
			},
			["Escaldris-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Escaldris-Silvermoon",
				["class"] = "ROGUE",
			},
			["Stormdraka-Alonsus"] = {
				["name"] = "Stormdraka-Alonsus",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Devilmonalei-Gilneas"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Devilmonalei-Gilneas",
				["class"] = "PALADIN",
			},
			["You-Ravenholdt"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "You-Ravenholdt",
				["class"] = "WARRIOR",
			},
			["Greydemon-ArgentDawn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Greydemon-ArgentDawn",
				["class"] = "DEMONHUNTER",
			},
			["Aewyla-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Aewyla-Silvermoon",
				["overall"] = {
				},
			},
			["Ferow-ArgentDawn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ferow-ArgentDawn",
				["class"] = "DRUID",
			},
			["Maxìma"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Maxìma",
				["class"] = "HUNTER",
			},
			["Emywy-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Emywy-Silvermoon",
				["overall"] = {
				},
			},
			["Tarrow-Blackmoore"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Tarrow-Blackmoore",
				["class"] = "DEMONHUNTER",
			},
			["Флуме-Гордунни"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Флуме-Гордунни",
				["overall"] = {
				},
			},
			["Elrend-Dalaran"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Elrend-Dalaran",
				["class"] = "MONK",
			},
			["Lunellach-KulTiras"] = {
				["name"] = "Lunellach-KulTiras",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Herrox-Anachronos"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Herrox-Anachronos",
				["class"] = "PALADIN",
			},
			["Garnilion-Terenas"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Garnilion-Terenas",
			},
			["Bajejo-Kilrogg"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Bajejo-Kilrogg",
				["class"] = "WARRIOR",
			},
			["Lîquitwalker-Ambossar"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Lîquitwalker-Ambossar",
				["class"] = "PALADIN",
			},
			["Йабики-Гордунни"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Йабики-Гордунни",
				["class"] = "SHAMAN",
			},
			["Inánná-Arthas"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Inánná-Arthas",
			},
			["Prinzluco-Lordaeron"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Prinzluco-Lordaeron",
				["class"] = "PALADIN",
			},
			["Tpaartosz-Ragnaros"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Tpaartosz-Ragnaros",
				["class"] = "PALADIN",
			},
			["Soulleater-Anachronos"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soulleater-Anachronos",
			},
			["Artèmis"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Artèmis",
				["overall"] = {
				},
			},
			["Chérrys-Alleria"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Chérrys-Alleria",
				["class"] = "PRIEST",
			},
			["Jynxxi"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Jynxxi",
				["class"] = "PRIEST",
			},
			["Siggeboi-ChamberofAspects"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Siggeboi-ChamberofAspects",
			},
			["Brisingir-DieewigeWacht"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Brisingir-DieewigeWacht",
				["class"] = "PALADIN",
			},
			["Persylina-Mal'Ganis"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Persylina-Mal'Ganis",
				["class"] = "WARRIOR",
			},
			["Kargana-Nefarian"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Kargana-Nefarian",
				["class"] = "PALADIN",
			},
			["Wornhart-Hyjal"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Wornhart-Hyjal",
				["overall"] = {
				},
			},
			["Brixs-Shadowsong"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Brixs-Shadowsong",
				["class"] = "HUNTER",
			},
			["Wheeler-Nozdormu"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Wheeler-Nozdormu",
				["class"] = "MAGE",
			},
		},
		["diff"] = 14,
	},
	["234214"] = {
		["hash"] = "234214",
		["type"] = "deaths",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 14,
		["player_db"] = {
			["Viridris-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Viridris-Silvermoon",
				["class"] = "WARRIOR",
			},
			["Алануир-Дракономор"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Алануир-Дракономор",
				["class"] = "DEMONHUNTER",
			},
			["Healstation-Khadgar"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Healstation-Khadgar",
				["class"] = "PRIEST",
			},
			["Spamwyn-Turalyon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Spamwyn-Turalyon",
				["class"] = "WARRIOR",
			},
			["Shoq-Khadgar"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Shoq-Khadgar",
				["class"] = "SHAMAN",
			},
			["Ioanaa-Sylvanas"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Ioanaa-Sylvanas",
				["class"] = "PALADIN",
			},
			["Nekrowman-ChamberofAspects"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Nekrowman-ChamberofAspects",
				["class"] = "DEMONHUNTER",
			},
			["Icrapmypánts-Silvermoon"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Icrapmypánts-Silvermoon",
				["class"] = "WARLOCK",
			},
			["Artèmis"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Artèmis",
				["class"] = "HUNTER",
			},
			["Saracor-ArgentDawn"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Saracor-ArgentDawn",
				["class"] = "WARRIOR",
			},
			["Джигурдинья-Голдринн"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Джигурдинья-Голдринн",
				["class"] = "MONK",
			},
			["Бадсаа-Дракономор"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Бадсаа-Дракономор",
				["class"] = "DRUID",
			},
			["Импозантная-Дракономор"] = {
				["overall"] = {
				},
				["deaths"] = {
				},
				["name"] = "Импозантная-Дракономор",
				["class"] = "PRIEST",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["encounter"] = "Opulence",
			["ej_instance_id"] = 1176,
			["diff"] = 14,
		},
	},
}
DeathGraphsDBEndurance = {
	["233515"] = {
		["hash"] = "233515",
		["type"] = "endurance",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2272,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["encounter"] = "King Rastakhan",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Ariaelth-BurningLegion"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						6, -- [1]
						203.853000000003, -- [2]
						"", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Antistit-Shadowsong"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Lilania"] = {
				["encounters"] = 2,
				["points"] = 170,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						181.766000000003, -- [2]
						"Caress of Death |cFFFF333318,080|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						188.025000000009, -- [2]
						"Scorching Detonation |cFFFF333330,929|r", -- [3]
					}, -- [2]
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 8,
				["points"] = 780,
				["deaths"] = {
					{
						3, -- [1]
						193.048000000068, -- [2]
						"Caress of Death |cFFFF333337,301|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						193.103000000003, -- [2]
						"Dread Reaping (DoT) |cFFFF333327,596|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Soely"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						186.464000000007, -- [2]
						"Dread Reaping (DoT) |cFFFF333348,164|r", -- [3]
					}, -- [1]
				},
			},
			["Hotarou-Alleria"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Viste-ZirkeldesCenarius"] = {
				["encounters"] = 3,
				["points"] = 280,
				["deaths"] = {
					{
						1, -- [1]
						120.793999999994, -- [2]
						"Plague of Fire |cFFFF333323,888|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						220.940999999992, -- [2]
						"Deathly Withering |cFFFF333322,280|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Ragæ-GrimBatol"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						6, -- [1]
						203.768999999971, -- [2]
						"Dread Reaping (DoT) |cFFFF333350,926|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Nakkor-Medivh"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Guldàníel"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Sukuo-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Kmii"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Artèmis"] = {
				["encounters"] = 11,
				["points"] = 1100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Larnoon-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Ailbert-Zuluhed"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Aspern"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Schifti"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Jinjewel"] = {
				["encounters"] = 8,
				["points"] = 790,
				["deaths"] = {
					{
						1, -- [1]
						202.929000000004, -- [2]
						"Bwonsamdi's Wrath |cFFFF333370,081|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Alleycut"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Seyden"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						2, -- [1]
						223.552999999956, -- [2]
						"Melee |cFFFF333352,696|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Slyre"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						120.793999999994, -- [2]
						"Plague of Fire |cFFFF333336,587|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Kimirchan-DefiasBrotherhood"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Nayven"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["encounters"] = 8,
				["points"] = 780,
				["deaths"] = {
					{
						1, -- [1]
						120.907999999938, -- [2]
						"Plague of Fire |cFFFF333326,620|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						226.128999999957, -- [2]
						"Withering Burst |cFFFF333313,204|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Chántý"] = {
				["encounters"] = 8,
				["points"] = 770,
				["deaths"] = {
					{
						2, -- [1]
						225.996999999974, -- [2]
						"Melee |cFFFF333387,236|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						190.756999999983, -- [2]
						"Bwonsamdi's Wrath |cFFFF333364,468|r", -- [3]
					}, -- [2]
					{
						3, -- [1]
						224.407000000007, -- [2]
						"Death's Door |cFFFF3333835|r", -- [3]
					}, -- [3]
				},
				["class"] = "DRUID",
			},
			["Ventex"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						57.1149999999907, -- [2]
						"Toad Toxin (DoT) |cFFFF333326,835|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Xaru"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Râân"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Schwoop"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Wystra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Chentis"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Sangoki"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Qyix"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Kindralia"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Andromaché"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Raineth-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Rusell"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						213.858999999997, -- [2]
						"Deathly Withering (DoT) |cFFFF333346,292|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Salanâ"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["encounters"] = 8,
				["points"] = 800,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Khromatian"] = {
				["encounters"] = 8,
				["points"] = 800,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Daddysenpai"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						223.238000000012, -- [2]
						"Dread Reaping (DoT) |cFFFF333349,559|r", -- [3]
					}, -- [1]
				},
			},
			["Làika"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						225.330000000016, -- [2]
						"Withering Burst |cFFFF33336,465|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Darkladyii-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						6, -- [1]
						200.795999999973, -- [2]
						"Scorching Detonation |cFFFF33331,010|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Narfnarf"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						2, -- [1]
						243.126999999862, -- [2]
						"Grave Bolt |cFFFF333322,557|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Petîtefleur-KhazModan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Metó"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Рукарынка-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Mêphis"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						2, -- [1]
						221.121999999974, -- [2]
						"Dread Reaping (DoT) |cFFFF333324,697|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Isrysa-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Hardcorë-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Inánná"] = {
				["encounters"] = 11,
				["points"] = 1060,
				["deaths"] = {
					{
						1, -- [1]
						226.128999999957, -- [2]
						"Withering Burst |cFFFF33339,924|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						214.630999999819, -- [2]
						"Melee |cFFFF333339,884|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						13.554999999993, -- [2]
						"Melee |cFFFF333320,037|r", -- [3]
					}, -- [3]
					{
						2, -- [1]
						191.877000000037, -- [2]
						"Focused Demise |cFFFF333313,689|r", -- [3]
					}, -- [4]
				},
				["class"] = "PALADIN",
			},
			["Lokiboy"] = {
				["encounters"] = 8,
				["points"] = 790,
				["deaths"] = {
					{
						3, -- [1]
						16.4629999999888, -- [2]
						"Melee |cFFFF3333104,921|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Laki"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Vave-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Julietté"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Yesiam"] = {
				["encounters"] = 8,
				["points"] = 790,
				["deaths"] = {
					{
						1, -- [1]
						41.5310000000172, -- [2]
						"Serpent's Breath |cFFFF333310,028|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Slapgodx-Sen'jin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
		},
	},
	["233016"] = {
		["hash"] = "233016",
		["type"] = "endurance",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Conclave of the Chosen",
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Aspern"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "MAGE",
				["deaths"] = {
					{
						2, -- [1]
						222.941999999995, -- [2]
						"Thundering Storm |cFFFF3333101,518|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						342.216, -- [2]
						"Jagged Claws |cFFFF333362,500|r", -- [3]
					}, -- [2]
				},
			},
			["Andromaché"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						3, -- [1]
						84.8470000000016, -- [2]
						"Pa'ku's Wrath |cFFFF333328,946|r", -- [3]
					}, -- [1]
				},
			},
			["Nelwyn"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Soely"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						84.226999999999, -- [2]
						"Pa'ku's Wrath |cFFFF333382,616|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						150.273999999998, -- [2]
						"Pa'ku's Wrath |cFFFF33337,962|r", -- [3]
					}, -- [2]
				},
			},
			["Metó"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Dovomir"] = {
				["encounters"] = 4,
				["points"] = 380,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						81.2830000000031, -- [2]
						"Pa'ku's Wrath |cFFFF333388,523|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						149.227999999996, -- [2]
						"Pa'ku's Wrath |cFFFF333376,902|r", -- [3]
					}, -- [2]
				},
			},
			["Almîna"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						282.285000000004, -- [2]
						"Pa'ku's Wrath |cFFFF333379,663|r", -- [3]
					}, -- [1]
				},
			},
			["Supersunny"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						3, -- [1]
						92.1749999999956, -- [2]
						"Melee |cFFFF333321,439|r", -- [3]
					}, -- [1]
				},
			},
			["Samîsu"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "MONK",
				["deaths"] = {
					{
						5, -- [1]
						295.919000000002, -- [2]
						"Jagged Claws |cFFFF3333108,402|r", -- [3]
					}, -- [1]
				},
			},
			["Neferupitou"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						4, -- [1]
						82.0489999999991, -- [2]
						"Pa'ku's Wrath |cFFFF333354,676|r", -- [3]
					}, -- [1]
				},
			},
			["Tyrellan"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						85.5729999999967, -- [2]
						"Krag'wa's Wrath |cFFFF3333107,182|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						338.637000000002, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33337,250|r", -- [3]
					}, -- [2]
				},
			},
			["Kalissta"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Isery"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Xaru"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Laki"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Salanâ"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						295.910999999993, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33337,030|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						84.7939999999944, -- [2]
						"Pa'ku's Wrath |cFFFF333389,828|r", -- [3]
					}, -- [2]
				},
			},
			["Qyix"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
		},
		["diff"] = 16,
	},
	["233714"] = {
		["hash"] = "233714",
		["type"] = "endurance",
		["name"] = "Stormwall Blockade",
		["id"] = 2337,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 8,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2280,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Stormwall Blockade",
			["diff"] = 14,
			["ej_instance_id"] = 1176,
			["encounter"] = "Stormwall Blockade",
		},
		["player_db"] = {
			["Unholyed-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						252.917999999998, -- [2]
						"Freezing Tidepool |cFFFF333315,347|r", -- [3]
					}, -- [1]
				},
			},
			["Akaflacko-Blackrock"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Cheesycrust-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Kalaratrii-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Qookie-Blackmoore"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "MAGE",
				["deaths"] = {
					{
						2, -- [1]
						354.324999999997, -- [2]
						"Freezing Tidepool (DoT) |cFFFF333325,688|r", -- [3]
					}, -- [1]
				},
			},
			["Wildemaus-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						245.559999999998, -- [2]
						"Freezing Tidepool |cFFFF333332,286|r", -- [3]
					}, -- [1]
				},
			},
			["Lexini-Blackhand"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Demoniq"] = {
				["encounters"] = 6,
				["points"] = 560,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						163.737000000001, -- [2]
						"Sea Swell |cFFFF333324,870|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						332.563999999999, -- [2]
						"Roiling Tides (DoT) |cFFFF333321,893|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						228.617000000006, -- [2]
						"Roiling Tides (DoT) |cFFFF333350,719|r", -- [3]
					}, -- [3]
				},
			},
			["Haptix-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Alynja-Blackmoore"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "ROGUE",
				["deaths"] = {
					{
						3, -- [1]
						327.438000000002, -- [2]
						"Roiling Tides (DoT) |cFFFF333361,233|r", -- [3]
					}, -- [1]
				},
			},
			["Vergo-Khaz'goroth"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						4, -- [1]
						206.246000000006, -- [2]
						"Sea Swell |cFFFF333337,091|r", -- [3]
					}, -- [1]
				},
			},
			["Ráyna"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						5, -- [1]
						212.825000000004, -- [2]
						"Sea Swell |cFFFF33331,227|r", -- [3]
					}, -- [1]
				},
			},
			["Zettler"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						4, -- [1]
						271.865000000005, -- [2]
						"Sea Swell |cFFFF333320,859|r", -- [3]
					}, -- [1]
				},
			},
			["Bmeíse-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Frêyár-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						221.843000000001, -- [2]
						"Sea Swell |cFFFF333338,116|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						192.122000000003, -- [2]
						"Sea Swell |cFFFF333339,204|r", -- [3]
					}, -- [2]
				},
			},
			["Roulin-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "ROGUE",
				["deaths"] = {
					{
						1, -- [1]
						134.364999999998, -- [2]
						"Thunderous Boom |cFFFF333350,296|r", -- [3]
					}, -- [1]
				},
			},
			["Môrrtis-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Ehnie"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						365.271000000001, -- [2]
						"Ire of the Deep |cFFFF3333115,549|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						254.160000000004, -- [2]
						"Sea Swell |cFFFF33339,765|r", -- [3]
					}, -- [2]
				},
			},
			["Emyniâ-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Acnosa-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Mzai-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
		},
		["diff"] = 14,
	},
	["233315"] = {
		["hash"] = "233315",
		["type"] = "endurance",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2265,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["encounter"] = "Champion of the Light",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 7,
				["points"] = 690,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						82.8110000000015, -- [2]
						"Sacred Blade (DoT) |cFFFF333397,278|r", -- [3]
					}, -- [1]
				},
			},
			["Aethalia-Silvermoon"] = {
				["encounters"] = 13,
				["points"] = 1300,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Singus-ChamberofAspects"] = {
				["encounters"] = 13,
				["points"] = 1290,
				["deaths"] = {
					{
						3, -- [1]
						72.4889999999432, -- [2]
						"Beam (DoT) |cFFFF333367,412|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Arenia-TheMaelstrom"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Lilania"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						31.8740000000107, -- [2]
						"Wave of Light (DoT) |cFFFF333358,376|r", -- [3]
					}, -- [1]
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 9,
				["points"] = 880,
				["deaths"] = {
					{
						1, -- [1]
						153.115999999922, -- [2]
						"Flash |cFFFF33334,870|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						113.271999999997, -- [2]
						"Environment (Falling) |cFFFF3333238,183|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Soely"] = {
				["encounters"] = 8,
				["points"] = 770,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						33.9799999999959, -- [2]
						"Environment (Falling) |cFFFF3333248,640|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						36.2989999999991, -- [2]
						"Beam (DoT) |cFFFF333347,784|r", -- [3]
					}, -- [2]
				},
			},
			["Hotarou-Alleria"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["encounters"] = 6,
				["points"] = 600,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 7,
				["points"] = 690,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						79.3360000000103, -- [2]
						"Melee |cFFFF333368,772|r", -- [3]
					}, -- [1]
				},
			},
			["Lokiboy"] = {
				["encounters"] = 8,
				["points"] = 800,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Viste-ZirkeldesCenarius"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						118.675999999978, -- [2]
						"Magma Trap |cFFFF3333224,763|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Nakkor-Medivh"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Wahreseele-Nethersturm"] = {
				["encounters"] = 15,
				["points"] = 1480,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						8, -- [1]
						204.581000000006, -- [2]
						"Judgment: Reckoning |cFFFF333320,677|r", -- [3]
					}, -- [1]
					{
						17, -- [1]
						151.967000000062, -- [2]
						"Burnout |cFFFF333310,580|r", -- [3]
					}, -- [2]
				},
			},
			["Guldàníel"] = {
				["encounters"] = 4,
				["points"] = 380,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						33.9410000000062, -- [2]
						"Environment (Falling) |cFFFF3333186,920|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						110.631999999998, -- [2]
						"Deathly Echo |cFFFF3333133,999|r", -- [3]
					}, -- [2]
				},
			},
			["Kamine-Arathor"] = {
				["encounters"] = 13,
				["points"] = 1280,
				["deaths"] = {
					{
						4, -- [1]
						91.8150000000605, -- [2]
						"Beam (DoT) |cFFFF333339,687|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						80.984999999986, -- [2]
						"Beam (DoT) |cFFFF333346,601|r", -- [3]
					}, -- [2]
				},
				["class"] = "PALADIN",
			},
			["Dréámzz-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Kmii"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["encounters"] = 47,
				["points"] = 4690,
				["deaths"] = {
					{
						16, -- [1]
						56.0210000000661, -- [2]
						"Unleashed Ember |cFFFF333325,981|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Ristaâ"] = {
				["encounters"] = 15,
				["points"] = 1470,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						11, -- [1]
						37.5829999999842, -- [2]
						"Environment (Falling) |cFFFF3333221,091|r", -- [3]
					}, -- [1]
					{
						13, -- [1]
						157.622999999905, -- [2]
						"Environment (Falling) |cFFFF3333243,200|r", -- [3]
					}, -- [2]
					{
						15, -- [1]
						233.108000000007, -- [2]
						"Environment (Falling) |cFFFF3333236,566|r", -- [3]
					}, -- [3]
				},
			},
			["Làika"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Káily"] = {
				["encounters"] = 15,
				["points"] = 1460,
				["class"] = "DRUID",
				["deaths"] = {
					{
						7, -- [1]
						115.60699999996, -- [2]
						"Consecration (DoT) |cFFFF33334,358|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						56.0210000000661, -- [2]
						"Unleashed Ember |cFFFF333329,461|r", -- [3]
					}, -- [2]
					{
						18, -- [1]
						82.2740000000922, -- [2]
						"Environment (Falling) |cFFFF3333204,200|r", -- [3]
					}, -- [3]
					{
						20, -- [1]
						66.2910000000848, -- [2]
						"Unleashed Ember |cFFFF333333,050|r", -- [3]
					}, -- [4]
				},
			},
			["Avoidwyaatt-DefiasBrotherhood"] = {
				["encounters"] = 10,
				["points"] = 1000,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Jinjewel"] = {
				["encounters"] = 6,
				["points"] = 600,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Djano-Blackmoore"] = {
				["encounters"] = 13,
				["points"] = 1300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Salzstange-Wrathbringer"] = {
				["encounters"] = 15,
				["points"] = 1480,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						7, -- [1]
						117.195999999996, -- [2]
						"Melee |cFFFF3333158,587|r", -- [3]
					}, -- [1]
					{
						19, -- [1]
						61.9579999999842, -- [2]
						"Explosion |cFFFF333323,248|r", -- [3]
					}, -- [2]
				},
			},
			["Aruwion-Silvermoon"] = {
				["encounters"] = 13,
				["points"] = 1300,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Kalissta"] = {
				["encounters"] = 7,
				["points"] = 690,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						163.902999999991, -- [2]
						"Death Knell |cFFFF333377,140|r", -- [3]
					}, -- [1]
				},
			},
			["Seyden"] = {
				["encounters"] = 9,
				["points"] = 900,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Telora"] = {
				["encounters"] = 15,
				["points"] = 1500,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Melaesa-ChamberofAspects"] = {
				["encounters"] = 13,
				["points"] = 1290,
				["deaths"] = {
					{
						1, -- [1]
						18.7389999999432, -- [2]
						"Burnout |cFFFF333312,610|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Slyre"] = {
				["encounters"] = 6,
				["points"] = 590,
				["deaths"] = {
					{
						1, -- [1]
						72.1159999999218, -- [2]
						"Environment (Falling) |cFFFF3333236,650|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Nayven"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Neferupitou"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						13, -- [1]
						166.17300000001, -- [2]
						"Death Touched (DoT) |cFFFF33334,162|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Chántý"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						13, -- [1]
						198.050999999978, -- [2]
						"Chill of Death (DoT) |cFFFF333317,524|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Wolfly-Silvermoon"] = {
				["encounters"] = 13,
				["points"] = 1260,
				["deaths"] = {
					{
						1, -- [1]
						72.2359999999171, -- [2]
						"Burnout |cFFFF333346,451|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						98.9749999999767, -- [2]
						"Unleashed Ember |cFFFF333338,669|r", -- [3]
					}, -- [2]
					{
						8, -- [1]
						98.3049999999348, -- [2]
						"Unleashed Ember |cFFFF333334,107|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						98.60699999996, -- [2]
						"Searing Embers (DoT) |cFFFF333311,087|r", -- [3]
					}, -- [4]
				},
				["class"] = "HUNTER",
			},
			["Phenòmena"] = {
				["encounters"] = 15,
				["points"] = 1460,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						3, -- [1]
						77.8000000000466, -- [2]
						"Melee |cFFFF333338,925|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						67.420999999973, -- [2]
						"Sacred Blade (DoT) |cFFFF333346,052|r", -- [3]
					}, -- [2]
					{
						14, -- [1]
						75.9239999999991, -- [2]
						"Fireball |cFFFF333337,718|r", -- [3]
					}, -- [3]
					{
						20, -- [1]
						121.511000000057, -- [2]
						"Rising Flames (DoT) |cFFFF33333,267|r", -- [3]
					}, -- [4]
				},
			},
			["Ventex"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Aspern"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Schifti"] = {
				["encounters"] = 6,
				["points"] = 600,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Petîtefleur-KhazModan"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Holystêve-ChamberofAspects"] = {
				["encounters"] = 13,
				["points"] = 1270,
				["deaths"] = {
					{
						2, -- [1]
						87.2380000000121, -- [2]
						"Crusader Strike |cFFFF333374,556|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						98.9749999999767, -- [2]
						"Unleashed Ember |cFFFF333346,006|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						102.565999999992, -- [2]
						"Rising Flames (DoT) |cFFFF33335,314|r", -- [3]
					}, -- [3]
				},
				["class"] = "PALADIN",
			},
			["Xaru"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Slapgodx-Sen'jin"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Râân"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Moncatzie"] = {
				["encounters"] = 15,
				["points"] = 1500,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Schwoop"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Elîn-DunModr"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Mupsy"] = {
				["encounters"] = 15,
				["points"] = 1490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						20, -- [1]
						244.389000000083, -- [2]
						"Environment (Falling) |cFFFF3333203,360|r", -- [3]
					}, -- [1]
				},
			},
			["Ariaelth-BurningLegion"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Bartli-Neptulon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Antistit-Shadowsong"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Lockary"] = {
				["encounters"] = 15,
				["points"] = 1490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						7, -- [1]
						161, -- [2]
						"Penance |cFFFF333338,216|r", -- [3]
					}, -- [1]
				},
			},
			["Lyrasiella"] = {
				["encounters"] = 15,
				["points"] = 1500,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Norå-Nagrand"] = {
				["encounters"] = 13,
				["points"] = 1300,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Almîna"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Salanâ"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Piffpâff"] = {
				["encounters"] = 15,
				["points"] = 1470,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						11, -- [1]
						65.6539999999805, -- [2]
						"Beam (DoT) |cFFFF333329,605|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						35.8909999999451, -- [2]
						"Environment (Falling) |cFFFF3333138,874|r", -- [3]
					}, -- [2]
					{
						14, -- [1]
						63.9629999999888, -- [2]
						"Burnout |cFFFF333313,762|r", -- [3]
					}, -- [3]
				},
			},
			["Alleycut"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Thalee-Shadowsong"] = {
				["encounters"] = 13,
				["points"] = 1290,
				["deaths"] = {
					{
						2, -- [1]
						82.4070000000065, -- [2]
						"Wave of Light (DoT) |cFFFF333323,541|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Tyrellan"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Chentis"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Qyix"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Darkladyii-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Isrysa-Ravencrest"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Sangoki"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Avasera-Silvermoon"] = {
				["encounters"] = 13,
				["points"] = 1260,
				["deaths"] = {
					{
						1, -- [1]
						102.05700000003, -- [2]
						"Judgment: Reckoning |cFFFF333348,248|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						102.06799999997, -- [2]
						"Wave of Light (DoT) |cFFFF333333,589|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						99.109999999986, -- [2]
						"Burnout |cFFFF33339,939|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						75.6720000000205, -- [2]
						"Beam (DoT) |cFFFF333368,039|r", -- [3]
					}, -- [4]
				},
				["class"] = "SHAMAN",
			},
			["Narfnarf"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Khromatian"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						1, -- [1]
						195.346999999834, -- [2]
						"Ferocious Roar |cFFFF333316,634|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Kindralia"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Bexy"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Shanxi-Aszune"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						3, -- [1]
						186.354999999981, -- [2]
						"Melee |cFFFF333387,547|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Zayross-Quel'Thalas"] = {
				["encounters"] = 13,
				["points"] = 1300,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Andromaché"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Tempole"] = {
				["encounters"] = 14,
				["points"] = 1310,
				["deaths"] = {
					{
						1, -- [1]
						42.5069999999832, -- [2]
						"Retribution Wave |cFFFF33332,481|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						94.6999999999534, -- [2]
						"Melee |cFFFF333385,627|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						49.4629999999888, -- [2]
						"Melee |cFFFF333319,237|r", -- [3]
					}, -- [3]
					{
						3, -- [1]
						76.3919999999926, -- [2]
						"Melee |cFFFF333317,930|r", -- [3]
					}, -- [4]
					{
						4, -- [1]
						69.6760000000941, -- [2]
						"Melee |cFFFF333315,082|r", -- [3]
					}, -- [5]
					{
						6, -- [1]
						108.376000000048, -- [2]
						"Multi-Sided Strike |cFFFF333340,928|r", -- [3]
					}, -- [6]
					{
						8, -- [1]
						71.7430000000168, -- [2]
						"Beam (DoT) |cFFFF333328,696|r", -- [3]
					}, -- [7]
					{
						9, -- [1]
						73.0620000000345, -- [2]
						"Melee |cFFFF333320,034|r", -- [3]
					}, -- [8]
				},
				["class"] = "WARRIOR",
			},
			["Golithor"] = {
				["encounters"] = 15,
				["points"] = 1460,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						5, -- [1]
						175.927999999956, -- [2]
						"Sacred Blade (DoT) |cFFFF333379,500|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						58.2929999999469, -- [2]
						"Melee |cFFFF333397,910|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						107.970999999903, -- [2]
						"Melee |cFFFF33332|r", -- [3]
					}, -- [3]
					{
						17, -- [1]
						103.95000000007, -- [2]
						"Melee |cFFFF333323,521|r", -- [3]
					}, -- [4]
				},
			},
			["Rusell"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Raineth-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Metó"] = {
				["encounters"] = 7,
				["points"] = 690,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						4, -- [1]
						117.606, -- [2]
						"Death Knell |cFFFF333341,939|r", -- [3]
					}, -- [1]
				},
			},
			["Shivas-Malorne"] = {
				["encounters"] = 13,
				["points"] = 1260,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						79.3209999999963, -- [2]
						"Melee |cFFFF3333132,278|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						179.547999999952, -- [2]
						"Wave of Light (DoT) |cFFFF333319,666|r", -- [3]
					}, -- [2]
					{
						11, -- [1]
						64.7099999999628, -- [2]
						"Beam (DoT) |cFFFF333332,163|r", -- [3]
					}, -- [3]
					{
						17, -- [1]
						84.2220000000671, -- [2]
						"Beam (DoT) |cFFFF333344,817|r", -- [3]
					}, -- [4]
				},
			},
			["Chaotic-Shadowsong"] = {
				["encounters"] = 12,
				["points"] = 1190,
				["deaths"] = {
					{
						5, -- [1]
						98.7519999999786, -- [2]
						"Searing Embers (DoT) |cFFFF333310,834|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Môdox"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						1, -- [1]
						180.72100000002, -- [2]
						"Bestial Smash |cFFFF3333317,614|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Wellorie-Aegwynn"] = {
				["encounters"] = 15,
				["points"] = 1460,
				["class"] = "MONK",
				["deaths"] = {
					{
						12, -- [1]
						65.7679999999236, -- [2]
						"Pounce |cFFFF333331,633|r", -- [3]
					}, -- [1]
					{
						15, -- [1]
						173.704999999958, -- [2]
						"Magma Trap |cFFFF333373,640|r", -- [3]
					}, -- [2]
					{
						16, -- [1]
						64.2870000000112, -- [2]
						"Pounce |cFFFF333319,980|r", -- [3]
					}, -- [3]
					{
						18, -- [1]
						36.2140000000363, -- [2]
						"Environment (Falling) |cFFFF3333183,140|r", -- [3]
					}, -- [4]
				},
			},
			["Рукарынка-Гордунни"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Angraem-DarkmoonFaire"] = {
				["encounters"] = 13,
				["points"] = 1270,
				["deaths"] = {
					{
						3, -- [1]
						128.783999999985, -- [2]
						"Wave of Light (DoT) |cFFFF333330,546|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						76.4220000000205, -- [2]
						"Burnout |cFFFF333344,449|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						36.109999999986, -- [2]
						"Environment (Falling) |cFFFF3333219,240|r", -- [3]
					}, -- [3]
				},
				["class"] = "WARLOCK",
			},
			["Tuathla"] = {
				["encounters"] = 15,
				["points"] = 1480,
				["class"] = "DRUID",
				["deaths"] = {
					{
						5, -- [1]
						35.1199999999953, -- [2]
						"Melee |cFFFF3333185,912|r", -- [3]
					}, -- [1]
					{
						15, -- [1]
						187.791999999899, -- [2]
						"Environment (Falling) |cFFFF3333254,100|r", -- [3]
					}, -- [2]
				},
			},
			["Mêphis"] = {
				["encounters"] = 6,
				["points"] = 600,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Devastatia-Aszune"] = {
				["encounters"] = 14,
				["points"] = 1340,
				["deaths"] = {
					{
						6, -- [1]
						102.44299999997, -- [2]
						"Beam (DoT) |cFFFF333358,946|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						105.410999999964, -- [2]
						"Environment (Falling) |cFFFF3333182,060|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						317.207000000053, -- [2]
						"Environment (Falling) |cFFFF3333165,520|r", -- [3]
					}, -- [3]
					{
						9, -- [1]
						36.2589999999618, -- [2]
						"Environment (Falling) |cFFFF3333182,060|r", -- [3]
					}, -- [4]
					{
						10, -- [1]
						34.9710000000196, -- [2]
						"Environment (Falling) |cFFFF3333182,060|r", -- [3]
					}, -- [5]
				},
				["class"] = "SHAMAN",
			},
			["Wystra"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Laki"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Kaberekon"] = {
				["encounters"] = 15,
				["points"] = 1460,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						8, -- [1]
						84.3570000000764, -- [2]
						"Melee |cFFFF3333140,460|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						148.375999999931, -- [2]
						"Environment (Falling) |cFFFF3333206,700|r", -- [3]
					}, -- [2]
					{
						18, -- [1]
						82.2740000000922, -- [2]
						"Environment (Falling) |cFFFF3333206,700|r", -- [3]
					}, -- [3]
					{
						19, -- [1]
						82.6790000000037, -- [2]
						"Environment (Falling) |cFFFF3333206,700|r", -- [3]
					}, -- [4]
				},
			},
			["Lindórië-Azuremyst"] = {
				["encounters"] = 13,
				["points"] = 1260,
				["deaths"] = {
					{
						4, -- [1]
						99.5230000000447, -- [2]
						"Unleashed Ember |cFFFF333324,331|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						98.8340000000317, -- [2]
						"Beam (DoT) |cFFFF333324,216|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						102.712999999989, -- [2]
						"Burnout |cFFFF333341,930|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						196.28899999999, -- [2]
						"Magma Trap |cFFFF333380,779|r", -- [3]
					}, -- [4]
				},
				["class"] = "DRUID",
			},
			["Hardcorë-Mal'Ganis"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["encounters"] = 48,
				["points"] = 4720,
				["deaths"] = {
					{
						2, -- [1]
						80.7790000000969, -- [2]
						"Wave of Light (DoT) |cFFFF333320,230|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						18.9370000000345, -- [2]
						"Melee |cFFFF333374,380|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						72.1769999999087, -- [2]
						"Melee |cFFFF3333100,583|r", -- [3]
					}, -- [3]
					{
						14, -- [1]
						59.6210000000428, -- [2]
						"Unleashed Ember |cFFFF333315,574|r", -- [3]
					}, -- [4]
					{
						19, -- [1]
						76.4179999999469, -- [2]
						"Magma Trap |cFFFF333369,139|r", -- [3]
					}, -- [5]
					{
						3, -- [1]
						39.6030000000028, -- [2]
						"Voodoo Blast |cFFFF333346,868|r", -- [3]
					}, -- [6]
					{
						3, -- [1]
						163.767999999996, -- [2]
						"Death Knell |cFFFF333370,676|r", -- [3]
					}, -- [7]
				},
				["class"] = "PALADIN",
			},
			["Sukuo-Ravencrest"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Thelyssa-Ravencrest"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Vave-Blackmoore"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Julietté"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						171.841999999946, -- [2]
						"Death Knell |cFFFF333363,203|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Yesiam"] = {
				["encounters"] = 4,
				["points"] = 380,
				["deaths"] = {
					{
						1, -- [1]
						109.890000000014, -- [2]
						"Deathly Echo |cFFFF3333122,625|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						76.0789999999106, -- [2]
						"Environment (Falling) |cFFFF3333226,600|r", -- [3]
					}, -- [2]
				},
				["class"] = "ROGUE",
			},
			["Ailbert-Zuluhed"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
		},
	},
	["233416"] = {
		["hash"] = "233416",
		["type"] = "endurance",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 6,
			["name"] = "Mekkatorque",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Mekkatorque",
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 73,
				["points"] = 7250,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						14, -- [1]
						78.9259999999777, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333334,046|r", -- [3]
					}, -- [1]
					{
						15, -- [1]
						56.1170000000857, -- [2]
						"Electroshock Strike |cFFFF333326,161|r", -- [3]
					}, -- [2]
					{
						27, -- [1]
						175.531000000075, -- [2]
						"Electroshock Strike |cFFFF333313,900|r", -- [3]
					}, -- [3]
					{
						43, -- [1]
						89.5530000000727, -- [2]
						"Melee |cFFFF333359,358|r", -- [3]
					}, -- [4]
					{
						2, -- [1]
						87.5259999999999, -- [2]
						"Melee |cFFFF3333107,386|r", -- [3]
					}, -- [5]
				},
			},
			["Aspern"] = {
				["encounters"] = 73,
				["points"] = 7260,
				["class"] = "MAGE",
				["deaths"] = {
					{
						12, -- [1]
						41.3449999999721, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33335,659|r", -- [3]
					}, -- [1]
					{
						45, -- [1]
						98.6419999999926, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF3333144,357|r", -- [3]
					}, -- [2]
					{
						50, -- [1]
						82.6979999999749, -- [2]
						"Buster Cannon |cFFFF3333232,947|r", -- [3]
					}, -- [3]
					{
						55, -- [1]
						82.7560000000522, -- [2]
						"Buster Cannon |cFFFF3333232,916|r", -- [3]
					}, -- [4]
				},
			},
			["Laki"] = {
				["encounters"] = 73,
				["points"] = 7190,
				["class"] = "DRUID",
				["deaths"] = {
					{
						7, -- [1]
						17.8179999999702, -- [2]
						"Buster Cannon |cFFFF333318,999|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						90.5340000001015, -- [2]
						"Buster Cannon |cFFFF33331,249|r", -- [3]
					}, -- [2]
					{
						21, -- [1]
						49.1030000000028, -- [2]
						"Buster Cannon |cFFFF3333221,889|r", -- [3]
					}, -- [3]
					{
						26, -- [1]
						68.1389999999665, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333320,151|r", -- [3]
					}, -- [4]
					{
						34, -- [1]
						144.386999999988, -- [2]
						"Crash Down |cFFFF3333238,723|r", -- [3]
					}, -- [5]
					{
						35, -- [1]
						83.4599999999628, -- [2]
						"Spark Volley |cFFFF333321,984|r", -- [3]
					}, -- [6]
					{
						43, -- [1]
						83.8379999999888, -- [2]
						"Buster Cannon |cFFFF333331,062|r", -- [3]
					}, -- [7]
					{
						58, -- [1]
						155.927000000025, -- [2]
						"Buster Cannon |cFFFF333322,408|r", -- [3]
					}, -- [8]
					{
						21, -- [1]
						154.561, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333328,216|r", -- [3]
					}, -- [9]
					{
						23, -- [1]
						45.6859999999997, -- [2]
						"Crash Down |cFFFF3333272,008|r", -- [3]
					}, -- [10]
					{
						24, -- [1]
						82.7340000000004, -- [2]
						"Spark Volley |cFFFF333326,950|r", -- [3]
					}, -- [11]
				},
			},
			["Nelwyn"] = {
				["encounters"] = 73,
				["points"] = 7190,
				["class"] = "DRUID",
				["deaths"] = {
					{
						10, -- [1]
						83.2010000000009, -- [2]
						"Buster Cannon |cFFFF333331,396|r", -- [3]
					}, -- [1]
					{
						30, -- [1]
						109.665000000037, -- [2]
						"Crash Down |cFFFF333331,556|r", -- [3]
					}, -- [2]
					{
						3, -- [1]
						82.5560000000005, -- [2]
						"Buster Cannon |cFFFF3333158,644|r", -- [3]
					}, -- [3]
					{
						9, -- [1]
						45.4090000000006, -- [2]
						"Crash Down |cFFFF3333253,380|r", -- [3]
					}, -- [4]
					{
						10, -- [1]
						49.2179999999999, -- [2]
						"Buster Cannon |cFFFF3333179,760|r", -- [3]
					}, -- [5]
					{
						16, -- [1]
						81.1939999999995, -- [2]
						"Trample |cFFFF3333116,275|r", -- [3]
					}, -- [6]
					{
						21, -- [1]
						154.103000000001, -- [2]
						"Buster Cannon |cFFFF3333220,564|r", -- [3]
					}, -- [7]
					{
						24, -- [1]
						144.214, -- [2]
						"Crash Down |cFFFF3333266,397|r", -- [3]
					}, -- [8]
					{
						26, -- [1]
						81.9840000000004, -- [2]
						"Buster Cannon |cFFFF3333197,738|r", -- [3]
					}, -- [9]
					{
						28, -- [1]
						180.235000000001, -- [2]
						"Buster Cannon |cFFFF3333220,152|r", -- [3]
					}, -- [10]
					{
						30, -- [1]
						117.504999999999, -- [2]
						"Gigavolt Blast |cFFFF333325,187|r", -- [3]
					}, -- [11]
				},
			},
			["Härridk"] = {
				["encounters"] = 73,
				["points"] = 7290,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						37, -- [1]
						99.3769999999786, -- [2]
						"Electroshock Strike |cFFFF333349,568|r", -- [3]
					}, -- [1]
				},
			},
			["Salanâ"] = {
				["encounters"] = 73,
				["points"] = 7110,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						11, -- [1]
						44.9179999999469, -- [2]
						"Spark Volley |cFFFF333330,568|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						45.4589999999153, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333340,108|r", -- [3]
					}, -- [2]
					{
						18, -- [1]
						49.2519999999786, -- [2]
						"Crash Down |cFFFF333367,934|r", -- [3]
					}, -- [3]
					{
						23, -- [1]
						49.6060000000289, -- [2]
						"Buster Cannon |cFFFF3333245,912|r", -- [3]
					}, -- [4]
					{
						34, -- [1]
						82.8469999999506, -- [2]
						"Spark Volley |cFFFF333329,674|r", -- [3]
					}, -- [5]
					{
						36, -- [1]
						61.4570000000531, -- [2]
						"Spark Pulse |cFFFF333377,996|r", -- [3]
					}, -- [6]
					{
						44, -- [1]
						45.3619999999646, -- [2]
						"Spark Volley |cFFFF333330,972|r", -- [3]
					}, -- [7]
					{
						52, -- [1]
						273.295000000042, -- [2]
						"Spark Volley |cFFFF333326,756|r", -- [3]
					}, -- [8]
					{
						58, -- [1]
						45.2880000000587, -- [2]
						"Spark Volley |cFFFF333329,829|r", -- [3]
					}, -- [9]
					{
						1, -- [1]
						43.6469999999999, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333334,295|r", -- [3]
					}, -- [10]
					{
						6, -- [1]
						59.3900000000003, -- [2]
						"Spark Volley |cFFFF333329,462|r", -- [3]
					}, -- [11]
					{
						8, -- [1]
						49.366, -- [2]
						"Spark Shield |cFFFF333344,852|r", -- [3]
					}, -- [12]
					{
						16, -- [1]
						109.360999999999, -- [2]
						"Spark Volley |cFFFF333329,080|r", -- [3]
					}, -- [13]
					{
						18, -- [1]
						148.389999999999, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF3333226,343|r", -- [3]
					}, -- [14]
					{
						22, -- [1]
						154.754999999999, -- [2]
						"Spark Volley |cFFFF333329,920|r", -- [3]
					}, -- [15]
					{
						25, -- [1]
						3.03900000000067, -- [2]
						"Melee |cFFFF333324,438|r", -- [3]
					}, -- [16]
					{
						28, -- [1]
						82.3790000000008, -- [2]
						"Spark Volley |cFFFF333329,222|r", -- [3]
					}, -- [17]
					{
						33, -- [1]
						205.401, -- [2]
						"Spark Volley |cFFFF333330,079|r", -- [3]
					}, -- [18]
					{
						34, -- [1]
						74.0100000000002, -- [2]
						"Spark Volley |cFFFF333330,103|r", -- [3]
					}, -- [19]
				},
			},
			["Metó"] = {
				["encounters"] = 74,
				["points"] = 7240,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						9, -- [1]
						45.3200000000652, -- [2]
						"Crash Down |cFFFF3333101,466|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						93.2430000000168, -- [2]
						"Spark Volley |cFFFF333323,533|r", -- [3]
					}, -- [2]
					{
						19, -- [1]
						144.309000000008, -- [2]
						"Crash Down |cFFFF3333209,018|r", -- [3]
					}, -- [3]
					{
						20, -- [1]
						82.5360000000801, -- [2]
						"Buster Cannon |cFFFF3333170,905|r", -- [3]
					}, -- [4]
					{
						27, -- [1]
						169.456000000006, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333317,865|r", -- [3]
					}, -- [5]
					{
						47, -- [1]
						45.5879999999888, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333336,174|r", -- [3]
					}, -- [6]
					{
						47, -- [1]
						311.577000000048, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333343,478|r", -- [3]
					}, -- [7]
					{
						50, -- [1]
						313.603999999934, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333327,849|r", -- [3]
					}, -- [8]
					{
						56, -- [1]
						45.4810000000289, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333336,424|r", -- [3]
					}, -- [9]
					{
						4, -- [1]
						83.6490000000003, -- [2]
						"Buster Cannon |cFFFF333335,058|r", -- [3]
					}, -- [10]
					{
						6, -- [1]
						43.0219999999999, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333327,519|r", -- [3]
					}, -- [11]
					{
						19, -- [1]
						154.272000000001, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333348,701|r", -- [3]
					}, -- [12]
					{
						25, -- [1]
						15.4510000000009, -- [2]
						"Buster Cannon |cFFFF3333155,530|r", -- [3]
					}, -- [13]
					{
						27, -- [1]
						1.54700000000048, -- [2]
						"Melee |cFFFF333377,682|r", -- [3]
					}, -- [14]
					{
						31, -- [1]
						193.693000000001, -- [2]
						"Crash Down |cFFFF3333329,098|r", -- [3]
					}, -- [15]
				},
			},
			["Ðaisuke"] = {
				["encounters"] = 45,
				["points"] = 4450,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						8, -- [1]
						45.2060000000056, -- [2]
						"Crash Down |cFFFF3333153,482|r", -- [3]
					}, -- [1]
					{
						25, -- [1]
						83.670999999973, -- [2]
						"Buster Cannon |cFFFF333335,428|r", -- [3]
					}, -- [2]
					{
						42, -- [1]
						82.5209999999497, -- [2]
						"Buster Cannon |cFFFF3333179,768|r", -- [3]
					}, -- [3]
					{
						54, -- [1]
						109.724000000046, -- [2]
						"Crash Down |cFFFF3333236,280|r", -- [3]
					}, -- [4]
					{
						57, -- [1]
						168.202000000048, -- [2]
						"Squish |cFFFF3333256,255|r", -- [3]
					}, -- [5]
				},
			},
			["Inánná"] = {
				["encounters"] = 73,
				["points"] = 7180,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						7, -- [1]
						38.8619999999646, -- [2]
						"Gigavolt Blast |cFFFF333321,609|r", -- [3]
					}, -- [1]
					{
						18, -- [1]
						16.890000000014, -- [2]
						"Buster Cannon |cFFFF333312,854|r", -- [3]
					}, -- [2]
					{
						23, -- [1]
						16.704000000027, -- [2]
						"Buster Cannon |cFFFF333326,698|r", -- [3]
					}, -- [3]
					{
						25, -- [1]
						45.3570000000764, -- [2]
						"Crash Down |cFFFF3333133,282|r", -- [3]
					}, -- [4]
					{
						27, -- [1]
						146.46100000001, -- [2]
						"Gigavolt Charge (DoT) |cFFFF33339,534|r", -- [3]
					}, -- [5]
					{
						33, -- [1]
						82.4980000000214, -- [2]
						"Buster Cannon |cFFFF3333222,397|r", -- [3]
					}, -- [6]
					{
						40, -- [1]
						79.2609999999404, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333334,100|r", -- [3]
					}, -- [7]
					{
						3, -- [1]
						49.7930000000006, -- [2]
						"Buster Cannon |cFFFF333310,653|r", -- [3]
					}, -- [8]
					{
						10, -- [1]
						45.3719999999994, -- [2]
						"Crash Down |cFFFF333340,232|r", -- [3]
					}, -- [9]
					{
						16, -- [1]
						109.396999999999, -- [2]
						"Crash Down |cFFFF333361,412|r", -- [3]
					}, -- [10]
					{
						26, -- [1]
						81.8210000000017, -- [2]
						"Spark Volley |cFFFF333314,716|r", -- [3]
					}, -- [11]
					{
						31, -- [1]
						45.2990000000009, -- [2]
						"Crash Down |cFFFF3333138,073|r", -- [3]
					}, -- [12]
				},
			},
			["Almîna"] = {
				["encounters"] = 73,
				["points"] = 7150,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						9, -- [1]
						45.3200000000652, -- [2]
						"Crash Down |cFFFF3333146,716|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						44.9780000000028, -- [2]
						"Crash Down |cFFFF3333129,452|r", -- [3]
					}, -- [2]
					{
						14, -- [1]
						45.6689999999944, -- [2]
						"Crash Down |cFFFF333315,803|r", -- [3]
					}, -- [3]
					{
						15, -- [1]
						45.6020000000717, -- [2]
						"Crash Down |cFFFF3333163,655|r", -- [3]
					}, -- [4]
					{
						22, -- [1]
						45.6259999999311, -- [2]
						"Crash Down |cFFFF3333174,620|r", -- [3]
					}, -- [5]
					{
						31, -- [1]
						45.6490000000922, -- [2]
						"Crash Down |cFFFF3333174,605|r", -- [3]
					}, -- [6]
					{
						32, -- [1]
						45.4599999999628, -- [2]
						"Crash Down |cFFFF3333168,267|r", -- [3]
					}, -- [7]
					{
						36, -- [1]
						45.6710000000894, -- [2]
						"Crash Down |cFFFF333313,503|r", -- [3]
					}, -- [8]
					{
						53, -- [1]
						144.084000000032, -- [2]
						"Crash Down |cFFFF3333240,203|r", -- [3]
					}, -- [9]
					{
						55, -- [1]
						83.9649999999674, -- [2]
						"Buster Cannon |cFFFF33339,982|r", -- [3]
					}, -- [10]
					{
						6, -- [1]
						45.3600000000006, -- [2]
						"Crash Down |cFFFF3333255,036|r", -- [3]
					}, -- [11]
					{
						9, -- [1]
						45.4090000000006, -- [2]
						"Crash Down |cFFFF3333140,763|r", -- [3]
					}, -- [12]
					{
						12, -- [1]
						45.7419999999993, -- [2]
						"Crash Down |cFFFF3333250,580|r", -- [3]
					}, -- [13]
					{
						27, -- [1]
						18.0889999999999, -- [2]
						"Buster Cannon |cFFFF3333971|r", -- [3]
					}, -- [14]
					{
						29, -- [1]
						45.6280000000006, -- [2]
						"Crash Down |cFFFF3333255,036|r", -- [3]
					}, -- [15]
				},
			},
			["Supersunny"] = {
				["encounters"] = 73,
				["points"] = 7240,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						22, -- [1]
						83.4769999999553, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333314,143|r", -- [3]
					}, -- [1]
					{
						32, -- [1]
						153.248999999953, -- [2]
						"Spark Volley |cFFFF333312,411|r", -- [3]
					}, -- [2]
					{
						33, -- [1]
						45.8510000000242, -- [2]
						"Crash Down |cFFFF3333135,989|r", -- [3]
					}, -- [3]
					{
						28, -- [1]
						116.030000000001, -- [2]
						"Buster Cannon |cFFFF33331,227|r", -- [3]
					}, -- [4]
					{
						29, -- [1]
						194.191999999999, -- [2]
						"Crash Down |cFFFF3333187,166|r", -- [3]
					}, -- [5]
					{
						30, -- [1]
						80.771999999999, -- [2]
						"Trample |cFFFF3333125,681|r", -- [3]
					}, -- [6]
				},
			},
			["Samîsu"] = {
				["encounters"] = 47,
				["points"] = 4670,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						12, -- [1]
						83.7649999999994, -- [2]
						"Buster Cannon |cFFFF333320,997|r", -- [3]
					}, -- [1]
					{
						18, -- [1]
						184.902999999998, -- [2]
						"Spark Pulse |cFFFF33333,934|r", -- [3]
					}, -- [2]
					{
						29, -- [1]
						194.191999999999, -- [2]
						"Crash Down |cFFFF3333294,901|r", -- [3]
					}, -- [3]
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 76,
				["points"] = 7380,
				["class"] = "MONK",
				["deaths"] = {
					{
						10, -- [1]
						45.2989999999991, -- [2]
						"Crash Down |cFFFF3333115,803|r", -- [3]
					}, -- [1]
					{
						10, -- [1]
						82.3990000000922, -- [2]
						"Buster Cannon |cFFFF3333227,980|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						50.4549999999581, -- [2]
						"Buster Cannon |cFFFF333340,884|r", -- [3]
					}, -- [3]
					{
						20, -- [1]
						114.55700000003, -- [2]
						"Buster Cannon |cFFFF333341,470|r", -- [3]
					}, -- [4]
					{
						21, -- [1]
						45.576999999932, -- [2]
						"Crash Down |cFFFF3333195,163|r", -- [3]
					}, -- [5]
					{
						29, -- [1]
						45.7680000000401, -- [2]
						"Crash Down |cFFFF3333250,760|r", -- [3]
					}, -- [6]
					{
						30, -- [1]
						109.665000000037, -- [2]
						"Crash Down |cFFFF3333154,387|r", -- [3]
					}, -- [7]
					{
						33, -- [1]
						82.9379999999656, -- [2]
						"Buster Cannon |cFFFF3333227,830|r", -- [3]
					}, -- [8]
					{
						34, -- [1]
						155.005000000005, -- [2]
						"Buster Cannon |cFFFF33334,103|r", -- [3]
					}, -- [9]
					{
						42, -- [1]
						83.1549999999115, -- [2]
						"Buster Cannon |cFFFF333346,381|r", -- [3]
					}, -- [10]
					{
						43, -- [1]
						83.9729999999982, -- [2]
						"Buster Cannon |cFFFF333336,868|r", -- [3]
					}, -- [11]
					{
						44, -- [1]
						82.3930000000401, -- [2]
						"Buster Cannon |cFFFF3333229,273|r", -- [3]
					}, -- [12]
					{
						54, -- [1]
						82.7630000000354, -- [2]
						"Buster Cannon |cFFFF3333238,979|r", -- [3]
					}, -- [13]
					{
						57, -- [1]
						50.9780000000028, -- [2]
						"Buster Cannon |cFFFF333322,201|r", -- [3]
					}, -- [14]
					{
						2, -- [1]
						45.5379999999996, -- [2]
						"Crash Down |cFFFF333357,089|r", -- [3]
					}, -- [15]
					{
						5, -- [1]
						154.478, -- [2]
						"Buster Cannon |cFFFF333323,153|r", -- [3]
					}, -- [16]
					{
						5, -- [1]
						279.948, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333369,875|r", -- [3]
					}, -- [17]
					{
						15, -- [1]
						45.7240000000002, -- [2]
						"Crash Down |cFFFF3333280,790|r", -- [3]
					}, -- [18]
					{
						15, -- [1]
						74.1950000000006, -- [2]
						"Crash Down |cFFFF3333298,258|r", -- [3]
					}, -- [19]
				},
			},
			["Neferupitou"] = {
				["encounters"] = 73,
				["points"] = 7160,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						14, -- [1]
						86.1369999999879, -- [2]
						"Melee |cFFFF3333169,395|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						103.874000000069, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF3333146,742|r", -- [3]
					}, -- [2]
					{
						18, -- [1]
						49.5870000000577, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333320,776|r", -- [3]
					}, -- [3]
					{
						19, -- [1]
						144.309000000008, -- [2]
						"Crash Down |cFFFF3333109,527|r", -- [3]
					}, -- [4]
					{
						32, -- [1]
						160.27099999995, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33338,549|r", -- [3]
					}, -- [5]
					{
						37, -- [1]
						82.5029999999097, -- [2]
						"Buster Cannon |cFFFF3333149,841|r", -- [3]
					}, -- [6]
					{
						39, -- [1]
						83.5840000000317, -- [2]
						"Buster Cannon |cFFFF333324,026|r", -- [3]
					}, -- [7]
					{
						42, -- [1]
						83.4499999999534, -- [2]
						"Buster Cannon |cFFFF333312,361|r", -- [3]
					}, -- [8]
					{
						44, -- [1]
						81.2489999999525, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333319,615|r", -- [3]
					}, -- [9]
					{
						45, -- [1]
						49.4619999999413, -- [2]
						"Buster Cannon |cFFFF3333152,089|r", -- [3]
					}, -- [10]
					{
						47, -- [1]
						79.6280000000261, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333338,059|r", -- [3]
					}, -- [11]
					{
						5, -- [1]
						294.158, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333315,632|r", -- [3]
					}, -- [12]
					{
						20, -- [1]
						151.891, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333374,178|r", -- [3]
					}, -- [13]
					{
						31, -- [1]
						154.238000000001, -- [2]
						"Buster Cannon |cFFFF333325,223|r", -- [3]
					}, -- [14]
				},
			},
			["Tyrellan"] = {
				["encounters"] = 54,
				["points"] = 5330,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						53, -- [1]
						45.5109999999404, -- [2]
						"Crash Down |cFFFF333325,515|r", -- [3]
					}, -- [1]
					{
						55, -- [1]
						82.5509999999777, -- [2]
						"Buster Cannon |cFFFF333375,248|r", -- [3]
					}, -- [2]
					{
						8, -- [1]
						65.5469999999996, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33336,211|r", -- [3]
					}, -- [3]
					{
						9, -- [1]
						113.039000000001, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333345,591|r", -- [3]
					}, -- [4]
					{
						12, -- [1]
						144.304999999999, -- [2]
						"Crash Down |cFFFF333360,351|r", -- [3]
					}, -- [5]
					{
						19, -- [1]
						82.3289999999997, -- [2]
						"Buster Cannon |cFFFF3333205,777|r", -- [3]
					}, -- [6]
					{
						34, -- [1]
						45.6579999999995, -- [2]
						"Crash Down |cFFFF333313,208|r", -- [3]
					}, -- [7]
				},
			},
			["Alleycut"] = {
				["encounters"] = 73,
				["points"] = 7180,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						7, -- [1]
						16.0199999999022, -- [2]
						"Buster Cannon |cFFFF333335,283|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						78.7989999999991, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333319,296|r", -- [3]
					}, -- [2]
					{
						19, -- [1]
						45.5970000000671, -- [2]
						"Crash Down |cFFFF3333244,280|r", -- [3]
					}, -- [3]
					{
						26, -- [1]
						48.7199999999721, -- [2]
						"Buster Cannon |cFFFF3333130,384|r", -- [3]
					}, -- [4]
					{
						39, -- [1]
						99.2410000000382, -- [2]
						"Spark Volley |cFFFF333311,107|r", -- [3]
					}, -- [5]
					{
						56, -- [1]
						45.5540000000037, -- [2]
						"Crash Down |cFFFF333350,862|r", -- [3]
					}, -- [6]
					{
						3, -- [1]
						99.2849999999999, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333343,564|r", -- [3]
					}, -- [7]
					{
						4, -- [1]
						101.494000000001, -- [2]
						"Spark Pulse |cFFFF33338,162|r", -- [3]
					}, -- [8]
					{
						19, -- [1]
						169.784, -- [2]
						"Squish |cFFFF3333250,341|r", -- [3]
					}, -- [9]
					{
						22, -- [1]
						179.624, -- [2]
						"Buster Cannon |cFFFF3333186,896|r", -- [3]
					}, -- [10]
					{
						24, -- [1]
						150.779, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333363,670|r", -- [3]
					}, -- [11]
					{
						27, -- [1]
						26.8010000000013, -- [2]
						"Melee |cFFFF333344,194|r", -- [3]
					}, -- [12]
				},
			},
			["Soely"] = {
				["encounters"] = 74,
				["points"] = 7270,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						8, -- [1]
						45.2060000000056, -- [2]
						"Crash Down |cFFFF3333268,062|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						44.8429999999935, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333360,384|r", -- [3]
					}, -- [2]
					{
						15, -- [1]
						45.6020000000717, -- [2]
						"Crash Down |cFFFF3333268,062|r", -- [3]
					}, -- [3]
					{
						29, -- [1]
						84.9139999999898, -- [2]
						"Buster Cannon |cFFFF333331,473|r", -- [3]
					}, -- [4]
					{
						31, -- [1]
						17.5810000000056, -- [2]
						"Buster Cannon |cFFFF333342,662|r", -- [3]
					}, -- [5]
					{
						31, -- [1]
						45.6490000000922, -- [2]
						"Crash Down |cFFFF333394,332|r", -- [3]
					}, -- [6]
					{
						35, -- [1]
						81.3850000000093, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333396,814|r", -- [3]
					}, -- [7]
					{
						40, -- [1]
						17.1309999999357, -- [2]
						"Buster Cannon |cFFFF333329,552|r", -- [3]
					}, -- [8]
					{
						56, -- [1]
						45.5540000000037, -- [2]
						"Crash Down |cFFFF3333195,466|r", -- [3]
					}, -- [9]
					{
						15, -- [1]
						51.2460000000001, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333354,256|r", -- [3]
					}, -- [10]
					{
						23, -- [1]
						121.293, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333330,118|r", -- [3]
					}, -- [11]
					{
						33, -- [1]
						144.254999999999, -- [2]
						"Crash Down |cFFFF3333261,660|r", -- [3]
					}, -- [12]
				},
			},
			["Artèmis"] = {
				["encounters"] = 73,
				["points"] = 7220,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						8, -- [1]
						45.2060000000056, -- [2]
						"Crash Down |cFFFF3333261,440|r", -- [3]
					}, -- [1]
					{
						13, -- [1]
						49.5779999999795, -- [2]
						"Buster Cannon |cFFFF333361,575|r", -- [3]
					}, -- [2]
					{
						20, -- [1]
						146.418999999994, -- [2]
						"Spark Volley |cFFFF33339,914|r", -- [3]
					}, -- [3]
					{
						41, -- [1]
						93.1419999999926, -- [2]
						"Spark Pulse |cFFFF333372,925|r", -- [3]
					}, -- [4]
					{
						52, -- [1]
						45.6790000000037, -- [2]
						"Crash Down |cFFFF3333266,003|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						43.7029999999995, -- [2]
						"Blast Off |cFFFF3333152,310|r", -- [3]
					}, -- [6]
					{
						18, -- [1]
						153.75, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333331,114|r", -- [3]
					}, -- [7]
					{
						30, -- [1]
						115.686, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF3333151,281|r", -- [3]
					}, -- [8]
				},
			},
			["Xaru"] = {
				["encounters"] = 74,
				["points"] = 7270,
				["class"] = "MAGE",
				["deaths"] = {
					{
						12, -- [1]
						45.3950000000186, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333315,324|r", -- [3]
					}, -- [1]
					{
						22, -- [1]
						82.3439999999246, -- [2]
						"Buster Cannon |cFFFF3333232,634|r", -- [3]
					}, -- [2]
					{
						36, -- [1]
						47.5489999999991, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333331,092|r", -- [3]
					}, -- [3]
					{
						37, -- [1]
						65.3159999999916, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333336,641|r", -- [3]
					}, -- [4]
					{
						39, -- [1]
						99.2410000000382, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333337,852|r", -- [3]
					}, -- [5]
					{
						41, -- [1]
						75.0200000000186, -- [2]
						"Spark Shield |cFFFF333340,579|r", -- [3]
					}, -- [6]
					{
						45, -- [1]
						76.652999999933, -- [2]
						"Spark Shield |cFFFF333346,971|r", -- [3]
					}, -- [7]
					{
						49, -- [1]
						78.4699999999721, -- [2]
						"Spark Shield |cFFFF33337,592|r", -- [3]
					}, -- [8]
					{
						49, -- [1]
						114.076000000001, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333364,967|r", -- [3]
					}, -- [9]
					{
						50, -- [1]
						289.63599999994, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333318,675|r", -- [3]
					}, -- [10]
					{
						20, -- [1]
						17.4130000000005, -- [2]
						"Buster Cannon |cFFFF33339,096|r", -- [3]
					}, -- [11]
					{
						34, -- [1]
						45.6579999999995, -- [2]
						"Crash Down |cFFFF3333306,692|r", -- [3]
					}, -- [12]
				},
			},
			["Kalissta"] = {
				["encounters"] = 73,
				["points"] = 7170,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						25, -- [1]
						45.2460000000428, -- [2]
						"Spark Volley |cFFFF333330,262|r", -- [3]
					}, -- [1]
					{
						29, -- [1]
						83.8769999999786, -- [2]
						"Buster Cannon |cFFFF3333243,220|r", -- [3]
					}, -- [2]
					{
						30, -- [1]
						109.579000000027, -- [2]
						"Spark Pulse |cFFFF333375,188|r", -- [3]
					}, -- [3]
					{
						35, -- [1]
						114.108000000007, -- [2]
						"Crash Down |cFFFF333369,479|r", -- [3]
					}, -- [4]
					{
						41, -- [1]
						82.2249999999767, -- [2]
						"Spark Volley |cFFFF333330,389|r", -- [3]
					}, -- [5]
					{
						49, -- [1]
						144.146999999997, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333339,951|r", -- [3]
					}, -- [6]
					{
						57, -- [1]
						83.4479999999749, -- [2]
						"Buster Cannon |cFFFF3333244,005|r", -- [3]
					}, -- [7]
					{
						1, -- [1]
						17.6109999999999, -- [2]
						"Buster Cannon |cFFFF3333242,630|r", -- [3]
					}, -- [8]
					{
						2, -- [1]
						82.4859999999999, -- [2]
						"Spark Pulse |cFFFF333374,554|r", -- [3]
					}, -- [9]
					{
						8, -- [1]
						49.125, -- [2]
						"Spark Volley |cFFFF333329,796|r", -- [3]
					}, -- [10]
					{
						10, -- [1]
						45.3000000000002, -- [2]
						"Blast Off |cFFFF3333169,515|r", -- [3]
					}, -- [11]
					{
						23, -- [1]
						154.519, -- [2]
						"Buster Cannon |cFFFF3333234,391|r", -- [3]
					}, -- [12]
					{
						25, -- [1]
						10.982, -- [2]
						"Melee |cFFFF3333227,800|r", -- [3]
					}, -- [13]
				},
			},
			["Qyix"] = {
				["encounters"] = 45,
				["points"] = 4410,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						13, -- [1]
						53.5509999999777, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333365,212|r", -- [3]
					}, -- [1]
					{
						21, -- [1]
						57.2939999999944, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333338,470|r", -- [3]
					}, -- [2]
					{
						23, -- [1]
						79.4499999999534, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333326,938|r", -- [3]
					}, -- [3]
					{
						26, -- [1]
						45.5019999999786, -- [2]
						"Crash Down |cFFFF333351,442|r", -- [3]
					}, -- [4]
					{
						40, -- [1]
						81.0569999999134, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333383,210|r", -- [3]
					}, -- [5]
					{
						52, -- [1]
						162.597999999998, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333333,258|r", -- [3]
					}, -- [6]
					{
						53, -- [1]
						144.084000000032, -- [2]
						"Crash Down |cFFFF3333222,491|r", -- [3]
					}, -- [7]
					{
						54, -- [1]
						109.724000000046, -- [2]
						"Crash Down |cFFFF333365,421|r", -- [3]
					}, -- [8]
					{
						58, -- [1]
						84.9200000000419, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333334,030|r", -- [3]
					}, -- [9]
				},
			},
			["Isery"] = {
				["encounters"] = 28,
				["points"] = 2740,
				["deaths"] = {
					{
						4, -- [1]
						93.1490000000004, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333321,841|r", -- [3]
					}, -- [1]
					{
						20, -- [1]
						184.248, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333369,925|r", -- [3]
					}, -- [2]
					{
						21, -- [1]
						152.544, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333354,242|r", -- [3]
					}, -- [3]
					{
						22, -- [1]
						169.044, -- [2]
						"Gigavolt Radiation (DoT) |cFFFF333343,974|r", -- [3]
					}, -- [4]
					{
						26, -- [1]
						82.2150000000002, -- [2]
						"Buster Cannon |cFFFF3333215,763|r", -- [3]
					}, -- [5]
					{
						33, -- [1]
						182.655999999999, -- [2]
						"Spark Pulse |cFFFF333327,922|r", -- [3]
					}, -- [6]
				},
				["class"] = "DRUID",
			},
		},
		["diff"] = 16,
	},
	["233015"] = {
		["hash"] = "233015",
		["type"] = "endurance",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["encounter"] = "Conclave of the Chosen",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Antistit-Shadowsong"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Arenia-TheMaelstrom"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Laki"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 17,
				["points"] = 1640,
				["deaths"] = {
					{
						3, -- [1]
						85.0420000000158, -- [2]
						"Wild Maul |cFFFF33334,144|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						149.762999999919, -- [2]
						"Pa'ku's Wrath |cFFFF333353,224|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						82.4790000000503, -- [2]
						"Pa'ku's Wrath |cFFFF333352,133|r", -- [3]
					}, -- [3]
					{
						3, -- [1]
						224.90399999998, -- [2]
						"Pa'ku's Wrath |cFFFF333312,125|r", -- [3]
					}, -- [4]
					{
						5, -- [1]
						185.156000000017, -- [2]
						"Lacerating Claws |cFFFF33334,954|r", -- [3]
					}, -- [5]
					{
						6, -- [1]
						164.484999999986, -- [2]
						"Jagged Claws |cFFFF333322,326|r", -- [3]
					}, -- [6]
				},
				["class"] = "SHAMAN",
			},
			["Soely"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Hotarou-Alleria"] = {
				["encounters"] = 8,
				["points"] = 770,
				["deaths"] = {
					{
						2, -- [1]
						87.9230000000098, -- [2]
						"Krag'wa's Wrath |cFFFF333365,823|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						238.66399999999, -- [2]
						"Kimbul's Wrath |cFFFF333344,173|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						84.1869999999763, -- [2]
						"Kimbul's Wrath |cFFFF333342,610|r", -- [3]
					}, -- [3]
				},
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						1, -- [1]
						276.378999999957, -- [2]
						"Static Orb |cFFFF333328,525|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Viste-ZirkeldesCenarius"] = {
				["encounters"] = 6,
				["points"] = 590,
				["deaths"] = {
					{
						2, -- [1]
						85.3499999999767, -- [2]
						"Wild Maul |cFFFF33333,400|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Ragæ-GrimBatol"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Nakkor-Medivh"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Guldàníel"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Márvino-Magtheridon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Sukuo-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Kmii"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Artèmis"] = {
				["encounters"] = 21,
				["points"] = 2100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Larnoon-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Ailbert-Zuluhed"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Làika"] = {
				["encounters"] = 8,
				["points"] = 780,
				["deaths"] = {
					{
						1, -- [1]
						229.32699999999, -- [2]
						"Jagged Claws |cFFFF333343,015|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						103.022999999987, -- [2]
						"Jagged Claws |cFFFF333368,613|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEMONHUNTER",
			},
			["Schifti"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						2, -- [1]
						82.6300000001211, -- [2]
						"Krag'wa's Wrath |cFFFF333320,037|r", -- [3]
					}, -- [1]
				},
				["class"] = "MONK",
			},
			["Jinjewel"] = {
				["encounters"] = 11,
				["points"] = 1030,
				["deaths"] = {
					{
						1, -- [1]
						150.951999999932, -- [2]
						"Melee |cFFFF3333122,272|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						229.466000000015, -- [2]
						"Jagged Claws |cFFFF333387,446|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						153.779999999912, -- [2]
						"Melee |cFFFF33336,126|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						168.224999999977, -- [2]
						"Melee |cFFFF3333194,941|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						282.921000000089, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33337,449|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						277.723999999929, -- [2]
						"Cry of the Fallen (DoT) |cFFFF33339,583|r", -- [3]
					}, -- [6]
					{
						7, -- [1]
						84.1089999999968, -- [2]
						"Pa'ku's Wrath |cFFFF333316,232|r", -- [3]
					}, -- [7]
				},
				["class"] = "PRIEST",
			},
			["Alleycut"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Rexc-Stormscale"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Kalissta"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Borntoteemo-Sylvanas"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Seyden"] = {
				["encounters"] = 15,
				["points"] = 1440,
				["deaths"] = {
					{
						2, -- [1]
						211.547000000021, -- [2]
						"Lacerating Claws |cFFFF333324,139|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						286.804999999935, -- [2]
						"Bleeding Wounds (DoT) |cFFFF3333999|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						170.769000000029, -- [2]
						"Melee |cFFFF333321,393|r", -- [3]
					}, -- [3]
					{
						3, -- [1]
						85.5190000000294, -- [2]
						"Wild Maul |cFFFF333318,701|r", -- [3]
					}, -- [4]
					{
						4, -- [1]
						85.4070000000065, -- [2]
						"Krag'wa's Wrath |cFFFF333370,406|r", -- [3]
					}, -- [5]
					{
						6, -- [1]
						232.600999999966, -- [2]
						"Lacerating Claws |cFFFF33334,590|r", -- [3]
					}, -- [6]
				},
				["class"] = "DEMONHUNTER",
			},
			["Aezar-Ragnaros"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Slyre"] = {
				["encounters"] = 6,
				["points"] = 600,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Nayven"] = {
				["encounters"] = 6,
				["points"] = 600,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						104.260000000009, -- [2]
						"Lacerating Claws |cFFFF33332,071|r", -- [3]
					}, -- [1]
				},
			},
			["Arameh"] = {
				["encounters"] = 17,
				["points"] = 1680,
				["deaths"] = {
					{
						3, -- [1]
						84.6809999999823, -- [2]
						"Pa'ku's Wrath |cFFFF333316,529|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						282.256999999983, -- [2]
						"Krag'wa's Wrath |cFFFF333343,918|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Voidhunteer-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Chántý"] = {
				["encounters"] = 17,
				["points"] = 1680,
				["deaths"] = {
					{
						2, -- [1]
						84.9180000000633, -- [2]
						"Pa'ku's Wrath |cFFFF333340,769|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						229.619999999995, -- [2]
						"Jagged Claws |cFFFF333328,111|r", -- [3]
					}, -- [2]
				},
				["class"] = "DRUID",
			},
			["Ventex"] = {
				["encounters"] = 8,
				["points"] = 780,
				["deaths"] = {
					{
						4, -- [1]
						84.7939999999944, -- [2]
						"Wild Maul |cFFFF33338,371|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						82.1170000000275, -- [2]
						"Pa'ku's Wrath |cFFFF333316,647|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Xaru"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Râân"] = {
				["encounters"] = 8,
				["points"] = 800,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Schwoop"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Avaqt"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						3, -- [1]
						106.364999999991, -- [2]
						"Cry of the Fallen (DoT) |cFFFF33333,547|r", -- [3]
					}, -- [1]
				},
			},
			["Grigones-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						1, -- [1]
						89.9839999999385, -- [2]
						"Lacerating Claws |cFFFF333348,415|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						85.0560000000987, -- [2]
						"Pa'ku's Wrath |cFFFF333343,182|r", -- [3]
					}, -- [2]
				},
				["class"] = "PRIEST",
			},
			["Tyrellan"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Grodav-Vol'jin"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Isrysa-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Yesiam"] = {
				["encounters"] = 9,
				["points"] = 900,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Sangoki"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Kirgit"] = {
				["encounters"] = 8,
				["points"] = 800,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Narfnarf"] = {
				["encounters"] = 9,
				["points"] = 890,
				["deaths"] = {
					{
						3, -- [1]
						83.7240000000456, -- [2]
						"Pa'ku's Wrath |cFFFF333339,849|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Overnatural-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						238.266999999993, -- [2]
						"Jagged Claws |cFFFF333367,067|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Kindralia"] = {
				["encounters"] = 7,
				["points"] = 700,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Рукарынка-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Мэидэи-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Qyix"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Lilania"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Andromaché"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Darkladyii-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Mêphis"] = {
				["encounters"] = 9,
				["points"] = 900,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Rusell"] = {
				["encounters"] = 8,
				["points"] = 760,
				["deaths"] = {
					{
						3, -- [1]
						225.896000000008, -- [2]
						"Pa'ku's Wrath |cFFFF333314,691|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						84.7939999999944, -- [2]
						"Wild Maul |cFFFF333320,863|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						167.837, -- [2]
						"Jagged Claws |cFFFF333339,112|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						248.864000000001, -- [2]
						"Cry of the Fallen (DoT) |cFFFF33334,961|r", -- [3]
					}, -- [4]
				},
				["class"] = "WARLOCK",
			},
			["Raineth-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						83.8390000000363, -- [2]
						"Pa'ku's Wrath |cFFFF33339,870|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Metó"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Bry-Azuremyst"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						1, -- [1]
						259.694000000018, -- [2]
						"Cry of the Fallen (DoT) |cFFFF33333,010|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						234.341000000015, -- [2]
						"Jagged Claws |cFFFF333332,232|r", -- [3]
					}, -- [2]
				},
				["class"] = "WARRIOR",
			},
			["Salanâ"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["encounters"] = 17,
				["points"] = 1700,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Khromatian"] = {
				["encounters"] = 17,
				["points"] = 1670,
				["deaths"] = {
					{
						2, -- [1]
						84.9180000000633, -- [2]
						"Pa'ku's Wrath |cFFFF333344,251|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						288.256000000052, -- [2]
						"Jagged Claws |cFFFF333344,029|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						69.4249999999884, -- [2]
						"Melee |cFFFF333342,771|r", -- [3]
					}, -- [3]
				},
				["class"] = "DRUID",
			},
			["Slapgodx-Sen'jin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Holyshot-Sylvanas"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Inánná"] = {
				["encounters"] = 20,
				["points"] = 1940,
				["deaths"] = {
					{
						1, -- [1]
						85.2879999999423, -- [2]
						"Krag'wa's Wrath |cFFFF333371,110|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						232.925000000047, -- [2]
						"Jagged Claws |cFFFF333345,093|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						69.8940000000876, -- [2]
						"Cry of the Fallen (DoT) |cFFFF33336,744|r", -- [3]
					}, -- [3]
					{
						1, -- [1]
						81.4919999998529, -- [2]
						"Pa'ku's Wrath |cFFFF333331,781|r", -- [3]
					}, -- [4]
					{
						3, -- [1]
						284.935000000056, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33334,097|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						139.210000000079, -- [2]
						"Melee |cFFFF3333103,454|r", -- [3]
					}, -- [6]
				},
				["class"] = "PALADIN",
			},
			["Wystra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Víntage-Eonar"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Thunder-Outland"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						285.929000000004, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33333,714|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Lokiboy"] = {
				["encounters"] = 17,
				["points"] = 1690,
				["deaths"] = {
					{
						1, -- [1]
						153.947999999975, -- [2]
						"Lacerating Claws |cFFFF33338,615|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Gonblex-Stormrage"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Aspern"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Hardcorë-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Ariaelth-BurningLegion"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Petîtefleur-KhazModan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Thelyssa-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						150.613000000012, -- [2]
						"Pa'ku's Wrath |cFFFF333369,400|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Vave-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Julietté"] = {
				["encounters"] = 6,
				["points"] = 590,
				["deaths"] = {
					{
						4, -- [1]
						155.765999999945, -- [2]
						"Pa'ku's Wrath |cFFFF333318,080|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Sorannian-Hyjal"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Chentis"] = {
				["encounters"] = 8,
				["points"] = 790,
				["deaths"] = {
					{
						5, -- [1]
						216.239999999991, -- [2]
						"Pa'ku's Wrath |cFFFF33331|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
		},
	},
	["233415"] = {
		["hash"] = "233415",
		["type"] = "endurance",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Mekkatorque",
			["encounter"] = "Mekkatorque",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Tigermaster-Bladefist"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Daddysenpai"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						3, -- [1]
						143.966999999946, -- [2]
						"Crash Down |cFFFF3333248,559|r", -- [3]
					}, -- [1]
				},
			},
			["Laki"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "DRUID",
				["deaths"] = {
					{
						5, -- [1]
						114.271999999997, -- [2]
						"Buster Cannon |cFFFF3333132,050|r", -- [3]
					}, -- [1]
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 17,
				["points"] = 1660,
				["deaths"] = {
					{
						2, -- [1]
						54.4810000000289, -- [2]
						"Buster Cannon |cFFFF333327,802|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						247.833999999915, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333310,637|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						138.789999999804, -- [2]
						"Spark Volley |cFFFF333316,009|r", -- [3]
					}, -- [3]
					{
						2, -- [1]
						142.463999999978, -- [2]
						"Blast Off |cFFFF3333101,190|r", -- [3]
					}, -- [4]
				},
				["class"] = "SHAMAN",
			},
			["Soely"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Kungfunkles-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Shìnigami"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						5, -- [1]
						225.772999999928, -- [2]
						"Spark Pulse |cFFFF333363,765|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						121.755000000121, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333335,175|r", -- [3]
					}, -- [2]
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Viste-ZirkeldesCenarius"] = {
				["encounters"] = 5,
				["points"] = 480,
				["deaths"] = {
					{
						3, -- [1]
						123.428000000073, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33331|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						129.876999999979, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333391,149|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Buttercarver-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Ømer-Khadgar"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Guldàníel"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						2, -- [1]
						67.3579999999929, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33336,130|r", -- [3]
					}, -- [1]
				},
			},
			["Shárf-Outland"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Pritamonkas-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "MONK",
				["deaths"] = {
					{
						1, -- [1]
						114.737000000081, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333351,559|r", -- [3]
					}, -- [1]
				},
			},
			["Làika"] = {
				["encounters"] = 7,
				["points"] = 690,
				["deaths"] = {
					{
						4, -- [1]
						158.338999999978, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33335,231|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Schifti"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						1, -- [1]
						51.3929999999236, -- [2]
						"Spark Volley |cFFFF333320,525|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						257.976999999955, -- [2]
						"Trample |cFFFF333312,878|r", -- [3]
					}, -- [2]
				},
				["class"] = "MONK",
			},
			["Jinjewel"] = {
				["encounters"] = 17,
				["points"] = 1670,
				["deaths"] = {
					{
						2, -- [1]
						113.880999999994, -- [2]
						"Spark Volley |cFFFF333321,943|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						97.48199999996, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333346,113|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						160.722999999998, -- [2]
						"Buster Cannon |cFFFF333334,584|r", -- [3]
					}, -- [3]
				},
				["class"] = "PRIEST",
			},
			["Slinki-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Seyden"] = {
				["encounters"] = 10,
				["points"] = 990,
				["deaths"] = {
					{
						4, -- [1]
						258.201999999932, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333311,694|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Aprofis-DieAldor"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						254.765000000014, -- [2]
						"Hyperdrive Discharge |cFFFF33337,602|r", -- [3]
					}, -- [1]
				},
			},
			["Slyre"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Nayven"] = {
				["encounters"] = 10,
				["points"] = 970,
				["deaths"] = {
					{
						2, -- [1]
						80.6790000000037, -- [2]
						"Spark Volley |cFFFF33332,676|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						109.405000000028, -- [2]
						"Crash Down |cFFFF3333239,038|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						156.698000000091, -- [2]
						"Buster Cannon |cFFFF33336,671|r", -- [3]
					}, -- [3]
				},
				["class"] = "WARLOCK",
			},
			["Neferupitou"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 4,
				["points"] = 360,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						59.4000000000233, -- [2]
						"Gigavolt Blast (DoT) |cFFFF33334,368|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						51.5499999999302, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333317,407|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						45.387999999919, -- [2]
						"Crash Down |cFFFF333347,944|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						155.915000000037, -- [2]
						"Buster Cannon |cFFFF33339,561|r", -- [3]
					}, -- [4]
				},
			},
			["Arameh"] = {
				["encounters"] = 17,
				["points"] = 1690,
				["deaths"] = {
					{
						3, -- [1]
						258.108000000007, -- [2]
						"Trample |cFFFF333323,703|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Hawtystep-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Chántý"] = {
				["encounters"] = 17,
				["points"] = 1660,
				["deaths"] = {
					{
						1, -- [1]
						125.563000000082, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333316,306|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						142.219000000041, -- [2]
						"Blast Off |cFFFF333378,145|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						45.570000000007, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333331,477|r", -- [3]
					}, -- [3]
					{
						7, -- [1]
						80.2380000000121, -- [2]
						"Spark Volley |cFFFF33339,843|r", -- [3]
					}, -- [4]
				},
				["class"] = "DRUID",
			},
			["Ventex"] = {
				["encounters"] = 7,
				["points"] = 690,
				["deaths"] = {
					{
						7, -- [1]
						98.8429999999935, -- [2]
						"Spark Pulse |cFFFF333358,913|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Xaru"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Râân"] = {
				["encounters"] = 7,
				["points"] = 690,
				["deaths"] = {
					{
						6, -- [1]
						91.5650000000023, -- [2]
						"Electroshock Strike |cFFFF333384,648|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Schwoop"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Wystra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["encounters"] = 5,
				["points"] = 460,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						4, -- [1]
						182.329000000027, -- [2]
						"Spark Volley |cFFFF33334,807|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						241.896999999997, -- [2]
						"Crash Down |cFFFF3333109,997|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						348.413000000059, -- [2]
						"Spark Pulse |cFFFF333342,169|r", -- [3]
					}, -- [3]
				},
			},
			["Supersunny"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Morfeeas-Darksorrow"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						333.870999999999, -- [2]
						"Melee |cFFFF333390,563|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						98.8549999999814, -- [2]
						"Spark Pulse |cFFFF333358,222|r", -- [3]
					}, -- [2]
				},
			},
			["Chentis"] = {
				["encounters"] = 7,
				["points"] = 680,
				["deaths"] = {
					{
						4, -- [1]
						180.446999999986, -- [2]
						"Buster Cannon |cFFFF3333105,251|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						45.570000000007, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333330,241|r", -- [3]
					}, -- [2]
				},
				["class"] = "MAGE",
			},
			["Ггрр-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Qyix"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						5, -- [1]
						192.557999999961, -- [2]
						"Gigavolt Blast |cFFFF333319,811|r", -- [3]
					}, -- [1]
				},
			},
			["Kindralia"] = {
				["encounters"] = 7,
				["points"] = 700,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["encounters"] = 7,
				["points"] = 700,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Kittyboompow-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Andromaché"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Freechain-DunModr"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Alísea-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Rusell"] = {
				["encounters"] = 7,
				["points"] = 680,
				["deaths"] = {
					{
						5, -- [1]
						186.689000000013, -- [2]
						"Buster Cannon |cFFFF333313,349|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						131.550999999978, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333319,845|r", -- [3]
					}, -- [2]
				},
				["class"] = "WARLOCK",
			},
			["Vèss-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["encounters"] = 17,
				["points"] = 1680,
				["deaths"] = {
					{
						2, -- [1]
						142.463999999978, -- [2]
						"Blast Off |cFFFF3333106,463|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						118.239000000001, -- [2]
						"Electroshock Strike |cFFFF333330,980|r", -- [3]
					}, -- [2]
				},
				["class"] = "DRUID",
			},
			["Khromatian"] = {
				["encounters"] = 17,
				["points"] = 1690,
				["deaths"] = {
					{
						1, -- [1]
						154.401999999769, -- [2]
						"Spark Volley |cFFFF33336,685|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Lokiboy"] = {
				["encounters"] = 17,
				["points"] = 1660,
				["deaths"] = {
					{
						1, -- [1]
						115.351000000024, -- [2]
						"Buster Cannon |cFFFF333314,488|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						44.9320000000298, -- [2]
						"Crash Down |cFFFF3333277,572|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						362.276000000071, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333315,956|r", -- [3]
					}, -- [3]
					{
						1, -- [1]
						106.844999999972, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333340,025|r", -- [3]
					}, -- [4]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Lilania"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						363.654999999999, -- [2]
						"Spark Volley |cFFFF333316,982|r", -- [3]
					}, -- [1]
				},
			},
			["Hotarou-Alleria"] = {
				["encounters"] = 7,
				["points"] = 690,
				["deaths"] = {
					{
						3, -- [1]
						115.478999999992, -- [2]
						"Buster Cannon |cFFFF333326,561|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Inánná"] = {
				["encounters"] = 22,
				["points"] = 2150,
				["deaths"] = {
					{
						3, -- [1]
						181.709000000032, -- [2]
						"Buster Cannon |cFFFF333311,487|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						121.808999999892, -- [2]
						"Spark Volley |cFFFF333317,246|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						92.6610000000801, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333396,055|r", -- [3]
					}, -- [3]
					{
						1, -- [1]
						86.7820000000065, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333344,093|r", -- [3]
					}, -- [4]
					{
						5, -- [1]
						225.117000000028, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333319,889|r", -- [3]
					}, -- [5]
				},
				["class"] = "PALADIN",
			},
			["Artèmis"] = {
				["encounters"] = 23,
				["points"] = 2280,
				["deaths"] = {
					{
						4, -- [1]
						181.316000000108, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333321,707|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						45.5359999999637, -- [2]
						"Gigavolt Blast |cFFFF333319,600|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Mêphis"] = {
				["encounters"] = 10,
				["points"] = 1000,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Apoktalipto-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Aspern"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						2, -- [1]
						51.2709999999497, -- [2]
						"Buster Cannon |cFFFF333327,546|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						272.228999999934, -- [2]
						"Gigavolt Blast (DoT) |cFFFF333321,094|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Verbathius-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "MONK",
				["deaths"] = {
					{
						1, -- [1]
						143.959000000032, -- [2]
						"Crash Down |cFFFF3333253,997|r", -- [3]
					}, -- [1]
				},
			},
			["Salanâ"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						157.66399999999, -- [2]
						"Spark Pulse |cFFFF333369,847|r", -- [3]
					}, -- [1]
				},
			},
			["Julietté"] = {
				["encounters"] = 5,
				["points"] = 480,
				["deaths"] = {
					{
						1, -- [1]
						130.431000000099, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333392,760|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						257.05700000003, -- [2]
						"Sheep Shrapnel |cFFFF333328,926|r", -- [3]
					}, -- [2]
				},
				["class"] = "WARRIOR",
			},
			["Yesiam"] = {
				["encounters"] = 17,
				["points"] = 1690,
				["deaths"] = {
					{
						3, -- [1]
						182.412000000011, -- [2]
						"Gigavolt Charge (DoT) |cFFFF33334,910|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Metó"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
		},
	},
	["233314"] = {
		["hash"] = "233314",
		["type"] = "endurance",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["diff"] = 14,
		["player_db"] = {
			["Viridris-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Джигурдинья-Голдринн"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Theodosa-ArgentDawn"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Phyrena-C'Thun"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Zaktos-ArgentDawn"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Shoq-Khadgar"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Бадсаа-Дракономор"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Алануир-Дракономор"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Лавкравт-Дракономор"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						28.1300000000047, -- [2]
						"Bestial Smash |cFFFF3333436,429|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Spamwyn-Turalyon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Charliefk-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						89.6710000000894, -- [2]
						"Melee |cFFFF333362,147|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Icrapmypánts-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Illidåri-Draenor"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Saracor-ArgentDawn"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Ioanaa-Sylvanas"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Healstation-Khadgar"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Спотка-ЧерныйШрам"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Artèmis"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Toryb-DieArguswacht"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Nekrowman-ChamberofAspects"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Natsukí-Arygos"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Импозантная-Дракономор"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Champion of the Light",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["diff"] = 14,
			["id"] = 2265,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
	},
	["234216"] = {
		["hash"] = "234216",
		["type"] = "endurance",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 16,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["encounter"] = "Opulence",
			["ej_instance_id"] = 1176,
			["diff"] = 16,
		},
		["player_db"] = {
			["Xaru"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "MAGE",
				["deaths"] = {
					{
						3, -- [1]
						335.626999999979, -- [2]
						"Molten Gold (DoT) |cFFFF333389,871|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						162.471000000005, -- [2]
						"Flames of Punishment |cFFFF333337,125|r", -- [3]
					}, -- [2]
				},
			},
			["Râân"] = {
				["encounters"] = 16,
				["points"] = 1600,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Laki"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 63,
				["points"] = 6180,
				["deaths"] = {
					{
						10, -- [1]
						103.997999999905, -- [2]
						"Flames of Punishment |cFFFF333394,811|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						101.683999999892, -- [2]
						"Volatile Charge |cFFFF333359,650|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						71.1459999999497, -- [2]
						"Volatile Charge |cFFFF333327,056|r", -- [3]
					}, -- [3]
					{
						15, -- [1]
						121.337999999989, -- [2]
						"Volatile Charge |cFFFF3333117,851|r", -- [3]
					}, -- [4]
					{
						17, -- [1]
						37.689000000013, -- [2]
						"Volatile Charge |cFFFF3333137,444|r", -- [3]
					}, -- [5]
					{
						6, -- [1]
						66.4720000000089, -- [2]
						"Flame Jet (DoT) |cFFFF333346,508|r", -- [3]
					}, -- [6]
					{
						8, -- [1]
						182.179000000004, -- [2]
						"Scorching Ground (DoT) |cFFFF333351,876|r", -- [3]
					}, -- [7]
					{
						14, -- [1]
						187.085000000021, -- [2]
						"Volatile Charge |cFFFF3333109,042|r", -- [3]
					}, -- [8]
					{
						21, -- [1]
						172.994999999995, -- [2]
						"Deadly Hex (DoT) |cFFFF3333110,501|r", -- [3]
					}, -- [9]
					{
						26, -- [1]
						316.642999999924, -- [2]
						"Flames of Punishment |cFFFF3333107,110|r", -- [3]
					}, -- [10]
					{
						37, -- [1]
						100.185999999987, -- [2]
						"Flames of Punishment |cFFFF3333100,615|r", -- [3]
					}, -- [11]
					{
						39, -- [1]
						141.945000000065, -- [2]
						"Flames of Punishment |cFFFF333351,553|r", -- [3]
					}, -- [12]
				},
				["class"] = "SHAMAN",
			},
			["Härridk"] = {
				["encounters"] = 6,
				["points"] = 590,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						4, -- [1]
						142.424999999988, -- [2]
						"Deadly Hex (DoT) |cFFFF333339,578|r", -- [3]
					}, -- [1]
				},
			},
			["Soely"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						167.418000000005, -- [2]
						"Scorching Ground (DoT) |cFFFF333344,312|r", -- [3]
					}, -- [1]
				},
			},
			["Shìnigami"] = {
				["encounters"] = 80,
				["points"] = 7880,
				["deaths"] = {
					{
						14, -- [1]
						167.325999999885, -- [2]
						"Volatile Charge |cFFFF3333130,291|r", -- [3]
					}, -- [1]
					{
						24, -- [1]
						53.3070000000298, -- [2]
						"Creeping Blaze (DoT) |cFFFF333393,910|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						25.7220000000089, -- [2]
						"Flames of Punishment |cFFFF3333129,944|r", -- [3]
					}, -- [3]
					{
						9, -- [1]
						244.494999999995, -- [2]
						"Flames of Punishment |cFFFF333390,308|r", -- [3]
					}, -- [4]
					{
						13, -- [1]
						69.390000000014, -- [2]
						"Flames of Punishment |cFFFF3333176,535|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						72.5779999999795, -- [2]
						"Flame Jet (DoT) |cFFFF333374,005|r", -- [3]
					}, -- [6]
					{
						4, -- [1]
						198.530000000028, -- [2]
						"Volatile Charge |cFFFF333315,724|r", -- [3]
					}, -- [7]
					{
						8, -- [1]
						162.600999999908, -- [2]
						"Volatile Charge |cFFFF333390,155|r", -- [3]
					}, -- [8]
					{
						31, -- [1]
						151.753999999957, -- [2]
						"Flames of Punishment |cFFFF3333117,771|r", -- [3]
					}, -- [9]
					{
						36, -- [1]
						111.320999999996, -- [2]
						"Crush |cFFFF333341,211|r", -- [3]
					}, -- [10]
					{
						37, -- [1]
						258.708999999915, -- [2]
						"Thief's Bane (DoT) |cFFFF3333234,141|r", -- [3]
					}, -- [11]
					{
						40, -- [1]
						218.040999999968, -- [2]
						"Flames of Punishment |cFFFF3333149,691|r", -- [3]
					}, -- [12]
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 6,
				["points"] = 590,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						97.9429999999702, -- [2]
						"Crush |cFFFF33337,285|r", -- [3]
					}, -- [1]
				},
			},
			["Lokiboy"] = {
				["encounters"] = 81,
				["points"] = 8030,
				["deaths"] = {
					{
						3, -- [1]
						25.5100000000093, -- [2]
						"Flames of Punishment |cFFFF3333172,911|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						53.6620000000112, -- [2]
						"Volatile Charge |cFFFF3333121,382|r", -- [3]
					}, -- [2]
					{
						10, -- [1]
						80.7039999999106, -- [2]
						"Volatile Charge |cFFFF333347,121|r", -- [3]
					}, -- [3]
					{
						20, -- [1]
						21.9990000000689, -- [2]
						"Flames of Punishment |cFFFF3333167,917|r", -- [3]
					}, -- [4]
					{
						20, -- [1]
						110.829000000143, -- [2]
						"Volatile Charge |cFFFF333364,714|r", -- [3]
					}, -- [5]
					{
						11, -- [1]
						217.043000000005, -- [2]
						"Flame Jet (DoT) |cFFFF333330,405|r", -- [3]
					}, -- [6]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Inánná"] = {
				["encounters"] = 86,
				["points"] = 8430,
				["deaths"] = {
					{
						12, -- [1]
						83.4890000000596, -- [2]
						"Flames of Punishment |cFFFF333370,940|r", -- [3]
					}, -- [1]
					{
						14, -- [1]
						76.2770000000019, -- [2]
						"Flame Jet (DoT) |cFFFF333357,161|r", -- [3]
					}, -- [2]
					{
						21, -- [1]
						123.611000000034, -- [2]
						"Crush |cFFFF333329,211|r", -- [3]
					}, -- [3]
					{
						22, -- [1]
						53.0360000000801, -- [2]
						"Volatile Charge |cFFFF33338,069|r", -- [3]
					}, -- [4]
					{
						1, -- [1]
						91.679999999993, -- [2]
						"Scorching Ground (DoT) |cFFFF333335,262|r", -- [3]
					}, -- [5]
					{
						4, -- [1]
						53.6300000000047, -- [2]
						"Volatile Charge |cFFFF333318,107|r", -- [3]
					}, -- [6]
					{
						12, -- [1]
						82.2899999999791, -- [2]
						"Volatile Charge |cFFFF333353,036|r", -- [3]
					}, -- [7]
					{
						15, -- [1]
						202.52999999997, -- [2]
						"Crush |cFFFF333394,448|r", -- [3]
					}, -- [8]
					{
						2, -- [1]
						94.0749999999534, -- [2]
						"Flames of Punishment |cFFFF3333181,028|r", -- [3]
					}, -- [9]
					{
						3, -- [1]
						69.7399999999907, -- [2]
						"Flame Jet (DoT) |cFFFF333362,175|r", -- [3]
					}, -- [10]
					{
						10, -- [1]
						113.616000000038, -- [2]
						"Volatile Charge |cFFFF3333138,307|r", -- [3]
					}, -- [11]
					{
						12, -- [1]
						71.4129999999423, -- [2]
						"Flames of Punishment |cFFFF333337,885|r", -- [3]
					}, -- [12]
					{
						14, -- [1]
						218.868000000017, -- [2]
						"Volatile Charge |cFFFF33336,303|r", -- [3]
					}, -- [13]
					{
						18, -- [1]
						57.1940000000177, -- [2]
						"Volatile Charge |cFFFF333396,595|r", -- [3]
					}, -- [14]
					{
						27, -- [1]
						166, -- [2]
						"Scorching Ground (DoT) |cFFFF333355,215|r", -- [3]
					}, -- [15]
					{
						30, -- [1]
						64.8340000000317, -- [2]
						"Flame Jet (DoT) |cFFFF333358,785|r", -- [3]
					}, -- [16]
					{
						40, -- [1]
						100.00299999991, -- [2]
						"Creeping Blaze (DoT) |cFFFF333359,430|r", -- [3]
					}, -- [17]
				},
				["class"] = "PALADIN",
			},
			["Almîna"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "MONK",
				["deaths"] = {
					{
						2, -- [1]
						91.0779999999795, -- [2]
						"Flames of Punishment |cFFFF333350,840|r", -- [3]
					}, -- [1]
				},
			},
			["Mêphis"] = {
				["encounters"] = 24,
				["points"] = 2400,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Chentis"] = {
				["encounters"] = 64,
				["points"] = 6270,
				["deaths"] = {
					{
						2, -- [1]
						63.9860000000335, -- [2]
						"Flames of Punishment |cFFFF333334,324|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						115.576000000117, -- [2]
						"Scorching Ground (DoT) |cFFFF333347,957|r", -- [3]
					}, -- [2]
					{
						12, -- [1]
						101.597000000067, -- [2]
						"Volatile Charge |cFFFF33337,558|r", -- [3]
					}, -- [3]
					{
						13, -- [1]
						111.317000000039, -- [2]
						"Flames of Punishment |cFFFF3333174,301|r", -- [3]
					}, -- [4]
					{
						18, -- [1]
						66.9389999997802, -- [2]
						"Volatile Charge |cFFFF3333105,525|r", -- [3]
					}, -- [5]
					{
						6, -- [1]
						191.32799999998, -- [2]
						"Flame Jet (DoT) |cFFFF333370,938|r", -- [3]
					}, -- [6]
					{
						20, -- [1]
						135.467000000062, -- [2]
						"Pulse-quickening Toxin (DoT) |cFFFF33336,835|r", -- [3]
					}, -- [7]
					{
						23, -- [1]
						188.871999999974, -- [2]
						"Scorching Ground (DoT) |cFFFF33337,855|r", -- [3]
					}, -- [8]
					{
						24, -- [1]
						47.8070000000298, -- [2]
						"Flame Jet (DoT) |cFFFF333369,971|r", -- [3]
					}, -- [9]
					{
						28, -- [1]
						299.569000000018, -- [2]
						"Flames of Punishment |cFFFF3333167,580|r", -- [3]
					}, -- [10]
					{
						29, -- [1]
						118.289999999921, -- [2]
						"Volatile Charge |cFFFF3333103,502|r", -- [3]
					}, -- [11]
					{
						32, -- [1]
						63.5820000000531, -- [2]
						"Flame Jet (DoT) |cFFFF333346,033|r", -- [3]
					}, -- [12]
					{
						38, -- [1]
						136.081000000006, -- [2]
						"Pulse-quickening Toxin (DoT) |cFFFF333312,310|r", -- [3]
					}, -- [13]
				},
				["class"] = "MAGE",
			},
			["Viste"] = {
				["encounters"] = 17,
				["points"] = 1650,
				["deaths"] = {
					{
						3, -- [1]
						68.5640000000131, -- [2]
						"Flames of Punishment |cFFFF333388,881|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						178.574000000022, -- [2]
						"Deadly Hex (DoT) |cFFFF333376,084|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						171.353000000003, -- [2]
						"Volatile Charge |cFFFF333395,212|r", -- [3]
					}, -- [3]
					{
						14, -- [1]
						204.565000000061, -- [2]
						"Volatile Charge |cFFFF3333121,798|r", -- [3]
					}, -- [4]
					{
						16, -- [1]
						199.68200000003, -- [2]
						"Deadly Hex (DoT) |cFFFF333384,078|r", -- [3]
					}, -- [5]
				},
				["class"] = "HUNTER",
			},
			["Artèmis"] = {
				["encounters"] = 86,
				["points"] = 8480,
				["deaths"] = {
					{
						7, -- [1]
						163.199000000022, -- [2]
						"Crush |cFFFF333324,114|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						93.8229999998585, -- [2]
						"Volatile Charge |cFFFF333362,026|r", -- [3]
					}, -- [2]
					{
						22, -- [1]
						119.581000000006, -- [2]
						"Volatile Charge |cFFFF333319,830|r", -- [3]
					}, -- [3]
					{
						1, -- [1]
						59.4270000000252, -- [2]
						"Flame Jet (DoT) |cFFFF333373,523|r", -- [3]
					}, -- [4]
					{
						2, -- [1]
						134.217999999993, -- [2]
						"Flames of Punishment |cFFFF333373,193|r", -- [3]
					}, -- [5]
					{
						11, -- [1]
						117.184000000008, -- [2]
						"Crush |cFFFF33338,318|r", -- [3]
					}, -- [6]
					{
						13, -- [1]
						70.6080000000075, -- [2]
						"Flames of Punishment |cFFFF333352,818|r", -- [3]
					}, -- [7]
					{
						1, -- [1]
						71.7029999999795, -- [2]
						"Volatile Charge |cFFFF333390,474|r", -- [3]
					}, -- [8]
					{
						22, -- [1]
						105.258999999962, -- [2]
						"Crush |cFFFF333330,789|r", -- [3]
					}, -- [9]
					{
						30, -- [1]
						98.5370000000112, -- [2]
						"Scorching Ground (DoT) |cFFFF333336,809|r", -- [3]
					}, -- [10]
					{
						31, -- [1]
						191.404999999912, -- [2]
						"Flames of Punishment |cFFFF3333128,523|r", -- [3]
					}, -- [11]
					{
						1, -- [1]
						127.419999999998, -- [2]
						"Flames of Punishment |cFFFF333389,897|r", -- [3]
					}, -- [12]
				},
				["class"] = "HUNTER",
			},
			["Narfnarf"] = {
				["encounters"] = 80,
				["points"] = 7890,
				["deaths"] = {
					{
						4, -- [1]
						53.6620000000112, -- [2]
						"Volatile Charge |cFFFF333370,430|r", -- [3]
					}, -- [1]
					{
						18, -- [1]
						113.300999999978, -- [2]
						"Flames of Punishment |cFFFF33337,406|r", -- [3]
					}, -- [2]
					{
						23, -- [1]
						57.3270000000484, -- [2]
						"Volatile Charge |cFFFF333356,315|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						59.1969999999856, -- [2]
						"Flame Jet (DoT) |cFFFF333348,950|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						82.9149999999791, -- [2]
						"Flames of Punishment |cFFFF333367,525|r", -- [3]
					}, -- [5]
					{
						14, -- [1]
						77.2390000000014, -- [2]
						"Flames of Punishment |cFFFF333314,814|r", -- [3]
					}, -- [6]
					{
						6, -- [1]
						173.138999999966, -- [2]
						"Deadly Hex (DoT) |cFFFF333381,067|r", -- [3]
					}, -- [7]
					{
						13, -- [1]
						66.939000000013, -- [2]
						"Flames of Punishment |cFFFF3333130,730|r", -- [3]
					}, -- [8]
					{
						22, -- [1]
						112.548999999999, -- [2]
						"Scorching Ground (DoT) |cFFFF333322,676|r", -- [3]
					}, -- [9]
					{
						26, -- [1]
						198.988999999943, -- [2]
						"Crush |cFFFF333325,174|r", -- [3]
					}, -- [10]
					{
						33, -- [1]
						46.4139999999898, -- [2]
						"Crush |cFFFF3333112,204|r", -- [3]
					}, -- [11]
				},
				["class"] = "HUNTER",
			},
			["Kindralia"] = {
				["encounters"] = 40,
				["points"] = 3980,
				["deaths"] = {
					{
						2, -- [1]
						95.2669999999926, -- [2]
						"Flames of Punishment |cFFFF3333166,833|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						182.555000000051, -- [2]
						"Flames of Punishment |cFFFF333373,250|r", -- [3]
					}, -- [2]
				},
				["class"] = "ROGUE",
			},
			["Kirgit"] = {
				["encounters"] = 24,
				["points"] = 2310,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						19, -- [1]
						24.9830000000075, -- [2]
						"Flames of Punishment |cFFFF333367,304|r", -- [3]
					}, -- [1]
					{
						19, -- [1]
						68.4039999999805, -- [2]
						"Flames of Punishment |cFFFF33337,877|r", -- [3]
					}, -- [2]
					{
						25, -- [1]
						51.2049999999581, -- [2]
						"Volatile Charge |cFFFF3333134,844|r", -- [3]
					}, -- [3]
					{
						32, -- [1]
						265.260000000009, -- [2]
						"Thief's Bane (DoT) |cFFFF3333237,421|r", -- [3]
					}, -- [4]
					{
						36, -- [1]
						109.03600000008, -- [2]
						"Flames of Punishment |cFFFF333330,897|r", -- [3]
					}, -- [5]
					{
						37, -- [1]
						186.990999999922, -- [2]
						"Deadly Hex (DoT) |cFFFF333354,149|r", -- [3]
					}, -- [6]
					{
						39, -- [1]
						191.839999999967, -- [2]
						"Crush |cFFFF333313,919|r", -- [3]
					}, -- [7]
					{
						40, -- [1]
						221.618999999948, -- [2]
						"Flames of Punishment |cFFFF333328,901|r", -- [3]
					}, -- [8]
				},
			},
			["Aspern"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Schifti"] = {
				["encounters"] = 81,
				["points"] = 7890,
				["deaths"] = {
					{
						3, -- [1]
						63.1430000001565, -- [2]
						"Flame Jet (DoT) |cFFFF333362,418|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						101.868999999948, -- [2]
						"Flames of Punishment |cFFFF333335,662|r", -- [3]
					}, -- [2]
					{
						17, -- [1]
						116.851000000024, -- [2]
						"Crush |cFFFF333311,080|r", -- [3]
					}, -- [3]
					{
						24, -- [1]
						115.334000000032, -- [2]
						"Crush |cFFFF333342,272|r", -- [3]
					}, -- [4]
					{
						5, -- [1]
						69.9409999999916, -- [2]
						"Crush |cFFFF333328,972|r", -- [3]
					}, -- [5]
					{
						7, -- [1]
						97.8420000000042, -- [2]
						"Volatile Charge |cFFFF333393,367|r", -- [3]
					}, -- [6]
					{
						10, -- [1]
						66.6610000000219, -- [2]
						"Volatile Charge |cFFFF333398,579|r", -- [3]
					}, -- [7]
					{
						14, -- [1]
						193.229999999981, -- [2]
						"Volatile Charge |cFFFF333310,985|r", -- [3]
					}, -- [8]
					{
						16, -- [1]
						67.8090000000084, -- [2]
						"Volatile Charge |cFFFF3333105,510|r", -- [3]
					}, -- [9]
					{
						10, -- [1]
						135.025000000023, -- [2]
						"Volatile Charge |cFFFF333314,242|r", -- [3]
					}, -- [10]
					{
						13, -- [1]
						84.5300000000279, -- [2]
						"Volatile Charge |cFFFF333318,264|r", -- [3]
					}, -- [11]
					{
						15, -- [1]
						85.9100000000326, -- [2]
						"Volatile Charge |cFFFF333311,113|r", -- [3]
					}, -- [12]
					{
						17, -- [1]
						174.343999999925, -- [2]
						"Volatile Charge |cFFFF3333133,735|r", -- [3]
					}, -- [13]
					{
						20, -- [1]
						64.9640000000363, -- [2]
						"Volatile Charge |cFFFF3333119,482|r", -- [3]
					}, -- [14]
					{
						21, -- [1]
						169.5, -- [2]
						"Deadly Hex (DoT) |cFFFF333345,108|r", -- [3]
					}, -- [15]
					{
						23, -- [1]
						162.251000000048, -- [2]
						"Scorching Ground (DoT) |cFFFF333345,039|r", -- [3]
					}, -- [16]
					{
						23, -- [1]
						185.873000000021, -- [2]
						"Volatile Charge |cFFFF333317,615|r", -- [3]
					}, -- [17]
					{
						24, -- [1]
						179.391999999993, -- [2]
						"Scorching Ground (DoT) |cFFFF33336,056|r", -- [3]
					}, -- [18]
					{
						29, -- [1]
						65.3759999999311, -- [2]
						"Volatile Charge |cFFFF333349,413|r", -- [3]
					}, -- [19]
					{
						34, -- [1]
						65.5010000000475, -- [2]
						"Volatile Charge |cFFFF3333126,634|r", -- [3]
					}, -- [20]
				},
				["class"] = "MONK",
			},
			["Jinjewel"] = {
				["encounters"] = 58,
				["points"] = 5560,
				["deaths"] = {
					{
						1, -- [1]
						25.8230000000913, -- [2]
						"Flames of Punishment |cFFFF3333184,773|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						70.2390000000596, -- [2]
						"Crush |cFFFF3333145,355|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						61.5900000000838, -- [2]
						"Flame Jet (DoT) |cFFFF333380,751|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						101.049000000116, -- [2]
						"Scorching Ground (DoT) |cFFFF333357,742|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						26.564000000013, -- [2]
						"Flames of Punishment |cFFFF3333184,774|r", -- [3]
					}, -- [5]
					{
						8, -- [1]
						94.7319999998435, -- [2]
						"Flames of Punishment |cFFFF3333184,774|r", -- [3]
					}, -- [6]
					{
						15, -- [1]
						113.381999999983, -- [2]
						"Flames of Punishment |cFFFF3333184,773|r", -- [3]
					}, -- [7]
					{
						17, -- [1]
						108.88599999994, -- [2]
						"Scorching Ground (DoT) |cFFFF333357,742|r", -- [3]
					}, -- [8]
					{
						19, -- [1]
						156.621999999974, -- [2]
						"Crush |cFFFF3333145,355|r", -- [3]
					}, -- [9]
					{
						3, -- [1]
						83.2920000000158, -- [2]
						"Volatile Charge |cFFFF333317,070|r", -- [3]
					}, -- [10]
					{
						4, -- [1]
						69.3880000000354, -- [2]
						"Volatile Charge |cFFFF333317,071|r", -- [3]
					}, -- [11]
					{
						15, -- [1]
						119.843999999983, -- [2]
						"Scorching Ground (DoT) |cFFFF333356,901|r", -- [3]
					}, -- [12]
					{
						16, -- [1]
						64.0910000000149, -- [2]
						"Flame Jet (DoT) |cFFFF333379,576|r", -- [3]
					}, -- [13]
					{
						2, -- [1]
						110.505000000005, -- [2]
						"Volatile Charge |cFFFF333397,202|r", -- [3]
					}, -- [14]
					{
						3, -- [1]
						67.8170000000391, -- [2]
						"Flame Jet (DoT) |cFFFF333358,745|r", -- [3]
					}, -- [15]
					{
						5, -- [1]
						49.2119999999413, -- [2]
						"Flame Jet (DoT) |cFFFF333338,251|r", -- [3]
					}, -- [16]
					{
						6, -- [1]
						189.380999999936, -- [2]
						"Volatile Charge |cFFFF333316,204|r", -- [3]
					}, -- [17]
					{
						11, -- [1]
						191.056000000099, -- [2]
						"Volatile Charge |cFFFF33334,592|r", -- [3]
					}, -- [18]
					{
						12, -- [1]
						71.1620000000112, -- [2]
						"Flame Jet (DoT) |cFFFF333379,560|r", -- [3]
					}, -- [19]
					{
						13, -- [1]
						45.4810000000289, -- [2]
						"Flame Jet (DoT) |cFFFF333322,546|r", -- [3]
					}, -- [20]
					{
						15, -- [1]
						58.0649999999441, -- [2]
						"Volatile Charge |cFFFF333399,105|r", -- [3]
					}, -- [21]
					{
						16, -- [1]
						118.636999999988, -- [2]
						"Scorching Ground (DoT) |cFFFF33336,359|r", -- [3]
					}, -- [22]
					{
						17, -- [1]
						82.3439999999246, -- [2]
						"Volatile Charge |cFFFF333315,544|r", -- [3]
					}, -- [23]
				},
				["class"] = "PRIEST",
			},
			["Isery"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["encounters"] = 6,
				["points"] = 580,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						4, -- [1]
						160.152000000002, -- [2]
						"Flames of Punishment |cFFFF333384,832|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						167.542999999998, -- [2]
						"Flames of Punishment |cFFFF3333131,742|r", -- [3]
					}, -- [2]
				},
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Rusell"] = {
				["encounters"] = 24,
				["points"] = 2310,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						18, -- [1]
						22.6169999999693, -- [2]
						"Flames of Punishment |cFFFF3333134,318|r", -- [3]
					}, -- [1]
					{
						19, -- [1]
						63.0699999999488, -- [2]
						"Volatile Charge |cFFFF33332,706|r", -- [3]
					}, -- [2]
					{
						24, -- [1]
						188.834000000032, -- [2]
						"Deadly Hex (DoT) |cFFFF333329,919|r", -- [3]
					}, -- [3]
					{
						27, -- [1]
						195.53899999999, -- [2]
						"Flames of Punishment |cFFFF3333147,807|r", -- [3]
					}, -- [4]
					{
						28, -- [1]
						299.569000000018, -- [2]
						"Flames of Punishment |cFFFF333380,161|r", -- [3]
					}, -- [5]
					{
						28, -- [1]
						321.220000000089, -- [2]
						"Flames of Punishment |cFFFF333327,948|r", -- [3]
					}, -- [6]
					{
						38, -- [1]
						172.333000000101, -- [2]
						"Scorching Ground (DoT) |cFFFF333321,455|r", -- [3]
					}, -- [7]
					{
						39, -- [1]
						256.880000000005, -- [2]
						"Volatile Charge |cFFFF333350,450|r", -- [3]
					}, -- [8]
				},
			},
			["Julietté"] = {
				["encounters"] = 56,
				["points"] = 5560,
				["deaths"] = {
					{
						3, -- [1]
						85.8870000000461, -- [2]
						"Volatile Charge |cFFFF333312,268|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						171.728999999992, -- [2]
						"Deadly Hex (DoT) |cFFFF333388,027|r", -- [3]
					}, -- [2]
					{
						15, -- [1]
						95.3209999999963, -- [2]
						"Flame Jet (DoT) |cFFFF333320,488|r", -- [3]
					}, -- [3]
					{
						35, -- [1]
						187.554000000004, -- [2]
						"Volatile Charge |cFFFF333315,614|r", -- [3]
					}, -- [4]
				},
				["class"] = "WARRIOR",
			},
			["Dovomir"] = {
				["encounters"] = 6,
				["points"] = 590,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						3, -- [1]
						360.579999999958, -- [2]
						"Molten Gold (DoT) |cFFFF333330,715|r", -- [3]
					}, -- [1]
				},
			},
			["Seyden"] = {
				["encounters"] = 81,
				["points"] = 7950,
				["deaths"] = {
					{
						1, -- [1]
						27.0190000000875, -- [2]
						"Flames of Punishment |cFFFF333387,725|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						78.3449999999721, -- [2]
						"Flames of Punishment |cFFFF333372,360|r", -- [3]
					}, -- [2]
					{
						16, -- [1]
						107.034999999916, -- [2]
						"Volatile Charge |cFFFF3333107,860|r", -- [3]
					}, -- [3]
					{
						23, -- [1]
						57.3270000000484, -- [2]
						"Volatile Charge |cFFFF33338,242|r", -- [3]
					}, -- [4]
					{
						11, -- [1]
						220.982000000018, -- [2]
						"Deadly Hex (DoT) |cFFFF333342,180|r", -- [3]
					}, -- [5]
					{
						16, -- [1]
						67.8090000000084, -- [2]
						"Volatile Charge |cFFFF333355,938|r", -- [3]
					}, -- [6]
					{
						1, -- [1]
						124.775999999954, -- [2]
						"Scorching Ground (DoT) |cFFFF333328,784|r", -- [3]
					}, -- [7]
					{
						9, -- [1]
						63.5860000000103, -- [2]
						"Flame Jet (DoT) |cFFFF333326,708|r", -- [3]
					}, -- [8]
					{
						9, -- [1]
						84.8999999999069, -- [2]
						"Crush |cFFFF3333116,542|r", -- [3]
					}, -- [9]
					{
						10, -- [1]
						136.03899999999, -- [2]
						"Volatile Charge |cFFFF33331|r", -- [3]
					}, -- [10]
					{
						11, -- [1]
						191.230000000098, -- [2]
						"Deadly Hex (DoT) |cFFFF333376,065|r", -- [3]
					}, -- [11]
					{
						20, -- [1]
						95.9280000000726, -- [2]
						"Volatile Charge |cFFFF333313,128|r", -- [3]
					}, -- [12]
					{
						30, -- [1]
						197.521000000066, -- [2]
						"Crush |cFFFF33339,835|r", -- [3]
					}, -- [13]
					{
						31, -- [1]
						111.902999999933, -- [2]
						"Scorching Ground (DoT) |cFFFF333324,867|r", -- [3]
					}, -- [14]
				},
				["class"] = "DEMONHUNTER",
			},
			["Khromatian"] = {
				["encounters"] = 80,
				["points"] = 7910,
				["deaths"] = {
					{
						1, -- [1]
						57.1680000000633, -- [2]
						"Volatile Charge |cFFFF333310,859|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						85.4000000001397, -- [2]
						"Creeping Blaze (DoT) |cFFFF3333116,039|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						59.8439999998082, -- [2]
						"Creeping Blaze (DoT) |cFFFF3333118,707|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						145.271999999881, -- [2]
						"Scorching Ground (DoT) |cFFFF333330,513|r", -- [3]
					}, -- [4]
					{
						12, -- [1]
						18.4420000000391, -- [2]
						"Volatile Charge |cFFFF3333101,441|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						125.494999999995, -- [2]
						"Flames of Punishment |cFFFF333337,036|r", -- [3]
					}, -- [6]
					{
						7, -- [1]
						66.4089999999851, -- [2]
						"Flame Jet (DoT) |cFFFF333365,015|r", -- [3]
					}, -- [7]
					{
						8, -- [1]
						111.039999999921, -- [2]
						"Flames of Punishment |cFFFF333349,228|r", -- [3]
					}, -- [8]
					{
						27, -- [1]
						106.158000000054, -- [2]
						"Flames of Punishment |cFFFF333369,411|r", -- [3]
					}, -- [9]
				},
				["class"] = "DRUID",
			},
			["Nelwyn"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Slyre"] = {
				["encounters"] = 80,
				["points"] = 7860,
				["deaths"] = {
					{
						4, -- [1]
						57.5820000001695, -- [2]
						"Flames of Punishment |cFFFF333373,606|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						42.7689999998547, -- [2]
						"Volatile Charge |cFFFF3333102,487|r", -- [3]
					}, -- [2]
					{
						14, -- [1]
						22.0329999998212, -- [2]
						"Flames of Punishment |cFFFF333367,663|r", -- [3]
					}, -- [3]
					{
						18, -- [1]
						118.924999999814, -- [2]
						"Crush |cFFFF333336,054|r", -- [3]
					}, -- [4]
					{
						20, -- [1]
						150.233000000007, -- [2]
						"Volatile Charge |cFFFF3333129,668|r", -- [3]
					}, -- [5]
					{
						2, -- [1]
						131.842000000004, -- [2]
						"Flames of Punishment |cFFFF3333182,279|r", -- [3]
					}, -- [6]
					{
						3, -- [1]
						139.541000000027, -- [2]
						"Volatile Charge |cFFFF333389,548|r", -- [3]
					}, -- [7]
					{
						4, -- [1]
						54.7119999999995, -- [2]
						"Volatile Charge |cFFFF33334,733|r", -- [3]
					}, -- [8]
					{
						7, -- [1]
						98.5650000000023, -- [2]
						"Scorching Ground (DoT) |cFFFF333337,426|r", -- [3]
					}, -- [9]
					{
						21, -- [1]
						107.498999999953, -- [2]
						"Flames of Punishment |cFFFF333371,829|r", -- [3]
					}, -- [10]
					{
						25, -- [1]
						56.2129999999888, -- [2]
						"Volatile Charge |cFFFF3333122,015|r", -- [3]
					}, -- [11]
					{
						26, -- [1]
						294.065999999992, -- [2]
						"Flames of Punishment |cFFFF3333113,418|r", -- [3]
					}, -- [12]
					{
						36, -- [1]
						102.179000000004, -- [2]
						"Flames of Punishment |cFFFF333374,258|r", -- [3]
					}, -- [13]
					{
						38, -- [1]
						157.545000000042, -- [2]
						"Deadly Hex (DoT) |cFFFF333391,883|r", -- [3]
					}, -- [14]
				},
				["class"] = "HUNTER",
			},
			["Salanâ"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Nayven"] = {
				["encounters"] = 58,
				["points"] = 5660,
				["deaths"] = {
					{
						6, -- [1]
						26.6769999999087, -- [2]
						"Crush |cFFFF333331,729|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						48.9179999998305, -- [2]
						"Creeping Blaze (DoT) |cFFFF333390,826|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						103.662999999942, -- [2]
						"Flames of Punishment |cFFFF333388,581|r", -- [3]
					}, -- [3]
					{
						13, -- [1]
						69.3200000000652, -- [2]
						"Volatile Charge |cFFFF3333119,641|r", -- [3]
					}, -- [4]
					{
						21, -- [1]
						56.0910000000149, -- [2]
						"Volatile Charge |cFFFF33338,761|r", -- [3]
					}, -- [5]
					{
						22, -- [1]
						53.0360000000801, -- [2]
						"Volatile Charge |cFFFF3333117,368|r", -- [3]
					}, -- [6]
					{
						24, -- [1]
						70.8260000001174, -- [2]
						"Flames of Punishment |cFFFF3333111,775|r", -- [3]
					}, -- [7]
					{
						5, -- [1]
						101.478000000003, -- [2]
						"Flames of Punishment |cFFFF3333140,559|r", -- [3]
					}, -- [8]
					{
						15, -- [1]
						187.997999999963, -- [2]
						"Deadly Hex (DoT) |cFFFF333389,909|r", -- [3]
					}, -- [9]
					{
						5, -- [1]
						65.9340000000084, -- [2]
						"Flames of Punishment |cFFFF3333138,319|r", -- [3]
					}, -- [10]
					{
						7, -- [1]
						66.658000000054, -- [2]
						"Flames of Punishment |cFFFF3333103,827|r", -- [3]
					}, -- [11]
					{
						12, -- [1]
						66.1609999999637, -- [2]
						"Flames of Punishment |cFFFF333391,016|r", -- [3]
					}, -- [12]
					{
						14, -- [1]
						213.560000000056, -- [2]
						"Volatile Charge |cFFFF333340,921|r", -- [3]
					}, -- [13]
				},
				["class"] = "WARLOCK",
			},
			["Metó"] = {
				["encounters"] = 6,
				["points"] = 590,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						3, -- [1]
						407.847999999998, -- [2]
						"Liquid Gold |cFFFF333378,850|r", -- [3]
					}, -- [1]
				},
			},
			["Neferupitou"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Qyix"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["encounters"] = 80,
				["points"] = 7980,
				["deaths"] = {
					{
						5, -- [1]
						69.9409999999916, -- [2]
						"Volatile Charge |cFFFF333397,112|r", -- [3]
					}, -- [1]
					{
						33, -- [1]
						51.2619999999879, -- [2]
						"Volatile Charge |cFFFF333391,964|r", -- [3]
					}, -- [2]
				},
				["class"] = "SHAMAN",
			},
			["Môdox"] = {
				["encounters"] = 80,
				["points"] = 7970,
				["deaths"] = {
					{
						2, -- [1]
						131.842000000004, -- [2]
						"Flames of Punishment |cFFFF333366,875|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						97.8759999999893, -- [2]
						"Creeping Blaze (DoT) |cFFFF333350,200|r", -- [3]
					}, -- [2]
					{
						34, -- [1]
						92.4479999999749, -- [2]
						"Melee |cFFFF3333150,563|r", -- [3]
					}, -- [3]
				},
				["class"] = "DRUID",
			},
			["Xenadia"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "ROGUE",
				["deaths"] = {
					{
						1, -- [1]
						163.365000000049, -- [2]
						"Flames of Punishment |cFFFF333391,197|r", -- [3]
					}, -- [1]
				},
			},
			["Tyrellan"] = {
				["encounters"] = 6,
				["points"] = 560,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						174.146999999997, -- [2]
						"Deadly Hex (DoT) |cFFFF33333,186|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						89.3439999999828, -- [2]
						"Flames of Punishment |cFFFF3333132,127|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						502.036000000022, -- [2]
						"Coin Shower |cFFFF3333274,253|r", -- [3]
					}, -- [3]
					{
						2, -- [1]
						171.092999999993, -- [2]
						"Deadly Hex (DoT) |cFFFF3333134,997|r", -- [3]
					}, -- [4]
				},
			},
			["Chántý"] = {
				["encounters"] = 63,
				["points"] = 6250,
				["deaths"] = {
					{
						23, -- [1]
						57.3270000000484, -- [2]
						"Volatile Charge |cFFFF333336,423|r", -- [3]
					}, -- [1]
					{
						22, -- [1]
						85.5359999999637, -- [2]
						"Volatile Charge |cFFFF33334,249|r", -- [3]
					}, -- [2]
					{
						29, -- [1]
						65.3759999999311, -- [2]
						"Volatile Charge |cFFFF33336,179|r", -- [3]
					}, -- [3]
					{
						32, -- [1]
						178.319000000018, -- [2]
						"Deadly Hex (DoT) |cFFFF333367,962|r", -- [3]
					}, -- [4]
					{
						35, -- [1]
						201.447000000044, -- [2]
						"Crush |cFFFF333325,987|r", -- [3]
					}, -- [5]
				},
				["class"] = "DRUID",
			},
			["Avaqt"] = {
				["encounters"] = 80,
				["points"] = 7960,
				["deaths"] = {
					{
						7, -- [1]
						136.133000000147, -- [2]
						"Volatile Charge |cFFFF33331,518|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						83.0119999998715, -- [2]
						"Flames of Punishment |cFFFF3333846|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						65.3019999999669, -- [2]
						"Flames of Punishment |cFFFF333384,246|r", -- [3]
					}, -- [3]
					{
						34, -- [1]
						104.601000000024, -- [2]
						"Flames of Punishment |cFFFF333379,248|r", -- [3]
					}, -- [4]
				},
				["class"] = "PALADIN",
			},
			["Bensolo"] = {
				["encounters"] = 57,
				["points"] = 5640,
				["deaths"] = {
					{
						2, -- [1]
						61.6570000001229, -- [2]
						"Flames of Punishment |cFFFF3333141,526|r", -- [3]
					}, -- [1]
					{
						16, -- [1]
						24.6000000000931, -- [2]
						"Flames of Punishment |cFFFF3333146,556|r", -- [3]
					}, -- [2]
					{
						19, -- [1]
						145.927000000142, -- [2]
						"Volatile Charge |cFFFF33339,482|r", -- [3]
					}, -- [3]
					{
						21, -- [1]
						74.2689999998547, -- [2]
						"Volatile Charge |cFFFF3333130,315|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						244.494999999995, -- [2]
						"Flames of Punishment |cFFFF3333137,863|r", -- [3]
					}, -- [5]
					{
						10, -- [1]
						66.6610000000219, -- [2]
						"Volatile Charge |cFFFF3333137,135|r", -- [3]
					}, -- [6]
				},
				["class"] = "MAGE",
			},
			["Yesiam"] = {
				["encounters"] = 80,
				["points"] = 7820,
				["deaths"] = {
					{
						5, -- [1]
						99.8730000001378, -- [2]
						"Flames of Punishment |cFFFF3333104,848|r", -- [3]
					}, -- [1]
					{
						15, -- [1]
						54.2139999999199, -- [2]
						"Crush |cFFFF333329,225|r", -- [3]
					}, -- [2]
					{
						16, -- [1]
						90.8700000001118, -- [2]
						"Crush |cFFFF3333114,189|r", -- [3]
					}, -- [3]
					{
						19, -- [1]
						176.189000000013, -- [2]
						"Deadly Hex (DoT) |cFFFF333348,318|r", -- [3]
					}, -- [4]
					{
						10, -- [1]
						136.035000000033, -- [2]
						"Flames of Punishment |cFFFF333354,953|r", -- [3]
					}, -- [5]
					{
						12, -- [1]
						82.2899999999791, -- [2]
						"Volatile Charge |cFFFF333310,408|r", -- [3]
					}, -- [6]
					{
						13, -- [1]
						73.5, -- [2]
						"Flames of Punishment |cFFFF3333160,621|r", -- [3]
					}, -- [7]
					{
						4, -- [1]
						92.0339999999851, -- [2]
						"Scorching Ground (DoT) |cFFFF333320,428|r", -- [3]
					}, -- [8]
					{
						5, -- [1]
						67.3619999999646, -- [2]
						"Flame Jet (DoT) |cFFFF333354,697|r", -- [3]
					}, -- [9]
					{
						7, -- [1]
						71.2519999999786, -- [2]
						"Flames of Punishment |cFFFF333343,267|r", -- [3]
					}, -- [10]
					{
						8, -- [1]
						175.777999999933, -- [2]
						"Deadly Hex (DoT) |cFFFF333349,196|r", -- [3]
					}, -- [11]
					{
						9, -- [1]
						95.3949999999022, -- [2]
						"Volatile Charge |cFFFF333316,280|r", -- [3]
					}, -- [12]
					{
						16, -- [1]
						200.777000000002, -- [2]
						"Crush |cFFFF333313,938|r", -- [3]
					}, -- [13]
					{
						17, -- [1]
						94.2079999999842, -- [2]
						"Crush |cFFFF333349,361|r", -- [3]
					}, -- [14]
					{
						18, -- [1]
						57.1940000000177, -- [2]
						"Volatile Charge |cFFFF3333113,148|r", -- [3]
					}, -- [15]
					{
						25, -- [1]
						101.962999999989, -- [2]
						"Crush |cFFFF333316,712|r", -- [3]
					}, -- [16]
					{
						33, -- [1]
						46.4139999999898, -- [2]
						"Crush |cFFFF333389,221|r", -- [3]
					}, -- [17]
					{
						35, -- [1]
						50.7900000000373, -- [2]
						"Flame Jet (DoT) |cFFFF333363,068|r", -- [3]
					}, -- [18]
				},
				["class"] = "ROGUE",
			},
			["Daddysenpai"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
		},
	},
	["234215"] = {
		["hash"] = "234215",
		["type"] = "endurance",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Opulence",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["diff"] = 15,
			["id"] = 2271,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Antistit-Shadowsong"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Arenia-TheMaelstrom"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Lilania"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						1, -- [1]
						36.5549999999348, -- [2]
						"Creeping Blaze (DoT) |cFFFF333345,557|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Soely"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Hotarou-Alleria"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Shìnigami"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						33.2960000000894, -- [2]
						"Creeping Blaze (DoT) |cFFFF333395,593|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Lokiboy"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						1, -- [1]
						275.957999999984, -- [2]
						"Flames of Punishment |cFFFF333375,570|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Inánná"] = {
				["encounters"] = 7,
				["points"] = 690,
				["deaths"] = {
					{
						2, -- [1]
						108.842999999877, -- [2]
						"Deadly Hex (DoT) |cFFFF333395,749|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Ragæ-GrimBatol"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						1, -- [1]
						209.418000000063, -- [2]
						"Flames of Punishment |cFFFF3333120,939|r", -- [3]
					}, -- [1]
				},
			},
			["Nakkor-Medivh"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Guldàníel"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						198.529999999999, -- [2]
						"Flames of Punishment |cFFFF3333125,010|r", -- [3]
					}, -- [1]
				},
			},
			["Sukuo-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Kmii"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["encounters"] = 8,
				["points"] = 790,
				["deaths"] = {
					{
						1, -- [1]
						205.296000000031, -- [2]
						"Flames of Punishment |cFFFF333392,476|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Ailbert-Zuluhed"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Aspern"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Schifti"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Jinjewel"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Alleycut"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Mcgubbins-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Seyden"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Wgh-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Slyre"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						155.412000000011, -- [2]
						"Flames of Punishment |cFFFF333371,874|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Nayven"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						1, -- [1]
						93.1429999999236, -- [2]
						"Volatile Charge |cFFFF333388,140|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Chántý"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Ventex"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Barkborkbork-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Xaru"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Wilissa-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Râân"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Schwoop"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Ðecayed-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Härridk"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Dthelianis-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Wystra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Zymosis-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Mêphis"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Chentis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Salanâ"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Slapgodx-Sen'jin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Julietté"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Sangoki"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Soladin-TheMaelstrom"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Qyix"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Isrysa-Ravencrest"] = {
				["encounters"] = 2,
				["points"] = 170,
				["class"] = "DRUID",
				["deaths"] = {
					{
						1, -- [1]
						325.641000000062, -- [2]
						"Molten Gold (DoT) |cFFFF333343,994|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						338.616999999969, -- [2]
						"Wail of Greed |cFFFF3333331,343|r", -- [3]
					}, -- [2]
				},
			},
			["Kindralia"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Рукарынка-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Bhaírava"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Elîn-DunModr"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Ariaelth-BurningLegion"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Andromaché"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Làika"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Darkladyii-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Moudii-Nordrassil"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Raineth-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Rusell"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						357.249000000011, -- [2]
						"Coin Shower |cFFFF3333470,534|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Laki"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Khromatian"] = {
				["encounters"] = 4,
				["points"] = 400,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Faye-Dalaran"] = {
				["encounters"] = 2,
				["points"] = 170,
				["deaths"] = {
					{
						3, -- [1]
						97.4430000000866, -- [2]
						"Volatile Charge |cFFFF333313,488|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						169.194000000018, -- [2]
						"Scorching Ground (DoT) |cFFFF33333,230|r", -- [3]
					}, -- [2]
				},
				["class"] = "MAGE",
			},
			["Keya-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Janissen-Nagrand"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Viste-ZirkeldesCenarius"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						204.089000000036, -- [2]
						"Flames of Punishment |cFFFF333394,486|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Kirgit"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Илюфа-Разувий"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Tyrellan"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Metó"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Hardcorë-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Sefa-Blade'sEdge"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Petîtefleur-KhazModan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Thelyssa-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Vave-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Vanadín-Magtheridon"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						3, -- [1]
						97.4930000000168, -- [2]
						"Scorching Ground (DoT) |cFFFF333336,411|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Yesiam"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Obídos"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
		},
	},
	["233516"] = {
		["hash"] = "233516",
		["type"] = "endurance",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2272,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "King Rastakhan",
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 23,
				["points"] = 2280,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						54.640000000014, -- [2]
						"Scorching Detonation |cFFFF333390,843|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						345.829000000027, -- [2]
						"Plague of Fire |cFFFF333339,681|r", -- [3]
					}, -- [2]
				},
			},
			["Aspern"] = {
				["encounters"] = 23,
				["points"] = 2280,
				["class"] = "MAGE",
				["deaths"] = {
					{
						9, -- [1]
						296.104999999996, -- [2]
						"Dread Reaping (DoT) |cFFFF333358,253|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						188.932000000001, -- [2]
						"Halo |cFFFF33332,133|r", -- [3]
					}, -- [2]
				},
			},
			["Andromaché"] = {
				["encounters"] = 23,
				["points"] = 2290,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						2, -- [1]
						38.5910000000004, -- [2]
						"Grievous Axe |cFFFF333322,318|r", -- [3]
					}, -- [1]
				},
			},
			["Isery"] = {
				["encounters"] = 23,
				["points"] = 2290,
				["class"] = "DRUID",
				["deaths"] = {
					{
						2, -- [1]
						21.8619999999937, -- [2]
						"Meteor Leap |cFFFF3333260,773|r", -- [3]
					}, -- [1]
				},
			},
			["Härridk"] = {
				["encounters"] = 12,
				["points"] = 1180,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						7, -- [1]
						264.534, -- [2]
						"Withering Burst |cFFFF333314,488|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						181.091, -- [2]
						"Toad Toxin (DoT) |cFFFF333384,114|r", -- [3]
					}, -- [2]
				},
			},
			["Salanâ"] = {
				["encounters"] = 23,
				["points"] = 2260,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						36.2519999999786, -- [2]
						"Seal of Purification |cFFFF333339,415|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						234.928999999989, -- [2]
						"Melee |cFFFF3333106,960|r", -- [3]
					}, -- [2]
					{
						12, -- [1]
						31.5230000000011, -- [2]
						"Scorching Detonation |cFFFF333384,482|r", -- [3]
					}, -- [3]
					{
						4, -- [1]
						257.290000000001, -- [2]
						"Deathly Withering (DoT) |cFFFF333334,527|r", -- [3]
					}, -- [4]
				},
			},
			["Metó"] = {
				["encounters"] = 23,
				["points"] = 2300,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 12,
				["points"] = 1180,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						3, -- [1]
						265.078999999998, -- [2]
						"Withering Burst |cFFFF33334,095|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						31.9320000000007, -- [2]
						"Grievous Axe |cFFFF33338,604|r", -- [3]
					}, -- [2]
				},
			},
			["Inánná"] = {
				["encounters"] = 6,
				["points"] = 580,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						1, -- [1]
						271.962, -- [2]
						"Withering Burst |cFFFF333312,160|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						38, -- [2]
						"Seal of Purification (DoT) |cFFFF333333,940|r", -- [3]
					}, -- [2]
				},
			},
			["Almîna"] = {
				["encounters"] = 23,
				["points"] = 2290,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						10, -- [1]
						249.774000000005, -- [2]
						"Dread Reaping (DoT) |cFFFF333354,850|r", -- [3]
					}, -- [1]
				},
			},
			["Supersunny"] = {
				["encounters"] = 28,
				["points"] = 2480,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						2, -- [1]
						37.5200000000186, -- [2]
						"Melee |cFFFF333335,913|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						183.041000000027, -- [2]
						"Deathly Withering (DoT) |cFFFF333375,288|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						127.065999999992, -- [2]
						"Deathly Withering (DoT) |cFFFF3333143,764|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						184.371000000043, -- [2]
						"Deathly Withering (DoT) |cFFFF3333103,310|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						182.630000000005, -- [2]
						"Caress of Death |cFFFF333360,423|r", -- [3]
					}, -- [5]
					{
						2, -- [1]
						36.4250000000029, -- [2]
						"Melee |cFFFF333355,612|r", -- [3]
					}, -- [6]
					{
						3, -- [1]
						189.501999999993, -- [2]
						"Deathly Withering (DoT) |cFFFF333380,538|r", -- [3]
					}, -- [7]
					{
						3, -- [1]
						234.054999999993, -- [2]
						"Withering Burst |cFFFF333312,195|r", -- [3]
					}, -- [8]
					{
						4, -- [1]
						193.596999999994, -- [2]
						"Deathly Withering (DoT) |cFFFF333398,907|r", -- [3]
					}, -- [9]
					{
						4, -- [1]
						219.562000000005, -- [2]
						"Deathly Withering (DoT) |cFFFF333346,297|r", -- [3]
					}, -- [10]
					{
						5, -- [1]
						59.9649999999965, -- [2]
						"Melee |cFFFF3333141,680|r", -- [3]
					}, -- [11]
					{
						6, -- [1]
						190.915999999997, -- [2]
						"Deathly Withering (DoT) |cFFFF333336,236|r", -- [3]
					}, -- [12]
					{
						7, -- [1]
						104.760999999999, -- [2]
						"Deathly Withering (DoT) |cFFFF333329,696|r", -- [3]
					}, -- [13]
					{
						7, -- [1]
						191.785000000004, -- [2]
						"Deathly Withering (DoT) |cFFFF3333116,786|r", -- [3]
					}, -- [14]
					{
						8, -- [1]
						192.788, -- [2]
						"Melee |cFFFF333327,609|r", -- [3]
					}, -- [15]
					{
						9, -- [1]
						190.555999999997, -- [2]
						"Melee |cFFFF333334,086|r", -- [3]
					}, -- [16]
					{
						10, -- [1]
						185.65400000001, -- [2]
						"Melee |cFFFF333368,773|r", -- [3]
					}, -- [17]
					{
						11, -- [1]
						38.2869999999966, -- [2]
						"Melee |cFFFF333386,845|r", -- [3]
					}, -- [18]
					{
						13, -- [1]
						191.264999999999, -- [2]
						"Deathly Withering (DoT) |cFFFF333341,265|r", -- [3]
					}, -- [19]
					{
						13, -- [1]
						213.315999999992, -- [2]
						"Deathly Withering (DoT) |cFFFF333368,553|r", -- [3]
					}, -- [20]
					{
						1, -- [1]
						189.144, -- [2]
						"Deathly Withering (DoT) |cFFFF333389,905|r", -- [3]
					}, -- [21]
					{
						2, -- [1]
						191.917999999998, -- [2]
						"Melee |cFFFF33338,945|r", -- [3]
					}, -- [22]
					{
						3, -- [1]
						192.837, -- [2]
						"Deathly Withering (DoT) |cFFFF3333141,123|r", -- [3]
					}, -- [23]
					{
						3, -- [1]
						246.154000000002, -- [2]
						"Melee |cFFFF333370,633|r", -- [3]
					}, -- [24]
					{
						4, -- [1]
						192.095999999998, -- [2]
						"Deathly Withering (DoT) |cFFFF3333107,460|r", -- [3]
					}, -- [25]
					{
						5, -- [1]
						183.936000000002, -- [2]
						"Melee |cFFFF333315,796|r", -- [3]
					}, -- [26]
					{
						6, -- [1]
						197.837, -- [2]
						"Deathly Withering (DoT) |cFFFF333388,803|r", -- [3]
					}, -- [27]
				},
			},
			["Samîsu"] = {
				["encounters"] = 23,
				["points"] = 2280,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						1, -- [1]
						272.546999999999, -- [2]
						"Withering Burst |cFFFF333318,172|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						315.434000000001, -- [2]
						"Scorching Detonation |cFFFF333365,272|r", -- [3]
					}, -- [2]
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 11,
				["points"] = 1090,
				["class"] = "MONK",
				["deaths"] = {
					{
						4, -- [1]
						139.023999999976, -- [2]
						"Melee |cFFFF333386,779|r", -- [3]
					}, -- [1]
				},
			},
			["Neferupitou"] = {
				["encounters"] = 23,
				["points"] = 2260,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						6, -- [1]
						301.995999999999, -- [2]
						"Deathly Withering (DoT) |cFFFF333327,486|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						258.886999999988, -- [2]
						"Deathly Withering (DoT) |cFFFF333341,586|r", -- [3]
					}, -- [2]
					{
						11, -- [1]
						31.7350000000006, -- [2]
						"Toad Toxin (DoT) |cFFFF333314,898|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						247.061999999998, -- [2]
						"Dread Reaping (DoT) |cFFFF333367,436|r", -- [3]
					}, -- [4]
				},
			},
			["Tyrellan"] = {
				["encounters"] = 6,
				["points"] = 590,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						296.188999999999, -- [2]
						"Withering Burst |cFFFF333314,089|r", -- [3]
					}, -- [1]
				},
			},
			["Soely"] = {
				["encounters"] = 24,
				["points"] = 2360,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						5, -- [1]
						259.581999999995, -- [2]
						"Deathly Withering (DoT) |cFFFF333324,708|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						10.7280000000028, -- [2]
						"Seal of Purification (DoT) |cFFFF33335,380|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						180.088000000003, -- [2]
						"Scorching Detonation |cFFFF333374,711|r", -- [3]
					}, -- [3]
				},
			},
			["Kalissta"] = {
				["encounters"] = 23,
				["points"] = 2280,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						182.812000000034, -- [2]
						"Deathly Withering (DoT) |cFFFF333361,491|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						101.131999999998, -- [2]
						"Melee |cFFFF333345,198|r", -- [3]
					}, -- [2]
				},
			},
			["Nelwyn"] = {
				["encounters"] = 23,
				["points"] = 2260,
				["class"] = "DRUID",
				["deaths"] = {
					{
						5, -- [1]
						247.561000000045, -- [2]
						"Deathly Withering (DoT) |cFFFF333323,830|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						37.1880000000238, -- [2]
						"Seal of Purification (DoT) |cFFFF33332,505|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						21.3389999999927, -- [2]
						"Meteor Leap |cFFFF3333253,380|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						247.307000000001, -- [2]
						"Dread Reaping (DoT) |cFFFF333318,306|r", -- [3]
					}, -- [4]
				},
			},
			["Artèmis"] = {
				["encounters"] = 23,
				["points"] = 2290,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						10, -- [1]
						253.40400000001, -- [2]
						"Plague of Fire |cFFFF333350,214|r", -- [3]
					}, -- [1]
				},
			},
			["Laki"] = {
				["encounters"] = 23,
				["points"] = 2280,
				["class"] = "DRUID",
				["deaths"] = {
					{
						3, -- [1]
						182.812000000034, -- [2]
						"Scorching Detonation |cFFFF3333113,833|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						77.7229999999981, -- [2]
						"Scorching Detonation |cFFFF3333111,493|r", -- [3]
					}, -- [2]
				},
			},
			["Xaru"] = {
				["encounters"] = 17,
				["points"] = 1680,
				["class"] = "MAGE",
				["deaths"] = {
					{
						4, -- [1]
						30.5740000000224, -- [2]
						"Scorching Detonation |cFFFF333348,024|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						299.191000000006, -- [2]
						"Dread Reaping (DoT) |cFFFF333347,808|r", -- [3]
					}, -- [2]
				},
			},
			["Qyix"] = {
				["encounters"] = 24,
				["points"] = 2360,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						5, -- [1]
						21.406999999992, -- [2]
						"Meteor Leap |cFFFF3333250,660|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						54.9959999999992, -- [2]
						"Scorching Detonation |cFFFF333352,527|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						312.800999999992, -- [2]
						"Seal of Bwonsamdi |cFFFF333369,457|r", -- [3]
					}, -- [3]
				},
			},
			["Alleycut"] = {
				["encounters"] = 23,
				["points"] = 2300,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
		},
		["diff"] = 16,
	},
	["233316"] = {
		["hash"] = "233316",
		["type"] = "endurance",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 10,
				["points"] = 960,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						203.006999999983, -- [2]
						"Fireball |cFFFF333344,107|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						302.837999999989, -- [2]
						"Searing Peck |cFFFF333367,598|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						315.370999999985, -- [2]
						"Bestial Impact |cFFFF3333136,450|r", -- [3]
					}, -- [3]
				},
			},
			["Râân"] = {
				["encounters"] = 10,
				["points"] = 980,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						5, -- [1]
						225.639000000025, -- [2]
						"Melee |cFFFF3333115,353|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						242.252999999968, -- [2]
						"Bestial Smash |cFFFF3333473,027|r", -- [3]
					}, -- [2]
				},
			},
			["Laki"] = {
				["encounters"] = 9,
				["points"] = 900,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 110,
				["points"] = 10800,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						3, -- [1]
						140.817000000039, -- [2]
						"Retribution Wave |cFFFF333329,473|r", -- [3]
					}, -- [1]
					{
						13, -- [1]
						38.7439999999478, -- [2]
						"Burnout |cFFFF333345,283|r", -- [3]
					}, -- [2]
					{
						15, -- [1]
						68.85699999996, -- [2]
						"Unleashed Ember |cFFFF333326,473|r", -- [3]
					}, -- [3]
					{
						19, -- [1]
						73.189000000013, -- [2]
						"Beam (DoT) |cFFFF333390,270|r", -- [3]
					}, -- [4]
					{
						27, -- [1]
						105.73900000006, -- [2]
						"Whirling Jade Storm |cFFFF333319,753|r", -- [3]
					}, -- [5]
					{
						28, -- [1]
						113.528000000049, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,252|r", -- [3]
					}, -- [6]
					{
						5, -- [1]
						35.8659999999218, -- [2]
						"", -- [3]
					}, -- [7]
					{
						7, -- [1]
						112.847000000067, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,251|r", -- [3]
					}, -- [8]
					{
						3, -- [1]
						93.810999999987, -- [2]
						"Bestial Impact |cFFFF333368,808|r", -- [3]
					}, -- [9]
					{
						3, -- [1]
						112.77099999995, -- [2]
						"Death Knell |cFFFF333364,040|r", -- [3]
					}, -- [10]
					{
						4, -- [1]
						67.2229999999981, -- [2]
						"Voodoo Blast |cFFFF333319,178|r", -- [3]
					}, -- [11]
					{
						8, -- [1]
						72.7899999998044, -- [2]
						"Chill of Death (DoT) |cFFFF333332,037|r", -- [3]
					}, -- [12]
					{
						19, -- [1]
						158.601000000024, -- [2]
						"Voodoo Blast |cFFFF333359,527|r", -- [3]
					}, -- [13]
					{
						21, -- [1]
						184.368999999948, -- [2]
						"Chill of Death (DoT) |cFFFF333339,978|r", -- [3]
					}, -- [14]
					{
						4, -- [1]
						78.3830000001472, -- [2]
						"Burnout |cFFFF333322,881|r", -- [3]
					}, -- [15]
					{
						1, -- [1]
						71.8170000000391, -- [2]
						"Chill of Death (DoT) |cFFFF333315,682|r", -- [3]
					}, -- [16]
					{
						8, -- [1]
						158.459999999963, -- [2]
						"Chill of Death (DoT) |cFFFF333322,848|r", -- [3]
					}, -- [17]
					{
						4, -- [1]
						182.622000000003, -- [2]
						"Flash |cFFFF33338,362|r", -- [3]
					}, -- [18]
					{
						10, -- [1]
						284.369999999995, -- [2]
						"Chill of Death (DoT) |cFFFF333323,549|r", -- [3]
					}, -- [19]
				},
			},
			["Whyalwaysme"] = {
				["encounters"] = 66,
				["points"] = 6400,
				["class"] = "MONK",
				["deaths"] = {
					{
						4, -- [1]
						142.070000000065, -- [2]
						"Retribution Wave |cFFFF333320,223|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						47.3319999999367, -- [2]
						"Environment (Falling) |cFFFF3333219,400|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						78.4150000000373, -- [2]
						"Beam (DoT) |cFFFF333354,243|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						76.7910000000848, -- [2]
						"Beam (DoT) |cFFFF333344,071|r", -- [3]
					}, -- [4]
					{
						18, -- [1]
						48.7930000000633, -- [2]
						"Environment (Falling) |cFFFF3333219,400|r", -- [3]
					}, -- [5]
					{
						21, -- [1]
						153.391999999993, -- [2]
						"Environment (Falling) |cFFFF3333219,400|r", -- [3]
					}, -- [6]
					{
						22, -- [1]
						112.729999999981, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,186|r", -- [3]
					}, -- [7]
					{
						1, -- [1]
						84.7739999999758, -- [2]
						"Divine Mallet |cFFFF33332,302|r", -- [3]
					}, -- [8]
					{
						1, -- [1]
						100.949999999953, -- [2]
						"Environment (Falling) |cFFFF3333224,360|r", -- [3]
					}, -- [9]
					{
						3, -- [1]
						144.910000000149, -- [2]
						"Environment (Falling) |cFFFF3333224,360|r", -- [3]
					}, -- [10]
					{
						6, -- [1]
						97.064000000013, -- [2]
						"Environment (Falling) |cFFFF3333224,360|r", -- [3]
					}, -- [11]
					{
						4, -- [1]
						177.362999999896, -- [2]
						"Death Knell |cFFFF333382,729|r", -- [3]
					}, -- [12]
					{
						1, -- [1]
						128.377, -- [2]
						"Divine Mallet |cFFFF333316,220|r", -- [3]
					}, -- [13]
					{
						1, -- [1]
						94.0030000000043, -- [2]
						"Burnout |cFFFF333327,997|r", -- [3]
					}, -- [14]
					{
						3, -- [1]
						179.685999999994, -- [2]
						"Environment (Falling) |cFFFF3333314,280|r", -- [3]
					}, -- [15]
					{
						3, -- [1]
						62.0279999999984, -- [2]
						"Rending Bite |cFFFF333339,821|r", -- [3]
					}, -- [16]
					{
						6, -- [1]
						155.182999999997, -- [2]
						"Bestial Impact |cFFFF333389,535|r", -- [3]
					}, -- [17]
					{
						10, -- [1]
						86.8979999999938, -- [2]
						"Rending Bite |cFFFF333313,693|r", -- [3]
					}, -- [18]
					{
						11, -- [1]
						158.471999999994, -- [2]
						"Rending Bite |cFFFF333341,349|r", -- [3]
					}, -- [19]
					{
						12, -- [1]
						156.302000000003, -- [2]
						"Rending Bite |cFFFF333315,863|r", -- [3]
					}, -- [20]
				},
			},
			["Soely"] = {
				["encounters"] = 9,
				["points"] = 890,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						195.923999999999, -- [2]
						"", -- [3]
					}, -- [1]
				},
			},
			["Shìnigami"] = {
				["encounters"] = 118,
				["points"] = 11720,
				["class"] = "MAGE",
				["deaths"] = {
					{
						2, -- [1]
						112.778999999864, -- [2]
						"Searing Embers (DoT) |cFFFF333315,920|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						71.594000000041, -- [2]
						"Chill of Death (DoT) |cFFFF333326,286|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						133.700999999885, -- [2]
						"Wave of Light (DoT) |cFFFF333323,312|r", -- [3]
					}, -- [3]
					{
						3, -- [1]
						143.453999999911, -- [2]
						"Divine Mallet |cFFFF333361,724|r", -- [3]
					}, -- [4]
					{
						2, -- [1]
						66.2449999998789, -- [2]
						"Necrotic Core (DoT) |cFFFF333313,358|r", -- [3]
					}, -- [5]
					{
						7, -- [1]
						160.375999999931, -- [2]
						"Chill of Death (DoT) |cFFFF333324,333|r", -- [3]
					}, -- [6]
					{
						9, -- [1]
						78.3570000000036, -- [2]
						"Deathly Echo |cFFFF3333134,056|r", -- [3]
					}, -- [7]
					{
						1, -- [1]
						135.807999999961, -- [2]
						"Divine Mallet |cFFFF333351,564|r", -- [3]
					}, -- [8]
				},
			},
			["Ðaisuke"] = {
				["encounters"] = 9,
				["points"] = 880,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						32.6270000000077, -- [2]
						"Divine Mallet |cFFFF33338,647|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						148.56700000001, -- [2]
						"Magma Trap |cFFFF3333203,157|r", -- [3]
					}, -- [2]
				},
			},
			["Avaqt"] = {
				["encounters"] = 119,
				["points"] = 11750,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						4, -- [1]
						91.8190000000177, -- [2]
						"Judgment: Reckoning |cFFFF333347,923|r", -- [3]
					}, -- [1]
					{
						14, -- [1]
						113.936999999918, -- [2]
						"Searing Embers (DoT) |cFFFF333316,175|r", -- [3]
					}, -- [2]
					{
						16, -- [1]
						125.381999999983, -- [2]
						"Beam (DoT) |cFFFF333370,052|r", -- [3]
					}, -- [3]
					{
						17, -- [1]
						111.837999999989, -- [2]
						"Blessing of Sacrifice |cFFFF33331,821|r", -- [3]
					}, -- [4]
					{
						24, -- [1]
						114.70000000007, -- [2]
						"Blessing of Sacrifice |cFFFF33332,271|r", -- [3]
					}, -- [5]
					{
						5, -- [1]
						36.0260000000708, -- [2]
						"Unleashed Ember |cFFFF333364,699|r", -- [3]
					}, -- [6]
					{
						5, -- [1]
						178.412000000011, -- [2]
						"Phoenix Strike |cFFFF333331,116|r", -- [3]
					}, -- [7]
					{
						4, -- [1]
						161.130000000121, -- [2]
						"Deathly Slam |cFFFF333358,296|r", -- [3]
					}, -- [8]
					{
						6, -- [1]
						77.4969999999739, -- [2]
						"Deathly Echo |cFFFF3333168,272|r", -- [3]
					}, -- [9]
					{
						8, -- [1]
						107.270000000019, -- [2]
						"Deathly Echo |cFFFF3333137,851|r", -- [3]
					}, -- [10]
					{
						4, -- [1]
						214.462000000007, -- [2]
						"Flash |cFFFF333312,951|r", -- [3]
					}, -- [11]
					{
						1, -- [1]
						107.815999999999, -- [2]
						"Ferocious Roar |cFFFF333351,454|r", -- [3]
					}, -- [12]
					{
						10, -- [1]
						77.9119999999966, -- [2]
						"Deathly Echo |cFFFF3333111,387|r", -- [3]
					}, -- [13]
					{
						9, -- [1]
						194.699000000022, -- [2]
						"Deathly Echo |cFFFF3333151,358|r", -- [3]
					}, -- [14]
				},
			},
			["Inánná"] = {
				["encounters"] = 127,
				["points"] = 12510,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						2, -- [1]
						77.5520000000252, -- [2]
						"Beam (DoT) |cFFFF333376,067|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						102.88599999994, -- [2]
						"Burnout |cFFFF333360,996|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						35.530999999959, -- [2]
						"Fireball |cFFFF333361,199|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						38.5500000000466, -- [2]
						"Multi-Sided Strike |cFFFF333332,042|r", -- [3]
					}, -- [4]
					{
						1, -- [1]
						63.4860000000335, -- [2]
						"Death Knell |cFFFF333352,313|r", -- [3]
					}, -- [5]
					{
						11, -- [1]
						158.47900000005, -- [2]
						"Voodoo Blast |cFFFF333345,254|r", -- [3]
					}, -- [6]
					{
						16, -- [1]
						18.7760000000708, -- [2]
						"Deathly Echo |cFFFF3333158,345|r", -- [3]
					}, -- [7]
					{
						1, -- [1]
						107.210999999894, -- [2]
						"Unleashed Ember |cFFFF333319,467|r", -- [3]
					}, -- [8]
					{
						6, -- [1]
						119.242000000086, -- [2]
						"Death Knell |cFFFF333399,536|r", -- [3]
					}, -- [9]
					{
						11, -- [1]
						58.4169999998994, -- [2]
						"Death Knell |cFFFF333379,554|r", -- [3]
					}, -- [10]
					{
						2, -- [1]
						135.718999999997, -- [2]
						"Burnout |cFFFF3333116,393|r", -- [3]
					}, -- [11]
					{
						1, -- [1]
						34.8420000000042, -- [2]
						"Ferocious Roar |cFFFF333353,233|r", -- [3]
					}, -- [12]
					{
						4, -- [1]
						119.565000000002, -- [2]
						"Death Knell |cFFFF3333104,056|r", -- [3]
					}, -- [13]
					{
						8, -- [1]
						244.461000000003, -- [2]
						"Death Knell |cFFFF333378,173|r", -- [3]
					}, -- [14]
					{
						4, -- [1]
						60.5250000000233, -- [2]
						"Death Knell |cFFFF333390,361|r", -- [3]
					}, -- [15]
					{
						7, -- [1]
						119.236000000034, -- [2]
						"Death Knell |cFFFF333380,874|r", -- [3]
					}, -- [16]
					{
						10, -- [1]
						180.565000000002, -- [2]
						"Death Knell |cFFFF333367,459|r", -- [3]
					}, -- [17]
					{
						2, -- [1]
						86.6040000000503, -- [2]
						"Divine Mallet |cFFFF333343,531|r", -- [3]
					}, -- [18]
					{
						3, -- [1]
						72.9349999999395, -- [2]
						"Unleashed Ember |cFFFF333365,649|r", -- [3]
					}, -- [19]
				},
			},
			["Almîna"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						5, -- [1]
						315.370999999985, -- [2]
						"Bestial Impact |cFFFF3333166,371|r", -- [3]
					}, -- [1]
				},
			},
			["Supersunny"] = {
				["encounters"] = 9,
				["points"] = 890,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						5, -- [1]
						167.097000000009, -- [2]
						"Melee |cFFFF333399,360|r", -- [3]
					}, -- [1]
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Mêphis"] = {
				["encounters"] = 86,
				["points"] = 8370,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						6, -- [1]
						39.1499999999069, -- [2]
						"Fireball |cFFFF33334,856|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						88.7719999999972, -- [2]
						"Beam (DoT) |cFFFF333338,500|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						90.0810000000056, -- [2]
						"Melee |cFFFF333324,486|r", -- [3]
					}, -- [3]
					{
						14, -- [1]
						99.7649999998976, -- [2]
						"Beam (DoT) |cFFFF333358,026|r", -- [3]
					}, -- [4]
					{
						17, -- [1]
						100.201000000001, -- [2]
						"Beam (DoT) |cFFFF33331|r", -- [3]
					}, -- [5]
					{
						18, -- [1]
						103.371000000043, -- [2]
						"Rising Flames (DoT) |cFFFF33331|r", -- [3]
					}, -- [6]
					{
						5, -- [1]
						126.115999999922, -- [2]
						"Melee |cFFFF333340,877|r", -- [3]
					}, -- [7]
					{
						8, -- [1]
						73.1739999998827, -- [2]
						"Melee |cFFFF333331,458|r", -- [3]
					}, -- [8]
					{
						8, -- [1]
						113.466999999946, -- [2]
						"Rising Flames (DoT) |cFFFF333311,909|r", -- [3]
					}, -- [9]
					{
						7, -- [1]
						126.412999999942, -- [2]
						"Melee |cFFFF3333124,195|r", -- [3]
					}, -- [10]
					{
						13, -- [1]
						160.439000000013, -- [2]
						"Rending Bite |cFFFF33339,416|r", -- [3]
					}, -- [11]
					{
						13, -- [1]
						220.096000000136, -- [2]
						"Bestial Impact |cFFFF3333134,737|r", -- [3]
					}, -- [12]
					{
						14, -- [1]
						162.708000000101, -- [2]
						"Melee |cFFFF3333110,458|r", -- [3]
					}, -- [13]
					{
						16, -- [1]
						64.5220000001136, -- [2]
						"Bestial Impact |cFFFF3333152,582|r", -- [3]
					}, -- [14]
					{
						18, -- [1]
						92.3190000001341, -- [2]
						"Bestial Throw |cFFFF33331,084|r", -- [3]
					}, -- [15]
					{
						20, -- [1]
						159.369999999879, -- [2]
						"Rending Bite |cFFFF333316,936|r", -- [3]
					}, -- [16]
					{
						21, -- [1]
						146.652000000002, -- [2]
						"Bestial Smash |cFFFF3333318,250|r", -- [3]
					}, -- [17]
					{
						21, -- [1]
						166.209000000032, -- [2]
						"Melee |cFFFF333369,163|r", -- [3]
					}, -- [18]
					{
						4, -- [1]
						102.636000000173, -- [2]
						"Melee |cFFFF333350,213|r", -- [3]
					}, -- [19]
					{
						1, -- [1]
						229.422999999952, -- [2]
						"Melee |cFFFF3333123,158|r", -- [3]
					}, -- [20]
				},
			},
			["Chentis"] = {
				["encounters"] = 77,
				["points"] = 7580,
				["class"] = "MAGE",
				["deaths"] = {
					{
						1, -- [1]
						38.2319999998435, -- [2]
						"Unleashed Ember |cFFFF333368,607|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						114.253999999957, -- [2]
						"Death Touched (DoT) |cFFFF33336,033|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						39.5949999999721, -- [2]
						"Chill of Death (DoT) |cFFFF333325,573|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						72.190000000177, -- [2]
						"Death Knell |cFFFF333384,187|r", -- [3]
					}, -- [4]
					{
						7, -- [1]
						49.2590000000782, -- [2]
						"Deathly Echo |cFFFF3333114,137|r", -- [3]
					}, -- [5]
					{
						10, -- [1]
						87.2629999998026, -- [2]
						"Death Knell |cFFFF333333,764|r", -- [3]
					}, -- [6]
					{
						15, -- [1]
						95, -- [2]
						"Death Touched (DoT) |cFFFF33331,199|r", -- [3]
					}, -- [7]
					{
						2, -- [1]
						18.2199999999721, -- [2]
						"Deathly Echo |cFFFF333343,129|r", -- [3]
					}, -- [8]
					{
						10, -- [1]
						278.083999999799, -- [2]
						"Ferocious Roar |cFFFF333310,954|r", -- [3]
					}, -- [9]
					{
						11, -- [1]
						58.4169999998994, -- [2]
						"Death Knell |cFFFF333365,205|r", -- [3]
					}, -- [10]
					{
						3, -- [1]
						186.690000000177, -- [2]
						"Death Knell |cFFFF3333106,196|r", -- [3]
					}, -- [11]
					{
						4, -- [1]
						301.861999999965, -- [2]
						"Death Knell |cFFFF333397,300|r", -- [3]
					}, -- [12]
				},
			},
			["Viste"] = {
				["encounters"] = 13,
				["points"] = 1300,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Artèmis"] = {
				["encounters"] = 129,
				["points"] = 12590,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						2, -- [1]
						154.581000000006, -- [2]
						"Wave of Light (DoT) |cFFFF333346,986|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						107.393999999971, -- [2]
						"Unleashed Ember |cFFFF333343,786|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						107.335000000079, -- [2]
						"Unleashed Ember |cFFFF333334,532|r", -- [3]
					}, -- [3]
					{
						7, -- [1]
						36.6319999999832, -- [2]
						"Multi-Sided Strike |cFFFF333360,630|r", -- [3]
					}, -- [4]
					{
						7, -- [1]
						36.6319999999832, -- [2]
						"", -- [3]
					}, -- [5]
					{
						8, -- [1]
						96.0080000000308, -- [2]
						"Magma Trap |cFFFF3333121,290|r", -- [3]
					}, -- [6]
					{
						9, -- [1]
						90.1530000000494, -- [2]
						"Burnout |cFFFF333365,558|r", -- [3]
					}, -- [7]
					{
						10, -- [1]
						33.8869999999879, -- [2]
						"Multi-Sided Strike |cFFFF333389,249|r", -- [3]
					}, -- [8]
					{
						10, -- [1]
						33.8869999999879, -- [2]
						"", -- [3]
					}, -- [9]
					{
						12, -- [1]
						39.4119999998948, -- [2]
						"Magma Trap |cFFFF3333125,644|r", -- [3]
					}, -- [10]
					{
						15, -- [1]
						68.85699999996, -- [2]
						"Unleashed Ember |cFFFF333355,495|r", -- [3]
					}, -- [11]
					{
						23, -- [1]
						147.347999999998, -- [2]
						"Burnout |cFFFF3333104,048|r", -- [3]
					}, -- [12]
					{
						24, -- [1]
						114.70000000007, -- [2]
						"Multi-Sided Strike |cFFFF333389,226|r", -- [3]
					}, -- [13]
					{
						1, -- [1]
						19.0080000001472, -- [2]
						"Deathly Echo |cFFFF3333157,560|r", -- [3]
					}, -- [14]
					{
						2, -- [1]
						71.2749999999069, -- [2]
						"Death Knell |cFFFF333345,145|r", -- [3]
					}, -- [15]
					{
						4, -- [1]
						67.4860000000335, -- [2]
						"Death Knell |cFFFF333367,444|r", -- [3]
					}, -- [16]
					{
						19, -- [1]
						118.945000000065, -- [2]
						"Death Knell |cFFFF333388,366|r", -- [3]
					}, -- [17]
					{
						1, -- [1]
						145.892999999924, -- [2]
						"Wave of Light (DoT) |cFFFF333333,084|r", -- [3]
					}, -- [18]
					{
						10, -- [1]
						301.608999999939, -- [2]
						"Death Knell |cFFFF3333104,222|r", -- [3]
					}, -- [19]
					{
						1, -- [1]
						282.861999999965, -- [2]
						"Death Touched (DoT) |cFFFF33331,277|r", -- [3]
					}, -- [20]
					{
						4, -- [1]
						301.861999999965, -- [2]
						"Death Knell |cFFFF333347,335|r", -- [3]
					}, -- [21]
					{
						4, -- [1]
						119.565000000002, -- [2]
						"Death Knell |cFFFF3333111,003|r", -- [3]
					}, -- [22]
					{
						12, -- [1]
						179.153000000006, -- [2]
						"Death Knell |cFFFF333341,123|r", -- [3]
					}, -- [23]
					{
						7, -- [1]
						119.236000000034, -- [2]
						"Death Knell |cFFFF333340,313|r", -- [3]
					}, -- [24]
					{
						5, -- [1]
						88.4590000000317, -- [2]
						"Burnout |cFFFF333359,529|r", -- [3]
					}, -- [25]
					{
						1, -- [1]
						225.516000000061, -- [2]
						"Chill of Death (DoT) |cFFFF333349,513|r", -- [3]
					}, -- [26]
					{
						2, -- [1]
						200.891999999993, -- [2]
						"Death Knell |cFFFF333375,916|r", -- [3]
					}, -- [27]
					{
						4, -- [1]
						179.847999999998, -- [2]
						"Death Knell |cFFFF3333103,538|r", -- [3]
					}, -- [28]
					{
						2, -- [1]
						32.6270000000077, -- [2]
						"Divine Mallet |cFFFF333364,285|r", -- [3]
					}, -- [29]
				},
			},
			["Narfnarf"] = {
				["encounters"] = 102,
				["points"] = 10100,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						26, -- [1]
						87.1269999999786, -- [2]
						"Environment (Falling) |cFFFF3333278,425|r", -- [3]
					}, -- [1]
					{
						28, -- [1]
						38.1780000000726, -- [2]
						"", -- [3]
					}, -- [2]
					{
						3, -- [1]
						113.931000000099, -- [2]
						"Searing Embers (DoT) |cFFFF333315,616|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						69.3610000000335, -- [2]
						"Beam (DoT) |cFFFF333369,421|r", -- [3]
					}, -- [4]
					{
						16, -- [1]
						64.8990000002086, -- [2]
						"Death Touched (DoT) |cFFFF33334,775|r", -- [3]
					}, -- [5]
					{
						20, -- [1]
						192.444999999832, -- [2]
						"Death Touched (DoT) |cFFFF33334,110|r", -- [3]
					}, -- [6]
					{
						8, -- [1]
						156.440999999875, -- [2]
						"Ferocious Roar |cFFFF333363,096|r", -- [3]
					}, -- [7]
					{
						9, -- [1]
						244.956999999937, -- [2]
						"Death Knell |cFFFF3333103,099|r", -- [3]
					}, -- [8]
					{
						2, -- [1]
						88.6100000001025, -- [2]
						"Divine Mallet |cFFFF333359,885|r", -- [3]
					}, -- [9]
					{
						1, -- [1]
						97.8159999999916, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33331|r", -- [3]
					}, -- [10]
				},
			},
			["Kindralia"] = {
				["encounters"] = 9,
				["points"] = 900,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Aspern"] = {
				["encounters"] = 9,
				["points"] = 890,
				["class"] = "MAGE",
				["deaths"] = {
					{
						2, -- [1]
						200.891999999993, -- [2]
						"Death Knell |cFFFF333355,414|r", -- [3]
					}, -- [1]
				},
			},
			["Schifti"] = {
				["encounters"] = 118,
				["points"] = 11600,
				["class"] = "MONK",
				["deaths"] = {
					{
						1, -- [1]
						67.5209999999497, -- [2]
						"Pounce |cFFFF333338,799|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						81.5259999999544, -- [2]
						"Beam (DoT) |cFFFF333335,186|r", -- [3]
					}, -- [2]
					{
						14, -- [1]
						113.936999999918, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,258|r", -- [3]
					}, -- [3]
					{
						17, -- [1]
						111.837999999989, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,258|r", -- [3]
					}, -- [4]
					{
						20, -- [1]
						105.402000000002, -- [2]
						"Environment (Falling) |cFFFF3333215,420|r", -- [3]
					}, -- [5]
					{
						26, -- [1]
						72.5849999999628, -- [2]
						"Beam (DoT) |cFFFF333378,169|r", -- [3]
					}, -- [6]
					{
						2, -- [1]
						105.805999999866, -- [2]
						"Environment (Falling) |cFFFF3333272,904|r", -- [3]
					}, -- [7]
					{
						4, -- [1]
						101.08899999992, -- [2]
						"Environment (Falling) |cFFFF3333227,420|r", -- [3]
					}, -- [8]
					{
						17, -- [1]
						237.766999999993, -- [2]
						"Melee |cFFFF3333172,795|r", -- [3]
					}, -- [9]
					{
						18, -- [1]
						76.7330000000075, -- [2]
						"Melee |cFFFF3333215,804|r", -- [3]
					}, -- [10]
					{
						1, -- [1]
						94.747999999905, -- [2]
						"Magma Trap |cFFFF333356,425|r", -- [3]
					}, -- [11]
					{
						5, -- [1]
						145.873000000138, -- [2]
						"Environment (Falling) |cFFFF3333228,260|r", -- [3]
					}, -- [12]
					{
						4, -- [1]
						161.955000000075, -- [2]
						"Chill of Death (DoT) |cFFFF333332,673|r", -- [3]
					}, -- [13]
					{
						5, -- [1]
						170.881000000052, -- [2]
						"Melee |cFFFF333327,360|r", -- [3]
					}, -- [14]
					{
						10, -- [1]
						195.497999999905, -- [2]
						"Ferocious Roar |cFFFF3333438|r", -- [3]
					}, -- [15]
					{
						1, -- [1]
						140.771999999997, -- [2]
						"Melee |cFFFF333341,153|r", -- [3]
					}, -- [16]
					{
						2, -- [1]
						98.2909999999975, -- [2]
						"Melee |cFFFF33338,834|r", -- [3]
					}, -- [17]
					{
						4, -- [1]
						56.6219999999739, -- [2]
						"Bestial Smash |cFFFF3333194,876|r", -- [3]
					}, -- [18]
					{
						10, -- [1]
						284.369999999995, -- [2]
						"Chill of Death (DoT) |cFFFF333315,245|r", -- [3]
					}, -- [19]
					{
						4, -- [1]
						91.5230000000447, -- [2]
						"Environment (Falling) |cFFFF3333234,120|r", -- [3]
					}, -- [20]
				},
			},
			["Andromaché"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["encounters"] = 120,
				["points"] = 11650,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						4, -- [1]
						102.77099999995, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,344|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						39.1139999999432, -- [2]
						"Burnout |cFFFF333359,821|r", -- [3]
					}, -- [2]
					{
						8, -- [1]
						95.9399999999441, -- [2]
						"Burnout |cFFFF333363,340|r", -- [3]
					}, -- [3]
					{
						11, -- [1]
						38.5699999999488, -- [2]
						"Burnout |cFFFF333356,302|r", -- [3]
					}, -- [4]
					{
						13, -- [1]
						79.2089999999153, -- [2]
						"Beam (DoT) |cFFFF333393,765|r", -- [3]
					}, -- [5]
					{
						15, -- [1]
						35.8649999999907, -- [2]
						"", -- [3]
					}, -- [6]
					{
						16, -- [1]
						81.2060000000056, -- [2]
						"Explosion |cFFFF333331,759|r", -- [3]
					}, -- [7]
					{
						21, -- [1]
						115.184000000008, -- [2]
						"Explosion |cFFFF333331,758|r", -- [3]
					}, -- [8]
					{
						25, -- [1]
						38.3800000000047, -- [2]
						"", -- [3]
					}, -- [9]
					{
						25, -- [1]
						69.2430000000168, -- [2]
						"Whirling Jade Storm |cFFFF333321,173|r", -- [3]
					}, -- [10]
					{
						3, -- [1]
						74.997999999905, -- [2]
						"Beam (DoT) |cFFFF333390,951|r", -- [3]
					}, -- [11]
					{
						4, -- [1]
						101.070000000065, -- [2]
						"Magma Trap |cFFFF3333127,442|r", -- [3]
					}, -- [12]
					{
						7, -- [1]
						37.4140000001062, -- [2]
						"", -- [3]
					}, -- [13]
					{
						15, -- [1]
						137.192000000039, -- [2]
						"Voodoo Blast |cFFFF333367,334|r", -- [3]
					}, -- [14]
					{
						17, -- [1]
						223.550999999978, -- [2]
						"Death Touched (DoT) |cFFFF33333,414|r", -- [3]
					}, -- [15]
					{
						19, -- [1]
						158.549000000116, -- [2]
						"Death Touched (DoT) |cFFFF33336,835|r", -- [3]
					}, -- [16]
					{
						4, -- [1]
						111.210000000196, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,302|r", -- [3]
					}, -- [17]
					{
						2, -- [1]
						64.3959999999497, -- [2]
						"Death Touched (DoT) |cFFFF33336,835|r", -- [3]
					}, -- [18]
					{
						5, -- [1]
						175.365999999922, -- [2]
						"Death Knell |cFFFF333387,459|r", -- [3]
					}, -- [19]
					{
						6, -- [1]
						119.185999999987, -- [2]
						"Death Knell |cFFFF333387,458|r", -- [3]
					}, -- [20]
					{
						7, -- [1]
						158.76099999994, -- [2]
						"Death Touched (DoT) |cFFFF33336,719|r", -- [3]
					}, -- [21]
					{
						9, -- [1]
						225.209999999963, -- [2]
						"Ferocious Roar |cFFFF333367,920|r", -- [3]
					}, -- [22]
					{
						11, -- [1]
						58.3559999999125, -- [2]
						"Death Knell |cFFFF333387,458|r", -- [3]
					}, -- [23]
					{
						2, -- [1]
						135.718999999997, -- [2]
						"Pounce |cFFFF333345,487|r", -- [3]
					}, -- [24]
					{
						4, -- [1]
						36.9890000000014, -- [2]
						"Burnout |cFFFF333344,383|r", -- [3]
					}, -- [25]
					{
						8, -- [1]
						244.419000000002, -- [2]
						"Death Knell |cFFFF333387,924|r", -- [3]
					}, -- [26]
					{
						9, -- [1]
						78.3280000000013, -- [2]
						"Death Touched (DoT) |cFFFF33336,755|r", -- [3]
					}, -- [27]
					{
						11, -- [1]
						160.877999999997, -- [2]
						"Death Touched (DoT) |cFFFF33333,880|r", -- [3]
					}, -- [28]
					{
						12, -- [1]
						180.243000000002, -- [2]
						"Death Knell |cFFFF333387,924|r", -- [3]
					}, -- [29]
					{
						7, -- [1]
						119.190000000002, -- [2]
						"Death Knell |cFFFF333387,924|r", -- [3]
					}, -- [30]
					{
						9, -- [1]
						156.269000000029, -- [2]
						"Death Touched (DoT) |cFFFF33336,755|r", -- [3]
					}, -- [31]
					{
						9, -- [1]
						242.309999999998, -- [2]
						"Death Touched (DoT) |cFFFF33336,755|r", -- [3]
					}, -- [32]
					{
						3, -- [1]
						72.9349999999395, -- [2]
						"Unleashed Ember |cFFFF333346,516|r", -- [3]
					}, -- [33]
				},
			},
			["Salanâ"] = {
				["encounters"] = 9,
				["points"] = 880,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						135.321999999986, -- [2]
						"Death Touched |cFFFF33336,963|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						179.847999999998, -- [2]
						"Death Knell |cFFFF333390,626|r", -- [3]
					}, -- [2]
				},
			},
			["Yanaizu"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["encounters"] = 9,
				["points"] = 890,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						200.790999999968, -- [2]
						"Death Knell |cFFFF333365,211|r", -- [3]
					}, -- [1]
				},
			},
			["Metó"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Bensolo"] = {
				["encounters"] = 57,
				["points"] = 5660,
				["deaths"] = {
					{
						3, -- [1]
						112.883000000147, -- [2]
						"Health Exchange |cFFFF33333,257|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						179.967999999994, -- [2]
						"Path of Niuzao (DoT) |cFFFF333324,101|r", -- [3]
					}, -- [2]
					{
						3, -- [1]
						165.482000000018, -- [2]
						"Deathly Echo |cFFFF3333142,335|r", -- [3]
					}, -- [3]
					{
						3, -- [1]
						103.13599999994, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF33332,063|r", -- [3]
					}, -- [4]
				},
				["class"] = "MAGE",
			},
			["Môdox"] = {
				["encounters"] = 121,
				["points"] = 11730,
				["class"] = "DRUID",
				["deaths"] = {
					{
						4, -- [1]
						102.716999999946, -- [2]
						"Fireball |cFFFF333349,754|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						106.631000000052, -- [2]
						"Rising Flames (DoT) |cFFFF33335,273|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						78.734999999986, -- [2]
						"Melee |cFFFF333310,307|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						103.951000000001, -- [2]
						"Fireball |cFFFF333323,586|r", -- [3]
					}, -- [4]
					{
						16, -- [1]
						125.993000000017, -- [2]
						"Fireball |cFFFF33333,100|r", -- [3]
					}, -- [5]
					{
						19, -- [1]
						96.6080000000075, -- [2]
						"Fireball |cFFFF333339,360|r", -- [3]
					}, -- [6]
					{
						24, -- [1]
						94.6659999999683, -- [2]
						"Beam (DoT) |cFFFF333344,247|r", -- [3]
					}, -- [7]
					{
						2, -- [1]
						115.111000000034, -- [2]
						"Rising Flames (DoT) |cFFFF33331,670|r", -- [3]
					}, -- [8]
					{
						9, -- [1]
						113.761000000173, -- [2]
						"Chi-Ji's Song (DoT) |cFFFF3333790|r", -- [3]
					}, -- [9]
					{
						2, -- [1]
						62.3540000000503, -- [2]
						"Rending Bite |cFFFF333373,493|r", -- [3]
					}, -- [10]
					{
						2, -- [1]
						116.706999999937, -- [2]
						"Bestial Smash |cFFFF3333143,077|r", -- [3]
					}, -- [11]
					{
						7, -- [1]
						87.5060000000522, -- [2]
						"Bestial Smash |cFFFF3333350,422|r", -- [3]
					}, -- [12]
					{
						9, -- [1]
						219.803000000073, -- [2]
						"Rending Bite |cFFFF333330,703|r", -- [3]
					}, -- [13]
					{
						14, -- [1]
						148.682999999961, -- [2]
						"Bestial Smash |cFFFF3333257,198|r", -- [3]
					}, -- [14]
					{
						15, -- [1]
						150.704000000143, -- [2]
						"Bestial Smash |cFFFF3333381,033|r", -- [3]
					}, -- [15]
					{
						18, -- [1]
						26.6659999999683, -- [2]
						"Bestial Smash |cFFFF3333379,421|r", -- [3]
					}, -- [16]
					{
						2, -- [1]
						101.558999999892, -- [2]
						"Fireball |cFFFF33339,900|r", -- [3]
					}, -- [17]
					{
						3, -- [1]
						145.003000000026, -- [2]
						"Environment (Falling) |cFFFF3333395,042|r", -- [3]
					}, -- [18]
					{
						6, -- [1]
						114.956999999937, -- [2]
						"Fireball |cFFFF333337,288|r", -- [3]
					}, -- [19]
					{
						1, -- [1]
						24.8000000000466, -- [2]
						"Bestial Smash |cFFFF3333416,194|r", -- [3]
					}, -- [20]
					{
						1, -- [1]
						96.1489999999758, -- [2]
						"Rending Bite |cFFFF333359,403|r", -- [3]
					}, -- [21]
					{
						1, -- [1]
						94.0030000000043, -- [2]
						"Fireball |cFFFF333350,279|r", -- [3]
					}, -- [22]
					{
						1, -- [1]
						88.2909999999975, -- [2]
						"Bestial Smash |cFFFF3333295,721|r", -- [3]
					}, -- [23]
					{
						2, -- [1]
						88.0879999999961, -- [2]
						"Bestial Smash |cFFFF3333283,530|r", -- [3]
					}, -- [24]
					{
						5, -- [1]
						26.8149999999951, -- [2]
						"Bestial Smash |cFFFF3333402,025|r", -- [3]
					}, -- [25]
					{
						10, -- [1]
						94.1759999999995, -- [2]
						"Bestial Impact |cFFFF3333161,928|r", -- [3]
					}, -- [26]
					{
						2, -- [1]
						26.7480000000214, -- [2]
						"Bestial Smash |cFFFF3333309,930|r", -- [3]
					}, -- [27]
					{
						2, -- [1]
						157.01800000004, -- [2]
						"Rending Bite |cFFFF33333,279|r", -- [3]
					}, -- [28]
					{
						4, -- [1]
						27.6730000000098, -- [2]
						"Bestial Smash |cFFFF3333404,694|r", -- [3]
					}, -- [29]
					{
						5, -- [1]
						96.8159999999916, -- [2]
						"Rending Bite |cFFFF333312,016|r", -- [3]
					}, -- [30]
					{
						8, -- [1]
						213.462999999989, -- [2]
						"Bestial Smash |cFFFF3333235,217|r", -- [3]
					}, -- [31]
					{
						1, -- [1]
						149.858000000007, -- [2]
						"Melee |cFFFF333372,547|r", -- [3]
					}, -- [32]
					{
						2, -- [1]
						113.739999999991, -- [2]
						"Fireball |cFFFF333338,223|r", -- [3]
					}, -- [33]
					{
						4, -- [1]
						111.175000000047, -- [2]
						"Rising Flames (DoT) |cFFFF333331,277|r", -- [3]
					}, -- [34]
				},
			},
			["Khromatian"] = {
				["encounters"] = 118,
				["points"] = 11660,
				["class"] = "DRUID",
				["deaths"] = {
					{
						2, -- [1]
						77.9340000000084, -- [2]
						"Beam (DoT) |cFFFF333338,915|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						69.0529999999562, -- [2]
						"Beam (DoT) |cFFFF333315,421|r", -- [3]
					}, -- [2]
					{
						12, -- [1]
						36.9629999999888, -- [2]
						"Burnout |cFFFF333342,236|r", -- [3]
					}, -- [3]
					{
						13, -- [1]
						99.4449999999488, -- [2]
						"Environment (Falling) |cFFFF3333217,140|r", -- [3]
					}, -- [4]
					{
						19, -- [1]
						77.7730000000447, -- [2]
						"Beam (DoT) |cFFFF333356,205|r", -- [3]
					}, -- [5]
					{
						6, -- [1]
						104.455000000075, -- [2]
						"Deathly Slam |cFFFF333380,735|r", -- [3]
					}, -- [6]
					{
						8, -- [1]
						72.7899999998044, -- [2]
						"Chill of Death (DoT) |cFFFF333341,484|r", -- [3]
					}, -- [7]
					{
						9, -- [1]
						224.385000000009, -- [2]
						"Ferocious Roar |cFFFF333364,360|r", -- [3]
					}, -- [8]
					{
						10, -- [1]
						87.2629999998026, -- [2]
						"Death Knell |cFFFF333399,546|r", -- [3]
					}, -- [9]
					{
						1, -- [1]
						133.82799999998, -- [2]
						"Divine Mallet |cFFFF333331,121|r", -- [3]
					}, -- [10]
					{
						2, -- [1]
						137.168999999994, -- [2]
						"Wave of Light (DoT) |cFFFF33337,007|r", -- [3]
					}, -- [11]
					{
						1, -- [1]
						248.746999999974, -- [2]
						"Death Touched (DoT) |cFFFF3333965|r", -- [3]
					}, -- [12]
					{
						6, -- [1]
						195.051999999996, -- [2]
						"Chill of Death (DoT) |cFFFF333341,059|r", -- [3]
					}, -- [13]
					{
						8, -- [1]
						194.956999999995, -- [2]
						"Chill of Death (DoT) |cFFFF333322,194|r", -- [3]
					}, -- [14]
				},
			},
			["Dovomir"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						4, -- [1]
						284.101999999955, -- [2]
						"Deathly Echo |cFFFF3333166,468|r", -- [3]
					}, -- [1]
				},
			},
			["Slyre"] = {
				["encounters"] = 118,
				["points"] = 11690,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						8, -- [1]
						96.0080000000308, -- [2]
						"Magma Trap |cFFFF3333122,895|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						35.7289999999339, -- [2]
						"Multi-Sided Strike |cFFFF333391,638|r", -- [3]
					}, -- [2]
					{
						20, -- [1]
						113.535999999964, -- [2]
						"Searing Embers (DoT) |cFFFF333314,905|r", -- [3]
					}, -- [3]
					{
						2, -- [1]
						102.971999999834, -- [2]
						"Explosion |cFFFF333321,597|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						225.297000000021, -- [2]
						"Chill of Death (DoT) |cFFFF333337,861|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						132.998, -- [2]
						"Divine Mallet |cFFFF333356,777|r", -- [3]
					}, -- [6]
					{
						1, -- [1]
						88.5140000000029, -- [2]
						"Magma Trap |cFFFF3333184,648|r", -- [3]
					}, -- [7]
					{
						4, -- [1]
						119.565000000002, -- [2]
						"Death Knell |cFFFF333347,786|r", -- [3]
					}, -- [8]
					{
						8, -- [1]
						224.156000000003, -- [2]
						"Chill of Death (DoT) |cFFFF333343,786|r", -- [3]
					}, -- [9]
					{
						5, -- [1]
						225.467000000004, -- [2]
						"Chill of Death (DoT) |cFFFF333345,057|r", -- [3]
					}, -- [10]
					{
						1, -- [1]
						225.516000000061, -- [2]
						"Chill of Death (DoT) |cFFFF333350,497|r", -- [3]
					}, -- [11]
				},
			},
			["Samîsu"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						1, -- [1]
						218.289000000004, -- [2]
						"Pounce |cFFFF333346,018|r", -- [3]
					}, -- [1]
				},
			},
			["Nayven"] = {
				["encounters"] = 118,
				["points"] = 11740,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						3, -- [1]
						107.393999999971, -- [2]
						"Unleashed Ember |cFFFF333336,632|r", -- [3]
					}, -- [1]
					{
						23, -- [1]
						113.881999999983, -- [2]
						"Explosion |cFFFF333330,130|r", -- [3]
					}, -- [2]
					{
						25, -- [1]
						68.2430000000168, -- [2]
						"Beam (DoT) |cFFFF333381,367|r", -- [3]
					}, -- [3]
					{
						27, -- [1]
						105.73900000006, -- [2]
						"Whirling Jade Storm |cFFFF333319,407|r", -- [3]
					}, -- [4]
					{
						5, -- [1]
						71.594000000041, -- [2]
						"Chill of Death (DoT) |cFFFF333339,261|r", -- [3]
					}, -- [5]
					{
						20, -- [1]
						194.799999999814, -- [2]
						"Voodoo Blast |cFFFF333334,842|r", -- [3]
					}, -- [6]
				},
			},
			["Alleycut"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Neferupitou"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						1, -- [1]
						215.994000000006, -- [2]
						"Whirling Jade Storm |cFFFF333319,556|r", -- [3]
					}, -- [1]
				},
			},
			["Härridk"] = {
				["encounters"] = 9,
				["points"] = 900,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Nelwyn"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["encounters"] = 119,
				["points"] = 11790,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						4, -- [1]
						101.08899999992, -- [2]
						"Environment (Falling) |cFFFF3333219,600|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						99.9800000002142, -- [2]
						"Environment (Falling) |cFFFF3333219,600|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						229.417000000132, -- [2]
						"Flash |cFFFF333313,034|r", -- [3]
					}, -- [3]
					{
						2, -- [1]
						139.757999999914, -- [2]
						"Divine Mallet |cFFFF333327,551|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						196.579000000143, -- [2]
						"Environment (Falling) |cFFFF3333222,500|r", -- [3]
					}, -- [5]
					{
						2, -- [1]
						93.4569999999949, -- [2]
						"Environment (Falling) |cFFFF3333243,420|r", -- [3]
					}, -- [6]
					{
						2, -- [1]
						96.3310000000056, -- [2]
						"Whirling Jade Storm |cFFFF333317,802|r", -- [3]
					}, -- [7]
					{
						6, -- [1]
						91.6720000000205, -- [2]
						"Environment (Falling) |cFFFF3333244,500|r", -- [3]
					}, -- [8]
					{
						6, -- [1]
						103.307999999961, -- [2]
						"", -- [3]
					}, -- [9]
					{
						1, -- [1]
						49.9370000000345, -- [2]
						"Chill of Death (DoT) |cFFFF333330,266|r", -- [3]
					}, -- [10]
				},
			},
			["Isery"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["encounters"] = 10,
				["points"] = 960,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						106.176999999967, -- [2]
						"Deathly Echo |cFFFF3333160,585|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						135.347999999998, -- [2]
						"Deathly Echo |cFFFF3333145,889|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						32.5590000000084, -- [2]
						"Divine Mallet |cFFFF333356,695|r", -- [3]
					}, -- [3]
				},
			},
			["Lokiboy"] = {
				["encounters"] = 118,
				["points"] = 11700,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						6, -- [1]
						39.2059999998892, -- [2]
						"Burnout |cFFFF333322,682|r", -- [3]
					}, -- [1]
					{
						18, -- [1]
						36.548000000068, -- [2]
						"Multi-Sided Strike |cFFFF333312,584|r", -- [3]
					}, -- [2]
					{
						20, -- [1]
						118.554999999935, -- [2]
						"Burnout |cFFFF333379,764|r", -- [3]
					}, -- [3]
					{
						21, -- [1]
						114.451999999932, -- [2]
						"Searing Embers (DoT) |cFFFF333311,597|r", -- [3]
					}, -- [4]
					{
						22, -- [1]
						106.581000000006, -- [2]
						"Environment (Falling) |cFFFF3333245,460|r", -- [3]
					}, -- [5]
					{
						23, -- [1]
						200.27099999995, -- [2]
						"Path of Niuzao (DoT) |cFFFF333333,926|r", -- [3]
					}, -- [6]
					{
						1, -- [1]
						36.435999999987, -- [2]
						"Multi-Sided Strike |cFFFF333375,947|r", -- [3]
					}, -- [7]
					{
						2, -- [1]
						102.964999999967, -- [2]
						"Whirling Jade Storm |cFFFF333320,002|r", -- [3]
					}, -- [8]
					{
						4, -- [1]
						104.533000000054, -- [2]
						"Rising Flames (DoT) |cFFFF33332,279|r", -- [3]
					}, -- [9]
					{
						5, -- [1]
						81.0760000000009, -- [2]
						"Melee |cFFFF333319,707|r", -- [3]
					}, -- [10]
				},
			},
			["Chántý"] = {
				["encounters"] = 109,
				["points"] = 10760,
				["class"] = "DRUID",
				["deaths"] = {
					{
						3, -- [1]
						141.402000000002, -- [2]
						"Divine Mallet |cFFFF333357,923|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						115.152000000002, -- [2]
						"Searing Embers (DoT) |cFFFF333315,451|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						34.0439999999944, -- [2]
						"Ferocious Roar |cFFFF333367,197|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						71.594000000041, -- [2]
						"Chill of Death (DoT) |cFFFF333339,703|r", -- [3]
					}, -- [4]
					{
						8, -- [1]
						72.7899999998044, -- [2]
						"Chill of Death (DoT) |cFFFF333343,229|r", -- [3]
					}, -- [5]
					{
						10, -- [1]
						87.2629999998026, -- [2]
						"Death Knell |cFFFF333388,685|r", -- [3]
					}, -- [6]
					{
						11, -- [1]
						118.648999999976, -- [2]
						"Death Knell |cFFFF333352,076|r", -- [3]
					}, -- [7]
					{
						2, -- [1]
						102.971999999834, -- [2]
						"Explosion |cFFFF333329,139|r", -- [3]
					}, -- [8]
					{
						5, -- [1]
						175.408000000054, -- [2]
						"Death Knell |cFFFF333349,600|r", -- [3]
					}, -- [9]
					{
						2, -- [1]
						34.5910000000004, -- [2]
						"Ferocious Roar |cFFFF333365,929|r", -- [3]
					}, -- [10]
					{
						1, -- [1]
						156.735999999975, -- [2]
						"Ferocious Roar |cFFFF333351,633|r", -- [3]
					}, -- [11]
					{
						1, -- [1]
						195.445000000007, -- [2]
						"Chill of Death (DoT) |cFFFF33335,065|r", -- [3]
					}, -- [12]
					{
						2, -- [1]
						97.9280000000144, -- [2]
						"Voodoo Blast |cFFFF333366,006|r", -- [3]
					}, -- [13]
				},
			},
			["Seyden"] = {
				["encounters"] = 99,
				["points"] = 9810,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						152.217999999993, -- [2]
						"Wave of Light (DoT) |cFFFF333317,959|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						137.584999999963, -- [2]
						"Divine Mallet |cFFFF333323,079|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						81.6089999999385, -- [2]
						"Beam (DoT) |cFFFF333371,395|r", -- [3]
					}, -- [3]
					{
						27, -- [1]
						109.989999999991, -- [2]
						"Searing Embers (DoT) |cFFFF333314,324|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						78.7550000001211, -- [2]
						"Ferocious Roar |cFFFF333353,365|r", -- [3]
					}, -- [5]
					{
						11, -- [1]
						158.47900000005, -- [2]
						"Voodoo Blast |cFFFF333358,111|r", -- [3]
					}, -- [6]
					{
						3, -- [1]
						135.981, -- [2]
						"Melee |cFFFF3333106,907|r", -- [3]
					}, -- [7]
					{
						1, -- [1]
						60.6239999999525, -- [2]
						"Melee |cFFFF3333154,861|r", -- [3]
					}, -- [8]
					{
						1, -- [1]
						64.5119999999879, -- [2]
						"Beam (DoT) |cFFFF333374,928|r", -- [3]
					}, -- [9]
				},
			},
			["Julietté"] = {
				["encounters"] = 96,
				["points"] = 9540,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						154.863000000012, -- [2]
						"Wave of Light (DoT) |cFFFF333327,439|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						134.540000000037, -- [2]
						"Divine Mallet |cFFFF333367,086|r", -- [3]
					}, -- [2]
					{
						12, -- [1]
						39.4119999998948, -- [2]
						"Magma Trap |cFFFF333388,500|r", -- [3]
					}, -- [3]
					{
						28, -- [1]
						113.528000000049, -- [2]
						"Searing Embers (DoT) |cFFFF333315,983|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						92.3549999999814, -- [2]
						"Beam (DoT) |cFFFF333325,691|r", -- [3]
					}, -- [5]
					{
						2, -- [1]
						86.4740000000457, -- [2]
						"Divine Mallet |cFFFF333321,540|r", -- [3]
					}, -- [6]
				},
			},
			["Yesiam"] = {
				["encounters"] = 115,
				["points"] = 11320,
				["class"] = "ROGUE",
				["deaths"] = {
					{
						22, -- [1]
						193.733999999939, -- [2]
						"Path of Niuzao (DoT) |cFFFF333322,523|r", -- [3]
					}, -- [1]
					{
						26, -- [1]
						81.8580000000075, -- [2]
						"Beam (DoT) |cFFFF333388,114|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						139.845999999903, -- [2]
						"Whirling Jade Storm |cFFFF333317,251|r", -- [3]
					}, -- [3]
					{
						6, -- [1]
						69.6210000000428, -- [2]
						"Beam (DoT) |cFFFF333385,576|r", -- [3]
					}, -- [4]
					{
						7, -- [1]
						134.773999999976, -- [2]
						"Melee |cFFFF3333201,195|r", -- [3]
					}, -- [5]
					{
						9, -- [1]
						191.621000000043, -- [2]
						"Deathly Slam |cFFFF333371,559|r", -- [3]
					}, -- [6]
					{
						13, -- [1]
						224.361999999965, -- [2]
						"Ferocious Roar |cFFFF333338,646|r", -- [3]
					}, -- [7]
					{
						14, -- [1]
						153.54700000002, -- [2]
						"Ferocious Roar |cFFFF333334,946|r", -- [3]
					}, -- [8]
					{
						17, -- [1]
						224.226000000024, -- [2]
						"Necrotic Core (DoT) |cFFFF33338,552|r", -- [3]
					}, -- [9]
					{
						7, -- [1]
						219.387000000104, -- [2]
						"Deathly Slam |cFFFF333378,802|r", -- [3]
					}, -- [10]
					{
						3, -- [1]
						192.20299999998, -- [2]
						"Deathly Slam |cFFFF333372,968|r", -- [3]
					}, -- [11]
					{
						3, -- [1]
						108.737000000001, -- [2]
						"Necrotic Core (DoT) |cFFFF33338,207|r", -- [3]
					}, -- [12]
					{
						6, -- [1]
						219.076000000001, -- [2]
						"Necrotic Core (DoT) |cFFFF333322,727|r", -- [3]
					}, -- [13]
					{
						1, -- [1]
						192.732000000018, -- [2]
						"Necrotic Core (DoT) |cFFFF333310,806|r", -- [3]
					}, -- [14]
					{
						3, -- [1]
						107.765000000014, -- [2]
						"Necrotic Core (DoT) |cFFFF33332,715|r", -- [3]
					}, -- [15]
					{
						6, -- [1]
						104.398000000045, -- [2]
						"Deathly Slam |cFFFF333378,771|r", -- [3]
					}, -- [16]
					{
						1, -- [1]
						38.6410000000615, -- [2]
						"Unleashed Ember |cFFFF333362,432|r", -- [3]
					}, -- [17]
					{
						5, -- [1]
						69.3399999999674, -- [2]
						"Unleashed Ember |cFFFF333334,869|r", -- [3]
					}, -- [18]
				},
			},
			["Qyix"] = {
				["encounters"] = 7,
				["points"] = 690,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						292.178999999989, -- [2]
						"Death Touched |cFFFF333311,108|r", -- [3]
					}, -- [1]
				},
			},
		},
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2265,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Champion of the Light",
		},
		["diff"] = 16,
	},
	["234315"] = {
		["hash"] = "234315",
		["type"] = "endurance",
		["name"] = "Lady Jaina Proudmoore",
		["id"] = 2343,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 9,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2281,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Lady Jaina Proudmoore",
			["encounter"] = "Lady Jaina Proudmoore",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						58.9679999999935, -- [2]
						"Ice Shard |cFFFF3333132,357|r", -- [3]
					}, -- [1]
				},
			},
			["Laki"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "DRUID",
				["deaths"] = {
					{
						1, -- [1]
						73.0670000000391, -- [2]
						"Searing Pitch |cFFFF333323,741|r", -- [3]
					}, -- [1]
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 13,
				["points"] = 1260,
				["deaths"] = {
					{
						4, -- [1]
						149.304000000004, -- [2]
						"Freezing Blast |cFFFF333341,587|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						263.488000000129, -- [2]
						"Broadside |cFFFF333328,567|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						268.510000000009, -- [2]
						"Siegebreaker Blast |cFFFF333343,427|r", -- [3]
					}, -- [3]
				},
				["class"] = "SHAMAN",
			},
			["Härridk"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Soely"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Shìnigami"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						13, -- [1]
						491.997999999905, -- [2]
						"Chilling Touch (DoT) |cFFFF33331,075|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Ðaisuke"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["encounters"] = 21,
				["points"] = 2040,
				["deaths"] = {
					{
						2, -- [1]
						68.0169999999926, -- [2]
						"Munitions Barrel |cFFFF333346,108|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						52.6500000001397, -- [2]
						"Munitions Barrel |cFFFF333341,559|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						279.679999999935, -- [2]
						"Burning Explosion |cFFFF333389,626|r", -- [3]
					}, -- [3]
					{
						15, -- [1]
						177.342999999877, -- [2]
						"Freezing Blast |cFFFF333372,871|r", -- [3]
					}, -- [4]
					{
						17, -- [1]
						286.469999999972, -- [2]
						"Ice Shard |cFFFF333355,716|r", -- [3]
					}, -- [5]
					{
						1, -- [1]
						294.591, -- [2]
						"Burning Explosion |cFFFF333397,088|r", -- [3]
					}, -- [6]
				},
				["class"] = "PALADIN",
			},
			["Almîna"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						2, -- [1]
						230.051999999996, -- [2]
						"Burning Explosion |cFFFF3333119,804|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						37.3429999999935, -- [2]
						"Ice Shard |cFFFF333362,599|r", -- [3]
					}, -- [2]
				},
			},
			["Guldàníel"] = {
				["encounters"] = 2,
				["points"] = 180,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						13.0129999999917, -- [2]
						"", -- [3]
					}, -- [1]
					{
						2, -- [1]
						19.4079999999958, -- [2]
						"", -- [3]
					}, -- [2]
				},
			},
			["Mêphis"] = {
				["encounters"] = 28,
				["points"] = 2710,
				["deaths"] = {
					{
						8, -- [1]
						252.196999999927, -- [2]
						"Ice Shard |cFFFF333369,459|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						330.884000000078, -- [2]
						"Ice Shard |cFFFF3333152,619|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						127.863000000129, -- [2]
						"Ring of Ice (DoT) |cFFFF333316,579|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						152.936999999918, -- [2]
						"Chilling Touch (DoT) |cFFFF3333730|r", -- [3]
					}, -- [4]
					{
						6, -- [1]
						259.502999999793, -- [2]
						"Ice Shard |cFFFF33332,218|r", -- [3]
					}, -- [5]
					{
						8, -- [1]
						42.4069999998901, -- [2]
						"Ice Shard |cFFFF333381,005|r", -- [3]
					}, -- [6]
					{
						9, -- [1]
						45.2949999999255, -- [2]
						"Ice Shard |cFFFF3333125,210|r", -- [3]
					}, -- [7]
					{
						15, -- [1]
						292.770000000019, -- [2]
						"Ice Shard |cFFFF333351,900|r", -- [3]
					}, -- [8]
					{
						16, -- [1]
						91.439000000013, -- [2]
						"Ice Shard |cFFFF333373,252|r", -- [3]
					}, -- [9]
				},
				["class"] = "DEMONHUNTER",
			},
			["Viste"] = {
				["encounters"] = 16,
				["points"] = 1550,
				["deaths"] = {
					{
						3, -- [1]
						52.6500000001397, -- [2]
						"Munitions Barrel |cFFFF333374,168|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						511.964999999851, -- [2]
						"Siegebreaker Blast |cFFFF333349,946|r", -- [3]
					}, -- [2]
					{
						11, -- [1]
						496.420999999857, -- [2]
						"Chilling Touch (DoT) |cFFFF33332,716|r", -- [3]
					}, -- [3]
					{
						12, -- [1]
						260.645000000019, -- [2]
						"Ice Shard |cFFFF333392,279|r", -- [3]
					}, -- [4]
					{
						17, -- [1]
						285.73499999987, -- [2]
						"Siegebreaker Blast |cFFFF333342,737|r", -- [3]
					}, -- [5]
				},
				["class"] = "HUNTER",
			},
			["Artèmis"] = {
				["encounters"] = 33,
				["points"] = 3240,
				["deaths"] = {
					{
						3, -- [1]
						26.6000000000931, -- [2]
						"", -- [3]
					}, -- [1]
					{
						13, -- [1]
						488.357000000076, -- [2]
						"Broadside |cFFFF33332,066|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						253.790000000037, -- [2]
						"Blistering Tornado |cFFFF333399,736|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						22.1709999998566, -- [2]
						"Avalanche |cFFFF333366,726|r", -- [3]
					}, -- [4]
					{
						11, -- [1]
						501.513999999967, -- [2]
						"Chilling Touch (DoT) |cFFFF33338,870|r", -- [3]
					}, -- [5]
					{
						14, -- [1]
						143.134000000078, -- [2]
						"Avalanche |cFFFF333342,758|r", -- [3]
					}, -- [6]
				},
				["class"] = "HUNTER",
			},
			["Narfnarf"] = {
				["encounters"] = 16,
				["points"] = 1570,
				["deaths"] = {
					{
						8, -- [1]
						328.471999999834, -- [2]
						"Frozen Solid |cFFFF33335,809|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						501.513999999967, -- [2]
						"Chilling Touch (DoT) |cFFFF33339,330|r", -- [3]
					}, -- [2]
					{
						13, -- [1]
						535.340000000084, -- [2]
						"Broadside |cFFFF333371,942|r", -- [3]
					}, -- [3]
				},
				["class"] = "HUNTER",
			},
			["Lyoli"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						468.007000000041, -- [2]
						"Glacial Ray |cFFFF333342,184|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Lilania"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Aspern"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "MAGE",
				["deaths"] = {
					{
						2, -- [1]
						465.925999999978, -- [2]
						"Glacial Ray |cFFFF333319,791|r", -- [3]
					}, -- [1]
				},
			},
			["Schifti"] = {
				["encounters"] = 28,
				["points"] = 2750,
				["deaths"] = {
					{
						4, -- [1]
						141.470999999903, -- [2]
						"Bombard |cFFFF333389,895|r", -- [3]
					}, -- [1]
					{
						10, -- [1]
						445.793000000063, -- [2]
						"Crystalline Dust |cFFFF333364,508|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						68.308999999892, -- [2]
						"Searing Pitch (DoT) |cFFFF33335,094|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						190.988999999827, -- [2]
						"Searing Pitch (DoT) |cFFFF333322,715|r", -- [3]
					}, -- [4]
					{
						14, -- [1]
						141.013999999966, -- [2]
						"Avalanche |cFFFF333364,521|r", -- [3]
					}, -- [5]
				},
				["class"] = "MONK",
			},
			["Andromaché"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Jinjewel"] = {
				["encounters"] = 12,
				["points"] = 1180,
				["deaths"] = {
					{
						5, -- [1]
						79.6000000000931, -- [2]
						"Avalanche |cFFFF333375,924|r", -- [3]
					}, -- [1]
					{
						12, -- [1]
						139.84300000011, -- [2]
						"Bombard |cFFFF333391,133|r", -- [3]
					}, -- [2]
				},
				["class"] = "PRIEST",
			},
			["Yugitø"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Salanâ"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						466.364999999991, -- [2]
						"Glacial Ray |cFFFF333341,063|r", -- [3]
					}, -- [1]
				},
			},
			["Anobine"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Kalissta"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						488.777000000002, -- [2]
						"Shattering Lance |cFFFF333344,391|r", -- [3]
					}, -- [1]
				},
			},
			["Schwoop"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Môdox"] = {
				["encounters"] = 30,
				["points"] = 2850,
				["deaths"] = {
					{
						2, -- [1]
						80.4619999998249, -- [2]
						"", -- [3]
					}, -- [1]
					{
						6, -- [1]
						285.439999999944, -- [2]
						"Ice Shard |cFFFF333374,902|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						322.954999999842, -- [2]
						"Ice Shard |cFFFF333396,993|r", -- [3]
					}, -- [3]
					{
						9, -- [1]
						111.92200000002, -- [2]
						"Chilling Touch (DoT) |cFFFF33331,480|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						312.163000000175, -- [2]
						"Ice Shard |cFFFF3333124,226|r", -- [3]
					}, -- [5]
					{
						10, -- [1]
						461.651000000071, -- [2]
						"Ice Shard |cFFFF333364,465|r", -- [3]
					}, -- [6]
					{
						2, -- [1]
						80.1450000000186, -- [2]
						"Searing Pitch (DoT) |cFFFF333324,037|r", -- [3]
					}, -- [7]
					{
						3, -- [1]
						58.2810000001919, -- [2]
						"", -- [3]
					}, -- [8]
					{
						6, -- [1]
						268.013999999967, -- [2]
						"Ice Shard |cFFFF333392,395|r", -- [3]
					}, -- [9]
					{
						9, -- [1]
						105.949000000022, -- [2]
						"Chilling Touch (DoT) |cFFFF33331,540|r", -- [3]
					}, -- [10]
					{
						10, -- [1]
						197.405000000028, -- [2]
						"Searing Pitch (DoT) |cFFFF333323,362|r", -- [3]
					}, -- [11]
					{
						16, -- [1]
						97.9219999997877, -- [2]
						"Ice Shard |cFFFF333358,404|r", -- [3]
					}, -- [12]
					{
						17, -- [1]
						282.841000000015, -- [2]
						"Ice Shard |cFFFF333380,361|r", -- [3]
					}, -- [13]
				},
				["class"] = "DRUID",
			},
			["Khromatian"] = {
				["encounters"] = 29,
				["points"] = 2820,
				["deaths"] = {
					{
						8, -- [1]
						255.490999999922, -- [2]
						"Burning Explosion |cFFFF333364,927|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						221.164000000106, -- [2]
						"Glacial Ray |cFFFF333319,022|r", -- [3]
					}, -- [2]
					{
						12, -- [1]
						490.992000000086, -- [2]
						"Crystalline Dust |cFFFF333363,774|r", -- [3]
					}, -- [3]
					{
						7, -- [1]
						297.800000000047, -- [2]
						"Glacial Ray |cFFFF333333,934|r", -- [3]
					}, -- [4]
					{
						9, -- [1]
						97.9660000000149, -- [2]
						"Grasp of Frost |cFFFF333355,433|r", -- [3]
					}, -- [5]
					{
						13, -- [1]
						201.459999999963, -- [2]
						"Avalanche |cFFFF333358,780|r", -- [3]
					}, -- [6]
					{
						13, -- [1]
						542.240999999922, -- [2]
						"Shattering Lance |cFFFF33336,126|r", -- [3]
					}, -- [7]
				},
				["class"] = "DRUID",
			},
			["Xaru"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Qyix"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Wystra"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Nayven"] = {
				["encounters"] = 17,
				["points"] = 1690,
				["deaths"] = {
					{
						2, -- [1]
						85.12099999981, -- [2]
						"Chilling Touch (DoT) |cFFFF33332,525|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Lokiboy"] = {
				["encounters"] = 28,
				["points"] = 2720,
				["deaths"] = {
					{
						3, -- [1]
						78.0859999998938, -- [2]
						"Avalanche |cFFFF333356,089|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						275.985000000102, -- [2]
						"Ice Shard |cFFFF333384,953|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						20.1210000000428, -- [2]
						"Avalanche |cFFFF333360,473|r", -- [3]
					}, -- [3]
					{
						11, -- [1]
						479.236999999965, -- [2]
						"Ice Shard |cFFFF333314,894|r", -- [3]
					}, -- [4]
					{
						4, -- [1]
						252.716000000015, -- [2]
						"Blistering Tornado |cFFFF333350,285|r", -- [3]
					}, -- [5]
					{
						5, -- [1]
						140.567000000039, -- [2]
						"Searing Pitch (DoT) |cFFFF333318,930|r", -- [3]
					}, -- [6]
					{
						7, -- [1]
						314.527999999933, -- [2]
						"Broadside |cFFFF333379,745|r", -- [3]
					}, -- [7]
					{
						15, -- [1]
						294.277999999933, -- [2]
						"Siegebreaker Blast |cFFFF33338,816|r", -- [3]
					}, -- [8]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Neferupitou"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						467.875, -- [2]
						"Glacial Ray |cFFFF333320,903|r", -- [3]
					}, -- [1]
				},
			},
			["Coffinlove"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						1, -- [1]
						81.9089999999997, -- [2]
						"Avalanche |cFFFF333371,243|r", -- [3]
					}, -- [1]
				},
			},
			["Arameh"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						16, -- [1]
						77.4839999999385, -- [2]
						"Avalanche |cFFFF333362,115|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Tyrellan"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Seyden"] = {
				["encounters"] = 12,
				["points"] = 1170,
				["deaths"] = {
					{
						3, -- [1]
						79.0600000000559, -- [2]
						"Avalanche |cFFFF333339,692|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						312.027000000002, -- [2]
						"Glacial Ray |cFFFF333311,918|r", -- [3]
					}, -- [2]
					{
						10, -- [1]
						466.243000000017, -- [2]
						"Ice Shard |cFFFF333336,758|r", -- [3]
					}, -- [3]
				},
				["class"] = "DEMONHUNTER",
			},
			["Metó"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Chántý"] = {
				["encounters"] = 29,
				["points"] = 2830,
				["deaths"] = {
					{
						5, -- [1]
						47.7639999999665, -- [2]
						"Bombard |cFFFF333390,100|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						162.404000000097, -- [2]
						"", -- [3]
					}, -- [2]
					{
						6, -- [1]
						230.614999999991, -- [2]
						"Glacial Ray |cFFFF333326,009|r", -- [3]
					}, -- [3]
					{
						12, -- [1]
						143.553000000073, -- [2]
						"Searing Pitch (DoT) |cFFFF33335,400|r", -- [3]
					}, -- [4]
					{
						12, -- [1]
						257.844999999972, -- [2]
						"Siegebreaker Blast |cFFFF333396,352|r", -- [3]
					}, -- [5]
					{
						14, -- [1]
						149.570000000065, -- [2]
						"Chilling Touch (DoT) |cFFFF33331,950|r", -- [3]
					}, -- [6]
				},
				["class"] = "DRUID",
			},
			["Fudgeless-Silvermoon"] = {
				["encounters"] = 12,
				["points"] = 1180,
				["deaths"] = {
					{
						8, -- [1]
						142.51099999994, -- [2]
						"Avalanche |cFFFF333344,806|r", -- [3]
					}, -- [1]
					{
						13, -- [1]
						488.038999999873, -- [2]
						"Siegebreaker Blast |cFFFF333347,019|r", -- [3]
					}, -- [2]
				},
				["class"] = "DRUID",
			},
			["Julietté"] = {
				["encounters"] = 12,
				["points"] = 1170,
				["deaths"] = {
					{
						4, -- [1]
						81.2739999999758, -- [2]
						"Avalanche |cFFFF33336,769|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						319.751000000164, -- [2]
						"Glacial Ray |cFFFF333329,602|r", -- [3]
					}, -- [2]
					{
						12, -- [1]
						491.727000000188, -- [2]
						"Frozen Solid (DoT) |cFFFF33338,043|r", -- [3]
					}, -- [3]
				},
				["class"] = "WARRIOR",
			},
			["Yesiam"] = {
				["encounters"] = 12,
				["points"] = 1190,
				["deaths"] = {
					{
						2, -- [1]
						71.7639999999665, -- [2]
						"Bombard |cFFFF333388,335|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Ahrela"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
		},
	},
	["233715"] = {
		["hash"] = "233715",
		["type"] = "endurance",
		["name"] = "Stormwall Blockade",
		["id"] = 2337,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 8,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2280,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Stormwall Blockade",
			["diff"] = 15,
			["ej_instance_id"] = 1176,
			["encounter"] = "Stormwall Blockade",
		},
		["player_db"] = {
			["Xaru"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Laki"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Yuzurihâ"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						2, -- [1]
						31.5840000000317, -- [2]
						"Sea Storm |cFFFF333345,845|r", -- [3]
					}, -- [1]
				},
			},
			["Soely"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Shìnigami"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "MAGE",
				["deaths"] = {
					{
						1, -- [1]
						31.6000000000931, -- [2]
						"Sea Storm |cFFFF333336,076|r", -- [3]
					}, -- [1]
				},
			},
			["Ðaisuke"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Wystra"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Guldàníel"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						7.64899999999034, -- [2]
						"Roiling Tides (DoT) |cFFFF333357,839|r", -- [3]
					}, -- [1]
				},
			},
			["Härridot"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Mêphis"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Artèmis"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Narfnarf"] = {
				["encounters"] = 4,
				["points"] = 380,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						2, -- [1]
						75.1190000001807, -- [2]
						"Roiling Tides (DoT) |cFFFF333360,414|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						173.003999999957, -- [2]
						"Ire of the Deep |cFFFF3333242,256|r", -- [3]
					}, -- [2]
				},
			},
			["Aspern"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Schifti"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "MONK",
				["deaths"] = {
					{
						4, -- [1]
						197.655000000028, -- [2]
						"Sea Swell |cFFFF333354,123|r", -- [3]
					}, -- [1]
				},
			},
			["Andromaché"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						31.3689999999915, -- [2]
						"Roiling Tides (DoT) |cFFFF333339,611|r", -- [3]
					}, -- [1]
				},
			},
			["Jinjewel"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						89.0670000000391, -- [2]
						"Voltaic Flash |cFFFF3333101,724|r", -- [3]
					}, -- [1]
				},
			},
			["Salanâ"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						1, -- [1]
						286.785999999964, -- [2]
						"Sea Swell |cFFFF333357,487|r", -- [3]
					}, -- [1]
				},
			},
			["Metó"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Seyden"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Khromatian"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DRUID",
				["deaths"] = {
					{
						4, -- [1]
						54.3429999998771, -- [2]
						"Jolting Volley |cFFFF333338,473|r", -- [3]
					}, -- [1]
				},
			},
			["Schwoop"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Kalissta"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Nayven"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						191.108999999939, -- [2]
						"Sea Swell |cFFFF333310,364|r", -- [3]
					}, -- [1]
				},
			},
			["Tyrellan"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Schliizîî"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						139.754000000074, -- [2]
						"Sea Swell |cFFFF333346,742|r", -- [3]
					}, -- [1]
				},
			},
			["Daddysenpai"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Arameh"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						3, -- [1]
						313.047999999952, -- [2]
						"Ire of the Deep |cFFFF3333235,660|r", -- [3]
					}, -- [1]
				},
			},
			["Lilania"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						151.936999999991, -- [2]
						"Sea Swell |cFFFF333328,512|r", -- [3]
					}, -- [1]
				},
			},
			["Chántý"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DRUID",
				["deaths"] = {
					{
						3, -- [1]
						192.189999999944, -- [2]
						"Roiling Tides (DoT) |cFFFF333312,383|r", -- [3]
					}, -- [1]
				},
			},
			["Lokiboy"] = {
				["encounters"] = 4,
				["points"] = 380,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						1, -- [1]
						133.368000000017, -- [2]
						"Tempting Song (DoT) |cFFFF33335,735|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						262.08899999992, -- [2]
						"Sea Swell |cFFFF333341,594|r", -- [3]
					}, -- [2]
				},
			},
			["Môdox"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Yesiam"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Qyix"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
		},
		["diff"] = 15,
	},
	["234314"] = {
		["hash"] = "234314",
		["type"] = "endurance",
		["name"] = "Lady Jaina Proudmoore",
		["id"] = 2343,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 9,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2281,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Lady Jaina Proudmoore",
			["diff"] = 14,
			["ej_instance_id"] = 1176,
			["encounter"] = "Lady Jaina Proudmoore",
		},
		["player_db"] = {
			["Кракапузик-ВечнаяПесня"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Volenar-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Pandexas-ChamberofAspects"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Zandak-Hyjal"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						3, -- [1]
						10.9639999999199, -- [2]
						"", -- [3]
					}, -- [1]
				},
			},
			["Shaj-Arygos"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						8, -- [1]
						16.7290000000503, -- [2]
						"Chilling Touch (DoT) |cFFFF3333603|r", -- [3]
					}, -- [1]
					{
						9, -- [1]
						130.530999999959, -- [2]
						"Searing Pitch (DoT) |cFFFF333327,515|r", -- [3]
					}, -- [2]
				},
				["class"] = "WARLOCK",
			},
			["Ferow-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DRUID",
				["deaths"] = {
					{
						2, -- [1]
						271.677999999956, -- [2]
						"Glacial Ray |cFFFF33334,079|r", -- [3]
					}, -- [1]
				},
			},
			["Inánná"] = {
				["encounters"] = 13,
				["points"] = 1260,
				["deaths"] = {
					{
						1, -- [1]
						145.836999999941, -- [2]
						"Freezing Blast |cFFFF333351,714|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						273.84600000002, -- [2]
						"Ice Shard |cFFFF333358,204|r", -- [3]
					}, -- [2]
					{
						4, -- [1]
						315.191999999923, -- [2]
						"Chilling Touch (DoT) |cFFFF333310,498|r", -- [3]
					}, -- [3]
					{
						10, -- [1]
						106.238000000012, -- [2]
						"Grasp of Frost |cFFFF333346,078|r", -- [3]
					}, -- [4]
				},
				["class"] = "PALADIN",
			},
			["Leonidás-Anachronos"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						4, -- [1]
						258.403000000049, -- [2]
						"Glacial Ray |cFFFF333318,629|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Siggeboi-ChamberofAspects"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "MAGE",
				["deaths"] = {
					{
						1, -- [1]
						391.114999999991, -- [2]
						"Glacial Ray |cFFFF333328,311|r", -- [3]
					}, -- [1]
				},
			},
			["Xavios-DefiasBrotherhood"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Shandaries-Aman'thul"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						2, -- [1]
						227.902000000002, -- [2]
						"Frozen Solid |cFFFF33332,149|r", -- [3]
					}, -- [1]
					{
						11, -- [1]
						544.315999999992, -- [2]
						"Shattering Lance |cFFFF333354,814|r", -- [3]
					}, -- [2]
				},
				["class"] = "MONK",
			},
			["Phenominah-Alleria"] = {
				["encounters"] = 10,
				["points"] = 980,
				["deaths"] = {
					{
						8, -- [1]
						13.4310000000987, -- [2]
						"", -- [3]
					}, -- [1]
					{
						9, -- [1]
						263.435999999987, -- [2]
						"Ice Shard |cFFFF333353,866|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEMONHUNTER",
			},
			["Fudgeytwo-SteamwheedleCartel"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "MONK",
				["deaths"] = {
					{
						2, -- [1]
						454.293999999994, -- [2]
						"Glacial Ray |cFFFF333316,183|r", -- [3]
					}, -- [1]
				},
			},
			["Gorgelia-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Rawpwnsl-Malygos"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Artèmis"] = {
				["encounters"] = 19,
				["points"] = 1870,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						2, -- [1]
						442.660000000033, -- [2]
						"Melee |cFFFF333343,210|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						259.884000000078, -- [2]
						"Glacial Ray |cFFFF333325,431|r", -- [3]
					}, -- [2]
					{
						9, -- [1]
						186.040000000037, -- [2]
						"Chilling Touch (DoT) |cFFFF3333592|r", -- [3]
					}, -- [3]
				},
			},
			["Binoü-Hyjal"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Amriah"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						5, -- [1]
						229.584000000032, -- [2]
						"", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Easycasting-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Wojtasas-BurningLegion"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Whitepearl-Aggramar"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Artega-Medivh"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Imtammala-EarthenRing"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						3, -- [1]
						23.5349999999162, -- [2]
						"Chilling Touch |cFFFF33331,205|r", -- [3]
					}, -- [1]
				},
			},
			["Shioa-Draenor"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Wolfbrofist-ChamberofAspects"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Berberechô-DunModr"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						312.009999999893, -- [2]
						"Ice Shard |cFFFF333354,257|r", -- [3]
					}, -- [1]
				},
			},
			["Trün-Ysera"] = {
				["encounters"] = 10,
				["points"] = 970,
				["deaths"] = {
					{
						4, -- [1]
						315.611999999965, -- [2]
						"Avalanche |cFFFF333351,188|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						345.832999999984, -- [2]
						"Icefall |cFFFF3333150,011|r", -- [3]
					}, -- [2]
					{
						10, -- [1]
						249.371999999974, -- [2]
						"Icefall |cFFFF3333141,228|r", -- [3]
					}, -- [3]
				},
				["class"] = "MONK",
			},
			["Gabbita-DunModr"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						5, -- [1]
						274.98199999996, -- [2]
						"Glacial Ray |cFFFF333329,630|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Grixxina"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						200.957999999984, -- [2]
						"Searing Pitch (DoT) |cFFFF333321,409|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Vulpinia-ChamberofAspects"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DRUID",
				["deaths"] = {
					{
						2, -- [1]
						540.366999999969, -- [2]
						"Melee |cFFFF333331,464|r", -- [3]
					}, -- [1]
				},
			},
			["Насфиратуу-ВечнаяПесня"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						2, -- [1]
						36.7789999999804, -- [2]
						"Freezing Blast |cFFFF333348,702|r", -- [3]
					}, -- [1]
				},
			},
			["Zhandruna-Ragnaros"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						107.914000000106, -- [2]
						"Searing Pitch (DoT) |cFFFF333315,581|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Blackangelww"] = {
				["encounters"] = 10,
				["points"] = 990,
				["deaths"] = {
					{
						7, -- [1]
						81.6870000000345, -- [2]
						"", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Cybergt-AzjolNerub"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Kerohun-Ragnaros"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Soulleater-Anachronos"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Zhari-Drak'thul"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Redbeaard"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Kazahr-Hyjal"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Wheeler-Nozdormu"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Wornhart-Hyjal"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "MONK",
				["deaths"] = {
					{
						1, -- [1]
						498.613999999943, -- [2]
						"Shattering Lance |cFFFF333358,671|r", -- [3]
					}, -- [1]
				},
			},
			["Privian-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						309.688999999897, -- [2]
						"Ice Shard |cFFFF333346,872|r", -- [3]
					}, -- [1]
				},
				["class"] = "DRUID",
			},
			["Emywy-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						1, -- [1]
						498.613999999943, -- [2]
						"Shattering Lance |cFFFF333368,553|r", -- [3]
					}, -- [1]
				},
			},
			["Iblisa-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Jubillee-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Hellslider-Aegwynn"] = {
				["encounters"] = 5,
				["points"] = 490,
				["deaths"] = {
					{
						11, -- [1]
						481.064000000013, -- [2]
						"Chilling Touch (DoT) |cFFFF33339,742|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Эльвенель-Гордунни"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						3, -- [1]
						5.42099999997299, -- [2]
						"Chilling Touch |cFFFF33331,089|r", -- [3]
					}, -- [1]
				},
			},
			["Tarrow-Blackmoore"] = {
				["encounters"] = 10,
				["points"] = 990,
				["deaths"] = {
					{
						3, -- [1]
						488.46399999992, -- [2]
						"Broadside |cFFFF333336,923|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Inánná-Arthas"] = {
				["encounters"] = 7,
				["points"] = 650,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						1, -- [1]
						409.866999999969, -- [2]
						"Broadside |cFFFF333352,991|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						500.601999999955, -- [2]
						"Shattering Lance |cFFFF333347,254|r", -- [3]
					}, -- [2]
					{
						2, -- [1]
						434.175000000047, -- [2]
						"Melee |cFFFF3333117,270|r", -- [3]
					}, -- [3]
					{
						4, -- [1]
						441.205000000075, -- [2]
						"Glacial Ray |cFFFF33338,922|r", -- [3]
					}, -- [4]
					{
						5, -- [1]
						325.212999999989, -- [2]
						"Ice Shard |cFFFF333377,417|r", -- [3]
					}, -- [5]
				},
			},
			["Orazca-LaCroisadeécarlate"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Geekasaurus-AzjolNerub"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Mäkiverem-Ragnaros"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						3, -- [1]
						199.033000000054, -- [2]
						"Searing Pitch (DoT) |cFFFF333315,647|r", -- [3]
					}, -- [1]
				},
				["class"] = "MONK",
			},
			["Vaedan-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Escaldris-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Preest-TheVentureCo"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Elrend-Dalaran"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Wedmak-Outland"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Devilmonalei-Gilneas"] = {
				["encounters"] = 10,
				["points"] = 990,
				["deaths"] = {
					{
						2, -- [1]
						277.52899999998, -- [2]
						"Chilling Touch (DoT) |cFFFF33335,911|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Cenny-Blackmoore"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Feralla-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Aewyla-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Tylessa-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["You-Ravenholdt"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Aarwen-AzjolNerub"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Bajejo-Kilrogg"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Greydemon-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Draiv-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Tpaartosz-Ragnaros"] = {
				["encounters"] = 3,
				["points"] = 280,
				["deaths"] = {
					{
						2, -- [1]
						297.298000000068, -- [2]
						"Icefall |cFFFF333365,728|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						131.76800000004, -- [2]
						"Searing Pitch (DoT) |cFFFF333315,753|r", -- [3]
					}, -- [2]
				},
				["class"] = "PALADIN",
			},
			["Maxìma"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Catastrophhe-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Kargana-Nefarian"] = {
				["encounters"] = 5,
				["points"] = 500,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Флуме-Гордунни"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Credible-Outland"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Lunellach-KulTiras"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Herrox-Anachronos"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						2, -- [1]
						471.20000000007, -- [2]
						"Melee |cFFFF333326,491|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Garnilion-Terenas"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						392.535999999964, -- [2]
						"Glacial Ray |cFFFF333315,573|r", -- [3]
					}, -- [1]
				},
			},
			["Inuviel-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Lorimbur-Aman'thul"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Йабики-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Muck-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Prinzluco-Lordaeron"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						10, -- [1]
						157.513999999966, -- [2]
						"Freezing Blast |cFFFF333353,410|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Stormdraka-Alonsus"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Tyllith-TheMaelstrom"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Mischtorius-Blackmoore"] = {
				["encounters"] = 10,
				["points"] = 1000,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Chérrys-Alleria"] = {
				["encounters"] = 10,
				["points"] = 940,
				["deaths"] = {
					{
						3, -- [1]
						506.685999999987, -- [2]
						"Shattering Lance |cFFFF333372,879|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						223.756999999983, -- [2]
						"Frozen Solid |cFFFF33336,081|r", -- [3]
					}, -- [2]
					{
						5, -- [1]
						210.655000000028, -- [2]
						"Frozen Solid |cFFFF33336,082|r", -- [3]
					}, -- [3]
					{
						5, -- [1]
						269.655000000028, -- [2]
						"Glacial Ray |cFFFF333330,407|r", -- [3]
					}, -- [4]
					{
						7, -- [1]
						84.8580000000075, -- [2]
						"Searing Pitch (DoT) |cFFFF333317,255|r", -- [3]
					}, -- [5]
				},
				["class"] = "PRIEST",
			},
			["Lîquitwalker-Ambossar"] = {
				["encounters"] = 6,
				["points"] = 590,
				["deaths"] = {
					{
						7, -- [1]
						35.9000000000233, -- [2]
						"Freezing Blast |cFFFF333345,127|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Shortynice"] = {
				["encounters"] = 10,
				["points"] = 960,
				["deaths"] = {
					{
						3, -- [1]
						488.46399999992, -- [2]
						"Broadside |cFFFF333365,900|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						270.508000000031, -- [2]
						"Glacial Ray |cFFFF33332,579|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						345.832999999984, -- [2]
						"Icefall |cFFFF3333217,880|r", -- [3]
					}, -- [3]
					{
						8, -- [1]
						12.1070000000764, -- [2]
						"", -- [3]
					}, -- [4]
				},
				["class"] = "WARRIOR",
			},
			["Jynxxi"] = {
				["encounters"] = 10,
				["points"] = 990,
				["deaths"] = {
					{
						6, -- [1]
						476.886000000057, -- [2]
						"Frozen Solid |cFFFF33336,153|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Persylina-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Coralin-Aggramar"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Seyrino-Hyjal"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Brixs-Shadowsong"] = {
				["encounters"] = 3,
				["points"] = 300,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Brisingir-DieewigeWacht"] = {
				["encounters"] = 4,
				["points"] = 390,
				["deaths"] = {
					{
						11, -- [1]
						119.587999999989, -- [2]
						"Chilling Touch (DoT) |cFFFF33333,624|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
		},
		["diff"] = 14,
	},
	["234214"] = {
		["hash"] = "234214",
		["type"] = "endurance",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 14,
		["player_db"] = {
			["Viridris-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Джигурдинья-Голдринн"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Theodosa-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Phyrena-C'Thun"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Zaktos-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Icrapmypánts-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Nekrowman-ChamberofAspects"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						97.155000000028, -- [2]
						"Flames of Punishment |cFFFF333322,597|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Алануир-Дракономор"] = {
				["encounters"] = 3,
				["points"] = 270,
				["deaths"] = {
					{
						1, -- [1]
						62.670999999973, -- [2]
						"Flames of Punishment |cFFFF33331,658|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						98.826999999932, -- [2]
						"Flames of Punishment |cFFFF333329,508|r", -- [3]
					}, -- [2]
				},
				["class"] = "DEMONHUNTER",
			},
			["Spamwyn-Turalyon"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						57.4889999999432, -- [2]
						"Flames of Punishment |cFFFF333310,598|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Healstation-Khadgar"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						54.60699999996, -- [2]
						"Flames of Punishment |cFFFF333342,693|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Бадсаа-Дракономор"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Shoq-Khadgar"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						60.9390000000131, -- [2]
						"Flames of Punishment |cFFFF33339,335|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Ioanaa-Sylvanas"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Лавкравт-Дракономор"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Спотка-ЧерныйШрам"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Artèmis"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Saracor-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Toryb-DieArguswacht"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Natsukí-Arygos"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Импозантная-Дракономор"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["encounter"] = "Opulence",
			["ej_instance_id"] = 1176,
			["diff"] = 14,
		},
	},
}
DeathGraphsDBCurrent = {
	{
		["deaths"] = {
			{
				["maxhealth"] = 352360,
				["timeofdeath"] = 197.837,
				["name"] = "Supersunny",
				["events"] = {
					{
						false, -- [1]
						61295, -- [2]
						0, -- [3]
						1553808608.488, -- [4]
						24945, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						3165, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						184092, -- [2]
						118346, -- [3]
						1553808608.885, -- [4]
						143291, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						4, -- [1]
						285195, -- [2]
						45, -- [3]
						1553808609.035, -- [4]
						143291, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						33763, -- [2]
						3211, -- [3]
						1553808609.083, -- [4]
						146502, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						119611, -- [2]
						4748, -- [3]
						1553808609.149, -- [4]
						151250, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						false, -- [1]
						183811, -- [2]
						733, -- [3]
						1553808609.487, -- [4]
						151983, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						33763, -- [2]
						1611, -- [3]
						1553808609.904, -- [4]
						153594, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						4, -- [1]
						285195, -- [2]
						46, -- [3]
						1553808610.04, -- [4]
						153594, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						152261, -- [2]
						73342, -- [3]
						1553808610.062, -- [4]
						153594, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						false, -- [1]
						288024, -- [2]
						12438, -- [3]
						1553808610.062, -- [4]
						153594, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						true, -- [1]
						285195, -- [2]
						148941, -- [3]
						1553808610.062, -- [4]
						90433, -- [5]
						"[*] Deathly Withering", -- [6]
						85780, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						272260, -- [2]
						4301, -- [3]
						1553808610.087, -- [4]
						94734, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						77489, -- [2]
						2276, -- [3]
						1553808610.106, -- [4]
						97010, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						2061, -- [2]
						20875, -- [3]
						1553808610.127, -- [4]
						117885, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553808610.447, -- [4]
						119010, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						183811, -- [2]
						736, -- [3]
						1553808610.447, -- [4]
						119746, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						false, -- [1]
						33763, -- [2]
						1615, -- [3]
						1553808610.686, -- [4]
						121361, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						183811, -- [2]
						737, -- [3]
						1553808610.778, -- [4]
						122098, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						119611, -- [2]
						2381, -- [3]
						1553808610.832, -- [4]
						124479, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						4, -- [1]
						285195, -- [2]
						47, -- [3]
						1553808611.029, -- [4]
						124479, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						false, -- [1]
						61295, -- [2]
						5862, -- [3]
						1553808611.091, -- [4]
						130341, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						2061, -- [2]
						41750, -- [3]
						1553808611.493, -- [4]
						172091, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						33763, -- [2]
						1620, -- [3]
						1553808611.493, -- [4]
						173711, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553808611.713, -- [4]
						174836, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						183811, -- [2]
						740, -- [3]
						1553808611.713, -- [4]
						175576, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						1, -- [2]
						91424, -- [3]
						1553808611.76, -- [4]
						175576, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						4, -- [1]
						285195, -- [2]
						48, -- [3]
						1553808612.044, -- [4]
						84152, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						33763, -- [2]
						1625, -- [3]
						1553808612.292, -- [4]
						85777, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						false, -- [1]
						119611, -- [2]
						2393, -- [3]
						1553808612.508, -- [4]
						88170, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						183811, -- [2]
						633, -- [3]
						1553808612.938, -- [4]
						88803, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						4, -- [1]
						285195, -- [2]
						49, -- [3]
						1553808613.033, -- [4]
						88803, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						285195, -- [2]
						88803, -- [3]
						1553808613.074, -- [4]
						1, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						69851, -- [10]
					}, -- [32]
					{
						3, -- [1]
						642, -- [2]
						1, -- [3]
						1553808556.76, -- [4]
						0, -- [5]
						"Supersunny", -- [6]
					}, -- [33]
				},
				["class"] = "PALADIN",
				["timestring"] = "3m 17s",
				["time"] = 1553808613.097,
			}, -- [1]
			{
				["maxhealth"] = 231700,
				["timeofdeath"] = 247.061999999998,
				["name"] = "Neferupitou",
				["events"] = {
					{
						4, -- [1]
						285195, -- [2]
						8, -- [3]
						1553808651.41, -- [4]
						252377, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						143924, -- [2]
						1778, -- [3]
						1553808651.502, -- [4]
						254155, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						true, -- [1]
						285195, -- [2]
						27592, -- [3]
						1553808651.502, -- [4]
						226563, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						73921, -- [2]
						2466, -- [3]
						1553808652.425, -- [4]
						229029, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						2790, -- [3]
						1553808652.797, -- [4]
						231819, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						596, -- [2]
						9243, -- [3]
						1553808653.023, -- [4]
						241062, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						77489, -- [2]
						4265, -- [3]
						1553808653.441, -- [4]
						245327, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						510, -- [3]
						1553808654.044, -- [4]
						245837, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						73921, -- [2]
						4771, -- [3]
						1553808654.15, -- [4]
						250608, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						4, -- [1]
						285195, -- [2]
						9, -- [3]
						1553808654.423, -- [4]
						250608, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						true, -- [1]
						285195, -- [2]
						31041, -- [3]
						1553808654.479, -- [4]
						219567, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						204883, -- [2]
						11757, -- [3]
						1553808654.828, -- [4]
						231324, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						743, -- [3]
						1553808655.255, -- [4]
						232067, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						73921, -- [2]
						1915, -- [3]
						1553808655.535, -- [4]
						233982, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808655.95, -- [4]
						233982, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						true, -- [1]
						287147, -- [2]
						69007, -- [3]
						1553808655.95, -- [4]
						164975, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						77489, -- [2]
						3988, -- [3]
						1553808656.432, -- [4]
						168963, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [17]
					{
						false, -- [1]
						1064, -- [2]
						18552, -- [3]
						1553808656.471, -- [4]
						187515, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						143924, -- [2]
						629, -- [3]
						1553808656.509, -- [4]
						188144, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						4, -- [1]
						285195, -- [2]
						10, -- [3]
						1553808657.42, -- [4]
						188144, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						true, -- [1]
						285195, -- [2]
						34490, -- [3]
						1553808657.484, -- [4]
						153654, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						419, -- [3]
						1553808657.877, -- [4]
						154073, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [22]
					{
						false, -- [1]
						1064, -- [2]
						13555, -- [3]
						1553808658.664, -- [4]
						167628, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [23]
					{
						false, -- [1]
						77489, -- [2]
						3988, -- [3]
						1553808659.446, -- [4]
						171616, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						1267, -- [3]
						1553808659.489, -- [4]
						172883, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [25]
					{
						4, -- [1]
						285195, -- [2]
						11, -- [3]
						1553808660.435, -- [4]
						172883, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						true, -- [1]
						285195, -- [2]
						37939, -- [3]
						1553808660.435, -- [4]
						134944, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						126, -- [3]
						1553808660.89, -- [4]
						135070, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808661.281, -- [4]
						135070, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						287147, -- [2]
						69007, -- [3]
						1553808661.281, -- [4]
						66063, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						1373, -- [3]
						1553808662.225, -- [4]
						67436, -- [5]
						"Neferupitou", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287147, -- [2]
						67436, -- [3]
						1553808662.322, -- [4]
						1, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						1571, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Neferupitou", -- [6]
					}, -- [33]
				},
				["class"] = "HUNTER",
				["timestring"] = "4m 7s",
				["time"] = 1553808662.322,
			}, -- [2]
			{
				["maxhealth"] = 230360,
				["timeofdeath"] = 247.307000000001,
				["name"] = "Nelwyn",
				["events"] = {
					{
						2, -- [1]
						20484, -- [2]
						1, -- [3]
						1553808677.405, -- [4]
						0, -- [5]
						"Laki", -- [6]
					}, -- [1]
					{
						false, -- [1]
						73921, -- [2]
						2553, -- [3]
						1553808652.425, -- [4]
						206690, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						77489, -- [2]
						4087, -- [3]
						1553808652.54, -- [4]
						210777, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						596, -- [2]
						9242, -- [3]
						1553808653.023, -- [4]
						220019, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						66, -- [3]
						1553808653.615, -- [4]
						220085, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						73921, -- [2]
						2487, -- [3]
						1553808654.15, -- [4]
						222572, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						4, -- [1]
						285195, -- [2]
						9, -- [3]
						1553808654.423, -- [4]
						222572, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						true, -- [1]
						285195, -- [2]
						30869, -- [3]
						1553808654.479, -- [4]
						191703, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						270661, -- [2]
						1710, -- [3]
						1553808654.794, -- [4]
						193413, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						false, -- [1]
						204883, -- [2]
						11757, -- [3]
						1553808654.828, -- [4]
						205170, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						143924, -- [2]
						547, -- [3]
						1553808654.867, -- [4]
						205717, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						73921, -- [2]
						3992, -- [3]
						1553808655.535, -- [4]
						209709, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						false, -- [1]
						77489, -- [2]
						3406, -- [3]
						1553808655.568, -- [4]
						213115, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						145109, -- [2]
						7602, -- [3]
						1553808656.068, -- [4]
						220717, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						143924, -- [2]
						434, -- [3]
						1553808656.1, -- [4]
						221151, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						275499, -- [2]
						1044, -- [3]
						1553808656.471, -- [4]
						222195, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						4, -- [1]
						288415, -- [2]
						1, -- [3]
						1553808656.772, -- [4]
						222195, -- [5]
						"Bwonsamdi", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						288415, -- [2]
						68624, -- [3]
						1553808656.772, -- [4]
						153571, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808656.848, -- [4]
						153571, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						true, -- [1]
						287147, -- [2]
						68624, -- [3]
						1553808656.848, -- [4]
						84947, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						4, -- [1]
						285195, -- [2]
						10, -- [3]
						1553808657.42, -- [4]
						84947, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						true, -- [1]
						285195, -- [2]
						34299, -- [3]
						1553808657.484, -- [4]
						50648, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						1, -- [1]
						22812, -- [2]
						1, -- [3]
						1553808658.286, -- [4]
						50648, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						77489, -- [2]
						0, -- [3]
						1553808658.543, -- [4]
						50648, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						3405, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						1064, -- [2]
						0, -- [3]
						1553808658.664, -- [4]
						50648, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						44714, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						4, -- [1]
						285195, -- [2]
						1, -- [3]
						1553808660.435, -- [4]
						50648, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						145109, -- [2]
						0, -- [3]
						1553808661.043, -- [4]
						50648, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						7602, -- [8]
					}, -- [27]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808661.521, -- [4]
						50648, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						false, -- [1]
						280165, -- [2]
						30792, -- [3]
						1553808661.521, -- [4]
						50648, -- [5]
						"Nelwyn", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						287147, -- [2]
						63134, -- [3]
						1553808661.521, -- [4]
						18306, -- [5]
						"[*] Dread Reaping", -- [6]
						30792, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						77489, -- [2]
						0, -- [3]
						1553808661.565, -- [4]
						18306, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						3405, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						false, -- [1]
						596, -- [2]
						0, -- [3]
						1553808661.85, -- [4]
						18306, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						22778, -- [8]
					}, -- [32]
					{
						true, -- [1]
						287147, -- [2]
						18306, -- [3]
						1553808662.525, -- [4]
						1, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						44828, -- [10]
					}, -- [33]
					{
						3, -- [1]
						22812, -- [2]
						1, -- [3]
						1553808658.286, -- [4]
						0, -- [5]
						"Nelwyn", -- [6]
					}, -- [34]
				},
				["class"] = "DRUID",
				["timestring"] = "4m 7s",
				["time"] = 1553808662.567,
			}, -- [3]
			{
				["maxhealth"] = 246260,
				["timeofdeath"] = 303.549999999996,
				["name"] = "Salanâ",
				["events"] = {
					{
						true, -- [1]
						286779, -- [2]
						27583, -- [3]
						1553808713.668, -- [4]
						209294, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						48438, -- [2]
						2297, -- [3]
						1553808713.969, -- [4]
						211591, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						77, -- [3]
						1553808714.154, -- [4]
						211668, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						288839, -- [2]
						11765, -- [3]
						1553808714.32, -- [4]
						223433, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						true, -- [1]
						286779, -- [2]
						27584, -- [3]
						1553808714.602, -- [4]
						195849, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						774, -- [2]
						3679, -- [3]
						1553808714.774, -- [4]
						199528, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						48438, -- [2]
						2171, -- [3]
						1553808714.812, -- [4]
						201699, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						119611, -- [2]
						2386, -- [3]
						1553808714.861, -- [4]
						204085, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						true, -- [1]
						288053, -- [2]
						16935, -- [3]
						1553808715.024, -- [4]
						187150, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						314, -- [3]
						1553808715.45, -- [4]
						187464, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						true, -- [1]
						286779, -- [2]
						27584, -- [3]
						1553808715.61, -- [4]
						159880, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						48438, -- [2]
						2046, -- [3]
						1553808715.61, -- [4]
						161926, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						77489, -- [2]
						5033, -- [3]
						1553808715.61, -- [4]
						166959, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						true, -- [1]
						288053, -- [2]
						16935, -- [3]
						1553808716.143, -- [4]
						150024, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						48438, -- [2]
						1932, -- [3]
						1553808716.423, -- [4]
						151956, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						true, -- [1]
						286779, -- [2]
						27583, -- [3]
						1553808716.609, -- [4]
						124373, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						166, -- [3]
						1553808716.851, -- [4]
						124539, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						119611, -- [2]
						2374, -- [3]
						1553808716.851, -- [4]
						126913, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						286671, -- [2]
						80815, -- [3]
						1553808717.126, -- [4]
						46098, -- [5]
						"Phantom of Retribution", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						280052, -- [2]
						9688, -- [3]
						1553808717.126, -- [4]
						55786, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						774, -- [2]
						3668, -- [3]
						1553808717.176, -- [4]
						59454, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						false, -- [1]
						774, -- [2]
						3669, -- [3]
						1553808717.176, -- [4]
						63123, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						48438, -- [2]
						1821, -- [3]
						1553808717.233, -- [4]
						64944, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						2061, -- [2]
						19950, -- [3]
						1553808717.615, -- [4]
						84894, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						true, -- [1]
						286779, -- [2]
						27583, -- [3]
						1553808717.615, -- [4]
						57311, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						48438, -- [2]
						1704, -- [3]
						1553808718.045, -- [4]
						59015, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						110, -- [3]
						1553808718.244, -- [4]
						59125, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						true, -- [1]
						288053, -- [2]
						16935, -- [3]
						1553808718.436, -- [4]
						42190, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						true, -- [1]
						288053, -- [2]
						16935, -- [3]
						1553808718.436, -- [4]
						25255, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						true, -- [1]
						288053, -- [2]
						19476, -- [3]
						1553808718.558, -- [4]
						5779, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						77489, -- [2]
						6401, -- [3]
						1553808718.642, -- [4]
						12180, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						false, -- [1]
						119611, -- [2]
						4760, -- [3]
						1553808718.642, -- [4]
						16940, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Salanâ", -- [6]
					}, -- [33]
				},
				["class"] = "PRIEST",
				["timestring"] = "5m 3s",
				["time"] = 1553808718.81,
			}, -- [4]
			{
				["maxhealth"] = 223180,
				["timeofdeath"] = 304.245999999999,
				["name"] = "Alleycut",
				["events"] = {
					{
						false, -- [1]
						183811, -- [2]
						560, -- [3]
						1553808710.134, -- [4]
						215371, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						183811, -- [2]
						560, -- [3]
						1553808710.282, -- [4]
						215931, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						183811, -- [2]
						560, -- [3]
						1553808710.395, -- [4]
						216491, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						183811, -- [2]
						560, -- [3]
						1553808710.395, -- [4]
						217051, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						183811, -- [2]
						560, -- [3]
						1553808710.533, -- [4]
						217611, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						25013, -- [3]
						1553808710.616, -- [4]
						242624, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						288333, -- [2]
						1137, -- [3]
						1553808710.88, -- [4]
						243761, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						157982, -- [2]
						848, -- [3]
						1553808711.174, -- [4]
						244609, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						288333, -- [2]
						1137, -- [3]
						1553808711.592, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						81269, -- [2]
						2596, -- [3]
						1553808711.852, -- [4]
						245480, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553808711.965, -- [4]
						245480, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						288333, -- [2]
						1137, -- [3]
						1553808712.383, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						81269, -- [2]
						5176, -- [3]
						1553808713.074, -- [4]
						245480, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						288333, -- [2]
						1137, -- [3]
						1553808713.362, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						288333, -- [2]
						650, -- [3]
						1553808713.883, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						269279, -- [2]
						15934, -- [3]
						1553808715.024, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						true, -- [7]
						0, -- [8]
					}, -- [16]
					{
						true, -- [1]
						288053, -- [2]
						15934, -- [3]
						1553808715.024, -- [4]
						245480, -- [5]
						"Death Rift <[*] Death Rift> <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						269279, -- [2]
						1760, -- [3]
						1553808716.143, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						288053, -- [2]
						15934, -- [3]
						1553808716.143, -- [4]
						231306, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						1760, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						270117, -- [2]
						6787, -- [3]
						1553808716.143, -- [4]
						238093, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808717.075, -- [4]
						238093, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						true, -- [1]
						287147, -- [2]
						59752, -- [3]
						1553808717.075, -- [4]
						178341, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						true, -- [1]
						286671, -- [2]
						78936, -- [3]
						1553808717.126, -- [4]
						99405, -- [5]
						"Phantom of Retribution", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						3347, -- [3]
						1553808717.278, -- [4]
						102752, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						285572, -- [2]
						41059, -- [3]
						1553808717.93, -- [4]
						61693, -- [5]
						"Phantom of Retribution", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						191840, -- [2]
						6417, -- [3]
						1553808718.045, -- [4]
						68110, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						true, -- [1]
						288053, -- [2]
						15935, -- [3]
						1553808718.436, -- [4]
						52175, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						true, -- [1]
						288053, -- [2]
						15935, -- [3]
						1553808718.436, -- [4]
						36240, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						true, -- [1]
						288053, -- [2]
						15935, -- [3]
						1553808718.558, -- [4]
						20305, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						true, -- [1]
						288053, -- [2]
						15934, -- [3]
						1553808718.81, -- [4]
						4371, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						2217, -- [3]
						1553808718.867, -- [4]
						6588, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						288053, -- [2]
						6588, -- [3]
						1553808719.255, -- [4]
						1, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						9347, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Alleycut", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "5m 4s",
				["time"] = 1553808719.506,
			}, -- [5]
			{
				["maxhealth"] = 230360,
				["timeofdeath"] = 305.046999999999,
				["name"] = "Nelwyn",
				["events"] = {
					{
						false, -- [1]
						270661, -- [2]
						1710, -- [3]
						1553808715.61, -- [4]
						216588, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						false, -- [1]
						774, -- [2]
						3668, -- [3]
						1553808715.978, -- [4]
						220256, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						145109, -- [2]
						6911, -- [3]
						1553808716.071, -- [4]
						227167, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						true, -- [1]
						288053, -- [2]
						17528, -- [3]
						1553808716.143, -- [4]
						209639, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						150, -- [3]
						1553808716.318, -- [4]
						209789, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						48438, -- [2]
						1932, -- [3]
						1553808716.423, -- [4]
						211721, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						true, -- [1]
						286671, -- [2]
						86934, -- [3]
						1553808717.126, -- [4]
						124787, -- [5]
						"Phantom of Retribution", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						774, -- [2]
						3668, -- [3]
						1553808717.126, -- [4]
						128455, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						48438, -- [2]
						1821, -- [3]
						1553808717.233, -- [4]
						130276, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						887, -- [3]
						1553808717.713, -- [4]
						131163, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [10]
					{
						false, -- [1]
						48438, -- [2]
						1704, -- [3]
						1553808718.045, -- [4]
						132867, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						true, -- [1]
						288053, -- [2]
						17528, -- [3]
						1553808718.436, -- [4]
						115339, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808718.436, -- [4]
						97810, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808718.558, -- [4]
						80281, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						270661, -- [2]
						1711, -- [3]
						1553808718.683, -- [4]
						81992, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [15]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808718.81, -- [4]
						64463, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						60, -- [3]
						1553808718.867, -- [4]
						64523, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [17]
					{
						false, -- [1]
						48438, -- [2]
						1572, -- [3]
						1553808718.973, -- [4]
						66095, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [18]
					{
						false, -- [1]
						269238, -- [2]
						9070, -- [3]
						1553808719.128, -- [4]
						75165, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						191840, -- [2]
						11893, -- [3]
						1553808719.128, -- [4]
						87058, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [20]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808719.255, -- [4]
						69529, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808719.255, -- [4]
						52000, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						48438, -- [2]
						1124, -- [3]
						1553808719.556, -- [4]
						53124, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						774, -- [2]
						3900, -- [3]
						1553808719.556, -- [4]
						57024, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [24]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808719.711, -- [4]
						39495, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						288053, -- [2]
						17529, -- [3]
						1553808719.711, -- [4]
						21966, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						287255, -- [2]
						2594, -- [3]
						1553808719.711, -- [4]
						24560, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						274436, -- [2]
						428, -- [3]
						1553808719.711, -- [4]
						24988, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						183811, -- [2]
						666, -- [3]
						1553808719.788, -- [4]
						25654, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [29]
					{
						true, -- [1]
						288053, -- [2]
						20158, -- [3]
						1553808720.008, -- [4]
						5496, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						397, -- [3]
						1553808720.174, -- [4]
						5893, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						288053, -- [2]
						5893, -- [3]
						1553808720.307, -- [4]
						1, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						14265, -- [10]
					}, -- [32]
					{
						3, -- [1]
						22812, -- [2]
						1, -- [3]
						1553808658.286, -- [4]
						0, -- [5]
						"Nelwyn", -- [6]
					}, -- [33]
				},
				["class"] = "DRUID",
				["timestring"] = "5m 5s",
				["time"] = 1553808720.307,
			}, -- [6]
			{
				["maxhealth"] = 234420,
				["timeofdeath"] = 310.106999999996,
				["name"] = "Aspern",
				["events"] = {
					{
						false, -- [1]
						269108, -- [2]
						7227, -- [3]
						1553808720.485, -- [4]
						90242, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						4, -- [1]
						285195, -- [2]
						1, -- [3]
						1553808720.485, -- [4]
						90242, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						61295, -- [2]
						43814, -- [3]
						1553808720.485, -- [4]
						134056, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						73921, -- [2]
						4170, -- [3]
						1553808720.958, -- [4]
						138226, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808721.076, -- [4]
						138226, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						true, -- [1]
						287147, -- [2]
						66448, -- [3]
						1553808721.076, -- [4]
						71778, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808721.706, -- [4]
						71778, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						true, -- [1]
						287147, -- [2]
						66448, -- [3]
						1553808721.706, -- [4]
						5330, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						280177, -- [2]
						4920, -- [3]
						1553808722.287, -- [4]
						10250, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						false, -- [1]
						259760, -- [2]
						246, -- [3]
						1553808722.343, -- [4]
						10496, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						false, -- [1]
						275499, -- [2]
						2686, -- [3]
						1553808722.343, -- [4]
						13182, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						77489, -- [2]
						4600, -- [3]
						1553808722.343, -- [4]
						17782, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808722.504, -- [4]
						17782, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						87023, -- [2]
						72469, -- [3]
						1553808722.504, -- [4]
						90251, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						86949, -- [2]
						76415, -- [3]
						1553808722.504, -- [4]
						90251, -- [5]
						"Aspern", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						true, -- [1]
						287147, -- [2]
						76415, -- [3]
						1553808722.504, -- [4]
						90251, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						73921, -- [2]
						3590, -- [3]
						1553808722.504, -- [4]
						93841, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						61295, -- [2]
						3381, -- [3]
						1553808723.074, -- [4]
						97222, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808723.245, -- [4]
						97222, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						true, -- [1]
						287147, -- [2]
						66448, -- [3]
						1553808723.245, -- [4]
						30774, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						280177, -- [2]
						8945, -- [3]
						1553808723.245, -- [4]
						39719, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						259760, -- [2]
						448, -- [3]
						1553808723.331, -- [4]
						40167, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						73921, -- [2]
						1824, -- [3]
						1553808723.416, -- [4]
						41991, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						4, -- [1]
						285195, -- [2]
						1, -- [3]
						1553808723.481, -- [4]
						41991, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						281265, -- [2]
						1568, -- [3]
						1553808723.742, -- [4]
						43559, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						87023, -- [2]
						19500, -- [3]
						1553808724.014, -- [4]
						24059, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						280177, -- [2]
						4472, -- [3]
						1553808724.056, -- [4]
						28531, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						259760, -- [2]
						224, -- [3]
						1553808724.133, -- [4]
						28755, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						false, -- [1]
						280177, -- [2]
						8945, -- [3]
						1553808724.959, -- [4]
						37700, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						259760, -- [2]
						447, -- [3]
						1553808725.006, -- [4]
						38147, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808725.248, -- [4]
						38147, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287147, -- [2]
						38147, -- [3]
						1553808725.289, -- [4]
						1, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						38268, -- [10]
					}, -- [32]
					{
						3, -- [1]
						45438, -- [2]
						1, -- [3]
						1553808666.652, -- [4]
						0, -- [5]
						"Aspern", -- [6]
					}, -- [33]
				},
				["class"] = "MAGE",
				["timestring"] = "5m 10s",
				["time"] = 1553808725.367,
			}, -- [7]
			{
				["maxhealth"] = 230220,
				["timeofdeath"] = 326.776999999995,
				["name"] = "Inánná",
				["events"] = {
					{
						false, -- [1]
						191840, -- [2]
						7472, -- [3]
						1553808732.261, -- [4]
						179675, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						false, -- [1]
						183811, -- [2]
						1332, -- [3]
						1553808732.344, -- [4]
						181007, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						183811, -- [2]
						663, -- [3]
						1553808732.479, -- [4]
						181670, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						120692, -- [2]
						21236, -- [3]
						1553808733.096, -- [4]
						202906, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						191840, -- [2]
						602, -- [3]
						1553808733.096, -- [4]
						203508, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						14943, -- [3]
						1553808733.23, -- [4]
						218451, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						183811, -- [2]
						663, -- [3]
						1553808733.381, -- [4]
						219114, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						285572, -- [2]
						48124, -- [3]
						1553808733.629, -- [4]
						170990, -- [5]
						"Phantom of Retribution", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						77489, -- [2]
						6671, -- [3]
						1553808734.172, -- [4]
						177661, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						true, -- [1]
						288053, -- [2]
						18367, -- [3]
						1553808734.246, -- [4]
						159294, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						true, -- [1]
						288053, -- [2]
						18367, -- [3]
						1553808734.895, -- [4]
						92831, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						191840, -- [2]
						605, -- [3]
						1553808734.943, -- [4]
						93436, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						183811, -- [2]
						660, -- [3]
						1553808734.943, -- [4]
						94096, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						183811, -- [2]
						663, -- [3]
						1553808735.391, -- [4]
						94759, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						191840, -- [2]
						603, -- [3]
						1553808736.902, -- [4]
						95362, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						4, -- [1]
						286779, -- [2]
						1, -- [3]
						1553808736.939, -- [4]
						95362, -- [5]
						"Phantom of Slaughter", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						false, -- [1]
						77489, -- [2]
						6671, -- [3]
						1553808737.179, -- [4]
						102033, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						183811, -- [2]
						670, -- [3]
						1553808737.401, -- [4]
						102703, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						288053, -- [2]
						18367, -- [3]
						1553808737.914, -- [4]
						84336, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						true, -- [1]
						286779, -- [2]
						27501, -- [3]
						1553808738.034, -- [4]
						56835, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						183811, -- [2]
						672, -- [3]
						1553808738.506, -- [4]
						57507, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						false, -- [1]
						191840, -- [2]
						601, -- [3]
						1553808738.622, -- [4]
						58108, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						183811, -- [2]
						672, -- [3]
						1553808738.749, -- [4]
						58780, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						15290, -- [2]
						37525, -- [3]
						1553808738.829, -- [4]
						96305, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						286779, -- [2]
						27501, -- [3]
						1553808738.939, -- [4]
						68804, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						286779, -- [2]
						27501, -- [3]
						1553808739.952, -- [4]
						41303, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						183811, -- [2]
						1352, -- [3]
						1553808740, -- [4]
						42655, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						77489, -- [2]
						6671, -- [3]
						1553808740.174, -- [4]
						49326, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						191840, -- [2]
						1197, -- [3]
						1553808740.539, -- [4]
						50523, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						true, -- [1]
						286779, -- [2]
						31626, -- [3]
						1553808741.019, -- [4]
						18897, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						183811, -- [2]
						673, -- [3]
						1553808741.928, -- [4]
						19570, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						286779, -- [2]
						19570, -- [3]
						1553808741.984, -- [4]
						1, -- [5]
						"Phantom of Slaughter", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						12056, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Inánná", -- [6]
					}, -- [33]
				},
				["class"] = "PALADIN",
				["timestring"] = "5m 26s",
				["time"] = 1553808742.037,
			}, -- [8]
			{
				["maxhealth"] = 220760,
				["timeofdeath"] = 329.479999999996,
				["name"] = "Tyrellan",
				["events"] = {
					{
						false, -- [1]
						183811, -- [2]
						666, -- [3]
						1553808736.939, -- [4]
						226084, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						183811, -- [2]
						666, -- [3]
						1553808736.939, -- [4]
						226750, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						183811, -- [2]
						667, -- [3]
						1553808736.98, -- [4]
						227417, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						183811, -- [2]
						667, -- [3]
						1553808736.98, -- [4]
						228084, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						1178, -- [3]
						1553808737.812, -- [4]
						229262, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						true, -- [1]
						288053, -- [2]
						16021, -- [3]
						1553808737.914, -- [4]
						213241, -- [5]
						"Death Rift <[*] Death Rift>", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						15290, -- [2]
						13348, -- [3]
						1553808737.914, -- [4]
						226589, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						288449, -- [2]
						34245, -- [3]
						1553808737.914, -- [4]
						192344, -- [5]
						"King Rastakhan", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						183811, -- [2]
						1339, -- [3]
						1553808738.034, -- [4]
						193683, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						774, -- [2]
						3221, -- [3]
						1553808738.622, -- [4]
						196904, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						274436, -- [2]
						423, -- [3]
						1553808738.669, -- [4]
						197327, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						191840, -- [2]
						601, -- [3]
						1553808738.785, -- [4]
						197928, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						589, -- [3]
						1553808738.899, -- [4]
						198517, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						183811, -- [2]
						673, -- [3]
						1553808738.988, -- [4]
						199190, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						183811, -- [2]
						673, -- [3]
						1553808739.149, -- [4]
						199863, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						77489, -- [2]
						5908, -- [3]
						1553808739.665, -- [4]
						205771, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						true, -- [1]
						288449, -- [2]
						34244, -- [3]
						1553808739.91, -- [4]
						171527, -- [5]
						"King Rastakhan", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						855, -- [3]
						1553808740.385, -- [4]
						172382, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						191840, -- [2]
						599, -- [3]
						1553808740.62, -- [4]
						172981, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						774, -- [2]
						3224, -- [3]
						1553808741.019, -- [4]
						176205, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						274436, -- [2]
						424, -- [3]
						1553808741.019, -- [4]
						176629, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						92, -- [3]
						1553808741.463, -- [4]
						176721, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						true, -- [1]
						288449, -- [2]
						34245, -- [3]
						1553808741.928, -- [4]
						142476, -- [5]
						"King Rastakhan", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						191840, -- [2]
						510, -- [3]
						1553808742.601, -- [4]
						142986, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						774, -- [2]
						2165, -- [3]
						1553808742.649, -- [4]
						145151, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						274436, -- [2]
						424, -- [3]
						1553808742.689, -- [4]
						145575, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						24, -- [3]
						1553808742.858, -- [4]
						145599, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						true, -- [1]
						286671, -- [2]
						83960, -- [3]
						1553808742.972, -- [4]
						61639, -- [5]
						"Phantom of Retribution", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						true, -- [1]
						288449, -- [2]
						34244, -- [3]
						1553808743.889, -- [4]
						27395, -- [5]
						"King Rastakhan", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						255, -- [3]
						1553808744.13, -- [4]
						27650, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						191840, -- [2]
						513, -- [3]
						1553808744.406, -- [4]
						28163, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						285349, -- [2]
						28163, -- [3]
						1553808744.74, -- [4]
						1, -- [5]
						"King Rastakhan", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						15070, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Tyrellan", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "5m 29s",
				["time"] = 1553808744.74,
			}, -- [9]
			{
				["maxhealth"] = 229320,
				["timeofdeath"] = 332.125,
				["name"] = "Almîna",
				["events"] = {
					{
						true, -- [1]
						285195, -- [2]
						23453, -- [3]
						1553808738.575, -- [4]
						185556, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808739.358, -- [4]
						185556, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						true, -- [1]
						287147, -- [2]
						67035, -- [3]
						1553808739.358, -- [4]
						118521, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						73921, -- [2]
						2795, -- [3]
						1553808739.665, -- [4]
						121316, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						291843, -- [2]
						833, -- [3]
						1553808739.83, -- [4]
						122149, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						204883, -- [2]
						23515, -- [3]
						1553808740, -- [4]
						145664, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						120692, -- [2]
						13840, -- [3]
						1553808740.174, -- [4]
						159504, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						77489, -- [2]
						7232, -- [3]
						1553808740.385, -- [4]
						166736, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						73921, -- [2]
						2727, -- [3]
						1553808741.341, -- [4]
						169463, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						4, -- [1]
						285195, -- [2]
						8, -- [3]
						1553808741.543, -- [4]
						169463, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						true, -- [1]
						285195, -- [2]
						26803, -- [3]
						1553808741.543, -- [4]
						142660, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						291843, -- [2]
						733, -- [3]
						1553808741.774, -- [4]
						143393, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						73921, -- [2]
						2697, -- [3]
						1553808743.119, -- [4]
						146090, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						596, -- [2]
						9798, -- [3]
						1553808743.208, -- [4]
						155888, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						77489, -- [2]
						5803, -- [3]
						1553808743.358, -- [4]
						161691, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						291843, -- [2]
						734, -- [3]
						1553808743.8, -- [4]
						162425, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						4, -- [1]
						288415, -- [2]
						1, -- [3]
						1553808744.245, -- [4]
						162425, -- [5]
						"Bwonsamdi", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						288415, -- [2]
						67035, -- [3]
						1553808744.245, -- [4]
						95390, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						4, -- [1]
						285195, -- [2]
						9, -- [3]
						1553808744.406, -- [4]
						95390, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						true, -- [1]
						285195, -- [2]
						30154, -- [3]
						1553808744.672, -- [4]
						65236, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						73921, -- [2]
						0, -- [3]
						1553808744.906, -- [4]
						65236, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						3002, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						1064, -- [2]
						0, -- [3]
						1553808745.385, -- [4]
						65236, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						10296, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						291843, -- [2]
						0, -- [3]
						1553808745.779, -- [4]
						65236, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						892, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						false, -- [1]
						73921, -- [2]
						0, -- [3]
						1553808746.144, -- [4]
						65236, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						2461, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						1, -- [1]
						108271, -- [2]
						1, -- [3]
						1553808746.273, -- [4]
						65236, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						274416, -- [2]
						0, -- [3]
						1553808746.32, -- [4]
						65236, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						24581, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						77489, -- [2]
						0, -- [3]
						1553808746.409, -- [4]
						65236, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						5802, -- [8]
					}, -- [27]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808746.852, -- [4]
						65236, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						true, -- [1]
						287147, -- [2]
						40221, -- [3]
						1553808746.852, -- [4]
						25015, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						4, -- [1]
						287147, -- [2]
						1, -- [3]
						1553808747.313, -- [4]
						25015, -- [5]
						"[*] Dread Reaping", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						false, -- [1]
						274416, -- [2]
						0, -- [3]
						1553808747.313, -- [4]
						25015, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						12290, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287147, -- [2]
						25015, -- [3]
						1553808747.385, -- [4]
						1, -- [5]
						"[*] Dread Reaping", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						21239, -- [10]
					}, -- [32]
					{
						3, -- [1]
						108271, -- [2]
						1, -- [3]
						1553808746.273, -- [4]
						0, -- [5]
						"Almîna", -- [6]
					}, -- [33]
				},
				["class"] = "SHAMAN",
				["timestring"] = "5m 32s",
				["time"] = 1553808747.385,
			}, -- [10]
		},
		["bossname"] = "King Rastakhan",
		["bossicon"] = {
			0.25, -- [1]
			0.5, -- [2]
			0.25, -- [3]
			0.5, -- [4]
			"Interface\\AddOns\\Details\\images\\raid\\DazaralorRaid_BossFaces", -- [5]
		},
		["date"] = 44149.066,
		["timeelapsed"] = 349.173999999999,
	}, -- [1]
	{
		["deaths"] = {
			{
				["maxhealth"] = 231940,
				["timeofdeath"] = 10.7280000000028,
				["name"] = "Soely",
				["events"] = {
					{
						2, -- [1]
						20484, -- [2]
						1, -- [3]
						1553808147.704, -- [4]
						0, -- [5]
						"Laki", -- [6]
					}, -- [1]
					{
						false, -- [1]
						120692, -- [2]
						9556, -- [3]
						1553808128.918, -- [4]
						255120, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						288839, -- [2]
						5882, -- [3]
						1553808129.793, -- [4]
						255120, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						false, -- [1]
						77489, -- [2]
						1587, -- [3]
						1553808131.951, -- [4]
						255120, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						4, -- [1]
						284676, -- [2]
						1, -- [3]
						1553808134.717, -- [4]
						255120, -- [5]
						"[*] Seal of Purification", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						true, -- [1]
						284676, -- [2]
						33894, -- [3]
						1553808134.717, -- [4]
						221226, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						4, -- [1]
						284676, -- [2]
						1, -- [3]
						1553808134.717, -- [4]
						221226, -- [5]
						"[*] Seal of Purification", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						true, -- [1]
						284676, -- [2]
						33894, -- [3]
						1553808134.717, -- [4]
						187332, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						132, -- [3]
						1553808134.85, -- [4]
						187464, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						77489, -- [2]
						1586, -- [3]
						1553808134.955, -- [4]
						189050, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [10]
					{
						true, -- [1]
						284676, -- [2]
						33893, -- [3]
						1553808135.71, -- [4]
						155157, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						true, -- [1]
						284676, -- [2]
						33894, -- [3]
						1553808135.71, -- [4]
						121263, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						222, -- [3]
						1553808136.037, -- [4]
						121485, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						145110, -- [2]
						7602, -- [3]
						1553808136.065, -- [4]
						129087, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [14]
					{
						false, -- [1]
						774, -- [2]
						3589, -- [3]
						1553808136.445, -- [4]
						132676, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [15]
					{
						false, -- [1]
						274436, -- [2]
						853, -- [3]
						1553808136.445, -- [4]
						133529, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [16]
					{
						4, -- [1]
						290955, -- [2]
						1, -- [3]
						1553808136.533, -- [4]
						133529, -- [5]
						"Headhunter Gal'wana", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						290955, -- [2]
						60362, -- [3]
						1553808136.533, -- [4]
						73167, -- [5]
						"Headhunter Gal'wana", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						284676, -- [2]
						33894, -- [3]
						1553808136.712, -- [4]
						39273, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						true, -- [1]
						284676, -- [2]
						33893, -- [3]
						1553808136.712, -- [4]
						5380, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						4, -- [1]
						284676, -- [2]
						1, -- [3]
						1553808136.781, -- [4]
						5380, -- [5]
						"[*] Seal of Purification", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						true, -- [1]
						284676, -- [2]
						5380, -- [3]
						1553808136.803, -- [4]
						1, -- [5]
						"[*] Seal of Purification", -- [6]
						nil, -- [7]
						6, -- [8]
						false, -- [9]
						33598, -- [10]
					}, -- [22]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Soely", -- [6]
					}, -- [23]
				},
				["class"] = "SHAMAN",
				["timestring"] = "0m 10s",
				["time"] = 1553808136.803,
			}, -- [1]
			{
				["maxhealth"] = 231940,
				["timeofdeath"] = 180.088000000003,
				["name"] = "Soely",
				["events"] = {
					{
						true, -- [1]
						285044, -- [2]
						67726, -- [3]
						1553808301.393, -- [4]
						41482, -- [5]
						"Plague Toad <King Rastakhan>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						33110, -- [2]
						9289, -- [3]
						1553808301.433, -- [4]
						50771, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						77489, -- [2]
						8049, -- [3]
						1553808301.462, -- [4]
						58820, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						18562, -- [2]
						54594, -- [3]
						1553808301.462, -- [4]
						113414, -- [5]
						"Isery", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						true, -- [1]
						285195, -- [2]
						13416, -- [3]
						1553808301.708, -- [4]
						99998, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						8004, -- [2]
						51760, -- [3]
						1553808301.989, -- [4]
						151758, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						143924, -- [2]
						22, -- [3]
						1553808302.136, -- [4]
						151780, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						false, -- [1]
						234946, -- [2]
						13965, -- [3]
						1553808302.214, -- [4]
						165745, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						243241, -- [2]
						5286, -- [3]
						1553808302.433, -- [4]
						171031, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						596, -- [2]
						11012, -- [3]
						1553808302.883, -- [4]
						182043, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						true, -- [1]
						285044, -- [2]
						67726, -- [3]
						1553808302.883, -- [4]
						114317, -- [5]
						"Plague Toad <King Rastakhan>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						61295, -- [2]
						2345, -- [3]
						1553808302.914, -- [4]
						116662, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						191840, -- [2]
						15005, -- [3]
						1553808302.97, -- [4]
						131667, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						122, -- [3]
						1553808303.341, -- [4]
						131789, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						77489, -- [2]
						3067, -- [3]
						1553808303.524, -- [4]
						134856, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						14974, -- [3]
						1553808303.895, -- [4]
						149830, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						true, -- [1]
						285044, -- [2]
						67726, -- [3]
						1553808304.399, -- [4]
						82104, -- [5]
						"Plague Toad <King Rastakhan>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						77489, -- [2]
						8077, -- [3]
						1553808304.441, -- [4]
						90181, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						143924, -- [2]
						51, -- [3]
						1553808304.566, -- [4]
						90232, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						false, -- [1]
						272428, -- [2]
						3748, -- [3]
						1553808304.591, -- [4]
						93980, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						61295, -- [2]
						12171, -- [3]
						1553808304.614, -- [4]
						106151, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						true, -- [1]
						285195, -- [2]
						13416, -- [3]
						1553808304.708, -- [4]
						92735, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						191840, -- [2]
						603, -- [3]
						1553808304.814, -- [4]
						93338, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [23]
					{
						false, -- [1]
						191840, -- [2]
						14943, -- [3]
						1553808304.814, -- [4]
						108281, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						61295, -- [2]
						2367, -- [3]
						1553808305.522, -- [4]
						110648, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						191840, -- [2]
						7457, -- [3]
						1553808305.731, -- [4]
						118105, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						146, -- [3]
						1553808305.78, -- [4]
						118251, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [27]
					{
						false, -- [1]
						234946, -- [2]
						7306, -- [3]
						1553808305.804, -- [4]
						125557, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						243241, -- [2]
						9278, -- [3]
						1553808305.86, -- [4]
						134835, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						285044, -- [2]
						67726, -- [3]
						1553808305.902, -- [4]
						67109, -- [5]
						"Plague Toad <King Rastakhan>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						145110, -- [2]
						7602, -- [3]
						1553808306.045, -- [4]
						74711, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [31]
					{
						true, -- [1]
						284846, -- [2]
						74711, -- [3]
						1553808306.163, -- [4]
						1, -- [5]
						"King Rastakhan", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						15626, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Soely", -- [6]
					}, -- [33]
				},
				["class"] = "SHAMAN",
				["timestring"] = "3m 0s",
				["time"] = 1553808306.163,
			}, -- [2]
			{
				["maxhealth"] = 352360,
				["timeofdeath"] = 183.936000000002,
				["name"] = "Supersunny",
				["events"] = {
					{
						false, -- [1]
						61295, -- [2]
						1189, -- [3]
						1553808305.731, -- [4]
						234491, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						77489, -- [2]
						1126, -- [3]
						1553808305.86, -- [4]
						235617, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						198533, -- [2]
						3221, -- [3]
						1553808305.86, -- [4]
						238838, -- [5]
						"Jade Serpent Statue <Hornpubmonk>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						152261, -- [2]
						31157, -- [3]
						1553808306.119, -- [4]
						238838, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						269279, -- [2]
						18464, -- [3]
						1553808306.119, -- [4]
						238838, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						true, -- [1]
						284846, -- [2]
						89672, -- [3]
						1553808306.119, -- [4]
						198787, -- [5]
						"King Rastakhan", -- [6]
						49621, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						183811, -- [2]
						630, -- [3]
						1553808306.294, -- [4]
						199417, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						false, -- [1]
						183811, -- [2]
						627, -- [3]
						1553808306.585, -- [4]
						200044, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						152261, -- [2]
						55503, -- [3]
						1553808306.709, -- [4]
						181858, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						true, -- [1]
						285195, -- [2]
						112714, -- [3]
						1553808306.709, -- [4]
						124647, -- [5]
						"[*] Deathly Withering", -- [6]
						55503, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						285195, -- [2]
						34, -- [3]
						1553808306.709, -- [4]
						124647, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						198533, -- [2]
						3220, -- [3]
						1553808306.728, -- [4]
						127867, -- [5]
						"Jade Serpent Statue <Hornpubmonk>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						183811, -- [2]
						1253, -- [3]
						1553808307.257, -- [4]
						129120, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553808307.605, -- [4]
						130245, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						183811, -- [2]
						623, -- [3]
						1553808307.605, -- [4]
						130868, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						198533, -- [2]
						3220, -- [3]
						1553808307.626, -- [4]
						134088, -- [5]
						"Jade Serpent Statue <Hornpubmonk>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						4, -- [1]
						285195, -- [2]
						35, -- [3]
						1553808307.686, -- [4]
						134088, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						20, -- [3]
						1553808307.851, -- [4]
						134108, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						4, -- [1]
						285213, -- [2]
						1, -- [3]
						1553808308.117, -- [4]
						134108, -- [5]
						"Bwonsamdi", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						false, -- [1]
						288024, -- [2]
						12438, -- [3]
						1553808308.14, -- [4]
						134108, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						true, -- [1]
						285213, -- [2]
						68338, -- [3]
						1553808308.14, -- [4]
						78208, -- [5]
						"Bwonsamdi", -- [6]
						12438, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						198533, -- [2]
						0, -- [3]
						1553808308.523, -- [4]
						78208, -- [5]
						"Jade Serpent Statue <Hornpubmonk>", -- [6]
						nil, -- [7]
						3221, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						183811, -- [2]
						0, -- [3]
						1553808308.646, -- [4]
						78208, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						623, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						4, -- [1]
						285195, -- [2]
						36, -- [3]
						1553808308.705, -- [4]
						78208, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						278785, -- [2]
						0, -- [3]
						1553808308.821, -- [4]
						78208, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						1125, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						183811, -- [2]
						0, -- [3]
						1553808308.821, -- [4]
						78208, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						623, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						198533, -- [2]
						0, -- [3]
						1553808309.429, -- [4]
						78208, -- [5]
						"Jade Serpent Statue <Hornpubmonk>", -- [6]
						nil, -- [7]
						3191, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						152261, -- [2]
						60548, -- [3]
						1553808309.699, -- [4]
						78208, -- [5]
						"Supersunny", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						true, -- [1]
						285195, -- [2]
						122960, -- [3]
						1553808309.699, -- [4]
						15796, -- [5]
						"[*] Deathly Withering", -- [6]
						60548, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						4, -- [1]
						285195, -- [2]
						37, -- [3]
						1553808309.699, -- [4]
						15796, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						false, -- [1]
						183811, -- [2]
						0, -- [3]
						1553808309.848, -- [4]
						15796, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						626, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						15796, -- [3]
						1553808309.986, -- [4]
						15796, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						45944, -- [10]
					}, -- [32]
					{
						3, -- [1]
						642, -- [2]
						1, -- [3]
						1553808264.937, -- [4]
						0, -- [5]
						"Supersunny", -- [6]
					}, -- [33]
				},
				["class"] = "PALADIN",
				["timestring"] = "3m 3s",
				["time"] = 1553808310.011,
			}, -- [3]
			{
				["maxhealth"] = 230560,
				["timeofdeath"] = 195.687000000005,
				["name"] = "Hornpubmonk",
				["events"] = {
					{
						true, -- [1]
						259756, -- [2]
						6, -- [3]
						1553808315.959, -- [4]
						242846, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						48438, -- [2]
						1293, -- [3]
						1553808316.159, -- [4]
						244139, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						287255, -- [2]
						2269, -- [3]
						1553808316.19, -- [4]
						246408, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						4, -- [1]
						285195, -- [2]
						5, -- [3]
						1553808316.702, -- [4]
						246408, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						77489, -- [2]
						4661, -- [3]
						1553808316.737, -- [4]
						251069, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						82, -- [3]
						1553808316.737, -- [4]
						251151, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						true, -- [1]
						12654, -- [2]
						135, -- [3]
						1553808316.928, -- [4]
						251016, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						259756, -- [2]
						7, -- [3]
						1553808316.955, -- [4]
						251009, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						6448, -- [3]
						1553808317.366, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						191840, -- [2]
						511, -- [3]
						1553808317.592, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						285195, -- [2]
						6, -- [3]
						1553808317.715, -- [4]
						253600, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						true, -- [1]
						12654, -- [2]
						135, -- [3]
						1553808317.924, -- [4]
						253465, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						true, -- [1]
						259756, -- [2]
						6, -- [3]
						1553808317.955, -- [4]
						253459, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						686, -- [3]
						1553808317.955, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						4, -- [1]
						285195, -- [2]
						7, -- [3]
						1553808318.713, -- [4]
						253600, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						true, -- [1]
						285195, -- [2]
						23478, -- [3]
						1553808318.713, -- [4]
						230122, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						191840, -- [2]
						12865, -- [3]
						1553808318.814, -- [4]
						242987, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						1, -- [2]
						96866, -- [3]
						1553808318.847, -- [4]
						242987, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						12654, -- [2]
						127, -- [3]
						1553808318.92, -- [4]
						145994, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						true, -- [1]
						259756, -- [2]
						6, -- [3]
						1553808318.957, -- [4]
						145988, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						579, -- [3]
						1553808319.16, -- [4]
						146567, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						191840, -- [2]
						509, -- [3]
						1553808319.5, -- [4]
						147076, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						4, -- [1]
						285195, -- [2]
						8, -- [3]
						1553808319.723, -- [4]
						147076, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						257, -- [3]
						1553808320.367, -- [4]
						147333, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						4, -- [1]
						285195, -- [2]
						9, -- [3]
						1553808320.7, -- [4]
						147333, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						1, -- [2]
						125550, -- [3]
						1553808320.854, -- [4]
						147333, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						true, -- [1]
						12654, -- [2]
						278, -- [3]
						1553808320.875, -- [4]
						21505, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						true, -- [1]
						259756, -- [2]
						15, -- [3]
						1553808320.897, -- [4]
						21490, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						191840, -- [2]
						934, -- [3]
						1553808321.321, -- [4]
						22424, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						50, -- [3]
						1553808321.582, -- [4]
						22474, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						285195, -- [2]
						10, -- [3]
						1553808321.709, -- [4]
						22474, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						285195, -- [2]
						22474, -- [3]
						1553808321.762, -- [4]
						1, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						16097, -- [10]
					}, -- [32]
					{
						3, -- [1]
						243435, -- [2]
						1, -- [3]
						1553808298.307, -- [4]
						0, -- [5]
						"Hornpubmonk", -- [6]
					}, -- [33]
				},
				["class"] = "MONK",
				["timestring"] = "3m 15s",
				["time"] = 1553808321.762,
			}, -- [4]
			{
				["maxhealth"] = 229320,
				["timeofdeath"] = 198.974000000002,
				["name"] = "Almîna",
				["events"] = {
					{
						false, -- [1]
						119611, -- [2]
						2629, -- [3]
						1553808293.514, -- [4]
						259862, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						4, -- [1]
						284995, -- [2]
						1, -- [3]
						1553808300.137, -- [4]
						259862, -- [5]
						"Zombie Dust Totem", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						1, -- [1]
						108271, -- [2]
						1, -- [3]
						1553808308.625, -- [4]
						231372, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						4, -- [1]
						285195, -- [2]
						1, -- [3]
						1553808314.728, -- [4]
						242149, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						4, -- [1]
						285195, -- [2]
						2, -- [3]
						1553808315.702, -- [4]
						236511, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						true, -- [1]
						201754, -- [2]
						494, -- [3]
						1553808316.258, -- [4]
						231497, -- [5]
						"Beast <Samîsu>", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						true, -- [1]
						201754, -- [2]
						1936, -- [3]
						1553808316.526, -- [4]
						229610, -- [5]
						"Bakura <Artèmis>", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						4, -- [1]
						285195, -- [2]
						3, -- [3]
						1553808316.702, -- [4]
						239251, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						4, -- [1]
						285195, -- [2]
						4, -- [3]
						1553808317.715, -- [4]
						217847, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						4, -- [1]
						285195, -- [2]
						5, -- [3]
						1553808318.713, -- [4]
						188168, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						4, -- [1]
						285195, -- [2]
						6, -- [3]
						1553808319.723, -- [4]
						162979, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						4, -- [1]
						285195, -- [2]
						7, -- [3]
						1553808320.7, -- [4]
						151925, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						4, -- [1]
						285195, -- [2]
						8, -- [3]
						1553808321.709, -- [4]
						90365, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						true, -- [1]
						201754, -- [2]
						4117, -- [3]
						1553808321.81, -- [4]
						86248, -- [5]
						"Sammy <Samîsu>", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						4, -- [1]
						285195, -- [2]
						9, -- [3]
						1553808322.697, -- [4]
						71590, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						4, -- [1]
						285195, -- [2]
						10, -- [3]
						1553808323.747, -- [4]
						57583, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						4, -- [1]
						285195, -- [2]
						11, -- [3]
						1553808324.721, -- [4]
						12491, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						201754, -- [2]
						4430, -- [3]
						1553808325.049, -- [4]
						1, -- [5]
						"Bakura <Artèmis>", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						1879, -- [10]
					}, -- [18]
					{
						3, -- [1]
						108271, -- [2]
						1, -- [3]
						1553808308.625, -- [4]
						0, -- [5]
						"Almîna", -- [6]
					}, -- [19]
				},
				["class"] = "SHAMAN",
				["timestring"] = "3m 18s",
				["time"] = 1553808325.049,
			}, -- [5]
			{
				["maxhealth"] = 232300,
				["timeofdeath"] = 200.676,
				["name"] = "Laki",
				["events"] = {
					{
						false, -- [1]
						77489, -- [2]
						7030, -- [3]
						1553808320.764, -- [4]
						230394, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						true, -- [1]
						12654, -- [2]
						153, -- [3]
						1553808320.897, -- [4]
						230241, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						true, -- [1]
						259756, -- [2]
						7, -- [3]
						1553808320.924, -- [4]
						230234, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						596, -- [2]
						24548, -- [3]
						1553808321.03, -- [4]
						254782, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						4, -- [1]
						285195, -- [2]
						11, -- [3]
						1553808321.709, -- [4]
						254782, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						true, -- [1]
						12654, -- [2]
						153, -- [3]
						1553808321.885, -- [4]
						254629, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						true, -- [1]
						205345, -- [2]
						711, -- [3]
						1553808321.907, -- [4]
						253918, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						259756, -- [2]
						7, -- [3]
						1553808321.936, -- [4]
						253911, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						4, -- [1]
						285195, -- [2]
						12, -- [3]
						1553808322.697, -- [4]
						253911, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						true, -- [1]
						2120, -- [2]
						6054, -- [3]
						1553808322.906, -- [4]
						247857, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						true, -- [1]
						12654, -- [2]
						153, -- [3]
						1553808322.906, -- [4]
						247704, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						true, -- [1]
						259756, -- [2]
						273, -- [3]
						1553808322.942, -- [4]
						247431, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						true, -- [1]
						259756, -- [2]
						6, -- [3]
						1553808322.942, -- [4]
						247425, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						4, -- [1]
						285195, -- [2]
						13, -- [3]
						1553808323.747, -- [4]
						247425, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						true, -- [1]
						285195, -- [2]
						41802, -- [3]
						1553808323.747, -- [4]
						205623, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						true, -- [1]
						1, -- [2]
						127008, -- [3]
						1553808323.747, -- [4]
						205623, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						true, -- [1]
						12654, -- [2]
						179, -- [3]
						1553808323.9, -- [4]
						78436, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						true, -- [1]
						259756, -- [2]
						8, -- [3]
						1553808323.924, -- [4]
						78428, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						145109, -- [2]
						8660, -- [3]
						1553808323.998, -- [4]
						87088, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						77489, -- [2]
						4008, -- [3]
						1553808324.042, -- [4]
						91096, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						false, -- [1]
						596, -- [2]
						24549, -- [3]
						1553808324.642, -- [4]
						115645, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						243241, -- [2]
						5552, -- [3]
						1553808324.642, -- [4]
						121197, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						4, -- [1]
						285195, -- [2]
						14, -- [3]
						1553808324.721, -- [4]
						121197, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						true, -- [1]
						12654, -- [2]
						179, -- [3]
						1553808324.896, -- [4]
						121018, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						259756, -- [2]
						8, -- [3]
						1553808324.924, -- [4]
						121010, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						188443, -- [2]
						3591, -- [3]
						1553808324.924, -- [4]
						117419, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						4, -- [1]
						285195, -- [2]
						15, -- [3]
						1553808325.703, -- [4]
						117419, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						true, -- [1]
						1, -- [2]
						111140, -- [3]
						1553808325.754, -- [4]
						117419, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						true, -- [1]
						12654, -- [2]
						179, -- [3]
						1553808325.902, -- [4]
						6100, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						true, -- [1]
						205345, -- [2]
						710, -- [3]
						1553808325.902, -- [4]
						5390, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						285195, -- [2]
						16, -- [3]
						1553808326.703, -- [4]
						5390, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						285195, -- [2]
						5390, -- [3]
						1553808326.751, -- [4]
						1, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						46059, -- [10]
					}, -- [32]
					{
						3, -- [1]
						29166, -- [2]
						1, -- [3]
						1553808164.915, -- [4]
						0, -- [5]
						"Laki", -- [6]
					}, -- [33]
				},
				["class"] = "DRUID",
				["timestring"] = "3m 20s",
				["time"] = 1553808326.751,
			}, -- [6]
			{
				["maxhealth"] = 246260,
				["timeofdeath"] = 201.696000000004,
				["name"] = "Salanâ",
				["events"] = {
					{
						false, -- [1]
						143924, -- [2]
						154, -- [3]
						1553808322.812, -- [4]
						227067, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						true, -- [1]
						2120, -- [2]
						6355, -- [3]
						1553808322.906, -- [4]
						220712, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						true, -- [1]
						12654, -- [2]
						214, -- [3]
						1553808322.906, -- [4]
						220498, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						true, -- [1]
						259756, -- [2]
						307, -- [3]
						1553808322.942, -- [4]
						220191, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						true, -- [1]
						259756, -- [2]
						10, -- [3]
						1553808322.942, -- [4]
						220181, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808323.457, -- [4]
						220598, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						4, -- [1]
						285195, -- [2]
						12, -- [3]
						1553808323.747, -- [4]
						220598, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						true, -- [1]
						12654, -- [2]
						156, -- [3]
						1553808323.9, -- [4]
						220442, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						33110, -- [2]
						8281, -- [3]
						1553808323.924, -- [4]
						228723, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						true, -- [1]
						259756, -- [2]
						8, -- [3]
						1553808323.924, -- [4]
						228715, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						143924, -- [2]
						291, -- [3]
						1553808324.02, -- [4]
						229006, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						596, -- [2]
						23136, -- [3]
						1553808324.642, -- [4]
						246260, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						4, -- [1]
						285195, -- [2]
						13, -- [3]
						1553808324.721, -- [4]
						246260, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						true, -- [1]
						285195, -- [2]
						44886, -- [3]
						1553808324.721, -- [4]
						201374, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						true, -- [1]
						12654, -- [2]
						188, -- [3]
						1553808324.896, -- [4]
						201186, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						true, -- [1]
						259756, -- [2]
						9, -- [3]
						1553808324.924, -- [4]
						201177, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						true, -- [1]
						188443, -- [2]
						3855, -- [3]
						1553808324.924, -- [4]
						197322, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						67, -- [3]
						1553808325.234, -- [4]
						197389, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						77489, -- [2]
						5676, -- [3]
						1553808325.257, -- [4]
						203065, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						191840, -- [2]
						834, -- [3]
						1553808325.363, -- [4]
						203899, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						4, -- [1]
						285195, -- [2]
						14, -- [3]
						1553808325.703, -- [4]
						203899, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						true, -- [1]
						12654, -- [2]
						188, -- [3]
						1553808325.902, -- [4]
						203711, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						true, -- [1]
						205345, -- [2]
						746, -- [3]
						1553808325.902, -- [4]
						202965, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						93, -- [3]
						1553808326.431, -- [4]
						203058, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						4, -- [1]
						285195, -- [2]
						15, -- [3]
						1553808326.751, -- [4]
						203058, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						12654, -- [2]
						188, -- [3]
						1553808326.896, -- [4]
						202870, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						77489, -- [2]
						1277, -- [3]
						1553808326.924, -- [4]
						204147, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808327.27, -- [4]
						204564, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						143924, -- [2]
						67, -- [3]
						1553808327.643, -- [4]
						204631, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						4, -- [1]
						285195, -- [2]
						16, -- [3]
						1553808327.724, -- [4]
						204631, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						true, -- [1]
						285195, -- [2]
						55244, -- [3]
						1553808327.724, -- [4]
						149387, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						149387, -- [3]
						1553808327.771, -- [4]
						149387, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						1684, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Salanâ", -- [6]
					}, -- [33]
				},
				["class"] = "PRIEST",
				["timestring"] = "3m 21s",
				["time"] = 1553808327.771,
			}, -- [7]
			{
				["maxhealth"] = 348040,
				["timeofdeath"] = 203.704000000005,
				["name"] = "Daddysenpai",
				["events"] = {
					{
						false, -- [1]
						274436, -- [2]
						441, -- [3]
						1553808325.257, -- [4]
						264041, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						4, -- [1]
						285195, -- [2]
						12, -- [3]
						1553808325.703, -- [4]
						264041, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						true, -- [1]
						1, -- [2]
						120619, -- [3]
						1553808325.754, -- [4]
						264041, -- [5]
						"King Rastakhan", -- [6]
						3841, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						272260, -- [2]
						527, -- [3]
						1553808325.754, -- [4]
						264568, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						203538, -- [2]
						3841, -- [3]
						1553808325.754, -- [4]
						264568, -- [5]
						"Inánná", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						267537, -- [2]
						1723, -- [3]
						1553808325.826, -- [4]
						149513, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						true, -- [1]
						12654, -- [2]
						198, -- [3]
						1553808325.902, -- [4]
						149315, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						205345, -- [2]
						785, -- [3]
						1553808325.902, -- [4]
						148530, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						834, -- [3]
						1553808325.957, -- [4]
						149364, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						4, -- [1]
						285195, -- [2]
						13, -- [3]
						1553808326.703, -- [4]
						149364, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						true, -- [1]
						285195, -- [2]
						44856, -- [3]
						1553808326.751, -- [4]
						104508, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						true, -- [1]
						12654, -- [2]
						198, -- [3]
						1553808326.896, -- [4]
						104310, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						true, -- [1]
						269031, -- [2]
						1140, -- [3]
						1553808326.924, -- [4]
						103170, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						1, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						77489, -- [2]
						3265, -- [3]
						1553808327.134, -- [4]
						106435, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						267537, -- [2]
						1723, -- [3]
						1553808327.624, -- [4]
						108158, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						77489, -- [2]
						5091, -- [3]
						1553808327.675, -- [4]
						113249, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						4, -- [1]
						285195, -- [2]
						14, -- [3]
						1553808327.724, -- [4]
						113249, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						774, -- [2]
						2878, -- [3]
						1553808327.771, -- [4]
						116127, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						272260, -- [2]
						1054, -- [3]
						1553808327.771, -- [4]
						117181, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						true, -- [1]
						1, -- [2]
						122667, -- [3]
						1553808327.771, -- [4]
						117181, -- [5]
						"King Rastakhan", -- [6]
						12214, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						288024, -- [2]
						12214, -- [3]
						1553808327.809, -- [4]
						117181, -- [5]
						"Daddysenpai", -- [6]
						true, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808327.873, -- [4]
						7145, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						true, -- [1]
						12654, -- [2]
						228, -- [3]
						1553808327.889, -- [4]
						6917, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						true, -- [1]
						205345, -- [2]
						827, -- [3]
						1553808327.909, -- [4]
						6090, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						269031, -- [2]
						1313, -- [3]
						1553808327.909, -- [4]
						4777, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						1, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						205345, -- [2]
						827, -- [3]
						1553808327.909, -- [4]
						3950, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						true, -- [1]
						205345, -- [2]
						826, -- [3]
						1553808327.909, -- [4]
						3124, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						267537, -- [2]
						711, -- [3]
						1553808328.025, -- [4]
						3835, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						4, -- [1]
						285195, -- [2]
						15, -- [3]
						1553808328.722, -- [4]
						3835, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						12654, -- [2]
						228, -- [3]
						1553808328.923, -- [4]
						3607, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						285195, -- [2]
						16, -- [3]
						1553808329.727, -- [4]
						3607, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						285195, -- [2]
						3607, -- [3]
						1553808329.779, -- [4]
						1, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						59881, -- [10]
					}, -- [32]
					{
						3, -- [1]
						12975, -- [2]
						1, -- [3]
						1553808309.657, -- [4]
						0, -- [5]
						"Daddysenpai", -- [6]
					}, -- [33]
				},
				["class"] = "WARRIOR",
				["timestring"] = "3m 23s",
				["time"] = 1553808329.779,
			}, -- [8]
			{
				["maxhealth"] = 251200,
				["timeofdeath"] = 205.738000000005,
				["name"] = "Kalissta",
				["events"] = {
					{
						false, -- [1]
						33110, -- [2]
						19357, -- [3]
						1553808325.341, -- [4]
						214178, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						true, -- [1]
						259756, -- [2]
						7, -- [3]
						1553808325.363, -- [4]
						214171, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						48, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						true, -- [1]
						269031, -- [2]
						2630, -- [3]
						1553808325.363, -- [4]
						211541, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						1, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						4, -- [1]
						285195, -- [2]
						14, -- [3]
						1553808325.703, -- [4]
						211541, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						true, -- [1]
						12654, -- [2]
						212, -- [3]
						1553808325.885, -- [4]
						211329, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						130, -- [3]
						1553808326.431, -- [4]
						211459, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						4, -- [1]
						285195, -- [2]
						15, -- [3]
						1553808326.703, -- [4]
						211459, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						true, -- [1]
						12654, -- [2]
						165, -- [3]
						1553808326.896, -- [4]
						211294, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						834, -- [3]
						1553808327.103, -- [4]
						212128, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						224, -- [3]
						1553808327.643, -- [4]
						212352, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						285195, -- [2]
						16, -- [3]
						1553808327.696, -- [4]
						212352, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						true, -- [1]
						285195, -- [2]
						47031, -- [3]
						1553808327.724, -- [4]
						165321, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						true, -- [1]
						12654, -- [2]
						165, -- [3]
						1553808327.889, -- [4]
						165156, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						77489, -- [2]
						4811, -- [3]
						1553808328.128, -- [4]
						169967, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						4, -- [1]
						285195, -- [2]
						17, -- [3]
						1553808328.722, -- [4]
						169967, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						143924, -- [2]
						588, -- [3]
						1553808328.868, -- [4]
						170555, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						true, -- [1]
						12654, -- [2]
						165, -- [3]
						1553808328.923, -- [4]
						170390, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808328.999, -- [4]
						170807, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						4, -- [1]
						285195, -- [2]
						18, -- [3]
						1553808329.727, -- [4]
						170807, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						true, -- [1]
						1, -- [2]
						122280, -- [3]
						1553808329.821, -- [4]
						170807, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						true, -- [1]
						12654, -- [2]
						136, -- [3]
						1553808329.908, -- [4]
						48391, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						139, -- [3]
						1553808330.081, -- [4]
						48530, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						true, -- [1]
						285195, -- [2]
						43573, -- [3]
						1553808330.705, -- [4]
						4957, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						4, -- [1]
						285195, -- [2]
						19, -- [3]
						1553808330.705, -- [4]
						4957, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808330.909, -- [4]
						5374, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						12654, -- [2]
						136, -- [3]
						1553808330.909, -- [4]
						5238, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						4, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						77489, -- [2]
						4812, -- [3]
						1553808331.138, -- [4]
						10050, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						143924, -- [2]
						478, -- [3]
						1553808331.313, -- [4]
						10528, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						191840, -- [2]
						160, -- [3]
						1553808331.624, -- [4]
						10688, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						false, -- [1]
						243241, -- [2]
						4703, -- [3]
						1553808331.646, -- [4]
						15391, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						285195, -- [2]
						20, -- [3]
						1553808331.699, -- [4]
						15391, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						1, -- [2]
						15391, -- [3]
						1553808331.795, -- [4]
						15391, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						68922, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Kalissta", -- [6]
					}, -- [33]
				},
				["class"] = "PRIEST",
				["timestring"] = "3m 25s",
				["time"] = 1553808331.813,
			}, -- [9]
			{
				["maxhealth"] = 228240,
				["timeofdeath"] = 206.742000000006,
				["name"] = "Qyix",
				["events"] = {
					{
						4, -- [1]
						285195, -- [2]
						13, -- [3]
						1553808326.703, -- [4]
						194019, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						true, -- [1]
						285195, -- [2]
						45147, -- [3]
						1553808326.751, -- [4]
						148872, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						true, -- [1]
						288449, -- [2]
						34743, -- [3]
						1553808326.814, -- [4]
						114129, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						34914, -- [2]
						3841, -- [3]
						1553808326.839, -- [4]
						117970, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						34914, -- [2]
						1921, -- [3]
						1553808326.96, -- [4]
						119891, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						143924, -- [2]
						176, -- [3]
						1553808327.27, -- [4]
						120067, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808327.675, -- [4]
						120484, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						77489, -- [2]
						1099, -- [3]
						1553808327.675, -- [4]
						121583, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						4, -- [1]
						285195, -- [2]
						14, -- [3]
						1553808327.696, -- [4]
						121583, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						false, -- [1]
						143924, -- [2]
						25, -- [3]
						1553808328.487, -- [4]
						121608, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						270661, -- [2]
						3344, -- [3]
						1553808328.557, -- [4]
						124952, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [11]
					{
						4, -- [1]
						285195, -- [2]
						15, -- [3]
						1553808328.722, -- [4]
						124952, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						true, -- [1]
						288449, -- [2]
						34743, -- [3]
						1553808328.792, -- [4]
						90209, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						34914, -- [2]
						1900, -- [3]
						1553808328.999, -- [4]
						92109, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						34914, -- [2]
						1899, -- [3]
						1553808329.086, -- [4]
						94008, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						417, -- [3]
						1553808329.558, -- [4]
						94425, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						409, -- [3]
						1553808329.708, -- [4]
						94834, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						4, -- [1]
						285195, -- [2]
						16, -- [3]
						1553808329.727, -- [4]
						94834, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						true, -- [1]
						285195, -- [2]
						55566, -- [3]
						1553808329.779, -- [4]
						39268, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						34914, -- [2]
						707, -- [3]
						1553808329.888, -- [4]
						39975, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						191840, -- [2]
						159, -- [3]
						1553808330.303, -- [4]
						40134, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						77489, -- [2]
						1099, -- [3]
						1553808330.686, -- [4]
						41233, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						4, -- [1]
						285195, -- [2]
						17, -- [3]
						1553808330.73, -- [4]
						41233, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						true, -- [1]
						288449, -- [2]
						39954, -- [3]
						1553808330.767, -- [4]
						1279, -- [5]
						"Bwonsamdi", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						202, -- [3]
						1553808330.892, -- [4]
						1481, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						34914, -- [2]
						3779, -- [3]
						1553808331.138, -- [4]
						5260, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						270661, -- [2]
						3344, -- [3]
						1553808331.557, -- [4]
						8604, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [27]
					{
						false, -- [1]
						243241, -- [2]
						4702, -- [3]
						1553808331.646, -- [4]
						13306, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						4, -- [1]
						285195, -- [2]
						18, -- [3]
						1553808331.699, -- [4]
						13306, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						106, -- [3]
						1553808332.118, -- [4]
						13412, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						4, -- [1]
						285195, -- [2]
						19, -- [3]
						1553808332.698, -- [4]
						13412, -- [5]
						"[*] Deathly Withering", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						285195, -- [2]
						13412, -- [3]
						1553808332.741, -- [4]
						1, -- [5]
						"[*] Deathly Withering", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						62471, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Qyix", -- [6]
					}, -- [33]
				},
				["class"] = "PRIEST",
				["timestring"] = "3m 26s",
				["time"] = 1553808332.817,
			}, -- [10]
		},
		["bossname"] = "King Rastakhan",
		["bossicon"] = {
			0.25, -- [1]
			0.5, -- [2]
			0.25, -- [3]
			0.5, -- [4]
			"Interface\\AddOns\\Details\\images\\raid\\DazaralorRaid_BossFaces", -- [5]
		},
		["date"] = 43730.171,
		["timeelapsed"] = 219.186000000002,
	}, -- [2]
}
DeathGraphsDBGraph = {
	["233515"] = {
		["deaths"] = {
			[193] = {
				1549488224, -- [1]
				1550956448, -- [2]
			},
			[224] = {
				1550956909, -- [1]
				1552244482, -- [2]
			},
			[120] = {
				1549487199, -- [1]
				1549487199, -- [2]
				1549487199, -- [3]
				1549487199, -- [4]
			},
			[16] = {
				1549488224, -- [1]
			},
			[213] = {
				1550956909, -- [1]
			},
			[186] = {
				1552244482, -- [1]
			},
			[190] = {
				1550956448, -- [1]
			},
			[225] = {
				1549487537, -- [1]
				1550956909, -- [2]
			},
			[220] = {
				1549488224, -- [1]
			},
			[202] = {
				1550176055, -- [1]
			},
			[191] = {
				1550956448, -- [1]
			},
			[243] = {
				1550176607, -- [1]
			},
			[214] = {
				1550176607, -- [1]
			},
			[41] = {
				1550956153, -- [1]
			},
			[222] = {
				1549488224, -- [1]
			},
			[195] = {
				1550956448, -- [1]
			},
			[137] = {
				1549487199, -- [1]
			},
			[203] = {
				1552842082, -- [1]
				1552842082, -- [2]
			},
			[181] = {
				1552244482, -- [1]
			},
			[204] = {
				1550956448, -- [1]
				1552842082, -- [2]
				1552842082, -- [3]
			},
			[13] = {
				1550956153, -- [1]
			},
			[188] = {
				1552244482, -- [1]
			},
			[223] = {
				1549487537, -- [1]
				1552848451, -- [2]
			},
			[227] = {
				1549487537, -- [1]
				1549487537, -- [2]
				1550176055, -- [3]
			},
			[200] = {
				1552842082, -- [1]
			},
			[73] = {
				1550956153, -- [1]
			},
			[226] = {
				1550176055, -- [1]
				1550176055, -- [2]
				1550176055, -- [3]
			},
			[77] = {
				1550956153, -- [1]
			},
			[269] = {
				1552244482, -- [1]
			},
			[57] = {
				1550956153, -- [1]
			},
			[221] = {
				1549487537, -- [1]
				1549488224, -- [2]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233016"] = {
		["deaths"] = {
			[347] = {
				1553804975, -- [1]
			},
			[85] = {
				1553804086, -- [1]
			},
			[99] = {
				1553804265, -- [1]
			},
			[295] = {
				1553195381, -- [1]
				1553804975, -- [2]
			},
			[342] = {
				1553804975, -- [1]
			},
			[296] = {
				1553195381, -- [1]
			},
			[82] = {
				1553804520, -- [1]
			},
			[84] = {
				1553804086, -- [1]
				1553804265, -- [2]
				1553804265, -- [3]
			},
			[336] = {
				1553195381, -- [1]
			},
			[282] = {
				1553195381, -- [1]
			},
			[92] = {
				1553804265, -- [1]
			},
			[96] = {
				1553804086, -- [1]
			},
			[98] = {
				1553804086, -- [1]
				1553804265, -- [2]
			},
			[338] = {
				1553804975, -- [1]
			},
			[343] = {
				1553804975, -- [1]
			},
			[150] = {
				1553804520, -- [1]
				1553804520, -- [2]
				1553804520, -- [3]
			},
			[222] = {
				1553195381, -- [1]
			},
			[81] = {
				1553804086, -- [1]
			},
			[149] = {
				1553804520, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233714"] = {
		["deaths"] = {
			[228] = {
				1552166709, -- [1]
			},
			[363] = {
				1552165021, -- [1]
			},
			[271] = {
				1552166709, -- [1]
			},
			[252] = {
				1552164092, -- [1]
			},
			[163] = {
				1552165021, -- [1]
			},
			[365] = {
				1552165633, -- [1]
			},
			[206] = {
				1552166709, -- [1]
			},
			[327] = {
				1552165633, -- [1]
			},
			[312] = {
				1552167543, -- [1]
			},
			[359] = {
				1552165021, -- [1]
			},
			[383] = {
				1552164092, -- [1]
			},
			[254] = {
				1552167543, -- [1]
			},
			[192] = {
				1552167543, -- [1]
			},
			[134] = {
				1552164092, -- [1]
			},
			[390] = {
				1552166709, -- [1]
				1552166709, -- [2]
			},
			[221] = {
				1552165633, -- [1]
			},
			[212] = {
				1552167543, -- [1]
			},
			[354] = {
				1552165021, -- [1]
			},
			[245] = {
				1552164092, -- [1]
			},
			[384] = {
				1552164092, -- [1]
			},
			[332] = {
				1552165021, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233415"] = {
		["deaths"] = {
			[121] = {
				1550178151, -- [1]
				1550178530, -- [2]
			},
			[123] = {
				1549489914, -- [1]
				1550958042, -- [2]
			},
			[247] = {
				1549490697, -- [1]
			},
			[125] = {
				1549488881, -- [1]
			},
			[258] = {
				1549490311, -- [1]
				1549490697, -- [2]
				1550178530, -- [3]
			},
			[266] = {
				1550959045, -- [1]
			},
			[397] = {
				1550179085, -- [1]
			},
			[274] = {
				1549490311, -- [1]
			},
			[278] = {
				1550178530, -- [1]
			},
			[142] = {
				1550957758, -- [1]
				1550957758, -- [2]
				1550959045, -- [3]
			},
			[144] = {
				1549488881, -- [1]
				1549488881, -- [2]
				1550959518, -- [3]
			},
			[154] = {
				1550177921, -- [1]
				1550177921, -- [2]
				1550177921, -- [3]
			},
			[156] = {
				1550179085, -- [1]
			},
			[158] = {
				1550958505, -- [1]
				1552848981, -- [2]
			},
			[160] = {
				1550958505, -- [1]
			},
			[44] = {
				1550178151, -- [1]
			},
			[45] = {
				1550957495, -- [1]
				1550959249, -- [2]
				1550959249, -- [3]
				1552849881, -- [4]
			},
			[180] = {
				1550958505, -- [1]
			},
			[182] = {
				1549489914, -- [1]
				1552849445, -- [2]
			},
			[186] = {
				1550959045, -- [1]
			},
			[192] = {
				1552849881, -- [1]
			},
			[259] = {
				1549490697, -- [1]
			},
			[263] = {
				1550959045, -- [1]
			},
			[398] = {
				1550179085, -- [1]
			},
			[51] = {
				1549489574, -- [1]
				1550177921, -- [2]
				1552849445, -- [3]
			},
			[283] = {
				1551469137, -- [1]
			},
			[54] = {
				1549489574, -- [1]
			},
			[335] = {
				1549489574, -- [1]
			},
			[234] = {
				1550958505, -- [1]
			},
			[246] = {
				1550958505, -- [1]
			},
			[254] = {
				1551469137, -- [1]
			},
			[129] = {
				1549490697, -- [1]
			},
			[131] = {
				1550959518, -- [1]
			},
			[67] = {
				1552245294, -- [1]
			},
			[272] = {
				1549490311, -- [1]
			},
			[276] = {
				1549490311, -- [1]
				1550178530, -- [2]
			},
			[143] = {
				1550957758, -- [1]
				1550957758, -- [2]
				1550959518, -- [3]
				1551469137, -- [4]
				1552848981, -- [5]
			},
			[300] = {
				1551469137, -- [1]
			},
			[155] = {
				1552850308, -- [1]
			},
			[157] = {
				1552848981, -- [1]
			},
			[80] = {
				1549489574, -- [1]
				1550959518, -- [2]
			},
			[161] = {
				1552848981, -- [1]
			},
			[86] = {
				1550957495, -- [1]
			},
			[348] = {
				1552850308, -- [1]
			},
			[91] = {
				1550959249, -- [1]
			},
			[92] = {
				1550179592, -- [1]
			},
			[241] = {
				1552850308, -- [1]
			},
			[97] = {
				1550958042, -- [1]
			},
			[376] = {
				1552245294, -- [1]
			},
			[96] = {
				1550959249, -- [1]
			},
			[257] = {
				1549490311, -- [1]
				1550178530, -- [2]
			},
			[98] = {
				1550959518, -- [1]
				1552849445, -- [2]
			},
			[59] = {
				1552848981, -- [1]
			},
			[362] = {
				1550179085, -- [1]
			},
			[363] = {
				1552245294, -- [1]
			},
			[333] = {
				1552245294, -- [1]
				1552849881, -- [2]
			},
			[181] = {
				1549489914, -- [1]
				1550179085, -- [2]
			},
			[183] = {
				1549489574, -- [1]
			},
			[113] = {
				1550957758, -- [1]
			},
			[106] = {
				1550957495, -- [1]
			},
			[107] = {
				1550959249, -- [1]
			},
			[109] = {
				1550178151, -- [1]
				1550957495, -- [2]
			},
			[217] = {
				1552849445, -- [1]
			},
			[309] = {
				1552849445, -- [1]
			},
			[130] = {
				1549488881, -- [1]
			},
			[194] = {
				1549489914, -- [1]
			},
			[225] = {
				1549490697, -- [1]
				1550959045, -- [2]
			},
			[114] = {
				1551469137, -- [1]
				1552849881, -- [2]
			},
			[115] = {
				1549488881, -- [1]
				1550958042, -- [2]
			},
			[116] = {
				1550957495, -- [1]
			},
			[193] = {
				1549489914, -- [1]
			},
			[118] = {
				1550958042, -- [1]
			},
			[119] = {
				1550958042, -- [1]
			},
			[239] = {
				1552849881, -- [1]
			},
			[138] = {
				1550177921, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233314"] = {
		["deaths"] = {
			[89] = {
				1551461791, -- [1]
			},
			[28] = {
				1551463515, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233315"] = {
		["deaths"] = {
			[121] = {
				1549316736, -- [1]
				1549326204, -- [2]
			},
			[31] = {
				1552240932, -- [1]
			},
			[253] = {
				1549324174, -- [1]
				1549324174, -- [2]
			},
			[128] = {
				1549311909, -- [1]
			},
			[33] = {
				1552241539, -- [1]
				1552241539, -- [2]
			},
			[132] = {
				1549315430, -- [1]
			},
			[34] = {
				1549317528, -- [1]
			},
			[35] = {
				1549320301, -- [1]
				1549323046, -- [2]
			},
			[36] = {
				1549317031, -- [1]
				1549317031, -- [2]
				1549325374, -- [3]
				1552241539, -- [4]
			},
			[37] = {
				1549322466, -- [1]
			},
			[148] = {
				1549323046, -- [1]
			},
			[39] = {
				1552242036, -- [1]
			},
			[42] = {
				1549310914, -- [1]
			},
			[342] = {
				1549323046, -- [1]
			},
			[176] = {
				1549321077, -- [1]
			},
			[180] = {
				1549320301, -- [1]
				1549481748, -- [2]
			},
			[184] = {
				1549321077, -- [1]
			},
			[186] = {
				1549311909, -- [1]
			},
			[188] = {
				1549320301, -- [1]
			},
			[49] = {
				1549313643, -- [1]
			},
			[196] = {
				1549317528, -- [1]
			},
			[198] = {
				1550949665, -- [1]
			},
			[204] = {
				1549321410, -- [1]
			},
			[208] = {
				1549481748, -- [1]
			},
			[216] = {
				1549481748, -- [1]
			},
			[367] = {
				1549316341, -- [1]
			},
			[56] = {
				1549324441, -- [1]
				1549324441, -- [2]
			},
			[76] = {
				1549314188, -- [1]
				1549314188, -- [2]
				1549317031, -- [3]
				1549317031, -- [4]
				1549325676, -- [5]
				1550171659, -- [6]
			},
			[77] = {
				1549319799, -- [1]
			},
			[78] = {
				1549323773, -- [1]
			},
			[58] = {
				1549320580, -- [1]
			},
			[233] = {
				1549324174, -- [1]
			},
			[59] = {
				1549323773, -- [1]
				1552241539, -- [2]
			},
			[343] = {
				1549326204, -- [1]
			},
			[81] = {
				1549314188, -- [1]
			},
			[163] = {
				1552242036, -- [1]
				1552242036, -- [2]
			},
			[61] = {
				1549325676, -- [1]
			},
			[244] = {
				1549326204, -- [1]
			},
			[83] = {
				1549320580, -- [1]
			},
			[248] = {
				1549323046, -- [1]
			},
			[63] = {
				1549323773, -- [1]
			},
			[87] = {
				1549311310, -- [1]
			},
			[64] = {
				1549322466, -- [1]
				1549324441, -- [2]
			},
			[65] = {
				1549322466, -- [1]
				1549323046, -- [2]
			},
			[66] = {
				1549326204, -- [1]
			},
			[67] = {
				1549320580, -- [1]
			},
			[268] = {
				1549317528, -- [1]
			},
			[69] = {
				1549314466, -- [1]
			},
			[195] = {
				1550172099, -- [1]
			},
			[71] = {
				1549316736, -- [1]
			},
			[72] = {
				1549313643, -- [1]
				1549314188, -- [2]
				1549320580, -- [3]
				1550171659, -- [4]
			},
			[73] = {
				1549317031, -- [1]
			},
			[292] = {
				1549317528, -- [1]
			},
			[75] = {
				1549316736, -- [1]
				1549323773, -- [2]
			},
			[151] = {
				1549325014, -- [1]
			},
			[153] = {
				1550171659, -- [1]
			},
			[155] = {
				1549325014, -- [1]
			},
			[79] = {
				1549319799, -- [1]
				1552240932, -- [2]
			},
			[80] = {
				1549311310, -- [1]
				1549314771, -- [2]
				1549319799, -- [3]
				1549323773, -- [4]
			},
			[161] = {
				1549321077, -- [1]
			},
			[82] = {
				1549311310, -- [1]
				1549314188, -- [2]
				1549325374, -- [3]
				1549325374, -- [4]
				1549325374, -- [5]
				1549325676, -- [6]
				1549325676, -- [7]
				1549325676, -- [8]
				1552240932, -- [9]
			},
			[165] = {
				1552242036, -- [1]
				1552242036, -- [2]
			},
			[84] = {
				1549320580, -- [1]
				1549321410, -- [2]
				1549325014, -- [3]
				1552240932, -- [4]
				1552240932, -- [5]
			},
			[94] = {
				1549310914, -- [1]
			},
			[86] = {
				1549324441, -- [1]
				1549324441, -- [2]
			},
			[173] = {
				1549324174, -- [1]
			},
			[175] = {
				1549320301, -- [1]
			},
			[98] = {
				1549313907, -- [1]
				1549313907, -- [2]
				1549314771, -- [3]
				1549314771, -- [4]
				1549316736, -- [5]
				1549317528, -- [6]
			},
			[179] = {
				1549320301, -- [1]
			},
			[91] = {
				1549314466, -- [1]
			},
			[364] = {
				1549316341, -- [1]
			},
			[109] = {
				1549314771, -- [1]
				1549481748, -- [2]
			},
			[187] = {
				1549324174, -- [1]
			},
			[95] = {
				1549313643, -- [1]
			},
			[96] = {
				1549322466, -- [1]
			},
			[108] = {
				1549315430, -- [1]
				1549315430, -- [2]
				1549322466, -- [3]
			},
			[261] = {
				1549325014, -- [1]
				1549326204, -- [2]
			},
			[99] = {
				1549313907, -- [1]
				1549313907, -- [2]
				1549313907, -- [3]
				1549314466, -- [4]
			},
			[100] = {
				1549313643, -- [1]
				1549314771, -- [2]
			},
			[101] = {
				1549314466, -- [1]
			},
			[102] = {
				1549310914, -- [1]
				1549310914, -- [2]
				1549310914, -- [3]
				1549311909, -- [4]
				1549315430, -- [5]
				1549315430, -- [6]
				1549316341, -- [7]
			},
			[103] = {
				1549325014, -- [1]
			},
			[104] = {
				1549314466, -- [1]
			},
			[105] = {
				1549316341, -- [1]
			},
			[106] = {
				1549311310, -- [1]
			},
			[107] = {
				1549323522, -- [1]
			},
			[215] = {
				1549311909, -- [1]
			},
			[217] = {
				1549311909, -- [1]
			},
			[110] = {
				1549319799, -- [1]
				1549325374, -- [2]
				1552242331, -- [3]
			},
			[111] = {
				1549316736, -- [1]
			},
			[317] = {
				1549316341, -- [1]
			},
			[113] = {
				1550949231, -- [1]
			},
			[171] = {
				1549481748, -- [1]
			},
			[115] = {
				1549321077, -- [1]
			},
			[157] = {
				1549323522, -- [1]
			},
			[117] = {
				1549321077, -- [1]
				1552242331, -- [2]
			},
			[118] = {
				1549480876, -- [1]
			},
			[18] = {
				1549313643, -- [1]
				1549319799, -- [2]
			},
			[133] = {
				1549311310, -- [1]
			},
			[166] = {
				1550949665, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233715"] = {
		["deaths"] = {
			[347] = {
				1550181503, -- [1]
			},
			[197] = {
				1550182067, -- [1]
			},
			[139] = {
				1552851169, -- [1]
			},
			[31] = {
				1550180655, -- [1]
				1550180937, -- [2]
				1552246285, -- [3]
			},
			[91] = {
				1550180937, -- [1]
			},
			[151] = {
				1552246285, -- [1]
			},
			[349] = {
				1550182067, -- [1]
			},
			[303] = {
				1550182067, -- [1]
			},
			[191] = {
				1550180655, -- [1]
				1550180655, -- [2]
				1550180655, -- [3]
			},
			[133] = {
				1550180655, -- [1]
			},
			[313] = {
				1550181503, -- [1]
			},
			[286] = {
				1552851169, -- [1]
			},
			[213] = {
				1552246285, -- [1]
			},
			[192] = {
				1550181503, -- [1]
			},
			[320] = {
				1550181503, -- [1]
			},
			[75] = {
				1550180937, -- [1]
			},
			[173] = {
				1550181503, -- [1]
			},
			[54] = {
				1550182067, -- [1]
			},
			[108] = {
				1550180937, -- [1]
			},
			[7] = {
				1552246285, -- [1]
			},
			[262] = {
				1550182067, -- [1]
				1552246285, -- [2]
			},
			[89] = {
				1550180937, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233416"] = {
		["deaths"] = {
			{
				1553547041, -- [1]
			}, -- [1]
			nil, -- [2]
			{
				1553546753, -- [1]
			}, -- [3]
			nil, -- [4]
			nil, -- [5]
			nil, -- [6]
			nil, -- [7]
			nil, -- [8]
			nil, -- [9]
			{
				1553546753, -- [1]
			}, -- [10]
			nil, -- [11]
			nil, -- [12]
			nil, -- [13]
			nil, -- [14]
			{
				1553546753, -- [1]
				1553546753, -- [2]
			}, -- [15]
			{
				1552932617, -- [1]
				1552934616, -- [2]
				1552935906, -- [3]
				1553546753, -- [4]
			}, -- [16]
			{
				1552932617, -- [1]
				1552937703, -- [2]
				1552940131, -- [3]
				1553541245, -- [4]
				1553545476, -- [5]
			}, -- [17]
			{
				1553547041, -- [1]
			}, -- [18]
			nil, -- [19]
			nil, -- [20]
			nil, -- [21]
			nil, -- [22]
			nil, -- [23]
			nil, -- [24]
			nil, -- [25]
			{
				1553547041, -- [1]
			}, -- [26]
			nil, -- [27]
			nil, -- [28]
			nil, -- [29]
			nil, -- [30]
			nil, -- [31]
			nil, -- [32]
			nil, -- [33]
			nil, -- [34]
			nil, -- [35]
			{
				1553547041, -- [1]
				1553547041, -- [2]
			}, -- [36]
			nil, -- [37]
			{
				1552932617, -- [1]
			}, -- [38]
			{
				1552932617, -- [1]
			}, -- [39]
			{
				1552932617, -- [1]
			}, -- [40]
			{
				1552933779, -- [1]
			}, -- [41]
			nil, -- [42]
			{
				1553541245, -- [1]
				1553541245, -- [2]
				1553542343, -- [3]
			}, -- [43]
			{
				1552933021, -- [1]
				1552933599, -- [2]
				1552933599, -- [3]
			}, -- [44]
			{
				1552932859, -- [1]
				1552932859, -- [2]
				1552932859, -- [3]
				1552933021, -- [4]
				1552933021, -- [5]
				1552933021, -- [6]
				1552933253, -- [7]
				1552933779, -- [8]
				1552933779, -- [9]
				1552934094, -- [10]
				1552934237, -- [11]
				1552934237, -- [12]
				1552934880, -- [13]
				1552935470, -- [14]
				1552935641, -- [15]
				1552936228, -- [16]
				1552936228, -- [17]
				1552936416, -- [18]
				1552937357, -- [19]
				1552937703, -- [20]
				1552937703, -- [21]
				1552938097, -- [22]
				1552938327, -- [23]
				1552938972, -- [24]
				1552940967, -- [25]
				1552941738, -- [26]
				1552942831, -- [27]
				1552943083, -- [28]
				1552943586, -- [29]
				1552943586, -- [30]
				1552943586, -- [31]
				1552944144, -- [32]
				1553541245, -- [33]
				1553541245, -- [34]
				1553541416, -- [35]
				1553542343, -- [36]
				1553542771, -- [37]
				1553542771, -- [38]
				1553542992, -- [39]
				1553542992, -- [40]
				1553543427, -- [41]
				1553543721, -- [42]
				1553546418, -- [43]
				1553547736, -- [44]
				1553548342, -- [45]
				1553548878, -- [46]
				1553548878, -- [47]
			}, -- [45]
			nil, -- [46]
			{
				1552938972, -- [1]
				1552943586, -- [2]
			}, -- [47]
			{
				1552932859, -- [1]
				1552933021, -- [2]
				1552936416, -- [3]
			}, -- [48]
			{
				1552933779, -- [1]
				1552933926, -- [2]
				1552934616, -- [3]
				1552934616, -- [4]
				1552935470, -- [5]
				1552935906, -- [6]
				1552937703, -- [7]
				1552941277, -- [8]
				1553541594, -- [9]
				1553542526, -- [10]
				1553542526, -- [11]
				1553542992, -- [12]
			}, -- [49]
			{
				1552933926, -- [1]
				1552937703, -- [2]
				1552943835, -- [3]
			}, -- [50]
			{
				1552934616, -- [1]
				1553543721, -- [2]
			}, -- [51]
			nil, -- [52]
			{
				1552933926, -- [1]
			}, -- [53]
			nil, -- [54]
			nil, -- [55]
			{
				1552934237, -- [1]
			}, -- [56]
			{
				1552933926, -- [1]
				1552935470, -- [2]
			}, -- [57]
			nil, -- [58]
			{
				1553542343, -- [1]
				1553542343, -- [2]
				1553542992, -- [3]
				1553542992, -- [4]
			}, -- [59]
			{
				1552943586, -- [1]
			}, -- [60]
			{
				1552938972, -- [1]
				1552938972, -- [2]
			}, -- [61]
			{
				1553542343, -- [1]
			}, -- [62]
			{
				1552933926, -- [1]
				1552938972, -- [2]
			}, -- [63]
			{
				1552934616, -- [1]
			}, -- [64]
			{
				1552939131, -- [1]
				1553542526, -- [2]
			}, -- [65]
			{
				1553542526, -- [1]
				1553542526, -- [2]
			}, -- [66]
			nil, -- [67]
			{
				1552936416, -- [1]
			}, -- [68]
			nil, -- [69]
			{
				1552935470, -- [1]
			}, -- [70]
			{
				1552933779, -- [1]
				1552934237, -- [2]
			}, -- [71]
			{
				1552934237, -- [1]
				1552935470, -- [2]
			}, -- [72]
			{
				1552936416, -- [1]
				1552936416, -- [2]
			}, -- [73]
			{
				1553543721, -- [1]
				1553548878, -- [2]
				1553548878, -- [3]
				1553548878, -- [4]
			}, -- [74]
			{
				1552940289, -- [1]
			}, -- [75]
			{
				1552941277, -- [1]
			}, -- [76]
			nil, -- [77]
			{
				1552933599, -- [1]
				1552934094, -- [2]
				1552941988, -- [3]
			}, -- [78]
			{
				1552935906, -- [1]
				1552940131, -- [2]
				1552941738, -- [3]
			}, -- [79]
			{
				1553547933, -- [1]
			}, -- [80]
			{
				1552932859, -- [1]
				1552938827, -- [2]
				1552940131, -- [3]
				1552940967, -- [4]
				1553543934, -- [5]
				1553546951, -- [6]
				1553546951, -- [7]
			}, -- [81]
			{
				1552933253, -- [1]
				1552935323, -- [2]
				1552935641, -- [3]
				1552938327, -- [4]
				1552938327, -- [5]
				1552938608, -- [6]
				1552939131, -- [7]
				1552940131, -- [8]
				1552940131, -- [9]
				1552940289, -- [10]
				1552940512, -- [11]
				1552940967, -- [12]
				1552942398, -- [13]
				1552943273, -- [14]
				1552943437, -- [15]
				1552943437, -- [16]
				1553541416, -- [17]
				1553541594, -- [18]
				1553543721, -- [19]
				1553545207, -- [20]
				1553546666, -- [21]
				1553546951, -- [22]
				1553547332, -- [23]
			}, -- [82]
			{
				1552933253, -- [1]
				1552935641, -- [2]
				1552936228, -- [3]
				1552937357, -- [4]
				1552938327, -- [5]
				1552938827, -- [6]
				1552939980, -- [7]
				1552940512, -- [8]
				1552940512, -- [9]
				1552940678, -- [10]
				1552940678, -- [11]
				1552943437, -- [12]
				1552943835, -- [13]
				1553541777, -- [14]
				1553543427, -- [15]
				1553543721, -- [16]
			}, -- [83]
			{
				1552937357, -- [1]
				1552944144, -- [2]
				1553546951, -- [3]
			}, -- [84]
			nil, -- [85]
			{
				1552934094, -- [1]
				1553546951, -- [2]
			}, -- [86]
			{
				1552934094, -- [1]
				1553541416, -- [2]
			}, -- [87]
			{
				1552935641, -- [1]
			}, -- [88]
			{
				1552934094, -- [1]
				1552940678, -- [2]
			}, -- [89]
			{
				1552934425, -- [1]
			}, -- [90]
			nil, -- [91]
			{
				1552943437, -- [1]
				1553541416, -- [2]
			}, -- [92]
			{
				1552934425, -- [1]
				1552940289, -- [2]
				1552943437, -- [3]
				1553541416, -- [4]
				1553541777, -- [5]
			}, -- [93]
			{
				1552938327, -- [1]
			}, -- [94]
			nil, -- [95]
			nil, -- [96]
			{
				1552936228, -- [1]
			}, -- [97]
			{
				1552941277, -- [1]
			}, -- [98]
			{
				1552939131, -- [1]
				1552939980, -- [2]
				1552939980, -- [3]
				1552941277, -- [4]
				1552941277, -- [5]
				1553541594, -- [6]
			}, -- [99]
			{
				1552940678, -- [1]
				1552940678, -- [2]
				1553541594, -- [3]
			}, -- [100]
			{
				1552935641, -- [1]
				1552939131, -- [2]
				1552939980, -- [3]
				1552939980, -- [4]
				1553541594, -- [5]
				1553541777, -- [6]
			}, -- [101]
			{
				1552936228, -- [1]
				1552939131, -- [2]
				1553541777, -- [3]
				1553541777, -- [4]
			}, -- [102]
			{
				1552934425, -- [1]
				1552940289, -- [2]
			}, -- [103]
			nil, -- [104]
			nil, -- [105]
			{
				1552940289, -- [1]
			}, -- [106]
			nil, -- [107]
			nil, -- [108]
			{
				1552937559, -- [1]
				1552937559, -- [2]
				1552937559, -- [3]
				1552937559, -- [4]
				1552937559, -- [5]
				1552943273, -- [6]
				1552943273, -- [7]
				1553543934, -- [8]
				1553543934, -- [9]
			}, -- [109]
			nil, -- [110]
			nil, -- [111]
			nil, -- [112]
			{
				1552934425, -- [1]
				1552934425, -- [2]
				1553542771, -- [3]
			}, -- [113]
			{
				1552933253, -- [1]
				1552935323, -- [2]
				1552938827, -- [3]
				1552941988, -- [4]
				1552943273, -- [5]
				1552943273, -- [6]
			}, -- [114]
			{
				1553547933, -- [1]
			}, -- [115]
			{
				1553547332, -- [1]
			}, -- [116]
			{
				1552933253, -- [1]
				1553543934, -- [2]
				1553547933, -- [3]
				1553547933, -- [4]
			}, -- [117]
			{
				1552940512, -- [1]
			}, -- [118]
			nil, -- [119]
			nil, -- [120]
			{
				1552940967, -- [1]
				1553546418, -- [2]
			}, -- [121]
			{
				1553547933, -- [1]
			}, -- [122]
			{
				1552937357, -- [1]
				1552938827, -- [2]
			}, -- [123]
			nil, -- [124]
			nil, -- [125]
			nil, -- [126]
			{
				1552938827, -- [1]
			}, -- [127]
			{
				1552940967, -- [1]
			}, -- [128]
			[179] = {
				1553545207, -- [1]
				1553546040, -- [2]
			},
			[148] = {
				1553544926, -- [1]
			},
			[180] = {
				1552935323, -- [1]
				1552936759, -- [2]
				1552936759, -- [3]
				1552943835, -- [4]
				1552944144, -- [5]
				1552944144, -- [6]
				1553546040, -- [7]
				1553547332, -- [8]
				1553547332, -- [9]
			},
			[294] = {
				1553542203, -- [1]
			},
			[181] = {
				1553547332, -- [1]
			},
			[150] = {
				1552943083, -- [1]
				1553546666, -- [2]
			},
			[297] = {
				1553543427, -- [1]
			},
			[151] = {
				1552943083, -- [1]
				1553545476, -- [2]
			},
			[246] = {
				1553547736, -- [1]
			},
			[152] = {
				1553545716, -- [1]
			},
			[184] = {
				1553544926, -- [1]
				1553545476, -- [2]
			},
			[153] = {
				1552938097, -- [1]
				1553544926, -- [2]
				1553546666, -- [3]
			},
			[154] = {
				1553542203, -- [1]
				1553545207, -- [2]
				1553545716, -- [3]
				1553545716, -- [4]
				1553546040, -- [5]
				1553546418, -- [6]
				1553548342, -- [7]
			},
			[155] = {
				1552938608, -- [1]
				1552938608, -- [2]
				1552944144, -- [3]
			},
			[156] = {
				1552938608, -- [1]
			},
			[311] = {
				1552941738, -- [1]
			},
			[313] = {
				1552942398, -- [1]
			},
			[315] = {
				1552942398, -- [1]
			},
			[160] = {
				1552938097, -- [1]
			},
			[192] = {
				1553544926, -- [1]
				1553546040, -- [2]
			},
			[161] = {
				1553546666, -- [1]
			},
			[193] = {
				1553544926, -- [1]
				1553548342, -- [2]
				1553548342, -- [3]
			},
			[162] = {
				1552942831, -- [1]
			},
			[321] = {
				1552942398, -- [1]
			},
			[163] = {
				1553542771, -- [1]
				1553545716, -- [2]
			},
			[306] = {
				1553542203, -- [1]
			},
			[245] = {
				1552938097, -- [1]
			},
			[291] = {
				1553548342, -- [1]
			},
			[197] = {
				1553545476, -- [1]
			},
			[177] = {
				1552943835, -- [1]
			},
			[295] = {
				1553542203, -- [1]
			},
			[182] = {
				1553548705, -- [1]
			},
			[284] = {
				1553546418, -- [1]
			},
			[168] = {
				1552937357, -- [1]
				1552943835, -- [2]
				1553545716, -- [3]
			},
			[333] = {
				1552941738, -- [1]
			},
			[169] = {
				1552936759, -- [1]
				1553545207, -- [2]
				1553546040, -- [3]
			},
			[335] = {
				1552941738, -- [1]
			},
			[273] = {
				1552942831, -- [1]
			},
			[194] = {
				1553545476, -- [1]
				1553546418, -- [2]
				1553547736, -- [3]
				1553547736, -- [4]
			},
			[143] = {
				1552933599, -- [1]
				1552933599, -- [2]
				1553542771, -- [3]
			},
			[142] = {
				1552940512, -- [1]
				1553543934, -- [2]
			},
			[277] = {
				1552938097, -- [1]
			},
			[278] = {
				1552942831, -- [1]
			},
			[279] = {
				1553542203, -- [1]
			},
			[205] = {
				1553548705, -- [1]
			},
			[281] = {
				1552942831, -- [1]
			},
			[206] = {
				1552935323, -- [1]
				1553548705, -- [2]
			},
			[175] = {
				1552936759, -- [1]
			},
			[144] = {
				1552934880, -- [1]
				1552934880, -- [2]
				1552934880, -- [3]
				1552934880, -- [4]
				1552935906, -- [5]
				1552935906, -- [6]
				1552938608, -- [7]
				1552941988, -- [8]
				1552941988, -- [9]
				1552941988, -- [10]
				1552943083, -- [11]
				1552943083, -- [12]
				1553543427, -- [13]
				1553546666, -- [14]
				1553548705, -- [15]
			},
			[176] = {
				1553545207, -- [1]
			},
			[258] = {
				1553547736, -- [1]
			},
			[287] = {
				1553543427, -- [1]
			},
			[146] = {
				1552935323, -- [1]
				1552936759, -- [2]
			},
			[289] = {
				1552942398, -- [1]
			},
			[212] = {
				1553548705, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234216"] = {
		["deaths"] = {
			nil, -- [1]
			nil, -- [2]
			nil, -- [3]
			nil, -- [4]
			nil, -- [5]
			nil, -- [6]
			nil, -- [7]
			nil, -- [8]
			nil, -- [9]
			nil, -- [10]
			nil, -- [11]
			nil, -- [12]
			nil, -- [13]
			nil, -- [14]
			nil, -- [15]
			nil, -- [16]
			nil, -- [17]
			{
				1550437161, -- [1]
			}, -- [18]
			nil, -- [19]
			nil, -- [20]
			{
				1550439863, -- [1]
			}, -- [21]
			{
				1550438045, -- [1]
				1551381560, -- [2]
			}, -- [22]
			nil, -- [23]
			{
				1550438708, -- [1]
				1551381923, -- [2]
			}, -- [24]
			{
				1550432930, -- [1]
				1550433451, -- [2]
				1551041910, -- [3]
			}, -- [25]
			{
				1550434331, -- [1]
				1550434331, -- [2]
			}, -- [26]
			{
				1550432930, -- [1]
			}, -- [27]
			nil, -- [28]
			nil, -- [29]
			nil, -- [30]
			nil, -- [31]
			nil, -- [32]
			nil, -- [33]
			nil, -- [34]
			nil, -- [35]
			nil, -- [36]
			{
				1550438925, -- [1]
			}, -- [37]
			nil, -- [38]
			nil, -- [39]
			nil, -- [40]
			nil, -- [41]
			{
				1550434915, -- [1]
			}, -- [42]
			nil, -- [43]
			nil, -- [44]
			{
				1551303612, -- [1]
			}, -- [45]
			{
				1551388355, -- [1]
				1551388355, -- [2]
			}, -- [46]
			{
				1551383913, -- [1]
			}, -- [47]
			{
				1550434331, -- [1]
			}, -- [48]
			{
				1551301099, -- [1]
			}, -- [49]
			{
				1551388978, -- [1]
			}, -- [50]
			{
				1551384172, -- [1]
				1551388355, -- [2]
			}, -- [51]
			nil, -- [52]
			{
				1550433882, -- [1]
				1550433882, -- [2]
				1550440438, -- [3]
				1550440438, -- [4]
				1550441006, -- [5]
				1551041478, -- [6]
			}, -- [53]
			{
				1550438423, -- [1]
				1551041478, -- [2]
			}, -- [54]
			{
				1551388355, -- [1]
			}, -- [55]
			{
				1550440136, -- [1]
				1551384172, -- [2]
			}, -- [56]
			{
				1550432930, -- [1]
				1550433882, -- [2]
				1550440645, -- [3]
				1550440645, -- [4]
				1550440645, -- [5]
				1551381560, -- [6]
				1551381560, -- [7]
				1551388355, -- [8]
			}, -- [57]
			{
				1551304426, -- [1]
			}, -- [58]
			{
				1550435289, -- [1]
				1551040558, -- [2]
				1551042520, -- [3]
			}, -- [59]
			nil, -- [60]
			{
				1550432930, -- [1]
				1550433193, -- [2]
				1550434072, -- [3]
			}, -- [61]
			nil, -- [62]
			{
				1550432930, -- [1]
				1550433193, -- [2]
				1550433451, -- [3]
				1551302464, -- [4]
				1551381923, -- [5]
				1551388198, -- [6]
			}, -- [63]
			{
				1550434331, -- [1]
				1551045591, -- [2]
				1551382403, -- [3]
				1551387376, -- [4]
			}, -- [64]
			{
				1551041910, -- [1]
				1551301099, -- [2]
				1551387071, -- [3]
				1551387071, -- [4]
				1551388544, -- [5]
			}, -- [65]
			{
				1550439197, -- [1]
				1551041910, -- [2]
				1551042154, -- [3]
				1551043624, -- [4]
				1551043624, -- [5]
				1551301866, -- [6]
				1551303409, -- [7]
				1551303612, -- [8]
			}, -- [66]
			{
				1551045591, -- [1]
				1551045591, -- [2]
				1551300390, -- [3]
				1551301099, -- [4]
			}, -- [67]
			{
				1551300390, -- [1]
				1551381923, -- [2]
			}, -- [68]
			{
				1550437573, -- [1]
				1550440645, -- [2]
				1550440645, -- [3]
				1551041478, -- [4]
				1551041478, -- [5]
				1551041698, -- [6]
				1551041698, -- [7]
				1551044669, -- [8]
				1551300390, -- [9]
			}, -- [69]
			{
				1550433193, -- [1]
				1550441006, -- [2]
				1551044669, -- [3]
			}, -- [70]
			{
				1550437573, -- [1]
				1551299101, -- [2]
				1551301099, -- [3]
				1551301866, -- [4]
				1551303409, -- [5]
				1551303409, -- [6]
			}, -- [71]
			{
				1551041910, -- [1]
				1551299101, -- [2]
			}, -- [72]
			{
				1551044669, -- [1]
			}, -- [73]
			{
				1550440136, -- [1]
				1551045591, -- [2]
			}, -- [74]
			nil, -- [75]
			{
				1550434331, -- [1]
				1550438045, -- [2]
				1551301099, -- [3]
			}, -- [76]
			{
				1551044981, -- [1]
			}, -- [77]
			{
				1550436920, -- [1]
				1551041910, -- [2]
				1551044669, -- [3]
			}, -- [78]
			nil, -- [79]
			{
				1550433193, -- [1]
				1550435685, -- [2]
				1551044669, -- [3]
			}, -- [80]
			nil, -- [81]
			{
				1551043317, -- [1]
				1551044410, -- [2]
				1551044410, -- [3]
				1551305136, -- [4]
			}, -- [82]
			{
				1550436920, -- [1]
				1550437161, -- [2]
				1551041210, -- [3]
			}, -- [83]
			{
				1551045591, -- [1]
				1551302464, -- [2]
				1551303612, -- [3]
			}, -- [84]
			{
				1550433451, -- [1]
				1551041210, -- [2]
				1551303612, -- [3]
				1551303612, -- [4]
				1551304426, -- [5]
				1551383134, -- [6]
			}, -- [85]
			{
				1551303409, -- [1]
			}, -- [86]
			nil, -- [87]
			{
				1551303409, -- [1]
			}, -- [88]
			{
				1552590652, -- [1]
			}, -- [89]
			{
				1550438708, -- [1]
			}, -- [90]
			{
				1551040558, -- [1]
				1552590652, -- [2]
			}, -- [91]
			{
				1550433882, -- [1]
				1550433882, -- [2]
				1551300829, -- [3]
				1551388544, -- [4]
			}, -- [92]
			{
				1550434915, -- [1]
			}, -- [93]
			{
				1550434915, -- [1]
				1551299449, -- [2]
				1551305136, -- [3]
			}, -- [94]
			{
				1551299449, -- [1]
				1551302464, -- [2]
				1551302464, -- [3]
				1551302464, -- [4]
				1551304426, -- [5]
				1551381560, -- [6]
				1551382403, -- [7]
			}, -- [95]
			{
				1550433193, -- [1]
				1551381560, -- [2]
			}, -- [96]
			{
				1551042154, -- [1]
				1551044410, -- [2]
				1551304426, -- [3]
				1551304426, -- [4]
				1552590652, -- [5]
				1552590652, -- [6]
				1552590652, -- [7]
			}, -- [97]
			{
				1551042154, -- [1]
				1551387376, -- [2]
			}, -- [98]
			{
				1550434072, -- [1]
			}, -- [99]
			{
				1550434915, -- [1]
				1551042154, -- [2]
				1551389798, -- [3]
				1551391310, -- [4]
			}, -- [100]
			{
				1550434072, -- [1]
				1550434072, -- [2]
				1550434072, -- [3]
				1550435289, -- [4]
				1550436920, -- [5]
				1550437161, -- [6]
				1551041478, -- [7]
				1551041698, -- [8]
				1551041698, -- [9]
				1551044410, -- [10]
				1551044410, -- [11]
				1551384172, -- [12]
			}, -- [101]
			{
				1551041698, -- [1]
				1551389238, -- [2]
			}, -- [102]
			{
				1550435289, -- [1]
				1550435685, -- [2]
				1551384172, -- [3]
			}, -- [103]
			{
				1551388544, -- [1]
			}, -- [104]
			{
				1551383134, -- [1]
				1551388544, -- [2]
			}, -- [105]
			{
				1551385152, -- [1]
				1551388544, -- [2]
			}, -- [106]
			{
				1550438708, -- [1]
				1551382756, -- [2]
			}, -- [107]
			{
				1550438925, -- [1]
			}, -- [108]
			{
				1550433451, -- [1]
				1551389238, -- [2]
			}, -- [109]
			{
				1550439863, -- [1]
				1551299449, -- [2]
				1551300390, -- [3]
				1551384172, -- [4]
			}, -- [110]
			{
				1550437573, -- [1]
				1551300390, -- [2]
				1551302266, -- [3]
				1551387718, -- [4]
				1551389238, -- [5]
			}, -- [111]
			{
				1551383134, -- [1]
			}, -- [112]
			{
				1550438423, -- [1]
				1550439197, -- [2]
				1551302784, -- [3]
			}, -- [113]
			nil, -- [114]
			{
				1550434699, -- [1]
				1550441006, -- [2]
			}, -- [115]
			{
				1550436920, -- [1]
				1550437573, -- [2]
				1550437573, -- [3]
				1550438925, -- [4]
				1550441006, -- [5]
				1551389238, -- [6]
			}, -- [116]
			{
				1551044175, -- [1]
			}, -- [117]
			{
				1550439197, -- [1]
				1551304828, -- [2]
				1551387071, -- [3]
			}, -- [118]
			{
				1550437161, -- [1]
				1550440438, -- [2]
				1551045355, -- [3]
			}, -- [119]
			{
				1550440438, -- [1]
			}, -- [120]
			{
				1550437161, -- [1]
				1550438423, -- [2]
				1550438423, -- [3]
			}, -- [121]
			nil, -- [122]
			{
				1550438925, -- [1]
				1550440136, -- [2]
			}, -- [123]
			{
				1551299101, -- [1]
				1551299449, -- [2]
			}, -- [124]
			{
				1551040558, -- [1]
			}, -- [125]
			{
				1550433451, -- [1]
				1550438925, -- [2]
				1550439197, -- [3]
				1551389238, -- [4]
			}, -- [126]
			{
				1550435289, -- [1]
				1553802854, -- [2]
			}, -- [127]
			nil, -- [128]
			{
				1550435289, -- [1]
				1551299101, -- [2]
			}, -- [129]
			{
				1551387071, -- [1]
			}, -- [130]
			{
				1551040861, -- [1]
				1551040861, -- [2]
			}, -- [131]
			nil, -- [132]
			nil, -- [133]
			{
				1550440136, -- [1]
				1551040861, -- [2]
			}, -- [134]
			{
				1550440136, -- [1]
				1551040861, -- [2]
				1551040861, -- [3]
				1551302784, -- [4]
				1551382403, -- [5]
			}, -- [135]
			{
				1550434699, -- [1]
				1550434915, -- [2]
				1551040558, -- [3]
				1551043624, -- [4]
				1551302784, -- [5]
				1551390187, -- [6]
			}, -- [136]
			nil, -- [137]
			nil, -- [138]
			{
				1550436920, -- [1]
				1551041210, -- [2]
				1551299101, -- [3]
			}, -- [139]
			{
				1550440438, -- [1]
			}, -- [140]
			{
				1551042154, -- [1]
				1551390758, -- [2]
			}, -- [141]
			{
				1552591812, -- [1]
			}, -- [142]
			{
				1551041210, -- [1]
				1551302784, -- [2]
			}, -- [143]
			{
				1551302784, -- [1]
			}, -- [144]
			{
				1550435685, -- [1]
				1550439547, -- [2]
			}, -- [145]
			nil, -- [146]
			nil, -- [147]
			nil, -- [148]
			nil, -- [149]
			{
				1550439863, -- [1]
			}, -- [150]
			{
				1550438423, -- [1]
				1551387718, -- [2]
			}, -- [151]
			nil, -- [152]
			nil, -- [153]
			nil, -- [154]
			nil, -- [155]
			{
				1550439547, -- [1]
			}, -- [156]
			{
				1550441006, -- [1]
				1551390187, -- [2]
			}, -- [157]
			nil, -- [158]
			nil, -- [159]
			{
				1552591812, -- [1]
			}, -- [160]
			{
				1550439197, -- [1]
				1551040558, -- [2]
				1551043624, -- [3]
			}, -- [161]
			{
				1551041210, -- [1]
				1551302266, -- [2]
				1551383480, -- [3]
				1553194330, -- [4]
			}, -- [162]
			{
				1550434699, -- [1]
				1550434699, -- [2]
				1550438708, -- [3]
				1552590473, -- [4]
			}, -- [163]
			{
				1551043624, -- [1]
			}, -- [164]
			{
				1551383134, -- [1]
			}, -- [165]
			{
				1550439863, -- [1]
				1551385152, -- [2]
			}, -- [166]
			{
				1550438045, -- [1]
				1550438708, -- [2]
				1552590473, -- [3]
				1553802854, -- [4]
			}, -- [167]
			{
				1550434699, -- [1]
			}, -- [168]
			{
				1550438045, -- [1]
				1551382756, -- [2]
			}, -- [169]
			nil, -- [170]
			{
				1551042520, -- [1]
				1551301866, -- [2]
				1553194330, -- [3]
			}, -- [171]
			{
				1551382756, -- [1]
				1551390187, -- [2]
			}, -- [172]
			{
				1551299449, -- [1]
				1551301468, -- [2]
				1551382403, -- [3]
			}, -- [173]
			{
				1550439863, -- [1]
				1551305136, -- [2]
				1552590473, -- [3]
			}, -- [174]
			{
				1551302266, -- [1]
				1551390187, -- [2]
			}, -- [175]
			{
				1550439547, -- [1]
			}, -- [176]
			{
				1551382756, -- [1]
				1551382756, -- [2]
			}, -- [177]
			{
				1551300829, -- [1]
				1551305136, -- [2]
				1551388198, -- [3]
			}, -- [178]
			{
				1551381923, -- [1]
				1551383913, -- [2]
			}, -- [179]
			nil, -- [180]
			nil, -- [181]
			{
				1551042520, -- [1]
				1551042520, -- [2]
				1551303160, -- [3]
			}, -- [182]
			{
				1552590473, -- [1]
			}, -- [183]
			{
				1552590473, -- [1]
			}, -- [184]
			{
				1551383480, -- [1]
			}, -- [185]
			{
				1551042520, -- [1]
				1551305136, -- [2]
				1551383134, -- [3]
				1551389798, -- [4]
			}, -- [186]
			{
				1551044981, -- [1]
				1551045355, -- [2]
				1551388978, -- [3]
			}, -- [187]
			{
				1551383480, -- [1]
				1551383913, -- [2]
			}, -- [188]
			{
				1551301468, -- [1]
				1551383480, -- [2]
			}, -- [189]
			nil, -- [190]
			{
				1550435685, -- [1]
				1551301468, -- [2]
				1551303160, -- [3]
				1551303160, -- [4]
				1551387718, -- [5]
				1551390758, -- [6]
			}, -- [191]
			{
				1550435685, -- [1]
				1551381923, -- [2]
				1551387718, -- [3]
			}, -- [192]
			{
				1551044981, -- [1]
				1551044981, -- [2]
				1551390187, -- [3]
			}, -- [193]
			{
				1551044981, -- [1]
				1551303160, -- [2]
				1551383480, -- [3]
			}, -- [194]
			{
				1550439547, -- [1]
				1551302266, -- [2]
				1551385152, -- [3]
			}, -- [195]
			nil, -- [196]
			{
				1551387376, -- [1]
				1551387376, -- [2]
			}, -- [197]
			{
				1551300829, -- [1]
				1551384728, -- [2]
			}, -- [198]
			{
				1551304828, -- [1]
			}, -- [199]
			{
				1551304828, -- [1]
			}, -- [200]
			{
				1551302266, -- [1]
				1551385152, -- [2]
				1551388978, -- [3]
				1551388978, -- [4]
			}, -- [201]
			{
				1551045355, -- [1]
			}, -- [202]
			{
				1550439547, -- [1]
			}, -- [203]
			{
				1551301468, -- [1]
				1551304154, -- [2]
			}, -- [204]
			nil, -- [205]
			{
				1551301866, -- [1]
				1551385152, -- [2]
				1551387718, -- [3]
			}, -- [206]
			{
				1551301468, -- [1]
				1551387376, -- [2]
			}, -- [207]
			nil, -- [208]
			nil, -- [209]
			nil, -- [210]
			nil, -- [211]
			{
				1551045355, -- [1]
			}, -- [212]
			{
				1551300829, -- [1]
				1551303160, -- [2]
				1551304154, -- [3]
			}, -- [213]
			nil, -- [214]
			{
				1551387071, -- [1]
			}, -- [215]
			nil, -- [216]
			{
				1551044175, -- [1]
			}, -- [217]
			{
				1551304154, -- [1]
				1551391310, -- [2]
			}, -- [218]
			nil, -- [219]
			{
				1551044175, -- [1]
				1551300829, -- [2]
				1551383913, -- [3]
			}, -- [220]
			{
				1551391310, -- [1]
			}, -- [221]
			nil, -- [222]
			nil, -- [223]
			{
				1550438045, -- [1]
			}, -- [224]
			nil, -- [225]
			nil, -- [226]
			{
				1551388978, -- [1]
			}, -- [227]
			nil, -- [228]
			nil, -- [229]
			nil, -- [230]
			nil, -- [231]
			nil, -- [232]
			nil, -- [233]
			nil, -- [234]
			nil, -- [235]
			{
				1551383913, -- [1]
			}, -- [236]
			nil, -- [237]
			nil, -- [238]
			{
				1551304154, -- [1]
			}, -- [239]
			{
				1551045355, -- [1]
				1551304828, -- [2]
			}, -- [240]
			{
				1551304828, -- [1]
			}, -- [241]
			nil, -- [242]
			{
				1551382403, -- [1]
			}, -- [243]
			{
				1551043317, -- [1]
				1551043317, -- [2]
			}, -- [244]
			{
				1551043317, -- [1]
				1551301866, -- [2]
			}, -- [245]
			{
				1551043317, -- [1]
			}, -- [246]
			nil, -- [247]
			nil, -- [248]
			nil, -- [249]
			nil, -- [250]
			nil, -- [251]
			nil, -- [252]
			nil, -- [253]
			nil, -- [254]
			nil, -- [255]
			{
				1551390758, -- [1]
			}, -- [256]
			[316] = {
				1551384728, -- [1]
			},
			[262] = {
				1551044175, -- [1]
			},
			[286] = {
				1551390758, -- [1]
			},
			[294] = {
				1551384728, -- [1]
			},
			[318] = {
				1551389798, -- [1]
			},
			[303] = {
				1551391310, -- [1]
			},
			[412] = {
				1551385885, -- [1]
			},
			[265] = {
				1551388198, -- [1]
			},
			[335] = {
				1552591241, -- [1]
			},
			[436] = {
				1552591241, -- [1]
			},
			[258] = {
				1551389798, -- [1]
			},
			[344] = {
				1551385885, -- [1]
			},
			[321] = {
				1551385885, -- [1]
			},
			[267] = {
				1551044175, -- [1]
			},
			[314] = {
				1551304154, -- [1]
				1551389798, -- [2]
			},
			[502] = {
				1552591812, -- [1]
			},
			[299] = {
				1551385885, -- [1]
				1551385885, -- [2]
			},
			[444] = {
				1552591241, -- [1]
			},
			[407] = {
				1552591241, -- [1]
			},
			[360] = {
				1552591241, -- [1]
			},
			[300] = {
				1551391310, -- [1]
			},
			[324] = {
				1551390758, -- [1]
			},
			[392] = {
				1551384728, -- [1]
				1551384728, -- [2]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234215"] = {
		["deaths"] = {
			[205] = {
				1550950649, -- [1]
			},
			[209] = {
				1552840097, -- [1]
			},
			[93] = {
				1550172806, -- [1]
			},
			[155] = {
				1550173353, -- [1]
			},
			[97] = {
				1551473868, -- [1]
				1551473868, -- [2]
			},
			[198] = {
				1551473868, -- [1]
				1552242977, -- [2]
			},
			[103] = {
				1550172806, -- [1]
			},
			[325] = {
				1552840097, -- [1]
			},
			[275] = {
				1549482625, -- [1]
			},
			[33] = {
				1550172806, -- [1]
			},
			[338] = {
				1552840097, -- [1]
			},
			[169] = {
				1551473868, -- [1]
			},
			[235] = {
				1551473868, -- [1]
			},
			[106] = {
				1550172806, -- [1]
			},
			[108] = {
				1550173353, -- [1]
			},
			[204] = {
				1549482625, -- [1]
			},
			[357] = {
				1550950649, -- [1]
			},
			[36] = {
				1550172806, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234315"] = {
		["deaths"] = {
			[488] = {
				1549917477, -- [1]
				1549917477, -- [2]
				1552247748, -- [3]
			},
			[125] = {
				1549911966, -- [1]
			},
			[126] = {
				1549911966, -- [1]
			},
			[253] = {
				1550517615, -- [1]
			},
			[255] = {
				1549914224, -- [1]
			},
			[512] = {
				1550519306, -- [1]
			},
			[274] = {
				1550517615, -- [1]
			},
			[140] = {
				1550517918, -- [1]
			},
			[282] = {
				1549914224, -- [1]
				1550523888, -- [2]
			},
			[286] = {
				1550523888, -- [1]
			},
			[37] = {
				1552851517, -- [1]
			},
			[294] = {
				1550523285, -- [1]
				1550523285, -- [2]
				1552247162, -- [3]
			},
			[298] = {
				1552247162, -- [1]
			},
			[152] = {
				1550517918, -- [1]
			},
			[314] = {
				1550518695, -- [1]
				1550518695, -- [2]
			},
			[445] = {
				1549915392, -- [1]
			},
			[162] = {
				1550517918, -- [1]
				1550517918, -- [2]
			},
			[330] = {
				1549916011, -- [1]
			},
			[461] = {
				1549915392, -- [1]
			},
			[465] = {
				1552852060, -- [1]
			},
			[473] = {
				1549915392, -- [1]
			},
			[45] = {
				1550519495, -- [1]
			},
			[493] = {
				1549916837, -- [1]
				1549916837, -- [2]
			},
			[497] = {
				1549917477, -- [1]
			},
			[501] = {
				1550521295, -- [1]
				1550521295, -- [2]
			},
			[505] = {
				1549916011, -- [1]
			},
			[259] = {
				1550518257, -- [1]
			},
			[263] = {
				1549913719, -- [1]
			},
			[200] = {
				1550519783, -- [1]
			},
			[275] = {
				1549912630, -- [1]
			},
			[279] = {
				1550518695, -- [1]
			},
			[52] = {
				1550517234, -- [1]
				1550517234, -- [2]
			},
			[13] = {
				1552247162, -- [1]
			},
			[346] = {
				1549914700, -- [1]
			},
			[142] = {
				1549914224, -- [1]
			},
			[42] = {
				1550519306, -- [1]
			},
			[271] = {
				1550521688, -- [1]
				1550521688, -- [2]
			},
			[496] = {
				1550521295, -- [1]
			},
			[315] = {
				1550518695, -- [1]
			},
			[319] = {
				1549916011, -- [1]
			},
			[58] = {
				1550517234, -- [1]
				1552851517, -- [2]
			},
			[466] = {
				1549915392, -- [1]
				1549915392, -- [2]
				1552852060, -- [3]
			},
			[230] = {
				1550518257, -- [1]
				1552247748, -- [2]
			},
			[20] = {
				1549913719, -- [1]
			},
			[547] = {
				1550522639, -- [1]
				1550522639, -- [2]
			},
			[68] = {
				1550517059, -- [1]
				1550517059, -- [2]
			},
			[60] = {
				1550517234, -- [1]
			},
			[111] = {
				1549914700, -- [1]
			},
			[61] = {
				1550517234, -- [1]
			},
			[141] = {
				1549912272, -- [1]
				1550522906, -- [2]
			},
			[490] = {
				1549916837, -- [1]
			},
			[312] = {
				1549913023, -- [1]
				1549914700, -- [2]
			},
			[479] = {
				1549916011, -- [1]
			},
			[252] = {
				1549914224, -- [1]
				1550517615, -- [2]
			},
			[506] = {
				1549916011, -- [1]
			},
			[510] = {
				1550521295, -- [1]
			},
			[260] = {
				1550521688, -- [1]
			},
			[297] = {
				1550518695, -- [1]
				1552247162, -- [2]
			},
			[268] = {
				1549913719, -- [1]
				1550518257, -- [2]
				1550518257, -- [3]
			},
			[336] = {
				1549913023, -- [1]
			},
			[276] = {
				1549912630, -- [1]
				1549914224, -- [2]
			},
			[71] = {
				1549911713, -- [1]
			},
			[143] = {
				1550521688, -- [1]
				1550522906, -- [2]
			},
			[73] = {
				1552851517, -- [1]
				1552851517, -- [2]
				1552851517, -- [3]
			},
			[292] = {
				1550523285, -- [1]
				1550523888, -- [2]
			},
			[149] = {
				1549912272, -- [1]
				1550522906, -- [2]
				1550522906, -- [3]
				1550522906, -- [4]
			},
			[467] = {
				1552852060, -- [1]
			},
			[304] = {
				1550517615, -- [1]
			},
			[78] = {
				1549911966, -- [1]
			},
			[79] = {
				1549911966, -- [1]
				1549912630, -- [2]
			},
			[80] = {
				1549911713, -- [1]
				1550517059, -- [2]
				1550517059, -- [3]
			},
			[81] = {
				1549912272, -- [1]
				1550517059, -- [2]
				1552247162, -- [3]
			},
			[163] = {
				1550517918, -- [1]
			},
			[328] = {
				1550519306, -- [1]
			},
			[177] = {
				1550523285, -- [1]
			},
			[85] = {
				1549911713, -- [1]
			},
			[86] = {
				1549911713, -- [1]
				1549911713, -- [2]
			},
			[22] = {
				1550519783, -- [1]
			},
			[91] = {
				1550523473, -- [1]
			},
			[352] = {
				1549914700, -- [1]
			},
			[97] = {
				1550519495, -- [1]
				1550523473, -- [2]
			},
			[181] = {
				1549912272, -- [1]
			},
			[491] = {
				1549916837, -- [1]
				1549917477, -- [2]
			},
			[201] = {
				1550522639, -- [1]
			},
			[199] = {
				1549912272, -- [1]
				1550519783, -- [2]
			},
			[503] = {
				1549917477, -- [1]
			},
			[511] = {
				1549913719, -- [1]
				1550519306, -- [2]
			},
			[257] = {
				1550521688, -- [1]
			},
			[98] = {
				1550523473, -- [1]
				1550523473, -- [2]
			},
			[197] = {
				1550519783, -- [1]
			},
			[269] = {
				1549913719, -- [1]
				1550518257, -- [2]
			},
			[542] = {
				1550522639, -- [1]
			},
			[277] = {
				1549912630, -- [1]
			},
			[26] = {
				1549911966, -- [1]
			},
			[285] = {
				1549913023, -- [1]
				1550523888, -- [2]
			},
			[105] = {
				1550519495, -- [1]
			},
			[293] = {
				1550523888, -- [1]
			},
			[107] = {
				1550519495, -- [1]
				1550519495, -- [2]
			},
			[517] = {
				1550519306, -- [1]
			},
			[305] = {
				1550523285, -- [1]
			},
			[77] = {
				1550523473, -- [1]
			},
			[221] = {
				1549914700, -- [1]
			},
			[19] = {
				1552247748, -- [1]
			},
			[139] = {
				1549916837, -- [1]
			},
			[502] = {
				1550521295, -- [1]
			},
			[47] = {
				1549912630, -- [1]
			},
			[535] = {
				1550522639, -- [1]
			},
			[190] = {
				1550519783, -- [1]
			},
			[468] = {
				1553456252, -- [1]
			},
			[127] = {
				1550517615, -- [1]
			},
			[322] = {
				1549913023, -- [1]
			},
			[334] = {
				1549913023, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233015"] = {
		["deaths"] = {
			[106] = {
				1550174411, -- [1]
				1552847699, -- [2]
			},
			[242] = {
				1550953770, -- [1]
			},
			[211] = {
				1549483745, -- [1]
			},
			[293] = {
				1549485584, -- [1]
			},
			[149] = {
				1549484572, -- [1]
			},
			[295] = {
				1551292641, -- [1]
			},
			[150] = {
				1549483244, -- [1]
				1552840943, -- [2]
			},
			[245] = {
				1549484572, -- [1]
			},
			[153] = {
				1549483244, -- [1]
				1549484572, -- [2]
			},
			[247] = {
				1549483745, -- [1]
			},
			[216] = {
				1550953276, -- [1]
			},
			[185] = {
				1550953276, -- [1]
			},
			[154] = {
				1549483244, -- [1]
				1549483244, -- [2]
			},
			[94] = {
				1550954752, -- [1]
			},
			[155] = {
				1549484572, -- [1]
			},
			[250] = {
				1550953770, -- [1]
			},
			[292] = {
				1551292641, -- [1]
			},
			[95] = {
				1550952551, -- [1]
			},
			[248] = {
				1550955173, -- [1]
			},
			[290] = {
				1550174847, -- [1]
			},
			[225] = {
				1550952227, -- [1]
			},
			[285] = {
				1549485584, -- [1]
				1551292641, -- [2]
			},
			[159] = {
				1550951774, -- [1]
			},
			[83] = {
				1549484054, -- [1]
				1552840943, -- [2]
			},
			[81] = {
				1550174184, -- [1]
			},
			[163] = {
				1550951774, -- [1]
			},
			[224] = {
				1549484572, -- [1]
				1550952227, -- [2]
			},
			[104] = {
				1550174411, -- [1]
				1552847699, -- [2]
			},
			[82] = {
				1549485074, -- [1]
				1550174411, -- [2]
				1550954752, -- [3]
			},
			[261] = {
				1551292054, -- [1]
			},
			[259] = {
				1550953276, -- [1]
				1551292054, -- [2]
			},
			[84] = {
				1549484054, -- [1]
				1550174411, -- [2]
				1550174411, -- [3]
				1550952551, -- [4]
				1550952551, -- [5]
				1550954752, -- [6]
				1550954752, -- [7]
			},
			[164] = {
				1550953770, -- [1]
			},
			[168] = {
				1549485074, -- [1]
			},
			[233] = {
				1549485074, -- [1]
			},
			[277] = {
				1550174184, -- [1]
				1550174184, -- [2]
			},
			[229] = {
				1549483745, -- [1]
				1550951439, -- [2]
				1550951439, -- [3]
			},
			[274] = {
				1549483745, -- [1]
				1549485074, -- [2]
			},
			[167] = {
				1550953770, -- [1]
			},
			[69] = {
				1549485584, -- [1]
				1550951774, -- [2]
			},
			[85] = {
				1549483244, -- [1]
				1549483745, -- [2]
				1549484054, -- [3]
				1549484054, -- [4]
				1550952227, -- [5]
				1550952551, -- [6]
				1551292641, -- [7]
			},
			[170] = {
				1550951439, -- [1]
			},
			[232] = {
				1549485074, -- [1]
				1550951439, -- [2]
				1550953770, -- [3]
			},
			[139] = {
				1552840943, -- [1]
			},
			[86] = {
				1549484054, -- [1]
				1550954752, -- [2]
			},
			[102] = {
				1550952551, -- [1]
			},
			[234] = {
				1551292641, -- [1]
			},
			[276] = {
				1550174184, -- [1]
			},
			[87] = {
				1550951774, -- [1]
			},
			[103] = {
				1550951774, -- [1]
			},
			[279] = {
				1550174184, -- [1]
			},
			[231] = {
				1550952227, -- [1]
			},
			[237] = {
				1550951439, -- [1]
			},
			[282] = {
				1549485584, -- [1]
				1549485584, -- [2]
				1551292054, -- [3]
			},
			[238] = {
				1550952227, -- [1]
				1550953276, -- [2]
				1551292054, -- [3]
			},
			[284] = {
				1550174847, -- [1]
			},
			[89] = {
				1551292054, -- [1]
			},
			[286] = {
				1550174847, -- [1]
			},
			[240] = {
				1550953276, -- [1]
			},
			[288] = {
				1550174847, -- [1]
			},
			[289] = {
				1550174847, -- [1]
			},
			[218] = {
				1552840943, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233316"] = {
		["deaths"] = {
			[33] = {
				1549570653, -- [1]
				1549570653, -- [2]
			},
			[35] = {
				1549570855, -- [1]
				1549572649, -- [2]
				1549827278, -- [3]
				1549827278, -- [4]
			},
			[37] = {
				1549827897, -- [1]
			},
			[39] = {
				1549569654, -- [1]
				1549569654, -- [2]
				1549569654, -- [3]
				1549569654, -- [4]
				1549571223, -- [5]
				1549571223, -- [6]
				1549830632, -- [7]
			},
			[179] = {
				1550690926, -- [1]
				1550690926, -- [2]
				1550695152, -- [3]
				1552589069, -- [4]
				1552589069, -- [5]
			},
			[47] = {
				1549568250, -- [1]
			},
			[49] = {
				1549832277, -- [1]
				1551298142, -- [2]
			},
			[203] = {
				1552587621, -- [1]
			},
			[219] = {
				1549832903, -- [1]
				1550093135, -- [2]
				1550693884, -- [3]
				1550693884, -- [4]
			},
			[61] = {
				1551036552, -- [1]
			},
			[63] = {
				1549829588, -- [1]
			},
			[66] = {
				1550091365, -- [1]
				1550091365, -- [2]
			},
			[70] = {
				1550095098, -- [1]
			},
			[74] = {
				1549576184, -- [1]
				1549826551, -- [2]
				1550091365, -- [3]
			},
			[78] = {
				1549568504, -- [1]
				1549570399, -- [2]
				1549571223, -- [3]
				1549831979, -- [4]
				1550088953, -- [5]
				1550694457, -- [6]
				1550694457, -- [7]
			},
			[82] = {
				1549568250, -- [1]
			},
			[86] = {
				1550694624, -- [1]
				1551294817, -- [2]
				1551294817, -- [3]
			},
			[90] = {
				1549570399, -- [1]
				1549570399, -- [2]
				1549570399, -- [3]
			},
			[94] = {
				1549575956, -- [1]
				1550087942, -- [2]
				1550690318, -- [3]
				1550690318, -- [4]
				1550690318, -- [5]
				1550690318, -- [6]
				1550694624, -- [7]
			},
			[98] = {
				1550692390, -- [1]
			},
			[102] = {
				1549569090, -- [1]
				1549569090, -- [2]
				1549569090, -- [3]
				1549569090, -- [4]
				1549569090, -- [5]
				1549572649, -- [6]
				1550088161, -- [7]
				1550088161, -- [8]
				1550088953, -- [9]
				1551295983, -- [10]
			},
			[106] = {
				1549569345, -- [1]
				1549575125, -- [2]
				1549835522, -- [3]
				1549835522, -- [4]
				1552588615, -- [5]
			},
			[110] = {
				1550088161, -- [1]
				1550088161, -- [2]
			},
			[114] = {
				1549574568, -- [1]
				1549575956, -- [2]
				1549575956, -- [3]
				1549575956, -- [4]
				1549828200, -- [5]
				1549830166, -- [6]
				1550089860, -- [7]
			},
			[118] = {
				1549574189, -- [1]
				1549827529, -- [2]
				1549833509, -- [3]
				1549835847, -- [4]
			},
			[122] = {
				1549572394, -- [1]
				1550088953, -- [2]
			},
			[126] = {
				1549577066, -- [1]
				1549827278, -- [2]
				1549832277, -- [3]
			},
			[132] = {
				1549829814, -- [1]
				1549829814, -- [2]
				1550689484, -- [3]
			},
			[140] = {
				1549567205, -- [1]
				1550689484, -- [2]
			},
			[148] = {
				1549827897, -- [1]
				1549834431, -- [2]
				1550086451, -- [3]
				1553192332, -- [4]
			},
			[156] = {
				1549566880, -- [1]
				1549566880, -- [2]
				1550093819, -- [3]
				1550695152, -- [4]
				1551035804, -- [5]
				1551038347, -- [6]
			},
			[164] = {
				1549567471, -- [1]
				1549834779, -- [2]
			},
			[359] = {
				1549828732, -- [1]
			},
			[188] = {
				1549574568, -- [1]
				1551294517, -- [2]
			},
			[196] = {
				1550089860, -- [1]
			},
			[204] = {
				1551294517, -- [1]
				1552588327, -- [2]
			},
			[212] = {
				1549836537, -- [1]
			},
			[220] = {
				1549834098, -- [1]
				1549836159, -- [2]
				1552588327, -- [3]
			},
			[244] = {
				1550094302, -- [1]
				1550094302, -- [2]
				1550694267, -- [3]
				1550694267, -- [4]
				1550694267, -- [5]
				1550694267, -- [6]
				1551036988, -- [7]
				1551036988, -- [8]
			},
			[252] = {
				1551037912, -- [1]
			},
			[280] = {
				1551298142, -- [1]
			},
			[133] = {
				1549572998, -- [1]
				1550086451, -- [2]
				1550086840, -- [3]
			},
			[141] = {
				1549567205, -- [1]
			},
			[149] = {
				1551294517, -- [1]
			},
			[157] = {
				1551036091, -- [1]
			},
			[165] = {
				1549834431, -- [1]
				1551036376, -- [2]
			},
			[181] = {
				1549833509, -- [1]
				1549833509, -- [2]
			},
			[213] = {
				1551037912, -- [1]
			},
			[221] = {
				1551295734, -- [1]
			},
			[229] = {
				1549828732, -- [1]
				1550430990, -- [2]
			},
			[237] = {
				1549835268, -- [1]
			},
			[253] = {
				1550094302, -- [1]
			},
			[67] = {
				1549568250, -- [1]
				1549830632, -- [2]
				1549830632, -- [3]
				1549830632, -- [4]
				1549834930, -- [5]
			},
			[71] = {
				1549829814, -- [1]
				1549831681, -- [2]
				1549831681, -- [3]
				1549831681, -- [4]
				1550091014, -- [5]
			},
			[79] = {
				1549572157, -- [1]
			},
			[330] = {
				1549575125, -- [1]
			},
			[87] = {
				1549576423, -- [1]
				1549832277, -- [2]
				1549833188, -- [3]
				1549833188, -- [4]
				1549833188, -- [5]
				1549833188, -- [6]
			},
			[91] = {
				1549567471, -- [1]
				1549576423, -- [2]
				1551294817, -- [3]
				1551296378, -- [4]
				1551297018, -- [5]
			},
			[95] = {
				1549570172, -- [1]
				1549570399, -- [2]
				1549834779, -- [3]
			},
			[99] = {
				1549572157, -- [1]
				1549572394, -- [2]
				1549827529, -- [3]
				1549827529, -- [4]
			},
			[103] = {
				1549570653, -- [1]
				1549573524, -- [2]
				1549832523, -- [3]
				1550091014, -- [4]
				1551296173, -- [5]
				1551297018, -- [6]
			},
			[107] = {
				1549568250, -- [1]
				1549568841, -- [2]
				1549568841, -- [3]
				1549569345, -- [4]
				1549569345, -- [5]
				1549569345, -- [6]
				1549831681, -- [7]
				1550087942, -- [8]
				1550087942, -- [9]
				1550087942, -- [10]
				1550093819, -- [11]
				1550692114, -- [12]
				1550692114, -- [13]
				1550692114, -- [14]
				1551036376, -- [15]
			},
			[111] = {
				1549572157, -- [1]
				1549572157, -- [2]
				1549573269, -- [3]
				1549573269, -- [4]
				1549573524, -- [5]
				1549576658, -- [6]
				1550088953, -- [7]
				1551296378, -- [8]
				1551296378, -- [9]
				1551296378, -- [10]
			},
			[115] = {
				1549568504, -- [1]
				1549568504, -- [2]
				1549571223, -- [3]
				1549574568, -- [4]
				1549826050, -- [5]
				1549826050, -- [6]
				1549826050, -- [7]
				1549826551, -- [8]
				1549826551, -- [9]
				1549831979, -- [10]
				1549831979, -- [11]
			},
			[119] = {
				1550092732, -- [1]
				1550092732, -- [2]
				1550092732, -- [3]
				1550092732, -- [4]
				1550692788, -- [5]
				1550692788, -- [6]
				1550692788, -- [7]
				1550692788, -- [8]
				1551037463, -- [9]
				1551037463, -- [10]
				1551037463, -- [11]
				1551037463, -- [12]
				1551037463, -- [13]
			},
			[134] = {
				1549567471, -- [1]
				1549572998, -- [2]
				1549827897, -- [3]
			},
			[142] = {
				1549567205, -- [1]
				1549567471, -- [2]
				1549567471, -- [3]
				1549825729, -- [4]
			},
			[150] = {
				1549827278, -- [1]
				1549834779, -- [2]
			},
			[158] = {
				1549833509, -- [1]
				1549833509, -- [2]
				1549835847, -- [3]
				1549835847, -- [4]
				1549835847, -- [5]
				1550093135, -- [6]
				1550093819, -- [7]
				1550694865, -- [8]
			},
			[166] = {
				1549834431, -- [1]
				1549836537, -- [2]
			},
			[182] = {
				1550691416, -- [1]
			},
			[190] = {
				1550690926, -- [1]
			},
			[206] = {
				1549575512, -- [1]
				1550089353, -- [2]
			},
			[214] = {
				1550691416, -- [1]
			},
			[18] = {
				1549834930, -- [1]
				1550091365, -- [2]
			},
			[19] = {
				1549829588, -- [1]
			},
			[24] = {
				1550091014, -- [1]
			},
			[26] = {
				1549835522, -- [1]
				1550693602, -- [2]
				1551036091, -- [3]
			},
			[27] = {
				1551036552, -- [1]
			},
			[32] = {
				1553191463, -- [1]
				1553191463, -- [2]
				1553191463, -- [3]
			},
			[34] = {
				1549829588, -- [1]
				1550692114, -- [2]
				1550692390, -- [3]
			},
			[36] = {
				1549569928, -- [1]
				1549569928, -- [2]
				1549571223, -- [3]
				1549573524, -- [4]
				1549825729, -- [5]
				1550089353, -- [6]
				1550691416, -- [7]
			},
			[38] = {
				1549570855, -- [1]
				1549572157, -- [2]
				1549576184, -- [3]
				1549577066, -- [4]
				1549825729, -- [5]
				1549828200, -- [6]
				1551295734, -- [7]
			},
			[159] = {
				1549836159, -- [1]
			},
			[167] = {
				1552589504, -- [1]
			},
			[175] = {
				1550092460, -- [1]
				1550092460, -- [2]
				1550092460, -- [3]
				1550092460, -- [4]
			},
			[183] = {
				1549830166, -- [1]
				1549830166, -- [2]
			},
			[48] = {
				1549573524, -- [1]
			},
			[207] = {
				1549574189, -- [1]
				1549575512, -- [2]
			},
			[215] = {
				1551035804, -- [1]
				1551035804, -- [2]
				1552587621, -- [3]
			},
			[223] = {
				1549835268, -- [1]
			},
			[58] = {
				1550095098, -- [1]
				1550095098, -- [2]
				1550095098, -- [3]
				1550095098, -- [4]
			},
			[60] = {
				1551036552, -- [1]
				1551036552, -- [2]
				1551294517, -- [3]
			},
			[62] = {
				1549829814, -- [1]
				1550692593, -- [2]
			},
			[64] = {
				1549829588, -- [1]
				1549829588, -- [2]
				1549834930, -- [3]
				1549834930, -- [4]
				1550091365, -- [5]
				1551295734, -- [6]
			},
			[68] = {
				1549569654, -- [1]
				1549572649, -- [2]
				1549572649, -- [3]
				1549576184, -- [4]
			},
			[72] = {
				1549576423, -- [1]
				1549831979, -- [2]
				1549832523, -- [3]
				1549832523, -- [4]
				1549832523, -- [5]
				1551296173, -- [6]
				1551296173, -- [7]
			},
			[76] = {
				1549569345, -- [1]
				1549835522, -- [2]
			},
			[84] = {
				1550086451, -- [1]
			},
			[88] = {
				1549569928, -- [1]
				1550690318, -- [2]
				1550692114, -- [3]
				1550692390, -- [4]
				1551294817, -- [5]
				1551294817, -- [6]
				1551296589, -- [7]
				1551296589, -- [8]
			},
			[92] = {
				1549576423, -- [1]
				1549828732, -- [2]
				1549835522, -- [3]
			},
			[96] = {
				1549570172, -- [1]
				1549570172, -- [2]
				1549570172, -- [3]
				1549570172, -- [4]
				1549573774, -- [5]
				1550091014, -- [6]
				1551036988, -- [7]
				1551295983, -- [8]
				1553191463, -- [9]
			},
			[100] = {
				1549569928, -- [1]
				1549569928, -- [2]
				1549573269, -- [3]
				1550087942, -- [4]
			},
			[104] = {
				1549570653, -- [1]
				1549573524, -- [2]
				1549831979, -- [3]
				1551037234, -- [4]
				1551296173, -- [5]
				1551296173, -- [6]
				1551296378, -- [7]
			},
			[108] = {
				1550692593, -- [1]
			},
			[112] = {
				1549575125, -- [1]
				1549576658, -- [2]
				1549826050, -- [3]
				1549826810, -- [4]
				1549827897, -- [5]
				1549830166, -- [6]
				1550088686, -- [7]
			},
			[116] = {
				1549829814, -- [1]
			},
			[120] = {
				1550692788, -- [1]
			},
			[124] = {
				1549575956, -- [1]
			},
			[128] = {
				1550689484, -- [1]
			},
			[136] = {
				1549574189, -- [1]
			},
			[144] = {
				1549567205, -- [1]
				1549825729, -- [2]
				1550088686, -- [3]
			},
			[152] = {
				1549566880, -- [1]
			},
			[160] = {
				1549832277, -- [1]
				1549834098, -- [2]
				1549835847, -- [3]
				1550093135, -- [4]
				1550694865, -- [5]
			},
			[351] = {
				1549828732, -- [1]
			},
			[184] = {
				1549577066, -- [1]
				1549836537, -- [2]
			},
			[192] = {
				1549574568, -- [1]
				1549826551, -- [2]
				1549836159, -- [3]
				1550088686, -- [4]
				1550431418, -- [5]
				1551035804, -- [6]
			},
			[200] = {
				1549575512, -- [1]
				1552588327, -- [2]
				1552588327, -- [3]
				1552588327, -- [4]
			},
			[224] = {
				1549832903, -- [1]
				1549832903, -- [2]
				1549832903, -- [3]
				1549834098, -- [4]
				1549835268, -- [5]
				1550693884, -- [6]
				1550694267, -- [7]
			},
			[248] = {
				1550093135, -- [1]
				1550430990, -- [2]
			},
			[352] = {
				1550089860, -- [1]
			},
			[137] = {
				1549567205, -- [1]
				1549834779, -- [2]
				1550086840, -- [3]
			},
			[145] = {
				1550086451, -- [1]
				1550088686, -- [2]
				1550089353, -- [3]
			},
			[153] = {
				1549574568, -- [1]
				1549834431, -- [2]
				1552588615, -- [3]
			},
			[161] = {
				1550092011, -- [1]
				1550092011, -- [2]
			},
			[353] = {
				1549575125, -- [1]
			},
			[185] = {
				1549827897, -- [1]
				1550089353, -- [2]
			},
			[193] = {
				1549575125, -- [1]
				1550092011, -- [2]
				1550092011, -- [3]
			},
			[225] = {
				1550094302, -- [1]
				1550094302, -- [2]
				1551036988, -- [3]
				1551036988, -- [4]
				1551298142, -- [5]
				1551298142, -- [6]
			},
			[233] = {
				1550088686, -- [1]
			},
			[191] = {
				1549832903, -- [1]
			},
			[282] = {
				1550093819, -- [1]
				1550430990, -- [2]
			},
			[65] = {
				1549834930, -- [1]
			},
			[69] = {
				1549570855, -- [1]
				1549576184, -- [2]
				1549576184, -- [3]
				1549827529, -- [4]
				1549827529, -- [5]
				1551296589, -- [6]
			},
			[73] = {
				1549573774, -- [1]
				1549828200, -- [2]
			},
			[77] = {
				1549568504, -- [1]
				1549568504, -- [2]
				1549573774, -- [3]
				1550092732, -- [4]
				1550694624, -- [5]
			},
			[81] = {
				1549568250, -- [1]
				1549568841, -- [2]
				1549572998, -- [3]
				1549576423, -- [4]
				1551296589, -- [5]
			},
			[315] = {
				1552589504, -- [1]
				1552589504, -- [2]
			},
			[89] = {
				1551296589, -- [1]
			},
			[93] = {
				1549830166, -- [1]
				1549830632, -- [2]
				1549833188, -- [3]
				1550690565, -- [4]
			},
			[97] = {
				1549573774, -- [1]
				1549573774, -- [2]
				1550089860, -- [3]
				1551036091, -- [4]
				1551295734, -- [5]
			},
			[101] = {
				1549570855, -- [1]
				1549826810, -- [2]
				1549826810, -- [3]
				1549826810, -- [4]
				1550088161, -- [5]
				1550091014, -- [6]
			},
			[105] = {
				1549570653, -- [1]
				1549570855, -- [2]
				1549572649, -- [3]
				1549574189, -- [4]
				1549576658, -- [5]
				1549576658, -- [6]
				1549826050, -- [7]
			},
			[109] = {
				1549568841, -- [1]
				1549576658, -- [2]
				1549826810, -- [3]
				1551295734, -- [4]
				1553191463, -- [5]
			},
			[113] = {
				1549568841, -- [1]
				1549572394, -- [2]
				1549572394, -- [3]
				1549572394, -- [4]
				1549573269, -- [5]
				1549573269, -- [6]
				1549574189, -- [7]
				1549575512, -- [8]
				1549577066, -- [9]
				1549577066, -- [10]
				1549826551, -- [11]
				1549828200, -- [12]
				1549828200, -- [13]
				1549828732, -- [14]
				1551295983, -- [15]
				1551295983, -- [16]
			},
			[117] = {
				1551295983, -- [1]
			},
			[286] = {
				1552589069, -- [1]
				1552589069, -- [2]
			},
			[125] = {
				1549572998, -- [1]
				1549572998, -- [2]
			},
			[147] = {
				1549575512, -- [1]
				1550086451, -- [2]
				1550689484, -- [3]
			},
			[306] = {
				1550430990, -- [1]
				1550430990, -- [2]
			},
			[146] = {
				1549836537, -- [1]
			},
			[154] = {
				1549566880, -- [1]
				1549566880, -- [2]
				1552588615, -- [3]
			},
			[162] = {
				1549831681, -- [1]
				1549832277, -- [2]
				1549834431, -- [3]
				1550086840, -- [4]
			},
			[170] = {
				1550092460, -- [1]
			},
			[178] = {
				1550089353, -- [1]
			},
			[186] = {
				1550431418, -- [1]
			},
			[194] = {
				1549836159, -- [1]
				1549836159, -- [2]
				1551037912, -- [3]
				1551038347, -- [4]
			},
			[278] = {
				1550094761, -- [1]
			},
			[210] = {
				1549836537, -- [1]
			},
			[218] = {
				1553192332, -- [1]
			},
			[302] = {
				1550093819, -- [1]
				1550094761, -- [2]
				1551038853, -- [3]
				1551038853, -- [4]
				1552587621, -- [5]
			},
			[177] = {
				1550092011, -- [1]
			},
			[242] = {
				1551037912, -- [1]
				1551038347, -- [2]
				1551038347, -- [3]
				1551038347, -- [4]
			},
			[250] = {
				1551037912, -- [1]
			},
			[301] = {
				1550094761, -- [1]
				1550094761, -- [2]
				1550431875, -- [3]
				1550431875, -- [4]
			},
			[195] = {
				1550094761, -- [1]
				1550693884, -- [2]
				1551035804, -- [3]
				1553192332, -- [4]
			},
			[292] = {
				1553193117, -- [1]
			},
			[308] = {
				1552587621, -- [1]
			},
			[143] = {
				1550086840, -- [1]
				1550087143, -- [2]
			},
			[139] = {
				1549825729, -- [1]
				1550086840, -- [2]
			},
			[367] = {
				1550089860, -- [1]
			},
			[287] = {
				1549827278, -- [1]
			},
			[267] = {
				1550093135, -- [1]
			},
			[155] = {
				1550689484, -- [1]
				1550693884, -- [2]
			},
			[135] = {
				1550690565, -- [1]
				1550690565, -- [2]
				1550690565, -- [3]
				1550690565, -- [4]
				1550690926, -- [5]
				1551294517, -- [6]
				1552588615, -- [7]
				1552588615, -- [8]
			},
			[331] = {
				1550691416, -- [1]
			},
			[56] = {
				1551036552, -- [1]
			},
			[326] = {
				1550691416, -- [1]
			},
			[180] = {
				1550690926, -- [1]
				1550695152, -- [2]
				1550695152, -- [3]
				1550695152, -- [4]
				1551038853, -- [5]
			},
			[284] = {
				1551038853, -- [1]
				1551038853, -- [2]
				1552589069, -- [3]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233516"] = {
		["deaths"] = {
			[31] = {
				1553200671, -- [1]
				1553200671, -- [2]
				1553200873, -- [3]
			},
			[247] = {
				1552596892, -- [1]
				1553197066, -- [2]
				1553808764, -- [3]
				1553808764, -- [4]
			},
			[249] = {
				1553197066, -- [1]
				1553200532, -- [2]
			},
			[253] = {
				1553200532, -- [1]
			},
			[258] = {
				1553199621, -- [1]
			},
			[266] = {
				1553199100, -- [1]
			},
			[274] = {
				1552596892, -- [1]
			},
			[36] = {
				1552595982, -- [1]
				1553196381, -- [2]
			},
			[37] = {
				1552595982, -- [1]
				1552597451, -- [2]
			},
			[294] = {
				1553200532, -- [1]
			},
			[38] = {
				1553196381, -- [1]
				1553200671, -- [2]
				1553806605, -- [3]
			},
			[10] = {
				1553808345, -- [1]
			},
			[314] = {
				1553201433, -- [1]
				1553806189, -- [2]
			},
			[318] = {
				1553198748, -- [1]
				1553198748, -- [2]
			},
			[326] = {
				1553199621, -- [1]
				1553808036, -- [2]
			},
			[346] = {
				1552597451, -- [1]
			},
			[45] = {
				1553196381, -- [1]
				1553200671, -- [2]
			},
			[180] = {
				1553808345, -- [1]
			},
			[182] = {
				1552596275, -- [1]
				1552596275, -- [2]
				1552597451, -- [3]
			},
			[184] = {
				1552596892, -- [1]
			},
			[186] = {
				1552596275, -- [1]
			},
			[188] = {
				1553806605, -- [1]
			},
			[190] = {
				1553198748, -- [1]
				1553200073, -- [2]
			},
			[192] = {
				1553199621, -- [1]
				1553807514, -- [2]
				1553808036, -- [3]
			},
			[259] = {
				1552596892, -- [1]
			},
			[198] = {
				1553808345, -- [1]
			},
			[271] = {
				1553806189, -- [1]
			},
			[299] = {
				1553198748, -- [1]
			},
			[303] = {
				1553806605, -- [1]
				1553807514, -- [2]
				1553808764, -- [3]
			},
			[55] = {
				1552595982, -- [1]
			},
			[315] = {
				1553200532, -- [1]
				1553808036, -- [2]
			},
			[234] = {
				1553196731, -- [1]
				1553199621, -- [2]
			},
			[359] = {
				1553201433, -- [1]
			},
			[62] = {
				1553198336, -- [1]
			},
			[371] = {
				1552597451, -- [1]
			},
			[65] = {
				1553198336, -- [1]
			},
			[264] = {
				1553199100, -- [1]
				1553199100, -- [2]
			},
			[272] = {
				1553806189, -- [1]
				1553806189, -- [2]
			},
			[139] = {
				1552596511, -- [1]
			},
			[280] = {
				1552596892, -- [1]
			},
			[296] = {
				1553200073, -- [1]
				1553200073, -- [2]
				1553807514, -- [3]
			},
			[300] = {
				1553806605, -- [1]
			},
			[77] = {
				1553200873, -- [1]
			},
			[312] = {
				1553201433, -- [1]
			},
			[316] = {
				1553808036, -- [1]
			},
			[83] = {
				1552595982, -- [1]
			},
			[181] = {
				1553200073, -- [1]
			},
			[183] = {
				1552596275, -- [1]
				1552596275, -- [2]
				1553808345, -- [3]
			},
			[185] = {
				1553200532, -- [1]
			},
			[189] = {
				1553196731, -- [1]
				1553806189, -- [2]
			},
			[191] = {
				1553199100, -- [1]
				1553201433, -- [2]
				1553806605, -- [3]
			},
			[193] = {
				1553197066, -- [1]
			},
			[195] = {
				1553808345, -- [1]
			},
			[265] = {
				1553196731, -- [1]
				1553196731, -- [2]
				1553196731, -- [3]
			},
			[304] = {
				1553808764, -- [1]
			},
			[101] = {
				1553200873, -- [1]
			},
			[197] = {
				1553808764, -- [1]
			},
			[103] = {
				1553200873, -- [1]
			},
			[104] = {
				1553199100, -- [1]
			},
			[105] = {
				1553200873, -- [1]
			},
			[257] = {
				1553808036, -- [1]
			},
			[213] = {
				1553201433, -- [1]
			},
			[301] = {
				1553198748, -- [1]
				1553807514, -- [2]
			},
			[246] = {
				1553807514, -- [1]
			},
			[219] = {
				1553197066, -- [1]
			},
			[142] = {
				1552596511, -- [1]
			},
			[317] = {
				1553200073, -- [1]
			},
			[46] = {
				1553196381, -- [1]
				1553200671, -- [2]
			},
			[325] = {
				1553199621, -- [1]
			},
			[54] = {
				1552595982, -- [1]
				1553198336, -- [2]
			},
			[127] = {
				1552596511, -- [1]
			},
			[21] = {
				1553196381, -- [1]
				1553197066, -- [2]
				1553198336, -- [3]
			},
			[59] = {
				1553198336, -- [1]
			},
			[345] = {
				1552597451, -- [1]
			},
			[30] = {
				1552596511, -- [1]
			},
			[141] = {
				1552596511, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234314"] = {
		["deaths"] = {
			[488] = {
				1549407854, -- [1]
				1549407854, -- [2]
			},
			[496] = {
				1549231000, -- [1]
			},
			[500] = {
				1549228674, -- [1]
			},
			[258] = {
				1549231000, -- [1]
			},
			[520] = {
				1549228674, -- [1]
				1549228674, -- [2]
			},
			[270] = {
				1549409133, -- [1]
			},
			[274] = {
				1549231893, -- [1]
			},
			[409] = {
				1549217666, -- [1]
			},
			[39] = {
				1549229769, -- [1]
			},
			[10] = {
				1549229769, -- [1]
			},
			[441] = {
				1549231000, -- [1]
			},
			[481] = {
				1549413761, -- [1]
			},
			[186] = {
				1549412048, -- [1]
			},
			[12] = {
				1549411261, -- [1]
			},
			[259] = {
				1549231000, -- [1]
			},
			[522] = {
				1549409853, -- [1]
			},
			[271] = {
				1549218823, -- [1]
			},
			[554] = {
				1549407046, -- [1]
			},
			[206] = {
				1549385850, -- [1]
			},
			[570] = {
				1549407046, -- [1]
			},
			[210] = {
				1549409133, -- [1]
			},
			[434] = {
				1549229473, -- [1]
			},
			[442] = {
				1549229473, -- [1]
				1549231000, -- [2]
			},
			[319] = {
				1549384171, -- [1]
			},
			[327] = {
				1549231893, -- [1]
			},
			[547] = {
				1549413761, -- [1]
			},
			[498] = {
				1549228674, -- [1]
				1549228674, -- [2]
			},
			[16] = {
				1549411261, -- [1]
				1549411261, -- [2]
			},
			[506] = {
				1549407854, -- [1]
			},
			[131] = {
				1549385850, -- [1]
			},
			[391] = {
				1549217666, -- [1]
			},
			[540] = {
				1549218823, -- [1]
			},
			[204] = {
				1549385850, -- [1]
			},
			[18] = {
				1549411261, -- [1]
			},
			[249] = {
				1549412995, -- [1]
			},
			[145] = {
				1549384171, -- [1]
			},
			[345] = {
				1549409853, -- [1]
				1549409853, -- [2]
			},
			[36] = {
				1549229473, -- [1]
			},
			[560] = {
				1549412048, -- [1]
			},
			[130] = {
				1549412048, -- [1]
			},
			[5] = {
				1549229769, -- [1]
			},
			[312] = {
				1549384171, -- [1]
			},
			[329] = {
				1549408360, -- [1]
				1549408360, -- [2]
			},
			[447] = {
				1549229473, -- [1]
			},
			[451] = {
				1549229473, -- [1]
			},
			[325] = {
				1549231893, -- [1]
			},
			[84] = {
				1549410671, -- [1]
			},
			[85] = {
				1549410671, -- [1]
				1549410671, -- [2]
			},
			[13] = {
				1549411261, -- [1]
			},
			[471] = {
				1549384991, -- [1]
			},
			[475] = {
				1549384991, -- [1]
			},
			[514] = {
				1549407854, -- [1]
			},
			[483] = {
				1549384991, -- [1]
			},
			[23] = {
				1549229769, -- [1]
			},
			[35] = {
				1549410671, -- [1]
			},
			[263] = {
				1549412048, -- [1]
				1549412995, -- [2]
			},
			[200] = {
				1549385850, -- [1]
			},
			[24] = {
				1549229769, -- [1]
			},
			[269] = {
				1549409133, -- [1]
			},
			[297] = {
				1549384991, -- [1]
			},
			[550] = {
				1549409133, -- [1]
				1549413761, -- [2]
			},
			[392] = {
				1549217666, -- [1]
			},
			[199] = {
				1549385850, -- [1]
			},
			[273] = {
				1549407046, -- [1]
			},
			[277] = {
				1549407046, -- [1]
			},
			[572] = {
				1549409133, -- [1]
				1549412995, -- [2]
			},
			[315] = {
				1549408360, -- [1]
				1549408360, -- [2]
			},
			[416] = {
				1549231893, -- [1]
			},
			[106] = {
				1549412995, -- [1]
			},
			[107] = {
				1549384991, -- [1]
			},
			[538] = {
				1549412048, -- [1]
			},
			[524] = {
				1549407854, -- [1]
			},
			[309] = {
				1549384171, -- [1]
			},
			[81] = {
				1549410671, -- [1]
			},
			[223] = {
				1549408360, -- [1]
			},
			[321] = {
				1549384171, -- [1]
			},
			[227] = {
				1549407046, -- [1]
			},
			[229] = {
				1549231893, -- [1]
			},
			[157] = {
				1549412995, -- [1]
			},
			[543] = {
				1549218823, -- [1]
				1549218823, -- [2]
			},
			[454] = {
				1549218823, -- [1]
			},
			[119] = {
				1549413761, -- [1]
			},
			[476] = {
				1549409853, -- [1]
				1549409853, -- [2]
			},
			[544] = {
				1549413761, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234214"] = {
		["deaths"] = {
			[154] = {
				1551465049, -- [1]
			},
			[54] = {
				1551465049, -- [1]
			},
			[186] = {
				1551464694, -- [1]
			},
			[60] = {
				1551465049, -- [1]
			},
			[62] = {
				1551464694, -- [1]
			},
			[98] = {
				1551464694, -- [1]
			},
			[189] = {
				1551465049, -- [1]
			},
			[57] = {
				1551465049, -- [1]
			},
			[97] = {
				1551464694, -- [1]
			},
			[172] = {
				1551464694, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
}
