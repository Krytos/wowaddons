
HeroRotationCharDB = {
	["GUISettings"] = {
	},
	["Toggles"] = {
		true, -- [1]
		true, -- [2]
		true, -- [3]
	},
}
