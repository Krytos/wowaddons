
PlaterDBChr = {
	["first_run2"] = {
		["Player-3686-0699EB7D"] = true,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3686-0699EB7D"] = true,
	},
	["spellRangeCheck"] = {
		[255] = "Serpent Sting",
		[254] = "Aimed Shot",
		[253] = "Cobra Shot",
	},
	["debuffsBanned"] = {
	},
}
