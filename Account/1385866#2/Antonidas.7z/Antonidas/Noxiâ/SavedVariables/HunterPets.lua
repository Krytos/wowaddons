
HunterPetsSettings = {
	["showZoneTamableText"] = true,
	["autoShowBrowser"] = true,
}
