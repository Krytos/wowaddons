
PlaterDBChr = {
	["first_run2"] = {
		["Player-3686-06A01A22"] = true,
	},
	["buffsBanned"] = {
	},
	["first_run3"] = {
		["Player-3686-06A01A22"] = true,
	},
	["spellRangeCheck"] = {
		[260] = "Pistol Shot",
		[261] = "Shuriken Toss",
		[259] = "Poisoned Knife",
	},
	["debuffsBanned"] = {
	},
}
