
EasyScrap_IgnoreList = {
	["addonVersion"] = 19,
}
