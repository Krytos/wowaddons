
DeathGraphsDBDeaths = {
	["233414"] = {
		["hash"] = "233414",
		["type"] = "deaths",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Mekkatorque",
			["encounter"] = "Mekkatorque",
			["ej_instance_id"] = 1176,
			["diff"] = 14,
		},
		["player_db"] = {
			["Alextradza-Illidan"] = {
				["name"] = "Alextradza-Illidan",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Kischu"] = {
				["name"] = "Kischu",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Which"] = {
				["name"] = "Which",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Angerfist-Kil'jaeden"] = {
				["name"] = "Angerfist-Kil'jaeden",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Varyuna"] = {
				["name"] = "Varyuna",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Noxiâ"] = {
				["name"] = "Noxiâ",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Hexylady-Area52"] = {
				["name"] = "Hexylady-Area52",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Miren-Madmortem"] = {
				["name"] = "Miren-Madmortem",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Demoniq"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Demoniq",
			},
			["Twílìght-Silvermoon"] = {
				["name"] = "Twílìght-Silvermoon",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["233315"] = {
		["hash"] = "233315",
		["type"] = "deaths",
		["name"] = "Grong the Revenant",
		["id"] = 2333,
		["player_db"] = {
			["Nyrph-Dalaran"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nyrph-Dalaran",
			},
			["Ashurbanipal-Silvermoon"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ashurbanipal-Silvermoon",
			},
			["Kiratai-Kilrogg"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Kiratai-Kilrogg",
				["overall"] = {
				},
			},
			["Airwalk"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Airwalk",
			},
			["Lantniuu-Kilrogg"] = {
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
				["name"] = "Lantniuu-Kilrogg",
				["overall"] = {
				},
			},
			["Noothunter-Silvermoon"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Noothunter-Silvermoon",
			},
			["Xilenia-Hyjal"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Xilenia-Hyjal",
			},
			["Maracuja-Madmortem"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Maracuja-Madmortem",
			},
			["Vuduu"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Vuduu",
			},
			["Mortako-DunModr"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Mortako-DunModr",
			},
			["Pachelbel-EmeraldDream"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Pachelbel-EmeraldDream",
				["overall"] = {
				},
			},
			["Choke-Zul'jin"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Choke-Zul'jin",
			},
			["Silberblick-DieewigeWacht"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Silberblick-DieewigeWacht",
			},
			["Неподмытый-Гордунни"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Неподмытый-Гордунни",
			},
			["Skratchit-Runetotem"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Skratchit-Runetotem",
				["overall"] = {
				},
			},
			["Zhelev-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "MONK",
				["name"] = "Zhelev-Silvermoon",
				["overall"] = {
				},
			},
			["Allister-Shen'dralar"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Allister-Shen'dralar",
			},
			["Xemena-Aggramar"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Xemena-Aggramar",
				["overall"] = {
				},
			},
			["Mageawe-Ravencrest"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Mageawe-Ravencrest",
			},
			["Ginèva"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ginèva",
			},
			["Tidemistress-Silvermoon"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tidemistress-Silvermoon",
			},
			["Procter-Anetheron"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Procter-Anetheron",
			},
			["Cathrina-Blackrock"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Cathrina-Blackrock",
			},
			["Ñursê-Aegwynn"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ñursê-Aegwynn",
			},
			["Demoniq"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Demoniq",
				["overall"] = {
				},
			},
			["Trona-Blackmoore"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Trona-Blackmoore",
			},
			["Wâr-Runetotem"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Wâr-Runetotem",
				["overall"] = {
				},
			},
			["Айригном-Гордунни"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Айригном-Гордунни",
			},
			["Haylîe-DunMorogh"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Haylîe-DunMorogh",
			},
			["Loayna-Aegwynn"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Loayna-Aegwynn",
			},
			["Evillyy-DunModr"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Evillyy-DunModr",
			},
			["Dragibos-Ravencrest"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dragibos-Ravencrest",
			},
			["Shízzoah-Mal'Ganis"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Shízzoah-Mal'Ganis",
			},
			["Jpxx-Aegwynn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Jpxx-Aegwynn",
			},
			["Chrille-Todeswache"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Chrille-Todeswache",
				["overall"] = {
				},
			},
			["Callier-Kilrogg"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Callier-Kilrogg",
				["overall"] = {
				},
			},
			["Wahookla-Kilrogg"] = {
				["deaths"] = {
				},
				["class"] = "ROGUE",
				["name"] = "Wahookla-Kilrogg",
				["overall"] = {
				},
			},
			["Nîlüfer-Aman'thul"] = {
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nîlüfer-Aman'thul",
			},
			["Blÿnk-LosErrantes"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Blÿnk-LosErrantes",
			},
			["Disorders-Zul'jin"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Disorders-Zul'jin",
			},
			["Cmalu-Dragonblight"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Cmalu-Dragonblight",
				["overall"] = {
				},
			},
			["Roìdrage-Ravencrest"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Roìdrage-Ravencrest",
			},
		},
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2284,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Grong the Revenant",
			["diff"] = 15,
			["ej_instance_id"] = 1176,
			["encounter"] = "Grong the Revenant",
		},
		["diff"] = 15,
	},
	["233415"] = {
		["hash"] = "233415",
		["type"] = "deaths",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Mekkatorque",
			["encounter"] = "Mekkatorque",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Salanâ"] = {
				["name"] = "Salanâ",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["name"] = "Coffinlove",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["name"] = "Ðaisuke",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["name"] = "Supersunny",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Soely"] = {
				["name"] = "Soely",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Lyoli"] = {
				["name"] = "Lyoli",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["233715"] = {
		["hash"] = "233715",
		["type"] = "deaths",
		["name"] = "Stormwall Blockade",
		["id"] = 2337,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 8,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Stormwall Blockade",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Stormwall Blockade",
			["diff"] = 15,
			["id"] = 2280,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Yanaizu"] = {
				["name"] = "Yanaizu",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Daddysenpai"] = {
				["name"] = "Daddysenpai",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Tyrellan"] = {
				["name"] = "Tyrellan",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["name"] = "Ðaisuke",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["234216"] = {
		["hash"] = "234216",
		["type"] = "deaths",
		["name"] = "Opulence",
		["id"] = 2342,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["name"] = "Opulence",
			["diff"] = 16,
			["encounter"] = "Opulence",
			["ej_instance_id"] = 1176,
		},
		["player_db"] = {
			["Aspern"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Aspern",
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Isery"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Isery",
			},
			["Alleycut"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alleycut",
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
			["Ðaisuke"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ðaisuke",
			},
			["Inánná"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Inánná",
			},
			["Dovomir"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dovomir",
			},
			["Almîna"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Almîna",
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Hornpubmonk"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hornpubmonk",
			},
			["Neferupitou"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Neferupitou",
			},
			["Tyrellan"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Tyrellan",
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Noxiâ"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Noxiâ",
			},
			["Andromaché"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Andromaché",
			},
			["Salanâ"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Salanâ",
			},
			["Qyix"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Qyix",
			},
			["Nelwyn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nelwyn",
			},
		},
		["diff"] = 16,
	},
	["234215"] = {
		["hash"] = "234215",
		["type"] = "deaths",
		["name"] = "Opulence",
		["id"] = 2342,
		["player_db"] = {
			["Nyrph-Dalaran"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nyrph-Dalaran",
			},
			["Nízn-Frostmane"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nízn-Frostmane",
			},
			["Ashurbanipal-Silvermoon"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ashurbanipal-Silvermoon",
			},
			["Asanty-Area52"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Asanty-Area52",
			},
			["Xilenia-Hyjal"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Xilenia-Hyjal",
			},
			["Cannach-ArgentDawn"] = {
				["name"] = "Cannach-ArgentDawn",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Maracuja-Madmortem"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Maracuja-Madmortem",
			},
			["Preastor-EmeraldDream"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Preastor-EmeraldDream",
				["overall"] = {
				},
			},
			["Dalorania-ArgentDawn"] = {
				["name"] = "Dalorania-ArgentDawn",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Mikase-Ravencrest"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Mikase-Ravencrest",
			},
			["Silberblick-DieewigeWacht"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Silberblick-DieewigeWacht",
			},
			["Drïzzt-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "HUNTER",
				["name"] = "Drïzzt-Silvermoon",
				["overall"] = {
				},
			},
			["Srinala"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Srinala",
			},
			["Holydench-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "PALADIN",
				["name"] = "Holydench-Silvermoon",
				["overall"] = {
				},
			},
			["Lesarot-Alleria"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Lesarot-Alleria",
			},
			["Evillyy-DunModr"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Evillyy-DunModr",
			},
			["Badtouch-ArgentDawn"] = {
				["name"] = "Badtouch-ArgentDawn",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Megawarrior-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "WARRIOR",
				["name"] = "Megawarrior-Silvermoon",
				["overall"] = {
				},
			},
			["Cathrina-Blackrock"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Cathrina-Blackrock",
			},
			["Demoniq"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Demoniq",
			},
			["Iwalyah-ArgentDawn"] = {
				["name"] = "Iwalyah-ArgentDawn",
				["class"] = "MONK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Argento-BurningLegion"] = {
				["name"] = "Argento-BurningLegion",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Bogoff-Quel'Thalas"] = {
				["deaths"] = {
				},
				["class"] = "PRIEST",
				["name"] = "Bogoff-Quel'Thalas",
				["overall"] = {
				},
			},
			["Sharynia-ArgentDawn"] = {
				["name"] = "Sharynia-ArgentDawn",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Loayna-Aegwynn"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Loayna-Aegwynn",
			},
			["Ilduce-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
				["name"] = "Ilduce-Silvermoon",
				["overall"] = {
				},
			},
			["Lÿnthia-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "WARLOCK",
				["name"] = "Lÿnthia-Silvermoon",
				["overall"] = {
				},
			},
			["Frezkoe-Silvermoon"] = {
				["deaths"] = {
				},
				["class"] = "SHAMAN",
				["name"] = "Frezkoe-Silvermoon",
				["overall"] = {
				},
			},
			["Zimarakos-Lightbringer"] = {
				["deaths"] = {
				},
				["class"] = "MAGE",
				["name"] = "Zimarakos-Lightbringer",
				["overall"] = {
				},
			},
			["Boomytunes-Quel'Thalas"] = {
				["deaths"] = {
				},
				["class"] = "DRUID",
				["name"] = "Boomytunes-Quel'Thalas",
				["overall"] = {
				},
			},
			["Jpxx-Aegwynn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Jpxx-Aegwynn",
			},
			["Deldhindes-Silvermoon"] = {
				["name"] = "Deldhindes-Silvermoon",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Noxiâ"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Noxiâ",
			},
			["Traumurlaub"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Traumurlaub",
			},
			["Hølyisbetter-Ravencrest"] = {
				["name"] = "Hølyisbetter-Ravencrest",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Arthemar-Ravencrest"] = {
				["name"] = "Arthemar-Ravencrest",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Creimos-ArgentDawn"] = {
				["name"] = "Creimos-ArgentDawn",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["diff"] = 15,
			["ej_instance_id"] = 1176,
			["encounter"] = "Opulence",
		},
		["diff"] = 15,
	},
	["233015"] = {
		["hash"] = "233015",
		["type"] = "deaths",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["encounter"] = "Conclave of the Chosen",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["name"] = "Daddysenpai",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Thareel"] = {
				["name"] = "Thareel",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Djevelen"] = {
				["name"] = "Djevelen",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Colwolf"] = {
				["name"] = "Colwolf",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Salanâ"] = {
				["name"] = "Salanâ",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yanaizu"] = {
				["name"] = "Yanaizu",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Inánná"] = {
				["name"] = "Inánná",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Demoniq"] = {
				["name"] = "Demoniq",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Fynnea"] = {
				["name"] = "Fynnea",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["name"] = "Härridk",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ahrela"] = {
				["name"] = "Ahrela",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Yomou"] = {
				["name"] = "Yomou",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Levante"] = {
				["name"] = "Levante",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Coffinlove"] = {
				["name"] = "Coffinlove",
				["class"] = "DEATHKNIGHT",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Shadey"] = {
				["name"] = "Shadey",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Applemary-Outland"] = {
				["name"] = "Applemary-Outland",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Noxiâ"] = {
				["name"] = "Noxiâ",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Almîna"] = {
				["name"] = "Almîna",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Aspern"] = {
				["name"] = "Aspern",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Qyix"] = {
				["name"] = "Qyix",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Lyoli"] = {
				["name"] = "Lyoli",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["233316"] = {
		["hash"] = "233316",
		["type"] = "deaths",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2265,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Champion of the Light",
		},
		["player_db"] = {
			["Dêathwing"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dêathwing",
			},
			["Darkthor"] = {
				["name"] = "Darkthor",
				["class"] = "PALADIN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Laki"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laki",
			},
			["Isery"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Isery",
			},
			["Seraphid"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Seraphid",
			},
			["Soely"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Soely",
			},
			["Catyo"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Catyo",
			},
			["Ðaisuke"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ðaisuke",
			},
			["Ravellá"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ravellá",
			},
			["Supersunny"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Supersunny",
			},
			["Härridot"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Härridot",
			},
			["Waybrighter"] = {
				["name"] = "Waybrighter",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Dwâlîm"] = {
				["class"] = "SHAMAN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dwâlîm",
			},
			["Laky"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Laky",
			},
			["Hyôryn"] = {
				["class"] = "MAGE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hyôryn",
			},
			["Andromaché"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Andromaché",
			},
			["Nelwyn"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nelwyn",
			},
			["Joyleen"] = {
				["name"] = "Joyleen",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Alleycut"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Alleycut",
			},
			["Kalissta"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Kalissta",
			},
			["Metó"] = {
				["class"] = "WARLOCK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Metó",
			},
			["Senpaisgirl"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Senpaisgirl",
			},
			["Demoniq"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Demoniq",
			},
			["Salanâ"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Salanâ",
			},
			["Daddysenpai"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Daddysenpai",
			},
			["Härridk"] = {
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Härridk",
			},
			["Nubz"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nubz",
			},
			["Dovomir"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Dovomir",
			},
			["Neferupitou"] = {
				["class"] = "HUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Neferupitou",
			},
			["Takoja"] = {
				["name"] = "Takoja",
				["class"] = "SHAMAN",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Thorgrond"] = {
				["name"] = "Thorgrond",
				["class"] = "WARRIOR",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Ankinia"] = {
				["class"] = "PRIEST",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Ankinia",
			},
			["Hornpubmonk"] = {
				["class"] = "MONK",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Hornpubmonk",
			},
			["Inánná"] = {
				["class"] = "PALADIN",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Inánná",
			},
			["Snero"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Snero",
			},
			["Noxiâ"] = {
				["class"] = "ROGUE",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Noxiâ",
			},
			["Breakerîna"] = {
				["class"] = "WARRIOR",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Breakerîna",
			},
			["Deanyris"] = {
				["name"] = "Deanyris",
				["class"] = "DRUID",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Nuitaria"] = {
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Nuitaria",
			},
			["Woowa"] = {
				["class"] = "DRUID",
				["deaths"] = {
				},
				["overall"] = {
				},
				["name"] = "Woowa",
			},
		},
		["diff"] = 16,
	},
	["233514"] = {
		["hash"] = "233514",
		["type"] = "deaths",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "King Rastakhan",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["diff"] = 14,
			["id"] = 2272,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Varyuna"] = {
				["name"] = "Varyuna",
				["class"] = "MAGE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Azlak-DunMorogh"] = {
				["name"] = "Azlak-DunMorogh",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Alextradza-Illidan"] = {
				["name"] = "Alextradza-Illidan",
				["class"] = "HUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Dweesel-Krag'jin"] = {
				["name"] = "Dweesel-Krag'jin",
				["class"] = "ROGUE",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
			["Dazul-Proudmoore"] = {
				["name"] = "Dazul-Proudmoore",
				["class"] = "DEMONHUNTER",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["233014"] = {
		["hash"] = "233014",
		["type"] = "deaths",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["encounter"] = "Conclave of the Chosen",
			["ej_instance_id"] = 1176,
			["diff"] = 14,
		},
		["player_db"] = {
			["Hexylady-Area52"] = {
				["name"] = "Hexylady-Area52",
				["class"] = "WARLOCK",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
	["233515"] = {
		["hash"] = "233515",
		["type"] = "deaths",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "King Rastakhan",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["diff"] = 15,
			["id"] = 2272,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
		},
	},
	["234214"] = {
		["hash"] = "234214",
		["type"] = "deaths",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Opulence",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["diff"] = 14,
			["id"] = 2271,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Shízzoah-Mal'Ganis"] = {
				["name"] = "Shízzoah-Mal'Ganis",
				["class"] = "PRIEST",
				["overall"] = {
				},
				["deaths"] = {
				},
			},
		},
	},
}
DeathGraphsDBEndurance = {
	["233414"] = {
		["hash"] = "233414",
		["type"] = "endurance",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Mekkatorque",
			["encounter"] = "Mekkatorque",
			["ej_instance_id"] = 1176,
			["diff"] = 14,
		},
		["player_db"] = {
			["Demaera"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Alextradza-Illidan"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						59.4340000000084, -- [2]
						"Buster Cannon |cFFFF333318,776|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Melíkaye-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Kwittz-DieAldor"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Kòne"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Hexylady-Area52"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Angerfist-Kil'jaeden"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Kischu"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						182.786999999953, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333351,318|r", -- [3]
					}, -- [1]
				},
				["class"] = "MONK",
			},
			["Ipetty"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Eelon-Thrall"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Naggl-Norgannon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Dweesel-Krag'jin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Varyuna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Azlak-DunMorogh"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Twílìght-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Miren-Madmortem"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Which"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						186.027000000002, -- [2]
						"Anti-Tampering Shock (DoT) |cFFFF333310,836|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
		},
	},
	["233315"] = {
		["hash"] = "233315",
		["type"] = "endurance",
		["name"] = "Grong the Revenant",
		["id"] = 2333,
		["player_db"] = {
			["Nyrph-Dalaran"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						210.956000000006, -- [2]
						"Bestial Smash |cFFFF3333112,255|r", -- [3]
					}, -- [1]
				},
			},
			["Nízn-Frostmane"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Ashurbanipal-Silvermoon"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						2, -- [1]
						182.685999999987, -- [2]
						"Bestial Smash |cFFFF3333396,790|r", -- [3]
					}, -- [1]
				},
			},
			["Kiratai-Kilrogg"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Airwalk"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Lantniuu-Kilrogg"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Noothunter-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Xilenia-Hyjal"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Ifrit-Shen'dralar"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Vuduu"] = {
				["encounters"] = 3,
				["points"] = 280,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						62.7590000000782, -- [2]
						"Chi-Ji's Song |cFFFF33331,741|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						56.7079999999842, -- [2]
						"Chi-Ji's Song |cFFFF33331,740|r", -- [3]
					}, -- [2]
				},
			},
			["Mikase-Ravencrest"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Mortako-DunModr"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						122.718999999925, -- [2]
						"Rending Bite |cFFFF333330,578|r", -- [3]
					}, -- [1]
				},
			},
			["Aquaknarré-Tirion"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Pachelbel-EmeraldDream"] = {
				["encounters"] = 2,
				["points"] = 180,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						1, -- [1]
						100.722999999998, -- [2]
						"Death Knell |cFFFF333365,731|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						72.0310000000172, -- [2]
						"Chill of Death (DoT) |cFFFF333321,957|r", -- [3]
					}, -- [2]
				},
			},
			["Choke-Zul'jin"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Maracuja-Madmortem"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						110.480000000098, -- [2]
						"Deathly Echo |cFFFF333392,351|r", -- [3]
					}, -- [1]
				},
			},
			["Disorders-Zul'jin"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Dragibos-Ravencrest"] = {
				["encounters"] = 3,
				["points"] = 280,
				["class"] = "DRUID",
				["deaths"] = {
					{
						3, -- [1]
						61.3340000000317, -- [2]
						"Unleashed Ember |cFFFF333344,320|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						63.5159999999451, -- [2]
						"Unleashed Ember |cFFFF33331,157|r", -- [3]
					}, -- [2]
				},
			},
			["Laints-Kilrogg"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Silberblick-DieewigeWacht"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						110.480000000098, -- [2]
						"Deathly Echo |cFFFF333399,444|r", -- [3]
					}, -- [1]
				},
			},
			["Неподмытый-Гордунни"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						1, -- [1]
						135.668999999994, -- [2]
						"Melee |cFFFF3333119,586|r", -- [3]
					}, -- [1]
				},
			},
			["Skratchit-Runetotem"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Zhelev-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Ñursê-Aegwynn"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Allister-Shen'dralar"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Haylîe-DunMorogh"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						2, -- [1]
						138.731000000029, -- [2]
						"Melee |cFFFF3333122,602|r", -- [3]
					}, -- [1]
				},
			},
			["Jpxx-Aegwynn"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Wahookla-Kilrogg"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Mageawe-Ravencrest"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Srinala"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Procter-Anetheron"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Lesarot-Alleria"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Ginèva"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						6, -- [1]
						124.98199999996, -- [2]
						"Environment (Falling) |cFFFF3333236,973|r", -- [3]
					}, -- [1]
				},
			},
			["Tidemistress-Silvermoon"] = {
				["encounters"] = 3,
				["points"] = 290,
				["class"] = "DRUID",
				["deaths"] = {
					{
						5, -- [1]
						64.8299999999581, -- [2]
						"Beam (DoT) |cFFFF333341,009|r", -- [3]
					}, -- [1]
				},
			},
			["Evillyy-DunModr"] = {
				["encounters"] = 4,
				["points"] = 390,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						134.187000000034, -- [2]
						"Wave of Light (DoT) |cFFFF333316,334|r", -- [3]
					}, -- [1]
				},
			},
			["Trona-Blackmoore"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						3, -- [1]
						57.1680000000633, -- [2]
						"Beam (DoT) |cFFFF333317,846|r", -- [3]
					}, -- [1]
				},
			},
			["Kíván"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Айригном-Гордунни"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						6, -- [1]
						184.077000000048, -- [2]
						"Environment (Falling) |cFFFF3333194,040|r", -- [3]
					}, -- [1]
				},
			},
			["Cathrina-Blackrock"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Xerowinger-Malfurion"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Demoniq"] = {
				["encounters"] = 8,
				["points"] = 780,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						44.1350000000093, -- [2]
						"Deathly Slam |cFFFF333336,171|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						137.701000000001, -- [2]
						"Reckoning |cFFFF333317,266|r", -- [3]
					}, -- [2]
				},
			},
			["Minsesa-Nethersturm"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Wâr-Runetotem"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Loayna-Aegwynn"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Blÿnk-LosErrantes"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Yllidan-Nemesis"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Nîlüfer-Aman'thul"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Suzycortez-Dalaran"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Shízzoah-Mal'Ganis"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Raidskil-Hyjal"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Chrille-Todeswache"] = {
				["encounters"] = 2,
				["points"] = 180,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						1, -- [1]
						100.774999999965, -- [2]
						"Death Knell |cFFFF333378,930|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						72.0690000000177, -- [2]
						"Death Knell |cFFFF333357,465|r", -- [3]
					}, -- [2]
				},
			},
			["Callier-Kilrogg"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						2, -- [1]
						71.5340000000433, -- [2]
						"Chill of Death (DoT) |cFFFF333321,951|r", -- [3]
					}, -- [1]
				},
			},
			["Xemena-Aggramar"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Noxiâ"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Clêaner-Alexstrasza"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Minnau-Dalaran"] = {
				["encounters"] = 4,
				["points"] = 400,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Cmalu-Dragonblight"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Roìdrage-Ravencrest"] = {
				["encounters"] = 4,
				["points"] = 370,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						131.820999999996, -- [2]
						"Wave of Light (DoT) |cFFFF333317,713|r", -- [3]
					}, -- [1]
					{
						6, -- [1]
						128.521000000066, -- [2]
						"Flash |cFFFF33337,273|r", -- [3]
					}, -- [2]
					{
						1, -- [1]
						48.51800000004, -- [2]
						"Deathly Echo |cFFFF333385,593|r", -- [3]
					}, -- [3]
				},
			},
		},
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2284,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Grong the Revenant",
			["diff"] = 15,
			["ej_instance_id"] = 1176,
			["encounter"] = "Grong the Revenant",
		},
		["diff"] = 15,
	},
	["233415"] = {
		["hash"] = "233415",
		["type"] = "endurance",
		["name"] = "Mekkatorque",
		["id"] = 2334,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 7,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2276,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Mekkatorque",
			["encounter"] = "Mekkatorque",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Aspern"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Laki"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Härridk"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Salanâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Metó"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Ðaisuke"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						3, -- [1]
						230.081000000006, -- [2]
						"Crash Down |cFFFF3333162,148|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Inánná"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Ahrela"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Supersunny"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						3, -- [1]
						230.908000000054, -- [2]
						"Melee |cFFFF333337,306|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Tyrellan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						3, -- [1]
						234.274000000034, -- [2]
						"Gigavolt Blast |cFFFF333319,193|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Soely"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Andromaché"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Qyix"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Lyoli"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
		},
	},
	["233715"] = {
		["hash"] = "233715",
		["type"] = "endurance",
		["name"] = "Stormwall Blockade",
		["id"] = 2337,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 8,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Stormwall Blockade",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Stormwall Blockade",
			["diff"] = 15,
			["id"] = 2280,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						138.559999999998, -- [2]
						"Sea Swell |cFFFF333343,597|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARRIOR",
			},
			["Aspern"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Laki"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Härridk"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Salanâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Metó"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Ðaisuke"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						5.08100000000559, -- [2]
						"Roiling Tides (DoT) |cFFFF333333,027|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Inánná"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Ahrela"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Supersunny"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Tyrellan"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						159.43200000003, -- [2]
						"Sea Swell |cFFFF333337,831|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Soely"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Andromaché"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Qyix"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Lyoli"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
		},
	},
	["234216"] = {
		["hash"] = "234216",
		["type"] = "endurance",
		["name"] = "Opulence",
		["id"] = 2342,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["name"] = "Opulence",
			["diff"] = 16,
			["encounter"] = "Opulence",
			["ej_instance_id"] = 1176,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Aspern"] = {
				["encounters"] = 8,
				["points"] = 780,
				["class"] = "MAGE",
				["deaths"] = {
					{
						5, -- [1]
						92.6860000000015, -- [2]
						"Cauterize |cFFFF333314,153|r", -- [3]
					}, -- [1]
					{
						7, -- [1]
						239.036999999997, -- [2]
						"Thief's Bane (DoT) |cFFFF3333289,221|r", -- [3]
					}, -- [2]
				},
			},
			["Andromaché"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						1, -- [1]
						174.584999999999, -- [2]
						"Flames of Punishment |cFFFF3333154,929|r", -- [3]
					}, -- [1]
				},
			},
			["Isery"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Soely"] = {
				["encounters"] = 8,
				["points"] = 770,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						168.142, -- [2]
						"Scorching Ground (DoT) |cFFFF33332,249|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						83.6779999999999, -- [2]
						"Flames of Punishment |cFFFF333393,508|r", -- [3]
					}, -- [2]
					{
						7, -- [1]
						290.396000000001, -- [2]
						"Flames of Punishment |cFFFF333366,928|r", -- [3]
					}, -- [3]
				},
			},
			["Kalissta"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						6, -- [1]
						193.337, -- [2]
						"Volatile Charge |cFFFF333317,116|r", -- [3]
					}, -- [1]
				},
			},
			["Ðaisuke"] = {
				["encounters"] = 8,
				["points"] = 780,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						7, -- [1]
						297.178, -- [2]
						"Crush |cFFFF333321,367|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						159.870000000003, -- [2]
						"Scorching Ground (DoT) |cFFFF333319,737|r", -- [3]
					}, -- [2]
				},
			},
			["Inánná"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						8, -- [1]
						93.8029999999999, -- [2]
						"Flames of Punishment |cFFFF3333143,694|r", -- [3]
					}, -- [1]
				},
			},
			["Dovomir"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						89.0120000000025, -- [2]
						"Scorching Ground (DoT) |cFFFF33334,287|r", -- [3]
					}, -- [1]
				},
			},
			["Almîna"] = {
				["encounters"] = 7,
				["points"] = 690,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						3, -- [1]
						159.779000000002, -- [2]
						"Flames of Punishment |cFFFF333388,326|r", -- [3]
					}, -- [1]
				},
			},
			["Supersunny"] = {
				["encounters"] = 7,
				["points"] = 700,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Samîsu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 8,
				["points"] = 780,
				["class"] = "MONK",
				["deaths"] = {
					{
						5, -- [1]
						259.317999999999, -- [2]
						"Flames of Punishment |cFFFF333389,639|r", -- [3]
					}, -- [1]
					{
						8, -- [1]
						93.8029999999999, -- [2]
						"Flames of Punishment |cFFFF333362,188|r", -- [3]
					}, -- [2]
				},
			},
			["Neferupitou"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						2, -- [1]
						43.5239999999976, -- [2]
						"Crush |cFFFF333328,656|r", -- [3]
					}, -- [1]
				},
			},
			["Tyrellan"] = {
				["encounters"] = 8,
				["points"] = 780,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						173.423999999999, -- [2]
						"Flame Jet (DoT) |cFFFF333365,373|r", -- [3]
					}, -- [1]
					{
						5, -- [1]
						259.317999999999, -- [2]
						"Flames of Punishment |cFFFF333384,909|r", -- [3]
					}, -- [2]
				},
			},
			["Salanâ"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Metó"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						3, -- [1]
						159.218000000001, -- [2]
						"Flames of Punishment |cFFFF3333112,890|r", -- [3]
					}, -- [1]
				},
			},
			["Noxiâ"] = {
				["encounters"] = 8,
				["points"] = 800,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Nelwyn"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "DRUID",
				["deaths"] = {
					{
						6, -- [1]
						238.188999999998, -- [2]
						"Flames of Punishment |cFFFF333391,102|r", -- [3]
					}, -- [1]
				},
			},
			["Alleycut"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						4, -- [1]
						120.604999999996, -- [2]
						"Creeping Blaze (DoT) |cFFFF333319,731|r", -- [3]
					}, -- [1]
				},
			},
			["Qyix"] = {
				["encounters"] = 8,
				["points"] = 790,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						147.512999999999, -- [2]
						"Scorching Ground (DoT) |cFFFF333335,930|r", -- [3]
					}, -- [1]
				},
			},
			["Laki"] = {
				["encounters"] = 9,
				["points"] = 860,
				["class"] = "DRUID",
				["deaths"] = {
					{
						4, -- [1]
						24.2229999999981, -- [2]
						"Flames of Punishment |cFFFF333386,494|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						100.733, -- [2]
						"Flames of Punishment |cFFFF3333123,403|r", -- [3]
					}, -- [2]
					{
						6, -- [1]
						165.358, -- [2]
						"Flames of Punishment |cFFFF333323,734|r", -- [3]
					}, -- [3]
				},
			},
		},
		["diff"] = 16,
	},
	["234215"] = {
		["hash"] = "234215",
		["type"] = "endurance",
		["name"] = "Opulence",
		["id"] = 2342,
		["player_db"] = {
			["Nyrph-Dalaran"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						1, -- [1]
						84.5799999999581, -- [2]
						"Flames of Punishment |cFFFF333350,093|r", -- [3]
					}, -- [1]
				},
			},
			["Aleriisa-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Nízn-Frostmane"] = {
				["encounters"] = 1,
				["points"] = 90,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						84.5799999999581, -- [2]
						"Flames of Punishment |cFFFF333347,326|r", -- [3]
					}, -- [1]
				},
			},
			["Ashurbanipal-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Asanty-Area52"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Beowulfqt-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Zimarakos-Lightbringer"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Cannach-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Maracuja-Madmortem"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						185.530000000028, -- [2]
						"Thief's Bane (DoT) |cFFFF3333212,760|r", -- [3]
					}, -- [1]
				},
			},
			["Preastor-EmeraldDream"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Barrond-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Dalorania-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Mikase-Ravencrest"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Mortako-DunModr"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Tristenne-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Creimos-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						174.510000000002, -- [2]
						"Deadly Hex (DoT) |cFFFF333334,777|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Loathing-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Argento-BurningLegion"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						182.529999999999, -- [2]
						"Deadly Hex (DoT) |cFFFF333357,542|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Silberblick-DieewigeWacht"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Mosses"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Pompidou-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Lÿnthia-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Jpxx-Aegwynn"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DRUID",
				["deaths"] = {
					{
						1, -- [1]
						83.4769999999553, -- [2]
						"Flames of Punishment |cFFFF3333109,864|r", -- [3]
					}, -- [1]
				},
			},
			["Unicornslayr-Sylvanas"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Ilduce-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Ñursê-Aegwynn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Evillyy-DunModr"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Arnlaug-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Sharynia-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						1, -- [1]
						198.258999999998, -- [2]
						"Volatile Charge |cFFFF333393,149|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Drïzzt-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						1, -- [1]
						130.380000000005, -- [2]
						"Volatile Charge |cFFFF333315,108|r", -- [3]
					}, -- [1]
				},
			},
			["Sukai-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Srinala"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PRIEST",
				["deaths"] = {
				},
			},
			["Holydench-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Lesarot-Alleria"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Ginèva"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "HUNTER",
				["deaths"] = {
				},
			},
			["Cathrina-Blackrock"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Sarcastroh-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Badtouch-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Gryphok-DunModr"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Megawarrior-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 180,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						1, -- [1]
						125.155000000028, -- [2]
						"Scorching Ground (DoT) |cFFFF333313,849|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						177.731000000029, -- [2]
						"Volatile Charge |cFFFF333313,023|r", -- [3]
					}, -- [2]
				},
			},
			["Arthemar-Ravencrest"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						81.1869999999981, -- [2]
						"Flames of Punishment |cFFFF3333107,293|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Xilenia-Hyjal"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						186.207000000053, -- [2]
						"Volatile Charge |cFFFF333374,491|r", -- [3]
					}, -- [1]
				},
			},
			["Demoniq"] = {
				["encounters"] = 6,
				["points"] = 590,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						188.57799999998, -- [2]
						"Thief's Bane (DoT) |cFFFF3333199,140|r", -- [3]
					}, -- [1]
				},
			},
			["Iwalyah-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Elderson"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Bogoff-Quel'Thalas"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						124.988000000012, -- [2]
						"Volatile Charge |cFFFF333370,194|r", -- [3]
					}, -- [1]
				},
			},
			["Enerysx-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Hølyisbetter-Ravencrest"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Loayna-Aegwynn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Chowmane-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Frezkoe-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 180,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						91.8180000000284, -- [2]
						"Flames of Punishment |cFFFF333328,069|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						187.457999999984, -- [2]
						"Flames of Punishment |cFFFF3333111,541|r", -- [3]
					}, -- [2]
				},
			},
			["Terobux-CultedelaRivenoire"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "SHAMAN",
				["deaths"] = {
				},
			},
			["Gilbot-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Boomytunes-Quel'Thalas"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Deldhindes-Silvermoon"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						1, -- [1]
						231.769, -- [2]
						"Flames of Punishment |cFFFF333372,169|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						138.748, -- [2]
						"Scorching Ground (DoT) |cFFFF33336,071|r", -- [3]
					}, -- [2]
				},
				["class"] = "HUNTER",
			},
			["Noxiâ"] = {
				["encounters"] = 6,
				["points"] = 600,
				["class"] = "ROGUE",
				["deaths"] = {
				},
			},
			["Traumurlaub"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Minnau-Dalaran"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Helliøn-ArgentDawn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Roìdrage-Ravencrest"] = {
				["encounters"] = 1,
				["points"] = 100,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
		},
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2271,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["diff"] = 15,
			["ej_instance_id"] = 1176,
			["encounter"] = "Opulence",
		},
		["diff"] = 15,
	},
	["233015"] = {
		["hash"] = "233015",
		["type"] = "endurance",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["encounter"] = "Conclave of the Chosen",
			["ej_instance_id"] = 1176,
			["diff"] = 15,
		},
		["player_db"] = {
			["Hlódyn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Daddysenpai"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Raphnik"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Laki"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Härridk"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						3, -- [1]
						172.478000000003, -- [2]
						"Jagged Claws |cFFFF333313,930|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Soely"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Dagonet-DieSilberneHand"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Ðaisuke"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Yanaizu"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Inánná"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						3, -- [1]
						144.514000000025, -- [2]
						"Pa'ku's Wrath |cFFFF333349,747|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Fynnea"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Supersunny"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Eyowín"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Kimchii"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Ganlin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Levante"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Qyix"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Lyoli"] = {
				["encounters"] = 2,
				["points"] = 180,
				["deaths"] = {
					{
						2, -- [1]
						107.38400000002, -- [2]
						"Cry of the Fallen (DoT) |cFFFF33336,352|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						173.337, -- [2]
						"Jagged Claws |cFFFF333338,576|r", -- [3]
					}, -- [2]
				},
				["class"] = "PALADIN",
			},
			["Aspern"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Djevelen"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Colwolf"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						121.995000000003, -- [2]
						"Lacerating Claws |cFFFF333331,127|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Salanâ"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						109.625999999989, -- [2]
						"Melee |cFFFF3333139,660|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Metó"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Demoniq"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						114.356, -- [2]
						"Kimbul's Wrath |cFFFF333324,310|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEMONHUNTER",
			},
			["Priklotis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Coffinlove"] = {
				["encounters"] = 2,
				["points"] = 190,
				["deaths"] = {
					{
						2, -- [1]
						109.082999999984, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33335,020|r", -- [3]
					}, -- [1]
				},
				["class"] = "DEATHKNIGHT",
			},
			["Shadey"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Neferupitou"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Keshera"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Hôlylîght"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Chilldude"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Ahrela"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Almîna"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Applemary-Outland"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Noxiâ"] = {
				["encounters"] = 3,
				["points"] = 290,
				["deaths"] = {
					{
						1, -- [1]
						117.379000000001, -- [2]
						"Bleeding Wounds (DoT) |cFFFF33333,791|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Yomou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Andromaché"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Thareel"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Tyrellan"] = {
				["encounters"] = 2,
				["points"] = 200,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
		},
	},
	["233316"] = {
		["hash"] = "233316",
		["type"] = "endurance",
		["name"] = "Champion of the Light",
		["id"] = 2333,
		["boss_table"] = {
			["diff_string"] = "Mythic",
			["index"] = 1,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2265,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Champion of the Light",
			["diff"] = 16,
			["ej_instance_id"] = 1176,
			["encounter"] = "Champion of the Light",
		},
		["player_db"] = {
			["Dêathwing"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Nelanas"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Takoja"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						143.228999999992, -- [2]
						"Wave of Light (DoT) |cFFFF333328,614|r", -- [3]
					}, -- [1]
				},
				["class"] = "SHAMAN",
			},
			["Laki"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Isery"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "DRUID",
				["deaths"] = {
					{
						3, -- [1]
						170.608, -- [2]
						"Death Knell |cFFFF333368,177|r", -- [3]
					}, -- [1]
				},
			},
			["Seraphid"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "MONK",
				["deaths"] = {
					{
						5, -- [1]
						93.0210000000079, -- [2]
						"Judgment: Reckoning |cFFFF333351,782|r", -- [3]
					}, -- [1]
				},
			},
			["Soely"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						38.5759999999973, -- [2]
						"Burnout |cFFFF333354,202|r", -- [3]
					}, -- [1]
				},
			},
			["Catyo"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Ðaisuke"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						32.6359999999986, -- [2]
						"Divine Mallet |cFFFF333350,057|r", -- [3]
					}, -- [1]
					{
						2, -- [1]
						225.866999999998, -- [2]
						"Ferocious Roar |cFFFF333360,143|r", -- [3]
					}, -- [2]
				},
			},
			["Ravellá"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Hornpubmonk"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "MONK",
				["deaths"] = {
				},
			},
			["Supersunny"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "PALADIN",
				["deaths"] = {
				},
			},
			["Dovomir"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						163.469999999994, -- [2]
						"Deathly Echo |cFFFF3333176,948|r", -- [3]
					}, -- [1]
				},
			},
			["Härridot"] = {
				["encounters"] = 2,
				["points"] = 190,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						4, -- [1]
						76.6429999999819, -- [2]
						"Crusader Strike |cFFFF333392,543|r", -- [3]
					}, -- [1]
				},
			},
			["Kalissta"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						2, -- [1]
						193.288, -- [2]
						"Chill of Death (DoT) |cFFFF333346,124|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						201.964, -- [2]
						"Death Touched |cFFFF333310,371|r", -- [3]
					}, -- [2]
				},
			},
			["Waybrighter"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Tyrellan"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Härridk"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Moonkeep"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Nurior"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Yaroz"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Daddysenpai"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARRIOR",
				["deaths"] = {
				},
			},
			["Musaríl"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Thèróck"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Salanâ"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						3, -- [1]
						170.499000000003, -- [2]
						"Death Touched |cFFFF333310,349|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						201.919999999998, -- [2]
						"Death Touched |cFFFF333310,349|r", -- [3]
					}, -- [2]
				},
			},
			["Marrnie"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Inánná"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PALADIN",
				["deaths"] = {
					{
						2, -- [1]
						31.6539999999986, -- [2]
						"Divine Mallet |cFFFF333348,352|r", -- [3]
					}, -- [1]
				},
			},
			["Dwâlîm"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "SHAMAN",
				["deaths"] = {
					{
						1, -- [1]
						141.206000000006, -- [2]
						"Retribution Wave |cFFFF333311,910|r", -- [3]
					}, -- [1]
				},
			},
			["Falok"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Hyôryn"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "MAGE",
				["deaths"] = {
					{
						3, -- [1]
						144.608000000007, -- [2]
						"Divine Mallet |cFFFF333362,866|r", -- [3]
					}, -- [1]
				},
			},
			["Aspern"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "MAGE",
				["deaths"] = {
				},
			},
			["Andromaché"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "WARLOCK",
				["deaths"] = {
					{
						3, -- [1]
						170.608, -- [2]
						"Death Knell |cFFFF3333123,472|r", -- [3]
					}, -- [1]
				},
			},
			["Nelwyn"] = {
				["encounters"] = 2,
				["points"] = 200,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Joyleen"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						140.474000000002, -- [2]
						"Wave of Light (DoT) |cFFFF333346,810|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Alleycut"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Dextor"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Metó"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "WARLOCK",
				["deaths"] = {
				},
			},
			["Senpaisgirl"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
					{
						1, -- [1]
						133.690000000002, -- [2]
						"Divine Mallet |cFFFF333324,165|r", -- [3]
					}, -- [1]
				},
			},
			["Lathors"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Shydabolo"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Demoniq"] = {
				["encounters"] = 6,
				["points"] = 580,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						85.7949999999837, -- [2]
						"Divine Mallet |cFFFF333345,388|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						136.635000000009, -- [2]
						"Divine Mallet |cFFFF333336,463|r", -- [3]
					}, -- [2]
				},
			},
			["Laky"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						2, -- [1]
						85.6959999999963, -- [2]
						"Divine Mallet |cFFFF333312,732|r", -- [3]
					}, -- [1]
					{
						3, -- [1]
						206.921000000031, -- [2]
						"Judgment: Reckoning |cFFFF3333102,080|r", -- [3]
					}, -- [2]
				},
			},
			["Ulthâr"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Noxiâ"] = {
				["encounters"] = 11,
				["points"] = 1080,
				["class"] = "ROGUE",
				["deaths"] = {
					{
						2, -- [1]
						31.6539999999986, -- [2]
						"Divine Mallet |cFFFF333362,062|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						88.6110000000008, -- [2]
						"Beam (DoT) |cFFFF333382,402|r", -- [3]
					}, -- [2]
				},
			},
			["Nubz"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DRUID",
				["deaths"] = {
				},
			},
			["Darkthor"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						152.303, -- [2]
						"Melee |cFFFF333330,265|r", -- [3]
					}, -- [1]
				},
				["class"] = "PALADIN",
			},
			["Neferupitou"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "HUNTER",
				["deaths"] = {
					{
						4, -- [1]
						202.004000000001, -- [2]
						"Death Knell |cFFFF333373,735|r", -- [3]
					}, -- [1]
				},
			},
			["Balrox"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Thorgrond"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Ankinia"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "PRIEST",
				["deaths"] = {
					{
						5, -- [1]
						164.157000000007, -- [2]
						"Divine Burst |cFFFF333358,563|r", -- [3]
					}, -- [1]
				},
			},
			["Schâuma"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Snero"] = {
				["encounters"] = 5,
				["points"] = 490,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
					{
						4, -- [1]
						91.3879999999772, -- [2]
						"Divine Mallet |cFFFF333313,534|r", -- [3]
					}, -- [1]
				},
			},
			["Butzjamin"] = {
				["encounters"] = 5,
				["points"] = 500,
				["class"] = "DEATHKNIGHT",
				["deaths"] = {
				},
			},
			["Dubstepdora"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Breakerîna"] = {
				["encounters"] = 5,
				["points"] = 480,
				["class"] = "WARRIOR",
				["deaths"] = {
					{
						2, -- [1]
						86.2859999999637, -- [2]
						"Wave of Light (DoT) |cFFFF333320,523|r", -- [3]
					}, -- [1]
					{
						4, -- [1]
						89.695000000007, -- [2]
						"Divine Mallet |cFFFF333350,972|r", -- [3]
					}, -- [2]
				},
			},
			["Deanyris"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Nuitaria"] = {
				["encounters"] = 3,
				["points"] = 300,
				["class"] = "DEMONHUNTER",
				["deaths"] = {
				},
			},
			["Woowa"] = {
				["encounters"] = 10,
				["points"] = 980,
				["class"] = "DRUID",
				["deaths"] = {
					{
						1, -- [1]
						140.130999999994, -- [2]
						"Divine Mallet |cFFFF333334,578|r", -- [3]
					}, -- [1]
					{
						1, -- [1]
						69.3070000000007, -- [2]
						"Unleashed Ember |cFFFF33332,870|r", -- [3]
					}, -- [2]
				},
			},
		},
		["diff"] = 16,
	},
	["233514"] = {
		["hash"] = "233514",
		["type"] = "endurance",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "King Rastakhan",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["diff"] = 14,
			["id"] = 2272,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Demaera"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Drudolein-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Alextradza-Illidan"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						283.962999999989, -- [2]
						"Deathly Withering (DoT) |cFFFF33334,522|r", -- [3]
					}, -- [1]
				},
				["class"] = "HUNTER",
			},
			["Melíkaye-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Kwittz-DieAldor"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Kòne"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Hexylady-Area52"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Angerfist-Kil'jaeden"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Demoniq"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Twílìght-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Ipetty"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Eelon-Thrall"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Shízzoah-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Dazul-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Senitrin-Gilneas"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Varyuna"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						276.534999999974, -- [2]
						"Withering Burst |cFFFF33331,499|r", -- [3]
					}, -- [1]
				},
				["class"] = "MAGE",
			},
			["Dweesel-Krag'jin"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						333.396000000008, -- [2]
						"Scorching Detonation |cFFFF333331,221|r", -- [3]
					}, -- [1]
				},
				["class"] = "ROGUE",
			},
			["Azlak-DunMorogh"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Miren-Madmortem"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Kischu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Which"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
		},
	},
	["233014"] = {
		["hash"] = "233014",
		["type"] = "endurance",
		["name"] = "Conclave of the Chosen",
		["id"] = 2330,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 5,
			["zone"] = "Battle of Dazar'alor",
			["id"] = 2268,
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Conclave of the Chosen",
			["encounter"] = "Conclave of the Chosen",
			["ej_instance_id"] = 1176,
			["diff"] = 14,
		},
		["player_db"] = {
			["Demaera"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Drudolein-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Alextradza-Illidan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Xran"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Kwittz-DieAldor"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Kòne"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Hexylady-Area52"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						2, -- [1]
						213.755999999994, -- [2]
						"Pa'ku's Wrath |cFFFF333341,550|r", -- [3]
					}, -- [1]
				},
				["class"] = "WARLOCK",
			},
			["Angerfist-Kil'jaeden"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Demoniq"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Twílìght-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Eelon-Thrall"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Shízzoah-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Dazul-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Senitrin-Gilneas"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Miren-Madmortem"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Dweesel-Krag'jin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Azlak-DunMorogh"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Kischu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Melíkaye-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Which"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
		},
	},
	["233515"] = {
		["hash"] = "233515",
		["type"] = "endurance",
		["name"] = "King Rastakhan",
		["id"] = 2335,
		["diff"] = 15,
		["boss_table"] = {
			["diff_string"] = "Heroic",
			["index"] = 6,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "King Rastakhan",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "King Rastakhan",
			["diff"] = 15,
			["id"] = 2272,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Daddysenpai"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Aspern"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Laki"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Härridk"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Salanâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Metó"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Ðaisuke"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Yanaizu"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Inánná"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Ahrela"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MAGE",
			},
			["Supersunny"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
			["Neferupitou"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Tyrellan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Coffinlove"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Soely"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Andromaché"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Almîna"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "SHAMAN",
			},
			["Qyix"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Lyoli"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PALADIN",
			},
		},
	},
	["234214"] = {
		["hash"] = "234214",
		["type"] = "endurance",
		["name"] = "Opulence",
		["id"] = 2342,
		["diff"] = 14,
		["boss_table"] = {
			["diff_string"] = "Normal",
			["index"] = 4,
			["zone"] = "Battle of Dazar'alor",
			["encounter"] = "Opulence",
			["mapid"] = 2070,
			["try_number"] = 1,
			["name"] = "Opulence",
			["diff"] = 14,
			["id"] = 2271,
			["ej_instance_id"] = 1176,
			["killed"] = true,
		},
		["player_db"] = {
			["Demaera"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Drudolein-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Alextradza-Illidan"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Melíkaye-Blackmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "PRIEST",
			},
			["Kwittz-DieAldor"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "MONK",
			},
			["Nilicks-Ysera"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "HUNTER",
			},
			["Decayer"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Hexylady-Area52"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
			["Angerfist-Kil'jaeden"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Demoniq"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Twílìght-Silvermoon"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Eelon-Thrall"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEATHKNIGHT",
			},
			["Shízzoah-Mal'Ganis"] = {
				["encounters"] = 1,
				["points"] = 90,
				["deaths"] = {
					{
						1, -- [1]
						320.477000000014, -- [2]
						"Melee |cFFFF3333102,098|r", -- [3]
					}, -- [1]
				},
				["class"] = "PRIEST",
			},
			["Dazul-Proudmoore"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DEMONHUNTER",
			},
			["Which"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARRIOR",
			},
			["Dweesel-Krag'jin"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Noxiâ"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Miren-Madmortem"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Idde-Azshara"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "DRUID",
			},
			["Quoos-Malygos"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "ROGUE",
			},
			["Twenty-Aegwynn"] = {
				["encounters"] = 1,
				["points"] = 100,
				["deaths"] = {
				},
				["class"] = "WARLOCK",
			},
		},
	},
}
DeathGraphsDBCurrent = {
	{
		["deaths"] = {
			{
				["maxhealth"] = 230560,
				["timeofdeath"] = 93.8029999999999,
				["name"] = "Hornpubmonk",
				["events"] = {
					{
						2, -- [1]
						20484, -- [2]
						1, -- [3]
						1553802031.272, -- [4]
						0, -- [5]
						"Isery", -- [6]
					}, -- [1]
					{
						false, -- [1]
						157503, -- [2]
						12576, -- [3]
						1553802007.782, -- [4]
						234494, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						1064, -- [2]
						8328, -- [3]
						1553802007.883, -- [4]
						242822, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						false, -- [1]
						191840, -- [2]
						6461, -- [3]
						1553802008.112, -- [4]
						249283, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						false, -- [1]
						191840, -- [2]
						512, -- [3]
						1553802008.591, -- [4]
						249795, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						145110, -- [2]
						7651, -- [3]
						1553802008.625, -- [4]
						253600, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						119611, -- [2]
						4771, -- [3]
						1553802009.477, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						191840, -- [2]
						6430, -- [3]
						1553802010.345, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						509, -- [3]
						1553802010.486, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						191840, -- [2]
						508, -- [3]
						1553802012.378, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [10]
					{
						false, -- [1]
						191840, -- [2]
						1011, -- [3]
						1553802014.12, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [11]
					{
						1, -- [1]
						122783, -- [2]
						1, -- [3]
						1553802015.77, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						false, -- [1]
						191840, -- [2]
						508, -- [3]
						1553802015.885, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						191840, -- [2]
						510, -- [3]
						1553802017.621, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [14]
					{
						true, -- [1]
						283063, -- [2]
						71544, -- [3]
						1553802018.902, -- [4]
						182056, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						4, -- [1]
						283063, -- [2]
						1, -- [3]
						1553802018.902, -- [4]
						182056, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						false, -- [1]
						191840, -- [2]
						513, -- [3]
						1553802019.352, -- [4]
						182569, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						924, -- [3]
						1553802019.915, -- [4]
						183493, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [18]
					{
						false, -- [1]
						145110, -- [2]
						7601, -- [3]
						1553802020.638, -- [4]
						191094, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						true, -- [1]
						283063, -- [2]
						8943, -- [3]
						1553802020.912, -- [4]
						182151, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						191840, -- [2]
						512, -- [3]
						1553802021.097, -- [4]
						182663, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						1133, -- [3]
						1553802021.118, -- [4]
						183796, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						116670, -- [2]
						19046, -- [3]
						1553802021.64, -- [4]
						202842, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						191894, -- [2]
						10298, -- [3]
						1553802021.67, -- [4]
						213140, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [24]
					{
						false, -- [1]
						191894, -- [2]
						10299, -- [3]
						1553802021.67, -- [4]
						223439, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [25]
					{
						false, -- [1]
						191894, -- [2]
						20542, -- [3]
						1553802021.961, -- [4]
						243981, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [26]
					{
						false, -- [1]
						191894, -- [2]
						10271, -- [3]
						1553802021.961, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [27]
					{
						false, -- [1]
						191840, -- [2]
						411, -- [3]
						1553802022.503, -- [4]
						253600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						true, -- [1]
						283063, -- [2]
						22357, -- [3]
						1553802022.915, -- [4]
						231243, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						true, -- [1]
						283063, -- [2]
						169085, -- [3]
						1553802023.009, -- [4]
						62158, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						283063, -- [2]
						2, -- [3]
						1553802023.009, -- [4]
						62158, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						false, -- [1]
						143924, -- [2]
						30, -- [3]
						1553802023.563, -- [4]
						62188, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [32]
					{
						true, -- [1]
						283063, -- [2]
						62188, -- [3]
						1553802023.638, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						106897, -- [10]
					}, -- [33]
					{
						3, -- [1]
						122783, -- [2]
						1, -- [3]
						1553802015.77, -- [4]
						0, -- [5]
						"Hornpubmonk", -- [6]
					}, -- [34]
				},
				["class"] = "MONK",
				["timestring"] = "1m 33s",
				["time"] = 1553802023.665,
			}, -- [1]
			{
				["maxhealth"] = 228340,
				["timeofdeath"] = 93.8029999999999,
				["name"] = "Inánná",
				["events"] = {
					{
						false, -- [1]
						1064, -- [2]
						17116, -- [3]
						1553802010.464, -- [4]
						245273, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						false, -- [1]
						191840, -- [2]
						6430, -- [3]
						1553802010.504, -- [4]
						251160, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802010.526, -- [4]
						251160, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						true, -- [1]
						284424, -- [2]
						56960, -- [3]
						1553802010.526, -- [4]
						194200, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						119611, -- [2]
						4746, -- [3]
						1553802011.379, -- [4]
						198946, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						508, -- [3]
						1553802011.766, -- [4]
						199454, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						119611, -- [2]
						2360, -- [3]
						1553802013.294, -- [4]
						201814, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						191840, -- [2]
						1011, -- [3]
						1553802013.492, -- [4]
						202825, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802014.791, -- [4]
						202825, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						true, -- [1]
						284424, -- [2]
						56961, -- [3]
						1553802014.791, -- [4]
						145864, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						33110, -- [2]
						16101, -- [3]
						1553802014.814, -- [4]
						161965, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [11]
					{
						false, -- [1]
						119611, -- [2]
						2366, -- [3]
						1553802015.017, -- [4]
						164331, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [12]
					{
						false, -- [1]
						145110, -- [2]
						7409, -- [3]
						1553802015.23, -- [4]
						171740, -- [5]
						"Isery", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						191840, -- [2]
						507, -- [3]
						1553802015.23, -- [4]
						172247, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [14]
					{
						false, -- [1]
						116670, -- [2]
						14691, -- [3]
						1553802015.539, -- [4]
						186938, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [15]
					{
						false, -- [1]
						119611, -- [2]
						2194, -- [3]
						1553802016.639, -- [4]
						189132, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [16]
					{
						false, -- [1]
						191840, -- [2]
						1019, -- [3]
						1553802016.988, -- [4]
						190151, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [17]
					{
						false, -- [1]
						116670, -- [2]
						19003, -- [3]
						1553802017.722, -- [4]
						209154, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						191894, -- [2]
						10271, -- [3]
						1553802017.745, -- [4]
						219425, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						false, -- [1]
						191894, -- [2]
						10271, -- [3]
						1553802017.745, -- [4]
						229696, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [20]
					{
						false, -- [1]
						191840, -- [2]
						511, -- [3]
						1553802018.715, -- [4]
						230207, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						true, -- [1]
						98021, -- [2]
						27610, -- [3]
						1553802019.028, -- [4]
						202597, -- [5]
						"Spirit Link Totem <Soely>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						98021, -- [2]
						11129, -- [3]
						1553802020.002, -- [4]
						213726, -- [5]
						"Spirit Link Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						false, -- [1]
						279505, -- [2]
						12551, -- [3]
						1553802020.026, -- [4]
						226277, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						191840, -- [2]
						512, -- [3]
						1553802020.462, -- [4]
						226789, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [25]
					{
						false, -- [1]
						98021, -- [2]
						10545, -- [3]
						1553802021.002, -- [4]
						237334, -- [5]
						"Spirit Link Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [26]
					{
						true, -- [1]
						98021, -- [2]
						36241, -- [3]
						1553802022.008, -- [4]
						201093, -- [5]
						"Spirit Link Totem <Soely>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						191840, -- [2]
						510, -- [3]
						1553802022.18, -- [4]
						201603, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						true, -- [1]
						98021, -- [2]
						6644, -- [3]
						1553802023.009, -- [4]
						194959, -- [5]
						"Spirit Link Totem <Soely>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802023.261, -- [4]
						194959, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						true, -- [1]
						284424, -- [2]
						51265, -- [3]
						1553802023.261, -- [4]
						143694, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						283063, -- [2]
						143694, -- [3]
						1553802023.638, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						20353, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Inánná", -- [6]
					}, -- [33]
				},
				["class"] = "PALADIN",
				["timestring"] = "1m 33s",
				["time"] = 1553802023.665,
			}, -- [2]
			{
				["maxhealth"] = 218020,
				["timeofdeath"] = 159.870000000003,
				["name"] = "Ðaisuke",
				["events"] = {
					{
						false, -- [1]
						143924, -- [2]
						5707, -- [3]
						1553802076.185, -- [4]
						213680, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						191840, -- [2]
						460, -- [3]
						1553802076.241, -- [4]
						214140, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						191840, -- [2]
						5866, -- [3]
						1553802076.241, -- [4]
						220006, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						191840, -- [2]
						5853, -- [3]
						1553802077.203, -- [4]
						225859, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						61295, -- [2]
						2698, -- [3]
						1553802077.479, -- [4]
						228557, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						458, -- [3]
						1553802078.129, -- [4]
						229015, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						191840, -- [2]
						5839, -- [3]
						1553802078.168, -- [4]
						234854, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						119611, -- [2]
						148, -- [3]
						1553802078.392, -- [4]
						235002, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						455, -- [3]
						1553802080.051, -- [4]
						235457, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						61295, -- [2]
						2650, -- [3]
						1553802080.07, -- [4]
						238107, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						1064, -- [2]
						66871, -- [3]
						1553802081.146, -- [4]
						239820, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						119611, -- [2]
						2123, -- [3]
						1553802081.783, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						191840, -- [2]
						456, -- [3]
						1553802081.939, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						61295, -- [2]
						4937, -- [3]
						1553802082.495, -- [4]
						239820, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						272428, -- [2]
						3749, -- [3]
						1553802082.515, -- [4]
						239820, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [15]
					{
						false, -- [1]
						119611, -- [2]
						2134, -- [3]
						1553802083.525, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						191840, -- [2]
						914, -- [3]
						1553802083.664, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						116670, -- [2]
						27115, -- [3]
						1553802084.148, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						119611, -- [2]
						4291, -- [3]
						1553802085.257, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						false, -- [1]
						191840, -- [2]
						541, -- [3]
						1553802085.406, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [20]
					{
						false, -- [1]
						288333, -- [2]
						1097, -- [3]
						1553802086.439, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						119611, -- [2]
						2532, -- [3]
						1553802087.019, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [22]
					{
						false, -- [1]
						191840, -- [2]
						1085, -- [3]
						1553802087.165, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [23]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802087.708, -- [4]
						239820, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						true, -- [1]
						284424, -- [2]
						50849, -- [3]
						1553802087.708, -- [4]
						188971, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						288333, -- [2]
						549, -- [3]
						1553802088.111, -- [4]
						189520, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						true, -- [1]
						283610, -- [2]
						132473, -- [3]
						1553802088.673, -- [4]
						57047, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						4, -- [1]
						283610, -- [2]
						1, -- [3]
						1553802088.702, -- [4]
						57047, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						true, -- [1]
						283610, -- [2]
						37850, -- [3]
						1553802088.702, -- [4]
						19197, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						191840, -- [2]
						540, -- [3]
						1553802088.835, -- [4]
						19737, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [30]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802089.683, -- [4]
						19737, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						284424, -- [2]
						19737, -- [3]
						1553802089.703, -- [4]
						1, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						31112, -- [10]
					}, -- [32]
					{
						3, -- [1]
						196555, -- [2]
						1, -- [3]
						1553802018.567, -- [4]
						0, -- [5]
						"Ðaisuke", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "2m 39s",
				["time"] = 1553802089.732,
			}, -- [3]
			{
				["maxhealth"] = 220760,
				["timeofdeath"] = 181.118999999999,
				["name"] = "Tyrellan",
				["events"] = {
					{
						false, -- [1]
						269279, -- [2]
						53176, -- [3]
						1553802104.951, -- [4]
						242820, -- [5]
						"Tyrellan", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						true, -- [1]
						283063, -- [2]
						155589, -- [3]
						1553802104.951, -- [4]
						140407, -- [5]
						"Yalat's Bulwark", -- [6]
						53176, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						4, -- [1]
						283063, -- [2]
						1, -- [3]
						1553802104.951, -- [4]
						140407, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						191840, -- [2]
						455, -- [3]
						1553802105.017, -- [4]
						140862, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						162530, -- [2]
						1251, -- [3]
						1553802105.203, -- [4]
						142113, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						145110, -- [2]
						7602, -- [3]
						1553802105.624, -- [4]
						149715, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						143924, -- [2]
						489, -- [3]
						1553802105.76, -- [4]
						150204, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						162530, -- [2]
						2509, -- [3]
						1553802105.909, -- [4]
						152713, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						288333, -- [2]
						513, -- [3]
						1553802106.598, -- [4]
						153226, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						162530, -- [2]
						2509, -- [3]
						1553802106.644, -- [4]
						155735, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802106.735, -- [4]
						155735, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						true, -- [1]
						284424, -- [2]
						48621, -- [3]
						1553802106.735, -- [4]
						107114, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						119611, -- [2]
						2134, -- [3]
						1553802106.868, -- [4]
						109248, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						191840, -- [2]
						915, -- [3]
						1553802106.905, -- [4]
						110163, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						true, -- [1]
						283063, -- [2]
						19448, -- [3]
						1553802106.969, -- [4]
						90715, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						143924, -- [2]
						952, -- [3]
						1553802106.969, -- [4]
						91667, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802107.333, -- [4]
						91667, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						284424, -- [2]
						48621, -- [3]
						1553802107.333, -- [4]
						43046, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						162530, -- [2]
						1258, -- [3]
						1553802107.333, -- [4]
						44304, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						288333, -- [2]
						263, -- [3]
						1553802107.454, -- [4]
						44567, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						23, -- [3]
						1553802108.182, -- [4]
						44590, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						6262, -- [2]
						71897, -- [3]
						1553802108.543, -- [4]
						116487, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						119611, -- [2]
						4280, -- [3]
						1553802108.778, -- [4]
						120767, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						191840, -- [2]
						458, -- [3]
						1553802108.816, -- [4]
						121225, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						283063, -- [2]
						19448, -- [3]
						1553802108.952, -- [4]
						101777, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						288333, -- [2]
						512, -- [3]
						1553802109.785, -- [4]
						102289, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						123, -- [3]
						1553802109.821, -- [4]
						102412, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802110.417, -- [4]
						102412, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						true, -- [1]
						284424, -- [2]
						48621, -- [3]
						1553802110.417, -- [4]
						53791, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						119611, -- [2]
						2152, -- [3]
						1553802110.548, -- [4]
						55943, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						true, -- [1]
						283610, -- [2]
						36062, -- [3]
						1553802110.569, -- [4]
						19881, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						283063, -- [2]
						19881, -- [3]
						1553802110.965, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						323, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Tyrellan", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "3m 1s",
				["time"] = 1553802110.981,
			}, -- [4]
			{
				["maxhealth"] = 229320,
				["timeofdeath"] = 185.226999999999,
				["name"] = "Almîna",
				["events"] = {
					{
						4, -- [1]
						284472, -- [2]
						2, -- [3]
						1553802109.063, -- [4]
						93827, -- [5]
						"[*] Deadly Hex", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						61295, -- [2]
						2862, -- [3]
						1553802109.118, -- [4]
						96689, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						115175, -- [2]
						7991, -- [3]
						1553802110.136, -- [4]
						104680, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						291843, -- [2]
						904, -- [3]
						1553802110.136, -- [4]
						105584, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						191894, -- [2]
						11084, -- [3]
						1553802110.136, -- [4]
						116668, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						191894, -- [2]
						11084, -- [3]
						1553802110.136, -- [4]
						127752, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						119611, -- [2]
						5594, -- [3]
						1553802110.185, -- [4]
						133346, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						false, -- [1]
						191840, -- [2]
						1199, -- [3]
						1553802110.24, -- [4]
						134545, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						6262, -- [2]
						72708, -- [3]
						1553802110.372, -- [4]
						207253, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						true, -- [1]
						283610, -- [2]
						33292, -- [3]
						1553802110.569, -- [4]
						173961, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						124682, -- [2]
						5061, -- [3]
						1553802111.011, -- [4]
						179022, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						115175, -- [2]
						7311, -- [3]
						1553802111.011, -- [4]
						186333, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						true, -- [1]
						284472, -- [2]
						89543, -- [3]
						1553802111.053, -- [4]
						96790, -- [5]
						"[*] Deadly Hex", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						116670, -- [2]
						42156, -- [3]
						1553802111.474, -- [4]
						138946, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						116670, -- [2]
						33018, -- [3]
						1553802111.474, -- [4]
						171964, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191894, -- [2]
						10139, -- [3]
						1553802111.474, -- [4]
						182103, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						4, -- [1]
						284472, -- [2]
						3, -- [3]
						1553802111.567, -- [4]
						182103, -- [5]
						"[*] Deadly Hex", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						61295, -- [2]
						5044, -- [3]
						1553802111.714, -- [4]
						187147, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						124682, -- [2]
						10093, -- [3]
						1553802111.9, -- [4]
						197240, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						false, -- [1]
						115175, -- [2]
						7290, -- [3]
						1553802111.9, -- [4]
						204530, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						119611, -- [2]
						2552, -- [3]
						1553802111.953, -- [4]
						207082, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						291843, -- [2]
						1422, -- [3]
						1553802112.14, -- [4]
						208504, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						124682, -- [2]
						5047, -- [3]
						1553802112.795, -- [4]
						213551, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						true, -- [1]
						284472, -- [2]
						134313, -- [3]
						1553802113.067, -- [4]
						79238, -- [5]
						"[*] Deadly Hex", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						124682, -- [2]
						5503, -- [3]
						1553802113.676, -- [4]
						84741, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						false, -- [1]
						119611, -- [2]
						2782, -- [3]
						1553802113.729, -- [4]
						87523, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						291843, -- [2]
						1843, -- [3]
						1553802114.152, -- [4]
						89366, -- [5]
						"Almîna", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						61295, -- [2]
						2879, -- [3]
						1553802114.305, -- [4]
						92245, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						124682, -- [2]
						5488, -- [3]
						1553802114.564, -- [4]
						97733, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [29]
					{
						false, -- [1]
						191840, -- [2]
						7573, -- [3]
						1553802114.874, -- [4]
						105306, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						284472, -- [2]
						4, -- [3]
						1553802115.067, -- [4]
						105306, -- [5]
						"[*] Deadly Hex", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						284472, -- [2]
						105306, -- [3]
						1553802115.089, -- [4]
						1, -- [5]
						"[*] Deadly Hex", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						73778, -- [10]
					}, -- [32]
					{
						3, -- [1]
						108271, -- [2]
						1, -- [3]
						1553802075.525, -- [4]
						0, -- [5]
						"Almîna", -- [6]
					}, -- [33]
				},
				["class"] = "SHAMAN",
				["timestring"] = "3m 5s",
				["time"] = 1553802115.089,
			}, -- [5]
			{
				["maxhealth"] = 243120,
				["timeofdeath"] = 196.707999999999,
				["name"] = "Salanâ",
				["events"] = {
					{
						true, -- [1]
						283507, -- [2]
						17294, -- [3]
						1553802117.412, -- [4]
						213330, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						33110, -- [2]
						16591, -- [3]
						1553802117.412, -- [4]
						229921, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						288839, -- [2]
						5755, -- [3]
						1553802117.437, -- [4]
						235676, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						139, -- [2]
						6802, -- [3]
						1553802117.798, -- [4]
						242478, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						212, -- [3]
						1553802117.91, -- [4]
						242690, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						77489, -- [2]
						10403, -- [3]
						1553802118.072, -- [4]
						243120, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						true, -- [1]
						283507, -- [2]
						17294, -- [3]
						1553802118.406, -- [4]
						225826, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						201, -- [3]
						1553802119.127, -- [4]
						226027, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						true, -- [1]
						283507, -- [2]
						17294, -- [3]
						1553802119.408, -- [4]
						208733, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						2061, -- [2]
						21235, -- [3]
						1553802120.177, -- [4]
						229968, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						77489, -- [2]
						4712, -- [3]
						1553802120.316, -- [4]
						234680, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						143924, -- [2]
						51, -- [3]
						1553802120.354, -- [4]
						234731, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						139, -- [2]
						4053, -- [3]
						1553802120.496, -- [4]
						238784, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						4, -- [1]
						285479, -- [2]
						1, -- [3]
						1553802120.683, -- [4]
						238784, -- [5]
						"[*] Flame Jet", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						true, -- [1]
						285479, -- [2]
						81431, -- [3]
						1553802120.683, -- [4]
						157353, -- [5]
						"[*] Flame Jet", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						77489, -- [2]
						9114, -- [3]
						1553802121.067, -- [4]
						166467, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						143924, -- [2]
						37, -- [3]
						1553802121.58, -- [4]
						166504, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						288839, -- [2]
						5755, -- [3]
						1553802122.401, -- [4]
						172259, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						4, -- [1]
						285479, -- [2]
						1, -- [3]
						1553802122.542, -- [4]
						172259, -- [5]
						"[*] Flame Jet", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						true, -- [1]
						285479, -- [2]
						81431, -- [3]
						1553802122.542, -- [4]
						90828, -- [5]
						"[*] Flame Jet", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						151, -- [3]
						1553802122.778, -- [4]
						90979, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						139, -- [2]
						4053, -- [3]
						1553802123.205, -- [4]
						95032, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						77489, -- [2]
						4712, -- [3]
						1553802123.317, -- [4]
						99744, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						20, -- [3]
						1553802124.012, -- [4]
						99764, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						77489, -- [2]
						6667, -- [3]
						1553802124.066, -- [4]
						106431, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						285479, -- [2]
						81432, -- [3]
						1553802124.545, -- [4]
						24999, -- [5]
						"[*] Flame Jet", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						116, -- [3]
						1553802125.226, -- [4]
						25115, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						4, -- [1]
						286501, -- [2]
						1, -- [3]
						1553802125.306, -- [4]
						25115, -- [5]
						"[*] Creeping Blaze", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						false, -- [1]
						139, -- [2]
						4257, -- [3]
						1553802125.926, -- [4]
						29372, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						269108, -- [2]
						6570, -- [3]
						1553802125.944, -- [4]
						35942, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553802125.981, -- [4]
						35942, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						false, -- [1]
						143924, -- [2]
						114, -- [3]
						1553802126.43, -- [4]
						36056, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Salanâ", -- [6]
					}, -- [33]
				},
				["class"] = "PRIEST",
				["timestring"] = "3m 16s",
				["time"] = 1553802126.57,
			}, -- [6]
			{
				["maxhealth"] = 240980,
				["timeofdeath"] = 196.889999999999,
				["name"] = "Dovomir",
				["events"] = {
					{
						false, -- [1]
						143924, -- [2]
						122, -- [3]
						1553802113.043, -- [4]
						258629, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						243241, -- [2]
						4719, -- [3]
						1553802113.343, -- [4]
						263348, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						117313, -- [2]
						13253, -- [3]
						1553802113.751, -- [4]
						265060, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						77489, -- [2]
						1847, -- [3]
						1553802113.774, -- [4]
						265060, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553802114.05, -- [4]
						265060, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						false, -- [1]
						77489, -- [2]
						1305, -- [3]
						1553802115.34, -- [4]
						265060, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						288091, -- [2]
						4907, -- [3]
						1553802115.804, -- [4]
						265060, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						234946, -- [2]
						7432, -- [3]
						1553802115.848, -- [4]
						265060, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						77489, -- [2]
						1848, -- [3]
						1553802116.779, -- [4]
						265060, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553802117.562, -- [4]
						265060, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						288091, -- [2]
						2454, -- [3]
						1553802117.778, -- [4]
						265060, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						4, -- [1]
						291146, -- [2]
						1, -- [3]
						1553802118.01, -- [4]
						265060, -- [5]
						"[*] Chaotic Displacement", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						77489, -- [2]
						1632, -- [3]
						1553802118.355, -- [4]
						265060, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						77489, -- [2]
						1848, -- [3]
						1553802119.806, -- [4]
						265060, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [14]
					{
						false, -- [1]
						288091, -- [2]
						1968, -- [3]
						1553802119.806, -- [4]
						265060, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802119.998, -- [4]
						265060, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						true, -- [1]
						284424, -- [2]
						58984, -- [3]
						1553802119.998, -- [4]
						206076, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802120.496, -- [4]
						206076, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						true, -- [1]
						284424, -- [2]
						58984, -- [3]
						1553802120.496, -- [4]
						147092, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						117313, -- [2]
						13253, -- [3]
						1553802120.821, -- [4]
						160345, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						174, -- [3]
						1553802121.157, -- [4]
						160519, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						false, -- [1]
						77489, -- [2]
						1632, -- [3]
						1553802121.345, -- [4]
						162151, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						143924, -- [2]
						214, -- [3]
						1553802122.362, -- [4]
						162365, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						143924, -- [2]
						610, -- [3]
						1553802123.586, -- [4]
						162975, -- [5]
						"Dovomir", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802123.878, -- [4]
						162975, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						284424, -- [2]
						58984, -- [3]
						1553802123.878, -- [4]
						103991, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						191894, -- [2]
						8502, -- [3]
						1553802124.037, -- [4]
						112493, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						77489, -- [2]
						1633, -- [3]
						1553802124.334, -- [4]
						114126, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [28]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802124.739, -- [4]
						114126, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						284424, -- [2]
						58984, -- [3]
						1553802124.739, -- [4]
						55142, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						119611, -- [2]
						2134, -- [3]
						1553802125.871, -- [4]
						57276, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						284424, -- [2]
						57276, -- [3]
						1553802126.752, -- [4]
						1, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						1708, -- [10]
					}, -- [32]
					{
						3, -- [1]
						184364, -- [2]
						1, -- [3]
						1553802074.448, -- [4]
						0, -- [5]
						"Dovomir", -- [6]
					}, -- [33]
				},
				["class"] = "WARRIOR",
				["timestring"] = "3m 16s",
				["time"] = 1553802126.752,
			}, -- [7]
			{
				["maxhealth"] = 228240,
				["timeofdeath"] = 197.601000000002,
				["name"] = "Qyix",
				["events"] = {
					{
						false, -- [1]
						270661, -- [2]
						1672, -- [3]
						1553802117.937, -- [4]
						222310, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						true, -- [1]
						283507, -- [2]
						17189, -- [3]
						1553802118.406, -- [4]
						205121, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						72, -- [3]
						1553802118.721, -- [4]
						205193, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						true, -- [1]
						283507, -- [2]
						17189, -- [3]
						1553802119.408, -- [4]
						188004, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						270117, -- [2]
						6272, -- [3]
						1553802119.408, -- [4]
						194276, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						77489, -- [2]
						2481, -- [3]
						1553802119.708, -- [4]
						196757, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						34914, -- [2]
						2059, -- [3]
						1553802119.806, -- [4]
						198816, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						143924, -- [2]
						171, -- [3]
						1553802119.936, -- [4]
						198987, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						77489, -- [2]
						2410, -- [3]
						1553802120.227, -- [4]
						201397, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						270661, -- [2]
						3344, -- [3]
						1553802120.938, -- [4]
						204741, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						143924, -- [2]
						194, -- [3]
						1553802121.157, -- [4]
						204935, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						34914, -- [2]
						3586, -- [3]
						1553802121.821, -- [4]
						208521, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						1, -- [1]
						47585, -- [2]
						1, -- [3]
						1553802121.984, -- [4]
						208521, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						77, -- [3]
						1553802122.362, -- [4]
						208598, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						288839, -- [2]
						11510, -- [3]
						1553802122.424, -- [4]
						220108, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						4, -- [1]
						285479, -- [2]
						1, -- [3]
						1553802122.424, -- [4]
						220108, -- [5]
						"[*] Flame Jet", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						true, -- [1]
						285479, -- [2]
						20234, -- [3]
						1553802122.424, -- [4]
						199874, -- [5]
						"[*] Flame Jet", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						77489, -- [2]
						2835, -- [3]
						1553802122.692, -- [4]
						202709, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						77489, -- [2]
						2409, -- [3]
						1553802123.222, -- [4]
						205118, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						143924, -- [2]
						24, -- [3]
						1553802123.586, -- [4]
						205142, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						34914, -- [2]
						3641, -- [3]
						1553802123.824, -- [4]
						208783, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						270661, -- [2]
						1673, -- [3]
						1553802123.924, -- [4]
						210456, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						true, -- [1]
						283574, -- [2]
						133189, -- [3]
						1553802124.4, -- [4]
						77267, -- [5]
						"Volatile Charge <Kalissta>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						280052, -- [2]
						9477, -- [3]
						1553802124.422, -- [4]
						86744, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						143924, -- [2]
						102, -- [3]
						1553802124.819, -- [4]
						86846, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						4, -- [1]
						286501, -- [2]
						1, -- [3]
						1553802125.256, -- [4]
						86846, -- [5]
						"[*] Creeping Blaze", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						77489, -- [2]
						2862, -- [3]
						1553802125.693, -- [4]
						89708, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						34914, -- [2]
						3597, -- [3]
						1553802125.847, -- [4]
						93305, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						false, -- [1]
						143924, -- [2]
						100, -- [3]
						1553802126.021, -- [4]
						93405, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						270661, -- [2]
						3344, -- [3]
						1553802126.938, -- [4]
						96749, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						24, -- [3]
						1553802127.221, -- [4]
						96773, -- [5]
						"Qyix", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						283574, -- [2]
						96773, -- [3]
						1553802127.425, -- [4]
						1, -- [5]
						"Volatile Charge <Kalissta>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						36416, -- [10]
					}, -- [32]
					{
						3, -- [1]
						47585, -- [2]
						1, -- [3]
						1553802121.984, -- [4]
						0, -- [5]
						"Qyix", -- [6]
					}, -- [33]
				},
				["class"] = "PRIEST",
				["timestring"] = "3m 17s",
				["time"] = 1553802127.463,
			}, -- [8]
			{
				["maxhealth"] = 231840,
				["timeofdeath"] = 201.277000000002,
				["name"] = "Laki",
				["events"] = {
					{
						false, -- [1]
						183811, -- [2]
						739, -- [3]
						1553802114.014, -- [4]
						241405, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						278785, -- [2]
						2250, -- [3]
						1553802114.05, -- [4]
						243655, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						139, -- [2]
						3401, -- [3]
						1553802114.152, -- [4]
						247056, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						183811, -- [2]
						739, -- [3]
						1553802114.152, -- [4]
						247795, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						77489, -- [2]
						1614, -- [3]
						1553802114.205, -- [4]
						249409, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						243241, -- [2]
						8873, -- [3]
						1553802114.205, -- [4]
						255020, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						77489, -- [2]
						3850, -- [3]
						1553802116.779, -- [4]
						255020, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						139, -- [2]
						3401, -- [3]
						1553802116.856, -- [4]
						255020, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						77489, -- [2]
						1614, -- [3]
						1553802117.178, -- [4]
						255020, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						278785, -- [2]
						1125, -- [3]
						1553802117.562, -- [4]
						255020, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						4, -- [1]
						291146, -- [2]
						1, -- [3]
						1553802118.01, -- [4]
						255020, -- [5]
						"[*] Chaotic Displacement", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						139, -- [2]
						3724, -- [3]
						1553802118.333, -- [4]
						255020, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802118.68, -- [4]
						255020, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						true, -- [1]
						284424, -- [2]
						57136, -- [3]
						1553802118.68, -- [4]
						197884, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						77489, -- [2]
						3850, -- [3]
						1553802119.806, -- [4]
						201734, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [15]
					{
						false, -- [1]
						77489, -- [2]
						1614, -- [3]
						1553802120.177, -- [4]
						203348, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						false, -- [1]
						77489, -- [2]
						3851, -- [3]
						1553802122.778, -- [4]
						207199, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						116670, -- [2]
						13616, -- [3]
						1553802123.243, -- [4]
						220815, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						145109, -- [2]
						7651, -- [3]
						1553802123.608, -- [4]
						228466, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [19]
					{
						4, -- [1]
						286501, -- [2]
						1, -- [3]
						1553802123.765, -- [4]
						228466, -- [5]
						"[*] Creeping Blaze", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						false, -- [1]
						119611, -- [2]
						2146, -- [3]
						1553802124.097, -- [4]
						230612, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						119611, -- [2]
						2135, -- [3]
						1553802125.981, -- [4]
						232747, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						true, -- [1]
						286501, -- [2]
						137095, -- [3]
						1553802126.78, -- [4]
						95652, -- [5]
						"[*] Creeping Blaze", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						119611, -- [2]
						2123, -- [3]
						1553802127.893, -- [4]
						97775, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						4, -- [1]
						284470, -- [2]
						1, -- [3]
						1553802128.438, -- [4]
						97775, -- [5]
						"Arcane Amethyst", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						false, -- [1]
						145109, -- [2]
						7651, -- [3]
						1553802128.593, -- [4]
						105426, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						4, -- [1]
						284472, -- [2]
						1, -- [3]
						1553802128.947, -- [4]
						105426, -- [5]
						"[*] Deadly Hex", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						119611, -- [2]
						2122, -- [3]
						1553802129.737, -- [4]
						107548, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						4, -- [1]
						284472, -- [2]
						2, -- [3]
						1553802130.444, -- [4]
						107548, -- [5]
						"[*] Deadly Hex", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						284472, -- [2]
						91419, -- [3]
						1553802130.949, -- [4]
						16129, -- [5]
						"[*] Deadly Hex", -- [6]
						nil, -- [7]
						32, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						284424, -- [2]
						1, -- [3]
						1553802131.109, -- [4]
						16129, -- [5]
						"[*] Scorching Ground", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						284424, -- [2]
						16129, -- [3]
						1553802131.139, -- [4]
						1, -- [5]
						"[*] Scorching Ground", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						49577, -- [10]
					}, -- [32]
					{
						3, -- [1]
						22812, -- [2]
						1, -- [3]
						1553802022.781, -- [4]
						0, -- [5]
						"Laki", -- [6]
					}, -- [33]
				},
				["class"] = "DRUID",
				["timestring"] = "3m 21s",
				["time"] = 1553802131.139,
			}, -- [9]
			{
				["maxhealth"] = 223180,
				["timeofdeath"] = 201.442999999999,
				["name"] = "Alleycut",
				["events"] = {
					{
						false, -- [1]
						272260, -- [2]
						264, -- [3]
						1553802120.801, -- [4]
						236485, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						4, -- [1]
						284883, -- [2]
						1, -- [3]
						1553802121.157, -- [4]
						236485, -- [5]
						"[*] Unleashed Rage", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						183811, -- [2]
						619, -- [3]
						1553802122.112, -- [4]
						237104, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						288333, -- [2]
						607, -- [3]
						1553802122.136, -- [4]
						237711, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						183811, -- [2]
						619, -- [3]
						1553802122.341, -- [4]
						238330, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						77489, -- [2]
						3124, -- [3]
						1553802122.778, -- [4]
						241454, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						272260, -- [2]
						1054, -- [3]
						1553802122.801, -- [4]
						242508, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						596, -- [2]
						11013, -- [3]
						1553802122.837, -- [4]
						245480, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						278785, -- [2]
						1126, -- [3]
						1553802122.883, -- [4]
						245480, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						288333, -- [2]
						619, -- [3]
						1553802123.924, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						285479, -- [2]
						1, -- [3]
						1553802124.779, -- [4]
						245480, -- [5]
						"[*] Flame Jet", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						269279, -- [2]
						17694, -- [3]
						1553802124.779, -- [4]
						245480, -- [5]
						"Alleycut", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						true, -- [1]
						285479, -- [2]
						67618, -- [3]
						1553802124.779, -- [4]
						195556, -- [5]
						"[*] Flame Jet", -- [6]
						17694, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						270117, -- [2]
						7101, -- [3]
						1553802124.8, -- [4]
						202657, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						272260, -- [2]
						1055, -- [3]
						1553802124.8, -- [4]
						203712, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [15]
					{
						4, -- [1]
						286501, -- [2]
						1, -- [3]
						1553802125.277, -- [4]
						203712, -- [5]
						"[*] Creeping Blaze", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						false, -- [1]
						288333, -- [2]
						588, -- [3]
						1553802125.746, -- [4]
						204300, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						77489, -- [2]
						1607, -- [3]
						1553802125.847, -- [4]
						205907, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						285479, -- [2]
						70041, -- [3]
						1553802126.78, -- [4]
						135866, -- [5]
						"[*] Flame Jet", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						272260, -- [2]
						2109, -- [3]
						1553802126.8, -- [4]
						137975, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						288839, -- [2]
						5754, -- [3]
						1553802127.425, -- [4]
						143729, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						288333, -- [2]
						597, -- [3]
						1553802127.56, -- [4]
						144326, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						288333, -- [2]
						188, -- [3]
						1553802128.131, -- [4]
						144514, -- [5]
						"Alleycut", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						true, -- [1]
						286501, -- [2]
						120172, -- [3]
						1553802128.292, -- [4]
						24342, -- [5]
						"[*] Creeping Blaze", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						280052, -- [2]
						9660, -- [3]
						1553802128.292, -- [4]
						34002, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553802128.316, -- [4]
						34002, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						272260, -- [2]
						8438, -- [3]
						1553802128.799, -- [4]
						42440, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						77489, -- [2]
						1504, -- [3]
						1553802128.835, -- [4]
						43944, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						false, -- [1]
						77489, -- [2]
						886, -- [3]
						1553802130.444, -- [4]
						44830, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [29]
					{
						false, -- [1]
						281265, -- [2]
						1762, -- [3]
						1553802130.842, -- [4]
						46592, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553802130.885, -- [4]
						46592, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						true, -- [1]
						286501, -- [2]
						46592, -- [3]
						1553802131.283, -- [4]
						1, -- [5]
						"[*] Creeping Blaze", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						73581, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Alleycut", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "3m 21s",
				["time"] = 1553802131.305,
			}, -- [10]
		},
		["bossname"] = "Opulence",
		["bossicon"] = {
			0.75, -- [1]
			1, -- [2]
			0, -- [3]
			0.25, -- [4]
			"Interface\\AddOns\\Details\\images\\raid\\DazaralorRaid_BossFaces", -- [5]
		},
		["date"] = 37531.491,
		["timeelapsed"] = 216.205000000002,
	}, -- [1]
	{
		["deaths"] = {
			{
				["maxhealth"] = 234420,
				["timeofdeath"] = 239.036999999997,
				["name"] = "Aspern",
				["events"] = {
					{
						2, -- [1]
						20484, -- [2]
						1, -- [3]
						1553801765.687, -- [4]
						0, -- [5]
						"Isery", -- [6]
					}, -- [1]
					{
						4, -- [1]
						284573, -- [2]
						4, -- [3]
						1553801741.914, -- [4]
						257860, -- [5]
						"[*] Tailwinds", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						191840, -- [2]
						2023, -- [3]
						1553801742.098, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						false, -- [1]
						162530, -- [2]
						2782, -- [3]
						1553801742.506, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						4, -- [1]
						284573, -- [2]
						5, -- [3]
						1553801742.548, -- [4]
						257860, -- [5]
						"[*] Tailwinds", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						false, -- [1]
						162530, -- [2]
						2782, -- [3]
						1553801743.13, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						191840, -- [2]
						1011, -- [3]
						1553801743.781, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						false, -- [1]
						280177, -- [2]
						4472, -- [3]
						1553801745.028, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						1017, -- [3]
						1553801745.461, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						4, -- [1]
						284664, -- [2]
						1, -- [3]
						1553801745.743, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						false, -- [1]
						280177, -- [2]
						4472, -- [3]
						1553801745.854, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						280177, -- [2]
						4472, -- [3]
						1553801746.674, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						4, -- [1]
						284664, -- [2]
						2, -- [3]
						1553801746.725, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						191840, -- [2]
						2044, -- [3]
						1553801747.143, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						280177, -- [2]
						8944, -- [3]
						1553801747.508, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						4, -- [1]
						284664, -- [2]
						3, -- [3]
						1553801747.73, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						false, -- [1]
						162530, -- [2]
						2819, -- [3]
						1553801748.205, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						280177, -- [2]
						4472, -- [3]
						1553801748.344, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						4, -- [1]
						284664, -- [2]
						4, -- [3]
						1553801748.747, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						false, -- [1]
						162530, -- [2]
						2820, -- [3]
						1553801748.846, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						191840, -- [2]
						1025, -- [3]
						1553801748.876, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						280177, -- [2]
						3751, -- [3]
						1553801749.036, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						162530, -- [2]
						2820, -- [3]
						1553801749.472, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						4, -- [1]
						284664, -- [2]
						5, -- [3]
						1553801749.721, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						191840, -- [2]
						997, -- [3]
						1553801750.595, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						4, -- [1]
						284664, -- [2]
						6, -- [3]
						1553801750.732, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						4, -- [1]
						284664, -- [2]
						7, -- [3]
						1553801751.73, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						191840, -- [2]
						25658, -- [3]
						1553801752.524, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						4, -- [1]
						284664, -- [2]
						8, -- [3]
						1553801752.724, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						4, -- [1]
						284664, -- [2]
						9, -- [3]
						1553801753.737, -- [4]
						257860, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						false, -- [1]
						191840, -- [2]
						12798, -- [3]
						1553801753.737, -- [4]
						257860, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [31]
					{
						false, -- [1]
						235313, -- [2]
						31361, -- [3]
						1553801753.755, -- [4]
						257860, -- [5]
						"Aspern", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [32]
					{
						true, -- [1]
						287424, -- [2]
						289221, -- [3]
						1553801753.775, -- [4]
						1, -- [5]
						"[*] Thief's Bane", -- [6]
						31361, -- [7]
						32, -- [8]
						false, -- [9]
						375255, -- [10]
					}, -- [33]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Aspern", -- [6]
					}, -- [34]
				},
				["class"] = "MAGE",
				["timestring"] = "3m 59s",
				["time"] = 1553801753.794,
			}, -- [1]
			{
				["maxhealth"] = 231940,
				["timeofdeath"] = 290.396000000001,
				["name"] = "Soely",
				["events"] = {
					{
						false, -- [1]
						61295, -- [2]
						3101, -- [3]
						1553801798.343, -- [4]
						160918, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						191840, -- [2]
						1202, -- [3]
						1553801798.452, -- [4]
						162120, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						126, -- [3]
						1553801798.991, -- [4]
						162246, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						61295, -- [2]
						3081, -- [3]
						1553801800.057, -- [4]
						165327, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						61295, -- [2]
						30672, -- [3]
						1553801800.135, -- [4]
						195999, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553801800.135, -- [4]
						195999, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						143924, -- [2]
						86, -- [3]
						1553801800.204, -- [4]
						196085, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						191840, -- [2]
						1196, -- [3]
						1553801800.361, -- [4]
						197281, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						136, -- [3]
						1553801801.426, -- [4]
						197417, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						162530, -- [2]
						3283, -- [3]
						1553801801.784, -- [4]
						200700, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						61295, -- [2]
						4917, -- [3]
						1553801801.806, -- [4]
						205617, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						191840, -- [2]
						2382, -- [3]
						1553801802.255, -- [4]
						207999, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						162530, -- [2]
						6549, -- [3]
						1553801802.459, -- [4]
						214548, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						108, -- [3]
						1553801802.623, -- [4]
						214656, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						162530, -- [2]
						3275, -- [3]
						1553801803.145, -- [4]
						217931, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						272428, -- [2]
						3748, -- [3]
						1553801803.509, -- [4]
						221679, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						61295, -- [2]
						2393, -- [3]
						1553801803.531, -- [4]
						224072, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553801803.531, -- [4]
						224072, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						1, -- [1]
						108271, -- [2]
						1, -- [3]
						1553801803.793, -- [4]
						224072, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						162530, -- [2]
						3275, -- [3]
						1553801803.809, -- [4]
						227347, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						112, -- [3]
						1553801803.848, -- [4]
						227459, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						191840, -- [2]
						2387, -- [3]
						1553801804.082, -- [4]
						229846, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						false, -- [1]
						59547, -- [2]
						10509, -- [3]
						1553801804.323, -- [4]
						240355, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						201633, -- [2]
						4313, -- [3]
						1553801804.498, -- [4]
						240355, -- [5]
						"Earthen Wall Totem <Soely>", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						287640, -- [2]
						81303, -- [3]
						1553801804.498, -- [4]
						163365, -- [5]
						"Volatile Charge <Almîna>", -- [6]
						4313, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						162530, -- [2]
						3282, -- [3]
						1553801804.498, -- [4]
						166647, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						201633, -- [2]
						4313, -- [3]
						1553801804.564, -- [4]
						166647, -- [5]
						"Earthen Wall Totem <Soely>", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						true, -- [1]
						287513, -- [2]
						108404, -- [3]
						1553801804.564, -- [4]
						62556, -- [5]
						"Yalat's Bulwark", -- [6]
						4313, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						4, -- [1]
						287513, -- [2]
						1, -- [3]
						1553801804.564, -- [4]
						62556, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						false, -- [1]
						143924, -- [2]
						59, -- [3]
						1553801805.047, -- [4]
						62615, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						false, -- [1]
						201633, -- [2]
						4313, -- [3]
						1553801805.135, -- [4]
						62615, -- [5]
						"Earthen Wall Totem <Soely>", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287513, -- [2]
						66928, -- [3]
						1553801805.153, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						4313, -- [7]
						4, -- [8]
						false, -- [9]
						41476, -- [10]
					}, -- [32]
					{
						3, -- [1]
						108271, -- [2]
						1, -- [3]
						1553801803.793, -- [4]
						0, -- [5]
						"Soely", -- [6]
					}, -- [33]
				},
				["class"] = "SHAMAN",
				["timestring"] = "4m 50s",
				["time"] = 1553801805.153,
			}, -- [2]
			{
				["maxhealth"] = 218020,
				["timeofdeath"] = 297.178,
				["name"] = "Ðaisuke",
				["events"] = {
					{
						false, -- [1]
						115310, -- [2]
						67441, -- [3]
						1553801791.777, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						288333, -- [2]
						759, -- [3]
						1553801792.696, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						288333, -- [2]
						158, -- [3]
						1553801792.941, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						288333, -- [2]
						1518, -- [3]
						1553801793.986, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						288333, -- [2]
						766, -- [3]
						1553801795.131, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						162530, -- [2]
						3312, -- [3]
						1553801795.959, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						288333, -- [2]
						1455, -- [3]
						1553801796.57, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						288333, -- [2]
						735, -- [3]
						1553801798.023, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						288333, -- [2]
						742, -- [3]
						1553801799.481, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						288333, -- [2]
						220, -- [3]
						1553801799.981, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						162530, -- [2]
						3275, -- [3]
						1553801802.459, -- [4]
						239820, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						288333, -- [2]
						1542, -- [3]
						1553801802.481, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						288333, -- [2]
						775, -- [3]
						1553801804.268, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						201633, -- [2]
						4313, -- [3]
						1553801804.498, -- [4]
						239820, -- [5]
						"Earthen Wall Totem <Soely>", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						269279, -- [2]
						17069, -- [3]
						1553801804.498, -- [4]
						239820, -- [5]
						"Ðaisuke", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						true, -- [1]
						287640, -- [2]
						119695, -- [3]
						1553801804.498, -- [4]
						141507, -- [5]
						"Volatile Charge <Almîna>", -- [6]
						21382, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						162530, -- [2]
						3283, -- [3]
						1553801804.498, -- [4]
						144790, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [17]
					{
						false, -- [1]
						162530, -- [2]
						6104, -- [3]
						1553801805.181, -- [4]
						150894, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						145110, -- [2]
						7409, -- [3]
						1553801805.233, -- [4]
						158303, -- [5]
						"Isery", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						162530, -- [2]
						3297, -- [3]
						1553801805.861, -- [4]
						161600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						288333, -- [2]
						1573, -- [3]
						1553801806.051, -- [4]
						163173, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						true, -- [1]
						287513, -- [2]
						160700, -- [3]
						1553801806.309, -- [4]
						2473, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						4, -- [1]
						287513, -- [2]
						1, -- [3]
						1553801806.309, -- [4]
						2473, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						false, -- [1]
						162530, -- [2]
						3060, -- [3]
						1553801806.541, -- [4]
						5533, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						162530, -- [2]
						3067, -- [3]
						1553801807.218, -- [4]
						8600, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						288333, -- [2]
						1670, -- [3]
						1553801807.827, -- [4]
						10270, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						162530, -- [2]
						2582, -- [3]
						1553801807.906, -- [4]
						12852, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						true, -- [1]
						287513, -- [2]
						19584, -- [3]
						1553801808.302, -- [4]
						39351, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						288333, -- [2]
						309, -- [3]
						1553801808.487, -- [4]
						39660, -- [5]
						"Ðaisuke", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						162530, -- [2]
						1290, -- [3]
						1553801809.243, -- [4]
						40950, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						true, -- [1]
						287513, -- [2]
						19583, -- [3]
						1553801810.308, -- [4]
						21367, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						283609, -- [2]
						21367, -- [3]
						1553801811.935, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						15076, -- [10]
					}, -- [32]
					{
						3, -- [1]
						196555, -- [2]
						1, -- [3]
						1553801602.3, -- [4]
						0, -- [5]
						"Ðaisuke", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "4m 57s",
				["time"] = 1553801811.935,
			}, -- [3]
			{
				["maxhealth"] = 231840,
				["timeofdeath"] = 311.798999999999,
				["name"] = "Laki",
				["events"] = {
					{
						true, -- [1]
						287648, -- [2]
						11200, -- [3]
						1553801822.035, -- [4]
						201202, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						139, -- [2]
						3605, -- [3]
						1553801822.117, -- [4]
						204807, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						77489, -- [2]
						1496, -- [3]
						1553801822.646, -- [4]
						206303, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						183811, -- [2]
						630, -- [3]
						1553801822.733, -- [4]
						206933, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						77489, -- [2]
						4569, -- [3]
						1553801822.856, -- [4]
						211502, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						true, -- [1]
						287648, -- [2]
						11200, -- [3]
						1553801823.028, -- [4]
						200302, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						true, -- [1]
						287640, -- [2]
						125574, -- [3]
						1553801823.25, -- [4]
						74728, -- [5]
						"Volatile Charge <Kalissta>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						145109, -- [2]
						7650, -- [3]
						1553801823.606, -- [4]
						82378, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						139, -- [2]
						3605, -- [3]
						1553801823.926, -- [4]
						85983, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						269108, -- [2]
						6571, -- [3]
						1553801823.958, -- [4]
						92554, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553801823.987, -- [4]
						92554, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						true, -- [1]
						287648, -- [2]
						11200, -- [3]
						1553801824.059, -- [4]
						81354, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						4, -- [1]
						291146, -- [2]
						1, -- [3]
						1553801824.2, -- [4]
						81354, -- [5]
						"[*] Chaotic Displacement", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						275499, -- [2]
						1500, -- [3]
						1553801824.44, -- [4]
						82854, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						183811, -- [2]
						626, -- [3]
						1553801824.505, -- [4]
						83480, -- [5]
						"Supersunny", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						14847, -- [3]
						1553801824.613, -- [4]
						98327, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						4, -- [1]
						284573, -- [2]
						2, -- [3]
						1553801824.658, -- [4]
						98327, -- [5]
						"[*] Tailwinds", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						6262, -- [2]
						68840, -- [3]
						1553801824.882, -- [4]
						167167, -- [5]
						"Laki", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						162530, -- [2]
						3282, -- [3]
						1553801825.025, -- [4]
						170449, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						true, -- [1]
						287648, -- [2]
						112, -- [3]
						1553801825.056, -- [4]
						170337, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						4, -- [1]
						284573, -- [2]
						3, -- [3]
						1553801825.056, -- [4]
						170337, -- [5]
						"[*] Tailwinds", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						191840, -- [2]
						14817, -- [3]
						1553801825.582, -- [4]
						185154, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						4, -- [1]
						284573, -- [2]
						4, -- [3]
						1553801825.6, -- [4]
						185154, -- [5]
						"[*] Tailwinds", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						false, -- [1]
						77489, -- [2]
						1496, -- [3]
						1553801825.668, -- [4]
						186650, -- [5]
						"Salanâ", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						162530, -- [2]
						3283, -- [3]
						1553801825.729, -- [4]
						189933, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						false, -- [1]
						139, -- [2]
						7211, -- [3]
						1553801825.729, -- [4]
						197144, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						4, -- [1]
						284573, -- [2]
						5, -- [3]
						1553801825.785, -- [4]
						197144, -- [5]
						"[*] Tailwinds", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						77489, -- [2]
						2201, -- [3]
						1553801825.854, -- [4]
						199345, -- [5]
						"Kalissta", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						true, -- [1]
						287513, -- [2]
						169123, -- [3]
						1553801825.932, -- [4]
						30222, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						4, -- [1]
						287513, -- [2]
						1, -- [3]
						1553801825.932, -- [4]
						30222, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						true, -- [1]
						287648, -- [2]
						12880, -- [3]
						1553801826.043, -- [4]
						17342, -- [5]
						"The Hand of In'zashi", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287513, -- [2]
						17342, -- [3]
						1553801826.512, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						177149, -- [10]
					}, -- [32]
					{
						3, -- [1]
						22812, -- [2]
						1, -- [3]
						1553801711.772, -- [4]
						0, -- [5]
						"Laki", -- [6]
					}, -- [33]
				},
				["class"] = "DRUID",
				["timestring"] = "5m 11s",
				["time"] = 1553801826.556,
			}, -- [4]
			{
				["maxhealth"] = 231940,
				["timeofdeath"] = 314.112999999998,
				["name"] = "Soely",
				["events"] = {
					{
						false, -- [1]
						191840, -- [2]
						14878, -- [3]
						1553801822.875, -- [4]
						157465, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [1]
					{
						false, -- [1]
						162530, -- [2]
						3297, -- [3]
						1553801822.875, -- [4]
						160762, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [2]
					{
						false, -- [1]
						61295, -- [2]
						2464, -- [3]
						1553801823.154, -- [4]
						163226, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [3]
					{
						false, -- [1]
						162530, -- [2]
						6595, -- [3]
						1553801823.579, -- [4]
						169821, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [4]
					{
						false, -- [1]
						191840, -- [2]
						2398, -- [3]
						1553801823.675, -- [4]
						172219, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						29694, -- [3]
						1553801824.005, -- [4]
						201913, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [6]
					{
						false, -- [1]
						162530, -- [2]
						3290, -- [3]
						1553801824.317, -- [4]
						205203, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [7]
					{
						false, -- [1]
						275499, -- [2]
						3070, -- [3]
						1553801824.44, -- [4]
						208273, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [8]
					{
						false, -- [1]
						61295, -- [2]
						2153, -- [3]
						1553801824.882, -- [4]
						210426, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [9]
					{
						false, -- [1]
						162530, -- [2]
						3283, -- [3]
						1553801825.025, -- [4]
						213709, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [10]
					{
						false, -- [1]
						145110, -- [2]
						7409, -- [3]
						1553801825.235, -- [4]
						221118, -- [5]
						"Isery", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [11]
					{
						true, -- [1]
						287513, -- [2]
						180673, -- [3]
						1553801825.338, -- [4]
						40445, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						4, -- [1]
						287513, -- [2]
						1, -- [3]
						1553801825.338, -- [4]
						40445, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						280052, -- [2]
						10017, -- [3]
						1553801825.363, -- [4]
						50462, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [14]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553801825.363, -- [4]
						50462, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						1194, -- [3]
						1553801825.582, -- [4]
						51656, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [16]
					{
						false, -- [1]
						162530, -- [2]
						6565, -- [3]
						1553801825.729, -- [4]
						58221, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						191840, -- [2]
						14817, -- [3]
						1553801825.757, -- [4]
						73038, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [18]
					{
						false, -- [1]
						162530, -- [2]
						3275, -- [3]
						1553801826.449, -- [4]
						76313, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [19]
					{
						false, -- [1]
						61295, -- [2]
						5766, -- [3]
						1553801826.602, -- [4]
						82079, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [20]
					{
						false, -- [1]
						191894, -- [2]
						23989, -- [3]
						1553801826.837, -- [4]
						106068, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						191894, -- [2]
						23990, -- [3]
						1553801826.837, -- [4]
						130058, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [22]
					{
						true, -- [1]
						287513, -- [2]
						22585, -- [3]
						1553801827.346, -- [4]
						107473, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						275499, -- [2]
						1988, -- [3]
						1553801827.439, -- [4]
						109461, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [24]
					{
						false, -- [1]
						191840, -- [2]
						1191, -- [3]
						1553801827.471, -- [4]
						110652, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						false, -- [1]
						61295, -- [2]
						26680, -- [3]
						1553801827.989, -- [4]
						137332, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [26]
					{
						4, -- [1]
						284556, -- [2]
						1, -- [3]
						1553801828.01, -- [4]
						137332, -- [5]
						"[*] Shadow-Touched", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						true, -- [1]
						287645, -- [2]
						135506, -- [3]
						1553801828.079, -- [4]
						1826, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						61295, -- [2]
						3349, -- [3]
						1553801828.344, -- [4]
						5175, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [29]
					{
						false, -- [1]
						119611, -- [2]
						5167, -- [3]
						1553801828.741, -- [4]
						10342, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						false, -- [1]
						157503, -- [2]
						1516, -- [3]
						1553801828.837, -- [4]
						11858, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [31]
					{
						true, -- [1]
						287513, -- [2]
						10342, -- [3]
						1553801828.87, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						197432, -- [10]
					}, -- [32]
					{
						3, -- [1]
						108271, -- [2]
						1, -- [3]
						1553801803.793, -- [4]
						0, -- [5]
						"Soely", -- [6]
					}, -- [33]
				},
				["class"] = "SHAMAN",
				["timestring"] = "5m 14s",
				["time"] = 1553801828.87,
			}, -- [5]
			{
				["maxhealth"] = 224520,
				["timeofdeath"] = 315.877,
				["name"] = "Isery",
				["events"] = {
					{
						true, -- [1]
						287651, -- [2]
						7946, -- [3]
						1553801819.014, -- [4]
						218811, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						162530, -- [2]
						1656, -- [3]
						1553801820.03, -- [4]
						220467, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						145109, -- [2]
						7408, -- [3]
						1553801820.227, -- [4]
						227875, -- [5]
						"Isery", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						true, -- [1]
						287651, -- [2]
						7947, -- [3]
						1553801820.667, -- [4]
						172774, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						162530, -- [2]
						1656, -- [3]
						1553801820.741, -- [4]
						174430, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						7469, -- [3]
						1553801821.277, -- [4]
						181899, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [6]
					{
						false, -- [1]
						162530, -- [2]
						3313, -- [3]
						1553801821.448, -- [4]
						185212, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						287651, -- [2]
						7947, -- [3]
						1553801821.989, -- [4]
						177265, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						162530, -- [2]
						3305, -- [3]
						1553801822.152, -- [4]
						180570, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						191840, -- [2]
						14907, -- [3]
						1553801822.585, -- [4]
						195477, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						true, -- [1]
						287651, -- [2]
						7946, -- [3]
						1553801822.667, -- [4]
						187531, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [11]
					{
						false, -- [1]
						162530, -- [2]
						3297, -- [3]
						1553801822.875, -- [4]
						190828, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						false, -- [1]
						191840, -- [2]
						2399, -- [3]
						1553801823.19, -- [4]
						193227, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						162530, -- [2]
						3298, -- [3]
						1553801823.579, -- [4]
						196525, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						191840, -- [2]
						29694, -- [3]
						1553801823.844, -- [4]
						226219, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						29694, -- [3]
						1553801824.79, -- [4]
						246960, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						191840, -- [2]
						1194, -- [3]
						1553801825.097, -- [4]
						246960, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						true, -- [1]
						287651, -- [2]
						7946, -- [3]
						1553801825.634, -- [4]
						239014, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						162530, -- [2]
						6565, -- [3]
						1553801825.729, -- [4]
						245579, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						true, -- [1]
						287651, -- [2]
						7946, -- [3]
						1553801826.286, -- [4]
						237633, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						191840, -- [2]
						14786, -- [3]
						1553801826.386, -- [4]
						246960, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						162530, -- [2]
						6550, -- [3]
						1553801826.449, -- [4]
						246960, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						191840, -- [2]
						1191, -- [3]
						1553801826.992, -- [4]
						246960, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						275499, -- [2]
						692, -- [3]
						1553801827.439, -- [4]
						246960, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						true, -- [1]
						287651, -- [2]
						7946, -- [3]
						1553801827.931, -- [4]
						239014, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						287645, -- [2]
						136920, -- [3]
						1553801828.079, -- [4]
						102094, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						157503, -- [2]
						1515, -- [3]
						1553801828.87, -- [4]
						103609, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						false, -- [1]
						191840, -- [2]
						2220, -- [3]
						1553801828.904, -- [4]
						105829, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						true, -- [1]
						287651, -- [2]
						7947, -- [3]
						1553801829.562, -- [4]
						97882, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						145109, -- [2]
						7409, -- [3]
						1553801830.206, -- [4]
						105291, -- [5]
						"Isery", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						true, -- [1]
						287651, -- [2]
						7946, -- [3]
						1553801830.233, -- [4]
						97345, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287513, -- [2]
						97345, -- [3]
						1553801830.634, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						87059, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Isery", -- [6]
					}, -- [33]
				},
				["class"] = "DRUID",
				["timestring"] = "5m 15s",
				["time"] = 1553801830.634,
			}, -- [6]
			{
				["maxhealth"] = 230560,
				["timeofdeath"] = 318.322999999997,
				["name"] = "Hornpubmonk",
				["events"] = {
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801825.956, -- [4]
						242725, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						false, -- [1]
						143924, -- [2]
						1851, -- [3]
						1553801826.125, -- [4]
						244576, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						162530, -- [2]
						3275, -- [3]
						1553801826.449, -- [4]
						247851, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801826.95, -- [4]
						238538, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						119611, -- [2]
						11115, -- [3]
						1553801827.073, -- [4]
						249653, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						191840, -- [2]
						1191, -- [3]
						1553801827.142, -- [4]
						250844, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						143924, -- [2]
						1148, -- [3]
						1553801827.362, -- [4]
						251992, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						true, -- [1]
						287645, -- [2]
						132803, -- [3]
						1553801828.079, -- [4]
						119189, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						64, -- [3]
						1553801828.573, -- [4]
						119253, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						157503, -- [2]
						1515, -- [3]
						1553801828.87, -- [4]
						120768, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						119611, -- [2]
						10360, -- [3]
						1553801828.99, -- [4]
						131128, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						191840, -- [2]
						1196, -- [3]
						1553801829.063, -- [4]
						132324, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						143924, -- [2]
						1137, -- [3]
						1553801829.777, -- [4]
						133461, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801829.908, -- [4]
						124148, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						287568, -- [2]
						9313, -- [3]
						1553801830.573, -- [4]
						124148, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801830.573, -- [4]
						124148, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						119611, -- [2]
						5205, -- [3]
						1553801830.862, -- [4]
						129353, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						false, -- [1]
						287568, -- [2]
						9313, -- [3]
						1553801830.906, -- [4]
						129353, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801830.906, -- [4]
						129353, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						191840, -- [2]
						2404, -- [3]
						1553801830.947, -- [4]
						131757, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						false, -- [1]
						143924, -- [2]
						153, -- [3]
						1553801831.011, -- [4]
						131910, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						287568, -- [2]
						9313, -- [3]
						1553801831.233, -- [4]
						131910, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801831.233, -- [4]
						131910, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						287568, -- [2]
						9313, -- [3]
						1553801831.544, -- [4]
						131910, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801831.544, -- [4]
						131910, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						false, -- [1]
						143924, -- [2]
						90, -- [3]
						1553801832.219, -- [4]
						132000, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [26]
					{
						false, -- [1]
						287568, -- [2]
						2771, -- [3]
						1553801832.569, -- [4]
						132000, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801832.569, -- [4]
						125458, -- [5]
						"Yalat's Bulwark", -- [6]
						2771, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						119611, -- [2]
						10435, -- [3]
						1553801832.765, -- [4]
						135893, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						191840, -- [2]
						1205, -- [3]
						1553801832.867, -- [4]
						137098, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						true, -- [1]
						287651, -- [2]
						9313, -- [3]
						1553801832.884, -- [4]
						127785, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287640, -- [2]
						127785, -- [3]
						1553801833.08, -- [4]
						1, -- [5]
						"Volatile Charge <Tyrellan>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						5018, -- [10]
					}, -- [32]
					{
						3, -- [1]
						243435, -- [2]
						1, -- [3]
						1553801606.431, -- [4]
						0, -- [5]
						"Hornpubmonk", -- [6]
					}, -- [33]
				},
				["class"] = "MONK",
				["timestring"] = "5m 18s",
				["time"] = 1553801833.08,
			}, -- [7]
			{
				["maxhealth"] = 230360,
				["timeofdeath"] = 318.322999999997,
				["name"] = "Nelwyn",
				["events"] = {
					{
						false, -- [1]
						275499, -- [2]
						774, -- [3]
						1553801824.44, -- [4]
						214207, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						false, -- [1]
						191840, -- [2]
						29693, -- [3]
						1553801824.482, -- [4]
						243900, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						143924, -- [2]
						73, -- [3]
						1553801824.925, -- [4]
						243973, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [3]
					{
						true, -- [1]
						287651, -- [2]
						7540, -- [3]
						1553801824.966, -- [4]
						236433, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						162530, -- [2]
						6565, -- [3]
						1553801825.025, -- [4]
						242998, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [5]
					{
						false, -- [1]
						145109, -- [2]
						7601, -- [3]
						1553801825.634, -- [4]
						250599, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						false, -- [1]
						162530, -- [2]
						3282, -- [3]
						1553801825.729, -- [4]
						253380, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						4, -- [1]
						284664, -- [2]
						1, -- [3]
						1553801825.785, -- [4]
						253380, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						191840, -- [2]
						1191, -- [3]
						1553801826.07, -- [4]
						253380, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						false, -- [1]
						191840, -- [2]
						14785, -- [3]
						1553801826.209, -- [4]
						253380, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						false, -- [1]
						162530, -- [2]
						3275, -- [3]
						1553801826.449, -- [4]
						253380, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						4, -- [1]
						284664, -- [2]
						2, -- [3]
						1553801826.761, -- [4]
						253380, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						true, -- [1]
						287651, -- [2]
						7540, -- [3]
						1553801827.271, -- [4]
						245840, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						101, -- [3]
						1553801827.362, -- [4]
						245941, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						true, -- [1]
						287651, -- [2]
						7540, -- [3]
						1553801827.606, -- [4]
						238401, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						1194, -- [3]
						1553801827.949, -- [4]
						239595, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						true, -- [1]
						287645, -- [2]
						130082, -- [3]
						1553801828.079, -- [4]
						109513, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [17]
					{
						true, -- [1]
						287651, -- [2]
						7540, -- [3]
						1553801828.258, -- [4]
						101973, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						false, -- [1]
						143924, -- [2]
						167, -- [3]
						1553801828.573, -- [4]
						102140, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						4, -- [1]
						284664, -- [2]
						3, -- [3]
						1553801828.773, -- [4]
						102140, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						false, -- [1]
						157503, -- [2]
						1516, -- [3]
						1553801828.87, -- [4]
						103656, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [21]
					{
						false, -- [1]
						143924, -- [2]
						60, -- [3]
						1553801829.799, -- [4]
						103716, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						191840, -- [2]
						1199, -- [3]
						1553801829.856, -- [4]
						104915, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						false, -- [1]
						145109, -- [2]
						7601, -- [3]
						1553801830.634, -- [4]
						112516, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [24]
					{
						false, -- [1]
						287568, -- [2]
						7540, -- [3]
						1553801830.906, -- [4]
						112516, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [25]
					{
						true, -- [1]
						287651, -- [2]
						7540, -- [3]
						1553801830.906, -- [4]
						112516, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						143924, -- [2]
						183, -- [3]
						1553801831.011, -- [4]
						112699, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						287568, -- [2]
						7540, -- [3]
						1553801831.544, -- [4]
						112699, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [28]
					{
						true, -- [1]
						287651, -- [2]
						7540, -- [3]
						1553801831.544, -- [4]
						112699, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						191840, -- [2]
						2403, -- [3]
						1553801831.749, -- [4]
						115102, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [30]
					{
						false, -- [1]
						143924, -- [2]
						175, -- [3]
						1553801832.219, -- [4]
						115277, -- [5]
						"Nelwyn", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287640, -- [2]
						115277, -- [3]
						1553801833.062, -- [4]
						1, -- [5]
						"Volatile Charge <Tyrellan>", -- [6]
						nil, -- [7]
						8, -- [8]
						false, -- [9]
						14805, -- [10]
					}, -- [32]
					{
						3, -- [1]
						22812, -- [2]
						1, -- [3]
						1553801802.442, -- [4]
						0, -- [5]
						"Nelwyn", -- [6]
					}, -- [33]
				},
				["class"] = "DRUID",
				["timestring"] = "5m 18s",
				["time"] = 1553801833.08,
			}, -- [8]
			{
				["maxhealth"] = 220760,
				["timeofdeath"] = 321.797999999995,
				["name"] = "Tyrellan",
				["events"] = {
					{
						false, -- [1]
						191894, -- [2]
						44609, -- [3]
						1553801828.592, -- [4]
						174411, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [1]
					{
						4, -- [1]
						287513, -- [2]
						2, -- [3]
						1553801828.87, -- [4]
						174411, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [2]
					{
						false, -- [1]
						157503, -- [2]
						1516, -- [3]
						1553801828.87, -- [4]
						175927, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						191840, -- [2]
						2220, -- [3]
						1553801828.922, -- [4]
						178147, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [4]
					{
						false, -- [1]
						143924, -- [2]
						82, -- [3]
						1553801828.99, -- [4]
						178229, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						4, -- [1]
						287513, -- [2]
						3, -- [3]
						1553801829.428, -- [4]
						178229, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						4, -- [1]
						287513, -- [2]
						4, -- [3]
						1553801830.016, -- [4]
						178229, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [7]
					{
						false, -- [1]
						288333, -- [2]
						643, -- [3]
						1553801830.075, -- [4]
						178872, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [8]
					{
						false, -- [1]
						143924, -- [2]
						376, -- [3]
						1553801830.206, -- [4]
						179248, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [9]
					{
						false, -- [1]
						119611, -- [2]
						5192, -- [3]
						1553801830.464, -- [4]
						184440, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [10]
					{
						4, -- [1]
						287513, -- [2]
						5, -- [3]
						1553801830.634, -- [4]
						184440, -- [5]
						"Yalat's Bulwark", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						false, -- [1]
						191840, -- [2]
						2225, -- [3]
						1553801830.824, -- [4]
						186665, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [12]
					{
						false, -- [1]
						288333, -- [2]
						649, -- [3]
						1553801831.544, -- [4]
						187314, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						false, -- [1]
						143924, -- [2]
						55, -- [3]
						1553801831.827, -- [4]
						187369, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [14]
					{
						false, -- [1]
						119611, -- [2]
						5620, -- [3]
						1553801832.367, -- [4]
						192989, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						false, -- [1]
						191840, -- [2]
						1118, -- [3]
						1553801832.709, -- [4]
						194107, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [16]
					{
						false, -- [1]
						288333, -- [2]
						1325, -- [3]
						1553801833.008, -- [4]
						195432, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						143924, -- [2]
						114, -- [3]
						1553801833.028, -- [4]
						195546, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [18]
					{
						false, -- [1]
						119611, -- [2]
						3867, -- [3]
						1553801834.272, -- [4]
						199413, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						false, -- [1]
						288333, -- [2]
						669, -- [3]
						1553801834.504, -- [4]
						200082, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [20]
					{
						true, -- [1]
						287513, -- [2]
						100080, -- [3]
						1553801834.54, -- [4]
						100002, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [21]
					{
						false, -- [1]
						191840, -- [2]
						414, -- [3]
						1553801834.612, -- [4]
						100416, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [22]
					{
						false, -- [1]
						143924, -- [2]
						57, -- [3]
						1553801834.659, -- [4]
						100473, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [23]
					{
						true, -- [1]
						287651, -- [2]
						9279, -- [3]
						1553801835.867, -- [4]
						91194, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						false, -- [1]
						288333, -- [2]
						672, -- [3]
						1553801836.011, -- [4]
						91866, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						false, -- [1]
						288333, -- [2]
						38, -- [3]
						1553801836.075, -- [4]
						91904, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						false, -- [1]
						119611, -- [2]
						1933, -- [3]
						1553801836.168, -- [4]
						93837, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [27]
					{
						true, -- [1]
						283610, -- [2]
						36998, -- [3]
						1553801836.245, -- [4]
						56839, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						false, -- [1]
						143924, -- [2]
						1554, -- [3]
						1553801836.294, -- [4]
						58393, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [29]
					{
						false, -- [1]
						191840, -- [2]
						414, -- [3]
						1553801836.532, -- [4]
						58807, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						true, -- [1]
						287651, -- [2]
						9250, -- [3]
						1553801836.532, -- [4]
						49557, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287513, -- [2]
						49557, -- [3]
						1553801836.532, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						4, -- [8]
						false, -- [9]
						50207, -- [10]
					}, -- [32]
					{
						3, -- [1]
						196555, -- [2]
						1, -- [3]
						1553801828.384, -- [4]
						0, -- [5]
						"Tyrellan", -- [6]
					}, -- [33]
				},
				["class"] = "DEMONHUNTER",
				["timestring"] = "5m 21s",
				["time"] = 1553801836.555,
			}, -- [9]
			{
				["maxhealth"] = 234420,
				["timeofdeath"] = 323.762999999999,
				["name"] = "Aspern",
				["events"] = {
					{
						false, -- [1]
						191840, -- [2]
						1197, -- [3]
						1553801824.317, -- [4]
						234420, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [1]
					{
						true, -- [1]
						287651, -- [2]
						9947, -- [3]
						1553801824.637, -- [4]
						224473, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [2]
					{
						false, -- [1]
						191840, -- [2]
						14816, -- [3]
						1553801825.263, -- [4]
						234420, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [3]
					{
						false, -- [1]
						119611, -- [2]
						11115, -- [3]
						1553801825.915, -- [4]
						234420, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [4]
					{
						false, -- [1]
						191840, -- [2]
						1191, -- [3]
						1553801826.209, -- [4]
						234420, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [5]
					{
						false, -- [1]
						275499, -- [2]
						988, -- [3]
						1553801827.439, -- [4]
						234420, -- [5]
						"Cloudburst Totem <Soely>", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [6]
					{
						true, -- [1]
						287645, -- [2]
						134170, -- [3]
						1553801828.079, -- [4]
						100250, -- [5]
						"Tyrellan", -- [6]
						nil, -- [7]
						8, -- [8]
						true, -- [9]
						-1, -- [10]
					}, -- [7]
					{
						false, -- [1]
						191840, -- [2]
						1107, -- [3]
						1553801828.13, -- [4]
						101357, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [8]
					{
						false, -- [1]
						157503, -- [2]
						1516, -- [3]
						1553801828.87, -- [4]
						102873, -- [5]
						"Soely", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [9]
					{
						false, -- [1]
						191840, -- [2]
						2225, -- [3]
						1553801830.016, -- [4]
						105098, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [10]
					{
						false, -- [1]
						287568, -- [2]
						9947, -- [3]
						1553801830.573, -- [4]
						105098, -- [5]
						"Hornpubmonk", -- [6]
						true, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [11]
					{
						true, -- [1]
						287651, -- [2]
						9947, -- [3]
						1553801830.573, -- [4]
						105098, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [12]
					{
						4, -- [1]
						284664, -- [2]
						1, -- [3]
						1553801830.73, -- [4]
						105098, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [13]
					{
						4, -- [1]
						284664, -- [2]
						2, -- [3]
						1553801831.719, -- [4]
						105098, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [14]
					{
						false, -- [1]
						191840, -- [2]
						1204, -- [3]
						1553801831.932, -- [4]
						106302, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [15]
					{
						4, -- [1]
						284664, -- [2]
						3, -- [3]
						1553801832.748, -- [4]
						106302, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [16]
					{
						4, -- [1]
						284664, -- [2]
						4, -- [3]
						1553801833.734, -- [4]
						106302, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [17]
					{
						false, -- [1]
						191840, -- [2]
						414, -- [3]
						1553801833.807, -- [4]
						106716, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [18]
					{
						true, -- [1]
						287651, -- [2]
						9948, -- [3]
						1553801834.54, -- [4]
						96768, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [19]
					{
						4, -- [1]
						284664, -- [2]
						5, -- [3]
						1553801834.73, -- [4]
						96768, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [20]
					{
						false, -- [1]
						191840, -- [2]
						414, -- [3]
						1553801835.715, -- [4]
						97182, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
					}, -- [21]
					{
						4, -- [1]
						284664, -- [2]
						6, -- [3]
						1553801835.715, -- [4]
						97182, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [22]
					{
						true, -- [1]
						287651, -- [2]
						9947, -- [3]
						1553801836.187, -- [4]
						87235, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [23]
					{
						true, -- [1]
						283610, -- [2]
						39790, -- [3]
						1553801836.245, -- [4]
						47445, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [24]
					{
						4, -- [1]
						284664, -- [2]
						7, -- [3]
						1553801836.741, -- [4]
						47445, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [25]
					{
						true, -- [1]
						287651, -- [2]
						9947, -- [3]
						1553801836.858, -- [4]
						37498, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [26]
					{
						true, -- [1]
						287651, -- [2]
						11440, -- [3]
						1553801837.504, -- [4]
						26058, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [27]
					{
						false, -- [1]
						191840, -- [2]
						829, -- [3]
						1553801837.63, -- [4]
						26887, -- [5]
						"Hornpubmonk", -- [6]
						nil, -- [7]
						0, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [28]
					{
						4, -- [1]
						284664, -- [2]
						8, -- [3]
						1553801837.728, -- [4]
						26887, -- [5]
						"[*] Incandescence", -- [6]
						false, -- [7]
						false, -- [8]
						false, -- [9]
						false, -- [10]
					}, -- [29]
					{
						true, -- [1]
						287651, -- [2]
						11440, -- [3]
						1553801837.84, -- [4]
						15447, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [30]
					{
						true, -- [1]
						287651, -- [2]
						11440, -- [3]
						1553801838.156, -- [4]
						4007, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						-1, -- [10]
					}, -- [31]
					{
						true, -- [1]
						287651, -- [2]
						4007, -- [3]
						1553801838.52, -- [4]
						1, -- [5]
						"Yalat's Bulwark", -- [6]
						nil, -- [7]
						1, -- [8]
						false, -- [9]
						7433, -- [10]
					}, -- [32]
					{
						3, -- [1]
						0, -- [2]
						0, -- [3]
						0, -- [4]
						0, -- [5]
						"Aspern", -- [6]
					}, -- [33]
				},
				["class"] = "MAGE",
				["timestring"] = "5m 23s",
				["time"] = 1553801838.52,
			}, -- [10]
		},
		["bossname"] = "Opulence",
		["bossicon"] = {
			0.75, -- [1]
			1, -- [2]
			0, -- [3]
			0.25, -- [4]
			"Interface\\AddOns\\Details\\images\\raid\\DazaralorRaid_BossFaces", -- [5]
		},
		["date"] = 37249.065,
		["timeelapsed"] = 349.156999999999,
	}, -- [2]
}
DeathGraphsDBGraph = {
	["233414"] = {
		["deaths"] = {
			[182] = {
				1552489071, -- [1]
			},
			[186] = {
				1552489071, -- [1]
			},
			[59] = {
				1552489071, -- [1]
			},
			[188] = {
				1552489071, -- [1]
			},
			[217] = {
				1552489071, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233315"] = {
		["deaths"] = {
			[131] = {
				1553012306, -- [1]
			},
			[135] = {
				1553009187, -- [1]
			},
			[228] = {
				1553014515, -- [1]
				1553014515, -- [2]
			},
			[61] = {
				1553010069, -- [1]
			},
			[62] = {
				1553010069, -- [1]
				1553010069, -- [2]
			},
			[182] = {
				1553014515, -- [1]
			},
			[64] = {
				1553010524, -- [1]
			},
			[128] = {
				1553013223, -- [1]
			},
			[85] = {
				1553010524, -- [1]
			},
			[101] = {
				1552424784, -- [1]
			},
			[72] = {
				1552425040, -- [1]
				1552425040, -- [2]
			},
			[74] = {
				1552425040, -- [1]
			},
			[210] = {
				1553014515, -- [1]
			},
			[110] = {
				1553014111, -- [1]
				1553014111, -- [2]
			},
			[122] = {
				1553014515, -- [1]
			},
			[44] = {
				1552424784, -- [1]
			},
			[48] = {
				1553014111, -- [1]
			},
			[137] = {
				1553009187, -- [1]
			},
			[88] = {
				1553010524, -- [1]
			},
			[138] = {
				1553012306, -- [1]
			},
			[260] = {
				1553013223, -- [1]
			},
			[267] = {
				1553013223, -- [1]
			},
			[124] = {
				1553013223, -- [1]
			},
			[184] = {
				1553013223, -- [1]
			},
			[100] = {
				1552424784, -- [1]
				1552424784, -- [2]
				1552424784, -- [3]
			},
			[71] = {
				1552425040, -- [1]
			},
			[134] = {
				1553012306, -- [1]
			},
			[168] = {
				1553014111, -- [1]
				1553014111, -- [2]
			},
			[63] = {
				1553010069, -- [1]
				1553010524, -- [2]
			},
			[56] = {
				1553010524, -- [1]
			},
			[57] = {
				1553010069, -- [1]
			},
			[93] = {
				1552425040, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233415"] = {
		["deaths"] = {
			[234] = {
				1553454483, -- [1]
			},
			[230] = {
				1553454483, -- [1]
				1553454483, -- [2]
			},
			[271] = {
				1553454483, -- [1]
				1553454483, -- [2]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234216"] = {
		["deaths"] = {
			[290] = {
				1553801864, -- [1]
			},
			[122] = {
				1553800753, -- [1]
			},
			[91] = {
				1553800294, -- [1]
			},
			[181] = {
				1553802146, -- [1]
			},
			[297] = {
				1553801864, -- [1]
			},
			[247] = {
				1553801452, -- [1]
			},
			[185] = {
				1553802146, -- [1]
			},
			[24] = {
				1553800753, -- [1]
			},
			[311] = {
				1553801864, -- [1]
			},
			[314] = {
				1553801864, -- [1]
			},
			[160] = {
				1553800531, -- [1]
			},
			[193] = {
				1553801452, -- [1]
			},
			[259] = {
				1553801117, -- [1]
				1553801117, -- [2]
				1553801117, -- [3]
			},
			[83] = {
				1553800294, -- [1]
			},
			[165] = {
				1553801452, -- [1]
			},
			[100] = {
				1553800753, -- [1]
			},
			[168] = {
				1553799956, -- [1]
				1553800531, -- [2]
			},
			[147] = {
				1553800531, -- [1]
			},
			[276] = {
				1553801117, -- [1]
			},
			[93] = {
				1553802146, -- [1]
				1553802146, -- [2]
			},
			[123] = {
				1553800753, -- [1]
			},
			[173] = {
				1553799956, -- [1]
			},
			[182] = {
				1553799956, -- [1]
			},
			[174] = {
				1553799956, -- [1]
			},
			[159] = {
				1553800531, -- [1]
				1553800531, -- [2]
				1553802146, -- [3]
			},
			[120] = {
				1553800753, -- [1]
			},
			[92] = {
				1553800294, -- [1]
				1553801117, -- [2]
			},
			[239] = {
				1553801864, -- [1]
			},
			[241] = {
				1553801452, -- [1]
			},
			[89] = {
				1553800294, -- [1]
			},
			[43] = {
				1553800294, -- [1]
			},
			[178] = {
				1553799956, -- [1]
			},
			[238] = {
				1553801452, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234215"] = {
		["deaths"] = {
			[83] = {
				1553015408, -- [1]
			},
			[174] = {
				1553115600, -- [1]
			},
			[91] = {
				1552423568, -- [1]
			},
			[124] = {
				1552423991, -- [1]
			},
			[186] = {
				1553016211, -- [1]
			},
			[221] = {
				1552423991, -- [1]
			},
			[198] = {
				1553114880, -- [1]
			},
			[241] = {
				1553114880, -- [1]
			},
			[195] = {
				1553016211, -- [1]
			},
			[187] = {
				1552423991, -- [1]
			},
			[189] = {
				1552423568, -- [1]
			},
			[84] = {
				1553015408, -- [1]
				1553015408, -- [2]
			},
			[199] = {
				1552423991, -- [1]
			},
			[180] = {
				1553015408, -- [1]
			},
			[231] = {
				1553114880, -- [1]
			},
			[259] = {
				1553115600, -- [1]
			},
			[125] = {
				1552423568, -- [1]
			},
			[188] = {
				1553016211, -- [1]
			},
			[130] = {
				1552423568, -- [1]
			},
			[200] = {
				1553015408, -- [1]
			},
			[138] = {
				1553115600, -- [1]
			},
			[182] = {
				1553114880, -- [1]
			},
			[177] = {
				1552423568, -- [1]
				1552423991, -- [2]
				1553115600, -- [3]
			},
			[261] = {
				1553114880, -- [1]
			},
			[185] = {
				1553016211, -- [1]
			},
			[81] = {
				1553115600, -- [1]
			},
			[193] = {
				1553016211, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233715"] = {
		["deaths"] = {
			[138] = {
				1553455344, -- [1]
			},
			[242] = {
				1553455344, -- [1]
			},
			[5] = {
				1553455344, -- [1]
			},
			[159] = {
				1553455344, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233015"] = {
		["deaths"] = {
			[107] = {
				1553452589, -- [1]
			},
			[159] = {
				1553117176, -- [1]
			},
			[121] = {
				1553117176, -- [1]
			},
			[164] = {
				1553117176, -- [1]
			},
			[172] = {
				1553452933, -- [1]
			},
			[109] = {
				1553452589, -- [1]
				1553452589, -- [2]
			},
			[173] = {
				1553452933, -- [1]
			},
			[117] = {
				1553117176, -- [1]
			},
			[144] = {
				1553452933, -- [1]
			},
			[110] = {
				1553452589, -- [1]
			},
			[114] = {
				1553117176, -- [1]
			},
			[113] = {
				1553452589, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233514"] = {
		["deaths"] = {
			[333] = {
				1552487321, -- [1]
			},
			[276] = {
				1552487321, -- [1]
			},
			[394] = {
				1552487321, -- [1]
				1552487321, -- [2]
			},
			[283] = {
				1552487321, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233014"] = {
		["deaths"] = {
			[213] = {
				1552485579, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["233316"] = {
		["deaths"] = {
			[31] = {
				1553796451, -- [1]
				1553796451, -- [2]
			},
			[38] = {
				1553797230, -- [1]
			},
			[91] = {
				1552497934, -- [1]
			},
			[294] = {
				1553797230, -- [1]
			},
			[76] = {
				1552497934, -- [1]
			},
			[152] = {
				1553624183, -- [1]
			},
			[93] = {
				1552498199, -- [1]
			},
			[94] = {
				1552497934, -- [1]
			},
			[32] = {
				1553796451, -- [1]
			},
			[189] = {
				1553798322, -- [1]
				1553798322, -- [2]
			},
			[159] = {
				1553624183, -- [1]
			},
			[193] = {
				1553797996, -- [1]
			},
			[225] = {
				1553797996, -- [1]
			},
			[194] = {
				1552497934, -- [1]
			},
			[163] = {
				1553797996, -- [1]
			},
			[164] = {
				1552498199, -- [1]
			},
			[133] = {
				1552496983, -- [1]
			},
			[69] = {
				1553797230, -- [1]
			},
			[85] = {
				1552497199, -- [1]
				1552497199, -- [2]
			},
			[201] = {
				1553798760, -- [1]
				1553798760, -- [2]
			},
			[86] = {
				1552497199, -- [1]
				1552497199, -- [2]
			},
			[202] = {
				1553798760, -- [1]
				1553798760, -- [2]
			},
			[118] = {
				1553796451, -- [1]
			},
			[140] = {
				1552496983, -- [1]
				1553624183, -- [2]
			},
			[172] = {
				1553624183, -- [1]
			},
			[141] = {
				1552496983, -- [1]
				1552496983, -- [2]
				1552496983, -- [3]
			},
			[119] = {
				1553796451, -- [1]
			},
			[314] = {
				1553798760, -- [1]
			},
			[88] = {
				1553797230, -- [1]
			},
			[143] = {
				1553624183, -- [1]
			},
			[170] = {
				1553798322, -- [1]
				1553798322, -- [2]
				1553798322, -- [3]
			},
			[144] = {
				1552497484, -- [1]
			},
			[89] = {
				1552497934, -- [1]
			},
			[259] = {
				1553797996, -- [1]
				1553797996, -- [2]
			},
			[87] = {
				1552497199, -- [1]
			},
			[136] = {
				1552497484, -- [1]
			},
			[90] = {
				1553797230, -- [1]
			},
			[206] = {
				1552497484, -- [1]
				1552497484, -- [2]
				1552497484, -- [3]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
	["234214"] = {
		["deaths"] = {
			[320] = {
				1552484054, -- [1]
			},
		},
		["spells"] = {
		},
		["ids"] = {
		},
	},
}
