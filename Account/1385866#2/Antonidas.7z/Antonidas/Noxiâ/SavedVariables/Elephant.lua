
ElephantDBPerChar = {
	["profileKeys"] = {
		["Noxiâ - Antonidas"] = "Noxiâ - Antonidas",
	},
	["char"] = {
		["Noxiâ - Antonidas"] = {
			["logs"] = {
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Whisper",
					["logs"] = {
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553080947,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [1]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553081276,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [2]
						{
							["arg2"] = "Tykero-Wrathbringer",
							["type"] = "WHISPER",
							["time"] = 1553081349,
							["arg1"] = "jo, wenn sich der tank auskennen würde dannja^^",
							["clColor"] = "ffa22fc8",
						}, -- [3]
						{
							["arg2"] = "Tykero-Wrathbringer",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553081360,
							["arg1"] = "aegwyn halt",
							["clColor"] = "ffa22fc8",
						}, -- [4]
						{
							["arg2"] = "Tykero-Wrathbringer",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553081364,
							["arg1"] = "hätte es wissen sollen",
							["clColor"] = "ffa22fc8",
						}, -- [5]
						{
							["arg2"] = "Tykero-Wrathbringer",
							["type"] = "WHISPER",
							["time"] = 1553081374,
							["arg1"] = "nrm ja xD",
							["clColor"] = "ffa22fc8",
						}, -- [6]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553081789,
							["arg1"] = "lust auf nen motherload 10?",
							["clColor"] = "fffe7b09",
						}, -- [7]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553081830,
							["arg1"] = "ich geh jetzt off muss noch was erledigen sry",
							["clColor"] = "fffe7b09",
						}, -- [8]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553081835,
							["arg1"] = "np",
							["clColor"] = "fffe7b09",
						}, -- [9]
						{
							["arg2"] = "Vdefregona-DunModr",
							["type"] = "WHISPER",
							["time"] = 1553081964,
							["arg1"] = "why ",
							["clColor"] = "ffa22fc8",
						}, -- [10]
						{
							["arg2"] = "Vdefregona-DunModr",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553082063,
							["arg1"] = "fuck off",
							["clColor"] = "ffa22fc8",
						}, -- [11]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553083937,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [12]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553084458,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [13]
						{
							["arg1"] = " ",
						}, -- [14]
						{
							["arg1"] = " ",
						}, -- [15]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/20/2019 at 21:22:54.",
						}, -- [16]
						{
							["arg2"] = "Helliøn-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553113837,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "ff006fdc",
						}, -- [17]
						{
							["arg2"] = "Aleriisa-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553115850,
							["arg1"] = "thanks for leaving <3",
							["clColor"] = "ffc31d39",
						}, -- [18]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553115910,
							["arg1"] = "hahaha",
							["clColor"] = "fffef367",
						}, -- [19]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553115910,
							["arg1"] = "<Deadly Boss Mods> Sukai is busy fighting against Heroic - Opulence (100% (Stage 1), 19/19 people alive)",
							["clColor"] = "fffef367",
						}, -- [20]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553115914,
							["arg1"] = "your logs are so fucking bad",
							["clColor"] = "fffef367",
						}, -- [21]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553115928,
							["arg1"] = "how are you this fucking terrible? xDDD",
							["clColor"] = "fffef367",
						}, -- [22]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553116076,
							["arg1"] = "<DBM> Sukai has wiped on Heroic - Opulence at 100% (Stage 1)",
							["clColor"] = "fffef367",
						}, -- [23]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553116082,
							["arg1"] = "i have better logs than you lmfao",
							["clColor"] = "fffef367",
						}, -- [24]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553116099,
							["arg1"] = "fucking embarrassment",
							["clColor"] = "fffef367",
						}, -- [25]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553116102,
							["arg1"] = "check ilvl you retard",
							["clColor"] = "fffef367",
						}, -- [26]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553116112,
							["arg1"] = "i got more than 10 ilvl less than you",
							["clColor"] = "fffef367",
						}, -- [27]
						{
							["arg2"] = "Sukai-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553116148,
							["arg1"] = "Yeah i can tell from your shit dps here",
							["clColor"] = "fffef367",
						}, -- [28]
						{
							["arg2"] = "Lilliyane-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553116431,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "ffa22fc8",
						}, -- [29]
						{
							["arg2"] = "Lilliyane-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553116432,
							["arg1"] = "<Deadly Boss Mods> Lilliyane ist damit beschäftigt gegen Heroisch - Opulenz zu kämpfen! (100% (Phase 1), 1/14 Spieler am Leben)",
							["clColor"] = "ffa22fc8",
						}, -- [30]
						{
							["arg2"] = "Lilliyane-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553116432,
							["arg1"] = "<DBM> Lilliyane war Heroisch - Opulenz bei 100% (Phase 1) unterlegen.",
							["clColor"] = "ffa22fc8",
						}, -- [31]
						{
							["arg2"] = "Osudjenik-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553116536,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "fff38bb9",
						}, -- [32]
						{
							["arg2"] = "Osudjenik-Sylvanas",
							["type"] = "WHISPER",
							["time"] = 1553116555,
							["arg1"] = "sry m8 grp is sooooooo melee heavy ",
							["clColor"] = "fff38bb9",
						}, -- [33]
						{
							["arg2"] = "Osudjenik-Sylvanas",
							["type"] = "WHISPER",
							["time"] = 1553116559,
							["arg1"] = "i rly need ranged ",
							["clColor"] = "fff38bb9",
						}, -- [34]
						{
							["arg2"] = "Osudjenik-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553116579,
							["arg1"] = "what if I change to my main? He's a hunter. Just need the boss for my DH buddy^^",
							["clColor"] = "fff38bb9",
						}, -- [35]
						{
							["arg2"] = "Eyowín-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553116702,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "fffe7b09",
						}, -- [36]
						{
							["arg2"] = "Eyowín-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553116702,
							["arg1"] = "<Deadly Boss Mods> Eyowín ist damit beschäftigt gegen Heroisch - Konklave der Auserwählten zu kämpfen! (98% (2 von 4 Bossen besiegt), 1/17 Spieler am Leben)",
							["clColor"] = "fffe7b09",
						}, -- [37]
						{
							["arg2"] = "Eyowín-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553116706,
							["arg1"] = "<DBM> Eyowín war Heroisch - Konklave der Auserwählten bei 98% (2 von 4 Bossen besiegt) unterlegen.",
							["clColor"] = "fffe7b09",
						}, -- [38]
						{
							["arg1"] = " ",
						}, -- [39]
						{
							["arg1"] = " ",
						}, -- [40]
						{
							["arg1"] = "Logging started on 03/21/2019 at 11:21:20.",
							["type"] = "SYSTEM",
						}, -- [41]
						{
							["arg2"] = "Fittpiss-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553164227,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "fffe7b09",
						}, -- [42]
						{
							["arg2"] = "Jarsel-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553164274,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "fffe7b09",
						}, -- [43]
						{
							["arg2"] = "Jarsel-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553164274,
							["arg1"] = "<Deadly Boss Mods> Jarsel is busy fighting against Heroic - Opulence (100% (Stage 1), 22/22 people alive)",
							["clColor"] = "fffe7b09",
						}, -- [44]
						{
							["arg2"] = "Jarsel-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553164591,
							["arg1"] = "<DBM> Jarsel has defeated Heroic - Opulence!",
							["clColor"] = "fffe7b09",
						}, -- [45]
						{
							["arg1"] = " ",
						}, -- [46]
						{
							["arg1"] = " ",
						}, -- [47]
						{
							["arg1"] = "Logging started on 03/24/2019 at 20:43:07.",
							["type"] = "SYSTEM",
						}, -- [48]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553457903,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [49]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553458009,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [50]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553458422,
							["arg1"] = "Haha! Now dat was an impressive death!",
						}, -- [51]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553458611,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [52]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553458679,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [53]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553459342,
							["arg1"] = "Haha! Now dat was an impressive death!",
						}, -- [54]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553459406,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [55]
						{
							["arg1"] = " ",
						}, -- [56]
						{
							["arg1"] = " ",
						}, -- [57]
						{
							["arg1"] = "Logging started on 03/25/2019 at 12:16:35.",
							["type"] = "SYSTEM",
						}, -- [58]
						{
							["arg2"] = "Elhendil-Pozzodell'Eternità",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553518625,
							["arg1"] = "Hey :) If you don't need |cffa335ee|Hitem:159327::::::::120:260::16:4:5007:40:1562:4786:::|h[Sand-Shined Snakeskin Sandals]|h|r, I would very much appreciate it <3",
							["clColor"] = "fffe7b09",
						}, -- [59]
						{
							["arg2"] = "Demonblade-Turalyon",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553518626,
							["arg1"] = "Hey :) If you don't need |cffa335ee|Hitem:159347::::::::120:260::16:3:5007:1562:4786:::|h[Moss-Covered Wingtip Shoes]|h|r, I would very much appreciate it <3",
							["clColor"] = "ffa22fc8",
						}, -- [60]
						{
							["arg2"] = "Demonblade-Turalyon",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553518657,
							["arg1"] = "thx <3",
							["clColor"] = "ffa22fc8",
						}, -- [61]
						{
							["arg1"] = " ",
						}, -- [62]
						{
							["arg1"] = " ",
						}, -- [63]
						{
							["arg1"] = "Logging started on 03/25/2019 at 15:41:04.",
							["type"] = "SYSTEM",
						}, -- [64]
						{
							["arg2"] = "Darktide-GrimBatol",
							["type"] = "WHISPER",
							["time"] = 1553526952,
							["arg1"] = "take em and fuck him",
							["clColor"] = "ffa22fc8",
						}, -- [65]
						{
							["arg2"] = "Darktide-GrimBatol",
							["type"] = "WHISPER",
							["time"] = 1553526976,
							["arg1"] = "report him",
							["clColor"] = "ffa22fc8",
						}, -- [66]
						{
							["arg2"] = "Darktide-GrimBatol",
							["type"] = "WHISPER",
							["time"] = 1553527320,
							["arg1"] = "he is getting banded trust me",
							["clColor"] = "ffa22fc8",
						}, -- [67]
						{
							["arg2"] = "Darktide-GrimBatol",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553527330,
							["arg1"] = "let'S hope it^^",
							["clColor"] = "ffa22fc8",
						}, -- [68]
						{
							["arg2"] = "Darktide-GrimBatol",
							["type"] = "WHISPER",
							["time"] = 1553527363,
							["arg1"] = "well you dont write shit like that to someone, i wrote what he said. Its a ban for sure",
							["clColor"] = "ffa22fc8",
						}, -- [69]
						{
							["arg2"] = "Darktide-GrimBatol",
							["type"] = "WHISPER",
							["time"] = 1553527391,
							["arg1"] = "hope she will get bether tho bro :)",
							["clColor"] = "ffa22fc8",
						}, -- [70]
						{
							["arg1"] = " ",
						}, -- [71]
						{
							["arg1"] = " ",
						}, -- [72]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:48:48.",
						}, -- [73]
						{
							["arg2"] = "Gêzeichnete-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553622667,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "ffc31d39",
						}, -- [74]
						{
							["arg2"] = "Nelanas-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553622869,
							["arg1"] = "inv heal",
							["clColor"] = "fffe7b09",
						}, -- [75]
						{
							["arg2"] = "Waybrighter-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553622887,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-06A13137:1:3:4:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: King Rastakhan]|h|r",
							["clColor"] = "fffe7b09",
						}, -- [76]
						{
							["arg2"] = "Marrnie-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553622923,
							["arg1"] = "|cffffff00|Hachievement:13292:Player-3686-0464A915:1:3:10:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Champion des Lichts]|h|r",
							["clColor"] = "ffc59a6c",
						}, -- [77]
						{
							["arg2"] = "Lathors-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623022,
							["arg1"] = "|cffffff00|Hachievement:13292:Player-3686-069026B8:1:3:4:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Champion des Lichts]|h|r",
							["clColor"] = "ff3ec5e9",
						}, -- [78]
						{
							["arg2"] = "Falok-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623026,
							["arg1"] = "wäre heal",
							["clColor"] = "ff006fdc",
						}, -- [79]
						{
							["arg2"] = "Thorgrond-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623064,
							["arg1"] = "hi, |cffffff00|Hachievement:13292:Player-3686-06105456:1:2:6:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Champion des Lichts]|h|r",
							["clColor"] = "ffc59a6c",
						}, -- [80]
						{
							["arg2"] = "Moonkeep-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623132,
							["arg1"] = "|cffffff00|Hachievement:13300:Player-3686-05E39F77:1:3:24:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Konklave der Auserwählten]|h|r",
							["clColor"] = "ff3ec5e9",
						}, -- [81]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623185,
							["arg1"] = "also ein main tank der jaina myth 14% try xp hat ablehnen wegen 383 gear? :D",
							["clColor"] = "ffc59a6c",
						}, -- [82]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623218,
							["arg1"] = "hast du mir dazu was gepostet? Glaub nicht",
							["clColor"] = "ffc59a6c",
						}, -- [83]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623230,
							["arg1"] = "|cffffff00|Hachievement:13292:Player-3686-044D5C64:1:2:3:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Champion des Lichts]|h|r?",
							["clColor"] = "ffc59a6c",
						}, -- [84]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623237,
							["arg1"] = "den :)",
							["clColor"] = "ffc59a6c",
						}, -- [85]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623246,
							["arg1"] = "oder willst du die anderen? :D",
							["clColor"] = "ffc59a6c",
						}, -- [86]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623254,
							["arg1"] = "mom kurz",
							["clColor"] = "ffc59a6c",
						}, -- [87]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623286,
							["arg1"] = "ablehnung kam hauptsächlich weil wir schon 3 tanks sind",
							["clColor"] = "ffc59a6c",
						}, -- [88]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623300,
							["arg1"] = "naja egal ;)",
							["clColor"] = "ffc59a6c",
						}, -- [89]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623338,
							["arg1"] = "der char ist 2 tage erst 120 soll ja nicht sein ;)",
							["clColor"] = "ffc59a6c",
						}, -- [90]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623359,
							["arg1"] = "außerdem, wie bist du schon bei jaina, wenn du erst vor 2 wochen champion gelegt hast?",
							["clColor"] = "ffc59a6c",
						}, -- [91]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623369,
							["arg1"] = "mit twinks?",
							["clColor"] = "ffc59a6c",
						}, -- [92]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623378,
							["arg1"] = "ich habe noch 2 twinks ",
							["clColor"] = "ffc59a6c",
						}, -- [93]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623391,
							["arg1"] = "|cffffff00|Hachievement:13298:Player-3686-044D5C64:1:2:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Jadefeuermeister]|h|r",
							["clColor"] = "ffc59a6c",
						}, -- [94]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623392,
							["arg1"] = "|cffffff00|Hachievement:13300:Player-3686-044D5C64:1:2:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: Konklave der Auserwählten]|h|r",
							["clColor"] = "ffc59a6c",
						}, -- [95]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623394,
							["arg1"] = "|cffffff00|Hachievement:13311:Player-3686-044D5C64:1:2:11:19:4294967295:4294967295:4294967295:4294967295|h[Mythisch: König Rastakhan]|h|r",
							["clColor"] = "ffc59a6c",
						}, -- [96]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623396,
							["arg1"] = "usw",
							["clColor"] = "ffc59a6c",
						}, -- [97]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623442,
							["arg1"] = "ach, sehe eben erst die gilde",
							["clColor"] = "ffc59a6c",
						}, -- [98]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623444,
							["arg1"] = "nvm",
							["clColor"] = "ffc59a6c",
						}, -- [99]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623449,
							["arg1"] = "ah",
							["clColor"] = "ffc59a6c",
						}, -- [100]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623449,
							["arg1"] = "passt^^",
							["clColor"] = "ffc59a6c",
						}, -- [101]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623462,
							["arg1"] = "aber wie gesagt, leider schon voll, was tanks angeht",
							["clColor"] = "ffc59a6c",
						}, -- [102]
						{
							["arg2"] = "Alucàrt-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623468,
							["arg1"] = "kein ding",
							["clColor"] = "ffc59a6c",
						}, -- [103]
						{
							["arg2"] = "Musaríl-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623616,
							["arg1"] = "hier",
							["clColor"] = "ffa9d271",
						}, -- [104]
						{
							["arg2"] = "Yaroz-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623630,
							["arg1"] = "inv  bin monk gs 407",
							["clColor"] = "ff00fe95",
						}, -- [105]
						{
							["arg2"] = "Joyleen-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553623686,
							["arg1"] = "haste richtiges shadow gear? Da du als heal und DD anmeldest",
							["clColor"] = "fffefefe",
						}, -- [106]
						{
							["arg2"] = "Joyleen-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553623697,
							["arg1"] = "jo",
							["clColor"] = "fffefefe",
						}, -- [107]
						{
							["arg2"] = "Dubstepdora-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624196,
							["arg1"] = "Hey :) If you don't need |cffa335ee|Hitem:165519::::::::120:259::6:4:4824:1537:4786:5420:::|h[Cowl of Righteous Resolve]|h|r, I would very much appreciate it <3",
							["clColor"] = "fffef367",
						}, -- [108]
						{
							["arg2"] = "Shydabolo-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624200,
							["arg1"] = "Hey :) If you don't need |cffa335ee|Hitem:165517::::::::120:259::6:3:4800:1537:4786:::|h[Bracers of Regal Devotion]|h|r, I would very much appreciate it <3",
							["clColor"] = "ffa22fc8",
						}, -- [109]
						{
							["arg2"] = "Dubstepdora-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553624203,
							["arg1"] = "need sry",
							["clColor"] = "fffef367",
						}, -- [110]
						{
							["arg2"] = "Dubstepdora-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624208,
							["arg1"] = "np^^",
							["clColor"] = "fffef367",
						}, -- [111]
						{
							["arg2"] = "Dubstepdora-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624210,
							["arg1"] = "gz",
							["clColor"] = "fffef367",
						}, -- [112]
						{
							["arg2"] = "Shydabolo-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624357,
							["arg1"] = "ist ok, hab gesehen ich hab die schon :D",
							["clColor"] = "ffa22fc8",
						}, -- [113]
						{
							["arg2"] = "Shydabolo-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624362,
							["arg1"] = "aber danke :)",
							["clColor"] = "ffa22fc8",
						}, -- [114]
						{
							["arg2"] = "Shydabolo-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553624369,
							["arg1"] = "ahh ok kein problem^^",
							["clColor"] = "ffa22fc8",
						}, -- [115]
						{
							["arg2"] = "Shydabolo-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553624374,
							["arg1"] = "wünsche dir noch einen schönen abend :)",
							["clColor"] = "ffa22fc8",
						}, -- [116]
						{
							["arg2"] = "Shydabolo-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553624382,
							["arg1"] = "danke ebenso",
							["clColor"] = "ffa22fc8",
						}, -- [117]
						{
							["arg1"] = " ",
						}, -- [118]
						{
							["arg1"] = " ",
						}, -- [119]
						{
							["arg1"] = "Logging started on 03/27/2019 at 10:46:09.",
							["type"] = "SYSTEM",
						}, -- [120]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553681572,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [121]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553681973,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [122]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553682072,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [123]
						{
							["arg1"] = " ",
						}, -- [124]
						{
							["arg1"] = " ",
						}, -- [125]
						{
							["arg1"] = "Logging started on 03/27/2019 at 12:10:34.",
							["type"] = "SYSTEM",
						}, -- [126]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553687340,
							["arg1"] = "why?",
							["clColor"] = "fffe7b09",
						}, -- [127]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER",
							["time"] = 1553687367,
							["arg1"] = "weil ich als erstes erst einmal ein Heiler Möchte. Und erst dann DD's lade. ",
							["clColor"] = "fffe7b09",
						}, -- [128]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553687382,
							["arg1"] = "ahja",
							["clColor"] = "fffe7b09",
						}, -- [129]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553687400,
							["arg1"] = "dir ist klar, je voller die gruppe ist, desto einfacher bekommst du auch einen heiler?",
							["clColor"] = "fffe7b09",
						}, -- [130]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER",
							["time"] = 1553687403,
							["arg1"] = "weil wenn ich 3 dd's habe dann warte ich auf heiler und die dd's gehen raus oder sonst etwas,.",
							["clColor"] = "fffe7b09",
						}, -- [131]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER",
							["time"] = 1553687440,
							["arg1"] = "oder aber auch, einfach um zu schauen... was sich anmeldet, vllt. meldet sich ja auch eine premate gruppe an mit 1 heiler und 3 dd's daher warte ich noch erstmal ^^ und mach ne WQ. ich habe zeit",
							["clColor"] = "fffe7b09",
						}, -- [132]
						{
							["arg2"] = "Julende-Alleria",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553687459,
							["arg1"] = "das macht wiederrum mehr Sinn^^",
							["clColor"] = "fffe7b09",
						}, -- [133]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553690194,
							["arg1"] = "Haha! Now dat was an impressive death!",
						}, -- [134]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553690693,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [135]
						{
							["arg1"] = " ",
						}, -- [136]
						{
							["arg1"] = " ",
						}, -- [137]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 13:55:25.",
						}, -- [138]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553699446,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [139]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553700264,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [140]
						{
							["arg1"] = " ",
						}, -- [141]
						{
							["arg1"] = " ",
						}, -- [142]
						{
							["arg1"] = "Logging started on 03/27/2019 at 18:22:22.",
							["type"] = "SYSTEM",
						}, -- [143]
						{
							["arg2"] = "Velandra-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553709828,
							["arg1"] = "pet BL",
							["clColor"] = "ffa9d271",
						}, -- [144]
						{
							["arg2"] = "Myueta-Frostmane",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553712350,
							["arg1"] = "diszi?",
							["clColor"] = "fffefefe",
						}, -- [145]
						{
							["arg2"] = "Myueta-Frostmane",
							["type"] = "WHISPER",
							["time"] = 1553712355,
							["arg1"] = "yes",
							["clColor"] = "fffefefe",
						}, -- [146]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553713673,
							["arg1"] = "Haha! Now dat was an impressive death!",
						}, -- [147]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553713777,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [148]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553714124,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [149]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553714539,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [150]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553714638,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [151]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553714721,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [152]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553715021,
							["arg1"] = "Haha! Now dat was an impressive death!",
						}, -- [153]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553715403,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [154]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553715799,
							["arg1"] = "Darkness roots. Pestilence spreads. The doorway is open.",
						}, -- [155]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553715888,
							["arg1"] = "I reside within your lungs!",
						}, -- [156]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553715909,
							["arg1"] = "Listen to the music of the drowned.",
						}, -- [157]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553715965,
							["arg1"] = "The crawling ones have awakened!",
						}, -- [158]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553716015,
							["arg1"] = "Listen to the music of the drowned.",
						}, -- [159]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553716063,
							["arg1"] = "The crawling ones have awakened!",
						}, -- [160]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553716106,
							["arg1"] = "Blood pours forth in the depths.",
						}, -- [161]
						{
							["arg2"] = "Vol'zith the Whisperer",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553716160,
							["arg1"] = "I will await you... in the dark...",
						}, -- [162]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716286,
							["arg1"] = "mind if I add you?",
							["clColor"] = "ffa22fc8",
						}, -- [163]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716292,
							["arg1"] = "you are a great tank :)",
							["clColor"] = "ffa22fc8",
						}, -- [164]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716308,
							["arg1"] = "sure thing",
							["clColor"] = "ffa22fc8",
						}, -- [165]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716315,
							["arg1"] = "I actually had a shitload of fun with this route",
							["clColor"] = "ffa22fc8",
						}, -- [166]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716326,
							["arg1"] = "that's like, best dung ever this week",
							["clColor"] = "ffa22fc8",
						}, -- [167]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716328,
							["arg1"] = "yeah, it was not bad",
							["clColor"] = "ffa22fc8",
						}, -- [168]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716351,
							["arg1"] = "it's just kinda sad the hunter was not BM. Then we might have survived some of the packs",
							["clColor"] = "ffa22fc8",
						}, -- [169]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716359,
							["arg1"] = "but it worked well for a PuG",
							["clColor"] = "ffa22fc8",
						}, -- [170]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716369,
							["arg1"] = "dude it's so awesome, jumping around taking everything, yolo surviving, healer does oil as he squeeze his ass harder",
							["clColor"] = "ffa22fc8",
						}, -- [171]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716388,
							["arg1"] = "love it",
							["clColor"] = "ffa22fc8",
						}, -- [172]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716404,
							["arg1"] = "can't add you krytos#2230",
							["clColor"] = "ffa22fc8",
						}, -- [173]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716479,
							["arg1"] = "done :)",
							["clColor"] = "ffa22fc8",
						}, -- [174]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716494,
							["arg1"] = "ping me if you happen to have shrine again",
							["clColor"] = "ffa22fc8",
						}, -- [175]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716499,
							["arg1"] = "awesome. I gotta grab something to eat after this^^",
							["clColor"] = "ffa22fc8",
						}, -- [176]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716504,
							["arg1"] = "will do",
							["clColor"] = "ffa22fc8",
						}, -- [177]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553716510,
							["arg1"] = "have a great evening man :)",
							["clColor"] = "ffa22fc8",
						}, -- [178]
						{
							["arg2"] = "Funkyedgykid-ArgentDawn",
							["type"] = "WHISPER",
							["time"] = 1553716519,
							["arg1"] = "have a good one too :)",
							["clColor"] = "ffa22fc8",
						}, -- [179]
						{
							["arg2"] = "|Kq36|k",
							["type"] = "BN_WHISPER_INFORM",
							["time"] = 1553716870,
							["arg1"] = "biste da?",
						}, -- [180]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553718627,
							["arg1"] = "also stevi ist dabei. Sag an wenn du fertig bist :)",
							["clColor"] = "ffc59a6c",
						}, -- [181]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553718635,
							["arg1"] = "jo sollte bald so weit sein",
							["clColor"] = "ffc59a6c",
						}, -- [182]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553718639,
							["arg1"] = "ist ne top gruppe^^",
							["clColor"] = "ffc59a6c",
						}, -- [183]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553718647,
							["arg1"] = "zwei gute russen lol",
							["clColor"] = "ffc59a6c",
						}, -- [184]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553718890,
							["arg1"] = "kk, cool :)",
							["clColor"] = "ffc59a6c",
						}, -- [185]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553718890,
							["arg1"] = "<Deadly Boss Mods> Dovomir ist damit beschäftigt gegen Mythisch+ (10) - Hadal Dunkelgrund zu kämpfen! (unbekannt, 5/5 Spieler am Leben)",
							["clColor"] = "ffc59a6c",
						}, -- [186]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553718948,
							["arg1"] = "<DBM> Dovomir hat Mythisch+ (10) - Hadal Dunkelgrund besiegt!",
							["clColor"] = "ffc59a6c",
						}, -- [187]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553719450,
							["arg1"] = "gz",
							["clColor"] = "ffc59a6c",
						}, -- [188]
						{
							["arg1"] = " ",
						}, -- [189]
						{
							["arg1"] = " ",
						}, -- [190]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 22:37:44.",
						}, -- [191]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553723726,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [192]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553724657,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [193]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553725451,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [194]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553725630,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [195]
						{
							["arg1"] = " ",
						}, -- [196]
						{
							["arg1"] = " ",
						}, -- [197]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [198]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553777283,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [199]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553777779,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [200]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553780586,
							["arg1"] = "nur mal so, dass mit \"nur letzer buss\" funktioniert für die weekly nicht mehr",
							["clColor"] = "fffe7b09",
						}, -- [201]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER",
							["time"] = 1553780596,
							["arg1"] = "realy? ",
							["clColor"] = "fffe7b09",
						}, -- [202]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553780607,
							["arg1"] = "jo wurde mit 8.1.5 geändert",
							["clColor"] = "fffe7b09",
						}, -- [203]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER",
							["time"] = 1553780614,
							["arg1"] = "was is das fürn kack? xD",
							["clColor"] = "fffe7b09",
						}, -- [204]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553780631,
							["arg1"] = "hat blizz halt net gefallen, dass man ihre ganze arbeit ignoriert hat^^",
							["clColor"] = "fffe7b09",
						}, -- [205]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER",
							["time"] = 1553780655,
							["arg1"] = "die machen eh nur kacke",
							["clColor"] = "fffe7b09",
						}, -- [206]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553780661,
							["arg1"] = "das sowieso :D",
							["clColor"] = "fffe7b09",
						}, -- [207]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553780671,
							["arg1"] = "einzig gute in BfA so weit sind raids^^",
							["clColor"] = "fffe7b09",
						}, -- [208]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER",
							["time"] = 1553780677,
							["arg1"] = "naja ",
							["clColor"] = "fffe7b09",
						}, -- [209]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER",
							["time"] = 1553780686,
							["arg1"] = "pvp is eh fürn arsch ",
							["clColor"] = "fffe7b09",
						}, -- [210]
						{
							["arg2"] = "Bakabi-DieArguswacht",
							["type"] = "WHISPER",
							["time"] = 1553780689,
							["arg1"] = "dh is fürn arsch ",
							["clColor"] = "fffe7b09",
						}, -- [211]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781389,
							["arg1"] = "I got 1k r.io and I'm a fucking rogue and you invite a DK?",
							["clColor"] = "ff3ec5e9",
						}, -- [212]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781390,
							["arg1"] = "lol",
							["clColor"] = "ff3ec5e9",
						}, -- [213]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER",
							["time"] = 1553781425,
							["arg1"] = "so?",
							["clColor"] = "ff3ec5e9",
						}, -- [214]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781441,
							["arg1"] = "It's dumb",
							["clColor"] = "ff3ec5e9",
						}, -- [215]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781447,
							["arg1"] = "it's freehold",
							["clColor"] = "ff3ec5e9",
						}, -- [216]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781452,
							["arg1"] = "the one thing you want is a rogue",
							["clColor"] = "ff3ec5e9",
						}, -- [217]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781453,
							["arg1"] = "lol",
							["clColor"] = "ff3ec5e9",
						}, -- [218]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER",
							["time"] = 1553781478,
							["arg1"] = "the only thing i want is to do the key in time",
							["clColor"] = "ff3ec5e9",
						}, -- [219]
						{
							["arg2"] = "Ultradog-Sylvanas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553781495,
							["arg1"] = "then agian, your best key is a 9 so, I guess you don't know your shit",
							["clColor"] = "ff3ec5e9",
						}, -- [220]
						{
							["arg1"] = " ",
						}, -- [221]
						{
							["arg1"] = " ",
						}, -- [222]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [223]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553790333,
							["arg1"] = "haben hier nen DH mit AoE stun dabei der kein einziges mal stunnt aber mich als \"tard\" bezeichnen großes kino",
							["clColor"] = "ffa9d271",
						}, -- [224]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553790353,
							["arg1"] = "hat 40 sec CD du vogel",
							["clColor"] = "ffa9d271",
						}, -- [225]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553790362,
							["arg1"] = "aber so was weiß man mit 1/9 HC natürlich nicht",
							["clColor"] = "ffa9d271",
						}, -- [226]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553790366,
							["arg1"] = "der erste kam gleich durch und nenn mich nicht vogel",
							["clColor"] = "ffa9d271",
						}, -- [227]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553790372,
							["arg1"] = "WEICH AUS",
							["clColor"] = "ffa9d271",
						}, -- [228]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553790375,
							["arg1"] = "ES IST NICHT SCHWER",
							["clColor"] = "ffa9d271",
						}, -- [229]
						{
							["arg2"] = "Marno-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553790378,
							["arg1"] = "L2P",
							["clColor"] = "ffa9d271",
						}, -- [230]
						{
							["arg2"] = "Ginug-Sylvanas",
							["type"] = "WHISPER",
							["time"] = 1553790724,
							["arg1"] = "invite me im good  dps  for  seth",
							["clColor"] = "ffa9d271",
						}, -- [231]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553791364,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [232]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553792356,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [233]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553792435,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [234]
						{
							["arg1"] = " ",
						}, -- [235]
						{
							["arg1"] = " ",
						}, -- [236]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [237]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553795381,
							["arg1"] = "inv",
							["clColor"] = "fffe7b09",
						}, -- [238]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553796142,
							["arg1"] = "das set ist echt nice",
							["clColor"] = "ffc31d39",
						}, -- [239]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553796151,
							["arg1"] = "danke :)",
							["clColor"] = "ffc31d39",
						}, -- [240]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553796217,
							["arg1"] = "aber guck dir den |cff1eff00|Hitem:31774::::::::120:252:::1:3524:::|h[Kurenai Tabard]|h|r mal an",
							["clColor"] = "ffc31d39",
						}, -- [241]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553796227,
							["arg1"] = "der sieht auch nice aus",
							["clColor"] = "ffc31d39",
						}, -- [242]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553796231,
							["arg1"] = "würde gut passen ",
							["clColor"] = "ffc31d39",
						}, -- [243]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553796238,
							["arg1"] = "Finde der passt besser dazu",
							["clColor"] = "ffc31d39",
						}, -- [244]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553796254,
							["arg1"] = "ja, ich mag den illidari total, aber es passt leider net so /",
							["clColor"] = "ffc31d39",
						}, -- [245]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553797453,
							["arg1"] = "|cffa335ee|Hitem:167217::::::::120:70::6:1:3524:::|h[Legplates of Unbound Anguish]|h|r",
							["clColor"] = "fff38bb9",
						}, -- [246]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553798877,
							["arg1"] = "soll ich umloggen? Opulence würde en dagger für mich droppen. Hab aktuell beide noch auf 385",
							["clColor"] = "fffe7b09",
						}, -- [247]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553798909,
							["arg1"] = "bleib mal kannst du gold regen als schurke alleine machen?",
							["clColor"] = "fffe7b09",
						}, -- [248]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "WHISPER_INFORM",
							["time"] = 1553798933,
							["arg1"] = "ne, leider net, ist physisch. ",
							["clColor"] = "fffe7b09",
						}, -- [249]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "WHISPER",
							["time"] = 1553798993,
							["arg1"] = "muss gleich mal setup schaun",
							["clColor"] = "fffe7b09",
						}, -- [250]
					},
				}, -- [1]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Raid",
					["logs"] = {
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553796441,
							["arg1"] = "PS Gestorben: Isery > 103k, |cff71d5ff|Hspell:283626:0|h[Göttliche Entladung]|h|r (O: 34k) [Jüngerin der Rezani] (Heilig)",
							["clColor"] = "ffc59a6c",
						}, -- [1]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553796443,
							["arg1"] = "PS Gestorben: Alleycut > 67k, |cff71d5ff|Hspell:283626:0|h[Göttliche Entladung]|h|r (O: 51k) [Jüngerin der Rezani] (Heilig)",
							["clColor"] = "ffc59a6c",
						}, -- [2]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "De Light judges all!",
						}, -- [3]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "Light guide me... to de... Other Side...",
						}, -- [4]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553796464,
							["arg1"] = "Steh auf ,.. du Pack",
							["clColor"] = "ff00fe95",
						}, -- [5]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553796514,
							["arg1"] = "|cffa335ee|Hitem:165549::::::::120:102::6:5:4800:1808:40:1537:4786:::|h[Verprügler des Kreuzzugs]|h|r wurde an Daddysenpai wegen BIS vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [6]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796523,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [7]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796525,
							["arg1"] = "All realities, all dimensions are open to me!",
							["clColor"] = "ff8686ec",
						}, -- [8]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796536,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [9]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796540,
							["arg1"] = "Never heard my blade coming!",
							["clColor"] = "ffa22fc8",
						}, -- [10]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796546,
							["arg1"] = "HAH!",
							["clColor"] = "fff38bb9",
						}, -- [11]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796550,
							["arg1"] = "AG VWYQ ZA AN'ZIG ",
							["clColor"] = "fffefefe",
						}, -- [12]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553796552,
							["arg1"] = "|cffa335ee|Hitem:165517::::::::120:102::6:3:4800:1537:4786:::|h[Armschienen der majestätischen Hingabe]|h|r wurde an Alleycut wegen Upgrade vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [13]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796553,
							["arg1"] = "Your greed, your foolishness has brought you to this end.",
							["clColor"] = "ff8686ec",
						}, -- [14]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553796558,
							["arg1"] = "|cffa335ee|Hitem:165533::::::::120:102::6:4:4800:1808:1537:4786:::|h[Sabatons der Gnade des Lichts]|h|r wurde an Neferupitou wegen Upgrade vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [15]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796564,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [16]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796572,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [17]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553796572,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted Rastari Flamespeaker's |cff71d5ff|Hspell:288815:0|h[Breath of Fire]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [18]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796647,
							["arg1"] = "Mortal minds... So easily manipulated.",
							["clColor"] = "fff38bb9",
						}, -- [19]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796649,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [20]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796651,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [21]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796653,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [22]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796682,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [23]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796696,
							["arg1"] = "Incoming!",
							["clColor"] = "ffc59a6c",
						}, -- [24]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796702,
							["arg1"] = "Your technique needs work.",
							["clColor"] = "ffc31d39",
						}, -- [25]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796735,
							["arg1"] = "Just as you deserve!",
							["clColor"] = "fffe7b09",
						}, -- [26]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796752,
							["arg1"] = "If only you understood!",
							["clColor"] = "ffa9d271",
						}, -- [27]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796767,
							["arg1"] = "I thank you for coming, but you really all must die now!",
							["clColor"] = "fff38bb9",
						}, -- [28]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796773,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [29]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796774,
							["arg1"] = "Out da way!",
							["clColor"] = "ffc59a6c",
						}, -- [30]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796776,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [31]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796778,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [32]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553796823,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [33]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796844,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [34]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796845,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [35]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796847,
							["arg1"] = "A taste... just a small taste... of the Spell-Weaver's power!",
							["clColor"] = "ffa9d271",
						}, -- [36]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796848,
							["arg1"] = "Ha! I have fought goren that proved more of a challenge!",
						}, -- [37]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796849,
							["arg1"] = "You will burn to ashes!",
						}, -- [38]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796854,
							["arg1"] = "You see? I told you they were nothing to worry about.",
						}, -- [39]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796913,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [40]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796914,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [41]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796915,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [42]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796918,
							["arg1"] = "You will burn to ashes!",
						}, -- [43]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796919,
							["arg1"] = "Brawl... with Rook.",
							["clColor"] = "fff38bb9",
						}, -- [44]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796923,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [45]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796925,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [46]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796929,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [47]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796940,
							["arg1"] = "Better watch your step!",
						}, -- [48]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796943,
							["arg1"] = "Your defense is feeble!",
						}, -- [49]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553796951,
							["arg1"] = "PS Gestorben: Soely > unbekannt",
							["clColor"] = "ffc59a6c",
						}, -- [50]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796961,
							["arg1"] = "Time to test your mettle!",
						}, -- [51]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796967,
							["arg1"] = "The elements will break you!",
						}, -- [52]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796971,
							["arg1"] = "The phoenix takes many forms!",
						}, -- [53]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796977,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [54]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796978,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [55]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796982,
							["arg1"] = "What... awaits me... now?",
							["clColor"] = "fffe7b09",
						}, -- [56]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553796983,
							["arg1"] = "PS Gestorben: Woowa > 2.8k, |cff71d5ff|Hspell:286989:0|h[Entfesselter Funken]|h|r (O: 60k) [Anathos Feuerrufer] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [57]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "You really have to want it!",
							["clColor"] = "fff38bb9",
						}, -- [58]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "There is only one true path of enlightenment! DEATH!",
							["clColor"] = "ff8686ec",
						}, -- [59]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796993,
							["arg1"] = "Better watch your step!",
						}, -- [60]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797002,
							["arg1"] = "PS Gestorben: Noxiâ > 2.9k, |cff71d5ff|Hspell:286503:0|h[Strahl]|h|r (O: 11.1k) [Lebende Bombe] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [61]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797003,
							["arg1"] = "Guess I... be off... ta the locker...",
							["clColor"] = "ff00fe95",
						}, -- [62]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797004,
							["arg1"] = "PS Gestorben: Hornpubmonk > 15.6k, |cff71d5ff|Hspell:286503:0|h[Strahl]|h|r (O: 87k) [Lebende Bombe] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [63]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797010,
							["arg1"] = "Your defense is feeble!",
						}, -- [64]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797028,
							["arg1"] = "Time to test your mettle!",
						}, -- [65]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797031,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [66]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797041,
							["arg1"] = "Better watch your step!",
						}, -- [67]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Your defense is feeble!",
						}, -- [68]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Better watch your step!",
						}, -- [69]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797106,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [70]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797123,
							["arg1"] = "Time to test your mettle!",
						}, -- [71]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797146,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [72]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797152,
							["arg1"] = "Better watch your step!",
						}, -- [73]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [74]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Better watch your step!",
						}, -- [75]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797198,
							["arg1"] = "Better watch your step!",
						}, -- [76]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797207,
							["arg1"] = "PS Gestorben: Härridk > 277k, Falling",
							["clColor"] = "ffc59a6c",
						}, -- [77]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797207,
							["arg1"] = "PS Gestorben: Soely > 255k, Falling",
							["clColor"] = "ffc59a6c",
						}, -- [78]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797210,
							["arg1"] = "Better watch your step!",
						}, -- [79]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797212,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [80]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797220,
							["arg1"] = "Better watch your step!",
						}, -- [81]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797366,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted Hateful Shade's |cff71d5ff|Hspell:288927:0|h[Necrotic Blast]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [82]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553797376,
							["arg1"] = "|cffa335ee|Hitem:165500::::::::120:102::6:4:4824:1537:4786:5420:::|h[Flammenschwingenkapuze]|h|r wurde an Metó wegen Titanenresiduum vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [83]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553797431,
							["arg1"] = "|cffa335ee|Hitem:165587::::::::120:102::6:4:4800:42:1537:4786:::|h[Phönixfeuerstab]|h|r wurde an Woowa wegen Upgrade vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [84]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797453,
							["arg1"] = "jap",
							["clColor"] = "fffe7b09",
						}, -- [85]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797497,
							["arg1"] = "sry sofort da",
							["clColor"] = "ffa22fc8",
						}, -- [86]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797525,
							["arg1"] = "|cffa335ee|Hitem:167868::::::::120:252::6:1:3524:::|h[Idol of Indiscriminate Consumption]|h|r",
							["clColor"] = "ffc31d39",
						}, -- [87]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553797544,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [88]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797722,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [89]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797730,
							["arg1"] = "Interrupted Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [90]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797744,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [91]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797757,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [92]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797843,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [93]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797859,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [94]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797861,
							["arg1"] = "PS Gestorben: Dovomir > 176k, |cff71d5ff|Hspell:282545:0|h[Tödliches Echo]|h|r (O: 10k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [95]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797872,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [96]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797891,
							["arg1"] = "PS Gestorben: Kalissta > 96k, |cff71d5ff|Hspell:282543:0|h[Tödliches Schmettern]|h|r [Grong der Zurückgekehrte] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [97]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797923,
							["arg1"] = "PS Gestorben: Ðaisuke > 60k, |cff71d5ff|Hspell:290574:0|h[Wildes Brüllen]|h|r (O: 7k) [Grong der Zurückgekehrte] (Körperlich)",
							["clColor"] = "ffc59a6c",
						}, -- [98]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797957,
							["arg1"] = "PS Gestorben: Neferupitou > 67k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r (O: 12k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [99]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797957,
							["arg1"] = "PS Gestorben: Isery > 77k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r (O: 12k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [100]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797961,
							["arg1"] = "PS Gestorben: {rt2}Laki > 56k, |cff71d5ff|Hspell:290574:0|h[Wildes Brüllen]|h|r (O: 4.1k) [Grong der Zurückgekehrte] (Körperlich)",
							["clColor"] = "ffc59a6c",
						}, -- [101]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797962,
							["arg1"] = "PS Gestorben: Woowa > 32k, |cff71d5ff|Hspell:286373:0|h[Kälte des Todes]|h|r (O: 10.8k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [102]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553797980,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted {rt8}Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [103]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553798016,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [104]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553798045,
							["arg1"] = "RSC > Metó hat einen Seelenbrunnen aufgestellt!",
							["clColor"] = "ffc59a6c",
						}, -- [105]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798132,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [106]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798151,
							["arg1"] = "Interrupted Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [107]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798156,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [108]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798252,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [109]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798268,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [110]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798277,
							["arg1"] = "PS Gestorben: Salanâ > 120k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r [Grong der Zurückgekehrte] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [111]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798277,
							["arg1"] = "PS Gestorben: Andromaché > 112k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r (O: 8k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [112]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798277,
							["arg1"] = "PS Gestorben: Isery > 68k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r (O: 36k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [113]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798291,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [114]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798295,
							["arg1"] = "PS Gestorben: Hornpubmonk > 44k, |cff71d5ff|Hspell:286373:0|h[Kälte des Todes]|h|r (O: 6.7k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [115]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798295,
							["arg1"] = "PS Gestorben: Soely > 42k, |cff71d5ff|Hspell:286373:0|h[Kälte des Todes]|h|r (O: 8.5k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [116]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798330,
							["arg1"] = "Steh auf ,.. du Pack",
							["clColor"] = "ff00fe95",
						}, -- [117]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553798341,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [118]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798422,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt7}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [119]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798433,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [120]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798439,
							["arg1"] = "Interrupted Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [121]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798447,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [122]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798458,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [123]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798546,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [124]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798564,
							["arg1"] = "Interrupted Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [125]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798564,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [126]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798599,
							["arg1"] = "PS Gestorben: Salanâ > 120k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r [Grong der Zurückgekehrte] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [127]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798599,
							["arg1"] = "PS Gestorben: Kalissta > 124k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r [Grong der Zurückgekehrte] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [128]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798599,
							["arg1"] = "PS Gestorben: Neferupitou > 73k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r (O: 50k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [129]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798599,
							["arg1"] = "PS Gestorben: Metó > 98k, |cff71d5ff|Hspell:282412:0|h[Totenglocke]|h|r (O: 19.8k) [Grong der Zurückgekehrte] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [130]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798667,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted {rt8}Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [131]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798679,
							["arg1"] = "Interrupted Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [132]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798712,
							["arg1"] = "PS Gestorben: Isery > 48k, |cff71d5ff|Hspell:290574:0|h[Wildes Brüllen]|h|r (O: 31k) [Grong der Zurückgekehrte] (Körperlich)",
							["clColor"] = "ffc59a6c",
						}, -- [133]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798730,
							["arg1"] = "|cff71d5ff|Hspell:57994:0|h[Windstoß]|h|r interrupted Gespenst des Todes's |cff71d5ff|Hspell:282533:0|h[Todeserfüllung]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [134]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798735,
							["arg1"] = "|cff71d5ff|Hspell:183752:0|h[Disrupt]|h|r interrupted Death Specter's |cff71d5ff|Hspell:282533:0|h[Death Empowerment]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [135]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798742,
							["arg1"] = "PS Gestorben: Daddysenpai > 146k, |cff71d5ff|Hspell:289412:0|h[Bestialischer Aufschlag]|h|r (O: 875)  (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [136]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798750,
							["arg1"] = "PS Gestorben: Salanâ > 74k, |cff71d5ff|Hspell:282471:0|h[Voodooentladung]|h|r [Gespenst des Todes] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [137]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798750,
							["arg1"] = "PS Gestorben: Kalissta > 64k, |cff71d5ff|Hspell:282471:0|h[Voodooentladung]|h|r [Gespenst des Todes] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [138]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798757,
							["arg1"] = "PS Gestorben: Supersunny > 296k, melee (O: 390k) [Grong der Zurückgekehrte]",
							["clColor"] = "ffc59a6c",
						}, -- [139]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798758,
							["arg1"] = "PS Gestorben: Dovomir > 265k, melee (O: 654k) [Grong der Zurückgekehrte]",
							["clColor"] = "ffc59a6c",
						}, -- [140]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553798764,
							["arg1"] = "RSC > Andromaché hat einen Seelenbrunnen aufgestellt!",
							["clColor"] = "ffc59a6c",
						}, -- [141]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798766,
							["arg1"] = "Steh auf ,.. du Pack",
							["clColor"] = "ff00fe95",
						}, -- [142]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553798854,
							["arg1"] = "|cffa335ee|Hitem:165513::::::::120:105::6:3:4800:1537:4786:::|h[Umhang des Silberrückens]|h|r wurde an Woowa wegen Upgrade vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [143]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "RAID_LEADER",
							["time"] = 1553798878,
							["arg1"] = "|cffa335ee|Hitem:165525::::::::120:105::6:3:4800:1537:4786:::|h[Gedehnte Sehnentaillenkordel]|h|r wurde an Isery wegen Upgrade vergeben!",
							["clColor"] = "fffe7b09",
						}, -- [144]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553798971,
							["arg1"] = "PS Gestorben: Supersunny > 40k, |cff71d5ff|Hspell:288927:0|h[Nekrotischer Stoß]|h|r (O: 6.1k) [Untoter Augur] (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [145]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799073,
							["arg1"] = "PS Gestorben: Aspern > 71k, melee (O: 18.2k) [Ewiger Vollstrecker]. Kauterisieren spent (2.8 Sek. zuvor) > 63k, Melee (O: 18.2k) [Ahnenrächer]",
							["clColor"] = "ffc59a6c",
						}, -- [146]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799096,
							["arg1"] = "ullllltraaaa lagg",
							["clColor"] = "ffc59a6c",
						}, -- [147]
						{
							["arg2"] = "Supersunny-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799100,
							["arg1"] = "laggg",
							["clColor"] = "fff38bb9",
						}, -- [148]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799108,
							["arg1"] = "laaaggg",
							["clColor"] = "fffe7b09",
						}, -- [149]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799231,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "ffc59a6c",
						}, -- [150]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799318,
							["arg1"] = "The waters whisper to me... enemies approach.",
							["clColor"] = "ffa9d271",
						}, -- [151]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799325,
							["arg1"] = "Avast, ye bilge suckers!",
							["clColor"] = "fffefefe",
						}, -- [152]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799396,
							["arg1"] = "kann ich wem nen buch abkaufen für nach dem boss, hab meins vergessen...",
							["clColor"] = "ffa22fc8",
						}, -- [153]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799415,
							["arg1"] = "Tunrbeutel vergesser lul",
							["clColor"] = "ff00fe95",
						}, -- [154]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799437,
							["arg1"] = "gelbampelbremser",
							["clColor"] = "ff8686ec",
						}, -- [155]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799450,
							["arg1"] = "o.o",
							["clColor"] = "ff00fe95",
						}, -- [156]
						{
							["arg2"] = "Aspern-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799453,
							["arg1"] = "hab auch mein Turnbeutel vergessen^^",
							["clColor"] = "ff3ec5e9",
						}, -- [157]
						{
							["arg2"] = "Andromaché-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799492,
							["arg1"] = "port bitte",
							["clColor"] = "ff8686ec",
						}, -- [158]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "RAID",
							["time"] = 1553799602,
							["arg1"] = "+",
							["clColor"] = "ff00fe95",
						}, -- [159]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799752,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [160]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799875,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [161]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553800099,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [162]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800176,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [163]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800219,
							["arg1"] = "PS Gestorben: Neferupitou > 28.6k, |cff71d5ff|Hspell:283610:0|h[Zermalmen]|h|r (O: 9.4k) [Yalats Bollwerk] (Körperlich)",
							["clColor"] = "ffc59a6c",
						}, -- [164]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800257,
							["arg1"] = "PS Gestorben: Soely > 93k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 87k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [165]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800263,
							["arg1"] = "PS Gestorben: Dovomir > 4.2k, |cff71d5ff|Hspell:284424:0|h[Sengender Boden]|h|r (O: 63k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [166]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800265,
							["arg1"] = "PS Gestorben: Alleycut > 21.2k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 98k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [167]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800266,
							["arg1"] = "PS Gestorben: {rt7}Laki > 45k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 112k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [168]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800269,
							["arg1"] = "PS Gestorben: Aspern > 14.8k, |cff71d5ff|Hspell:284424:0|h[Sengender Boden]|h|r (O: 49k)  (Feuer). Kauterisieren spent (2.5 Sek. zuvor) > 18.3k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r (O: 115k) [Unstete Ladung]",
							["clColor"] = "ffc59a6c",
						}, -- [169]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800269,
							["arg1"] = "PS Gestorben: Kalissta > 129k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r [Unstete Ladung] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [170]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800269,
							["arg1"] = "PS Gestorben: Supersunny > 128k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 8.1k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [171]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553800302,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [172]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800349,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [173]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800494,
							["arg1"] = "PS Gestorben: Qyix > 35k, |cff71d5ff|Hspell:284424:0|h[Sengender Boden]|h|r (O: 30k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [174]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800507,
							["arg1"] = "PS Gestorben: Metó > 96k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 312) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [175]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800507,
							["arg1"] = "PS Gestorben: Almîna > 88k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 83k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [176]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800507,
							["arg1"] = "PS Gestorben: Hornpubmonk > 145k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 23.2k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [177]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800515,
							["arg1"] = "PS Gestorben: Ðaisuke > 25.7k, |cff71d5ff|Hspell:283610:0|h[Zermalmen]|h|r (O: 12.1k) [Yalats Bollwerk] (Körperlich)",
							["clColor"] = "ffc59a6c",
						}, -- [178]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800515,
							["arg1"] = "PS Gestorben: Soely > 68k, |cff71d5ff|Hspell:284472:0|h[Tödliche Verhexung]|h|r (O: 20.7k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [179]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800515,
							["arg1"] = "PS Gestorben: Salanâ > 81k, |cff71d5ff|Hspell:285479:0|h[Flammenstrahl]|h|r (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [180]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800516,
							["arg1"] = "PS Gestorben: Dovomir > 66k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r (O: 72k) [Unstete Ladung] (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [181]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553800540,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [182]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553800579,
							["arg1"] = "RSC > Metó hat einen Repbot aufgestellt!",
							["clColor"] = "ffc59a6c",
						}, -- [183]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800638,
							["arg1"] = "PS Gestorben: {rt7}Laki > 86k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 82k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [184]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800714,
							["arg1"] = "PS Gestorben: {rt7}Laki > 123k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 28.8k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [185]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800736,
							["arg1"] = "PS Gestorben: Alleycut > 19.7k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 94k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [186]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800736,
							["arg1"] = "PS Gestorben: Qyix > 55k, |cff71d5ff|Hspell:284424:0|h[Sengender Boden]|h|r (O: 2.1k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [187]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800736,
							["arg1"] = "PS Gestorben: Salanâ > 127k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r [Unstete Ladung] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [188]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800737,
							["arg1"] = "PS Gestorben: Hornpubmonk > 53k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 80k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [189]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800739,
							["arg1"] = "PS Gestorben: Noxiâ > 46k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 91k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [190]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800739,
							["arg1"] = "PS Gestorben: Supersunny > 110k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 26.5k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [191]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800739,
							["arg1"] = "PS Gestorben: Kalissta > 127k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r [Unstete Ladung] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [192]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800753,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [193]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553800770,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [194]
						{
							["arg2"] = "Isery",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800804,
							["arg1"] = "None may challenge the Brotherhood!",
							["clColor"] = "fffe7b09",
						}, -- [195]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800822,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [196]
						{
							["arg2"] = "Ðaisuke",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800831,
							["arg1"] = "Pay for your crimes!",
							["clColor"] = "ffa22fc8",
						}, -- [197]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553800915,
							["arg1"] = "PS Gestorben: Aspern > 14.1k, |cff71d5ff|Hspell:87023:0|h[Kauterisieren]|h|r (O: 5.3k). Aufgrund von Kauterisieren > 48k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 130k) [Yalats Bollwerk]",
							["clColor"] = "ffc59a6c",
						}, -- [198]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800943,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [199]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800963,
							["arg1"] = "W'OQ ZA ",
							["clColor"] = "fffefefe",
						}, -- [200]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801082,
							["arg1"] = "PS Gestorben: Hornpubmonk > 89k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 79k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [201]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801082,
							["arg1"] = "PS Gestorben: Tyrellan > 84k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 75k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [202]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801082,
							["arg1"] = "PS Gestorben: Aspern > 55k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 123k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [203]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801085,
							["arg1"] = "YOUR SOUL IS MINE!",
							["clColor"] = "fffe7b09",
						}, -- [204]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801099,
							["arg1"] = "PS Gestorben: Dovomir > 124k, |cff71d5ff|Hspell:287640:0|h[Unstete Ladung]|h|r (O: 15.1k) [Unstete Ladung] (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [205]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801100,
							["arg1"] = "PS Gestorben: Salanâ > 139k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [206]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801100,
							["arg1"] = "PS Gestorben: Alleycut > 96k, |cff71d5ff|Hspell:287645:0|h[Unstete Ladung]|h|r (O: 17.3k) [Salanâ] (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [207]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801101,
							["arg1"] = "PS Gestorben: {rt7}Laki > 116k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 20k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [208]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801117,
							["arg1"] = "Oh thank GOODNESS! Don't you worry, my precious baby boy. I'm gonna take good care of you.",
						}, -- [209]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553801126,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [210]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553801130,
							["arg1"] = "RSC > Metó hat einen Seelenbrunnen aufgestellt!",
							["clColor"] = "ffc59a6c",
						}, -- [211]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801189,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [212]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801328,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [213]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801343,
							["arg1"] = "PS Gestorben: {rt7}Laki > 23.7k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 2.5k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [214]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801371,
							["arg1"] = "PS Gestorben: Kalissta > 17.1k, |cff71d5ff|Hspell:283507:0|h[Unstete Ladung]|h|r [Die Hand von In'zashi] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [215]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801416,
							["arg1"] = "Class... dismissed.",
							["clColor"] = "fffe7b09",
						}, -- [216]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801418,
							["arg1"] = "PS Gestorben: Nelwyn > 91k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 49k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [217]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801420,
							["arg1"] = "Well... done, heh. But I wonder if you're good enough... to best him.",
							["clColor"] = "fffefefe",
						}, -- [218]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801420,
							["arg1"] = "PS Gestorben: Qyix > 251k, |cff71d5ff|Hspell:287424:0|h[Fluch des Diebes]|h|r (O: 419k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [219]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801425,
							["arg1"] = "PS Gestorben: Metó > 287k, |cff71d5ff|Hspell:287424:0|h[Fluch des Diebes]|h|r (O: 304k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [220]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801436,
							["arg1"] = "PS Gestorben: Aspern > 73k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 60k)  (Feuer). Kauterisieren spent (1.8 Sek. zuvor) > 12.5k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r (O: 121k) [Unstete Ladung]",
							["clColor"] = "ffc59a6c",
						}, -- [221]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801436,
							["arg1"] = "PS Gestorben: Dovomir > 36k, |cff71d5ff|Hspell:286501:0|h[Kriechende Flammen]|h|r (O: 125k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [222]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801437,
							["arg1"] = "PS Gestorben: Salanâ > 146k, |cff71d5ff|Hspell:287645:0|h[Unstete Ladung]|h|r [Alleycut] (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [223]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553801461,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [224]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801516,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [225]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801636,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [226]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801637,
							["arg1"] = "You! You need more practice.",
							["clColor"] = "ffc59a6c",
						}, -- [227]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801640,
							["arg1"] = "Yogg-Saron! Grant me your power!",
							["clColor"] = "ffa22fc8",
						}, -- [228]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801755,
							["arg1"] = "PS Gestorben: Aspern > 257k, |cff71d5ff|Hspell:287424:0|h[Fluch des Diebes]|h|r (O: 375k)  (Schatten). Kauterisieren spent (0.1 Sek. zuvor) > 257k, |cff71d5ff|Hspell:287424:0|h[Fluch des Diebes]|h|r (O: 375k)",
							["clColor"] = "ffc59a6c",
						}, -- [229]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801762,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [230]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801806,
							["arg1"] = "PS Gestorben: Soely > 62k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 41k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [231]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801813,
							["arg1"] = "PS Gestorben: Ðaisuke > 21.3k, |cff71d5ff|Hspell:283609:0|h[Zermalmen]|h|r (O: 15k) [Yalats Bollwerk] (Körperlich)",
							["clColor"] = "ffc59a6c",
						}, -- [232]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801827,
							["arg1"] = "PS Gestorben: {rt7}Laki > 17.3k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 177k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [233]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801830,
							["arg1"] = "PS Gestorben: Soely > 10.3k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 197k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [234]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801831,
							["arg1"] = "PS Gestorben: Isery > 97k, |cff71d5ff|Hspell:287513:0|h[Flammen der Bestrafung]|h|r (O: 87k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [235]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801834,
							["arg1"] = "PS Gestorben: Hornpubmonk > 127k, |cff71d5ff|Hspell:287640:0|h[Unstete Ladung]|h|r (O: 5k) [Unstete Ladung] (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [236]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553801834,
							["arg1"] = "PS Gestorben: Nelwyn > 115k, |cff71d5ff|Hspell:287640:0|h[Unstete Ladung]|h|r (O: 14.8k) [Unstete Ladung] (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [237]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801861,
							["arg1"] = "Serves ya right!",
						}, -- [238]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553801872,
							["arg1"] = "RSC > Laki hat ein Festmahl zubereitet! > Blutiges Festmahl",
							["clColor"] = "ffc59a6c",
						}, -- [239]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801930,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [240]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802024,
							["arg1"] = "PS Gestorben: Hornpubmonk > 62k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 106k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [241]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802024,
							["arg1"] = "PS Gestorben: Inánná > 143k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 20.3k) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [242]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802090,
							["arg1"] = "PS Gestorben: Ðaisuke > 19.7k, |cff71d5ff|Hspell:284424:0|h[Sengender Boden]|h|r (O: 31k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [243]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802112,
							["arg1"] = "PS Gestorben: Tyrellan > 19.8k, |cff71d5ff|Hspell:283063:0|h[Flammen der Bestrafung]|h|r (O: 323) [Yalats Bollwerk] (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [244]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802116,
							["arg1"] = "PS Gestorben: Almîna > 105k, |cff71d5ff|Hspell:284472:0|h[Tödliche Verhexung]|h|r (O: 73k)  (Schatten)",
							["clColor"] = "ffc59a6c",
						}, -- [245]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802127,
							["arg1"] = "PS Gestorben: Salanâ > 93k, |cff71d5ff|Hspell:285479:0|h[Flammenstrahl]|h|r (absorbiert von |cff71d5ff|Hspell:27827:0|h[Geist der Erlösung]|h|r)",
							["clColor"] = "ffc59a6c",
						}, -- [246]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802127,
							["arg1"] = "PS Gestorben: Dovomir > 57k, |cff71d5ff|Hspell:284424:0|h[Sengender Boden]|h|r (O: 1.7k)  (Feuer)",
							["clColor"] = "ffc59a6c",
						}, -- [247]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID",
							["time"] = 1553802129,
							["arg1"] = "PS Gestorben: Qyix > 96k, |cff71d5ff|Hspell:283574:0|h[Unstete Ladung]|h|r (O: 36k) [Unstete Ladung] (Natur)",
							["clColor"] = "ffc59a6c",
						}, -- [248]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553802146,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [249]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "RAID_WARNING",
							["time"] = 1553802176,
							["arg1"] = "RSC > Metó hat einen Seelenbrunnen aufgestellt!",
							["clColor"] = "ffc59a6c",
						}, -- [250]
					},
				}, -- [2]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Party",
					["logs"] = {
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553790571,
							["arg1"] = "sry doesnt read ur first answer :D",
							["clColor"] = "ffa22fc8",
						}, -- [1]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553790580,
							["arg1"] = "all his high keys are with players 1.7k and up",
							["clColor"] = "fffef367",
						}, -- [2]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790580,
							["arg1"] = "so? Neither do I",
							["clColor"] = "fff38bb9",
						}, -- [3]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790591,
							["arg1"] = "ah lol",
							["clColor"] = "fff38bb9",
						}, -- [4]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790620,
							["arg1"] = "you french?",
							["clColor"] = "fff38bb9",
						}, -- [5]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553790625,
							["arg1"] = "german",
							["clColor"] = "fffef367",
						}, -- [6]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790644,
							["arg1"] = "scol?",
							["clColor"] = "fff38bb9",
						}, -- [7]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790654,
							["arg1"] = "don't rember if tha's german",
							["clColor"] = "fff38bb9",
						}, -- [8]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553790668,
							["arg1"] = "think that's swedish",
							["clColor"] = "fffef367",
						}, -- [9]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790673,
							["arg1"] = "prost?",
							["clColor"] = "fff38bb9",
						}, -- [10]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553790750,
							["arg1"] = "my raider.io addon sucks",
							["clColor"] = "ffa22fc8",
						}, -- [11]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553790782,
							["arg1"] = "I wish Rio website could show all the chars scores and not only Main's one",
							["clColor"] = "fff38bb9",
						}, -- [12]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553790873,
							["arg1"] = "hi all",
							["clColor"] = "ff006fdc",
						}, -- [13]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553790873,
							["arg1"] = "hi",
							["clColor"] = "fffef367",
						}, -- [14]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553790877,
							["arg1"] = "hey ;)",
							["clColor"] = "ffa9d271",
						}, -- [15]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791024,
							["arg1"] = "what key guys ? i dont remember lol",
							["clColor"] = "ff006fdc",
						}, -- [16]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553791031,
							["arg1"] = "temple",
							["clColor"] = "fffef367",
						}, -- [17]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791036,
							["arg1"] = "ok",
							["clColor"] = "ff006fdc",
						}, -- [18]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553791041,
							["arg1"] = "then arway",
							["clColor"] = "fffef367",
						}, -- [19]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553791044,
							["arg1"] = "shittralis :D ",
							["clColor"] = "ffa9d271",
						}, -- [20]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553791046,
							["arg1"] = "*arcway",
							["clColor"] = "fffef367",
						}, -- [21]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791050,
							["arg1"] = "can you me summ plz .",
							["clColor"] = "ff006fdc",
						}, -- [22]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553791056,
							["arg1"] = "sure",
							["clColor"] = "fffef367",
						}, -- [23]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791060,
							["arg1"] = "ty :)",
							["clColor"] = "ff006fdc",
						}, -- [24]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791129,
							["arg1"] = "thanks",
							["clColor"] = "ff006fdc",
						}, -- [25]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791188,
							["arg1"] = "this pack, then shroud",
							["clColor"] = "fffef367",
						}, -- [26]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791230,
							["arg1"] = "...",
							["clColor"] = "fffef367",
						}, -- [27]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553791284,
							["arg1"] = "hunter?",
							["clColor"] = "fff38bb9",
						}, -- [28]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791294,
							["arg1"] = "are you fucking retarded, Hunter?",
							["clColor"] = "fffef367",
						}, -- [29]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553791298,
							["arg1"] = "lag saw you run in sorry",
							["clColor"] = "ffa9d271",
						}, -- [30]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791299,
							["arg1"] = "why the fuck you attack?",
							["clColor"] = "fffef367",
						}, -- [31]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791308,
							["arg1"] = "yeah, run in with shroud",
							["clColor"] = "fffef367",
						}, -- [32]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791314,
							["arg1"] = "which I said like 2 times before",
							["clColor"] = "fffef367",
						}, -- [33]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791346,
							["arg1"] = "Rise, fallen ones!",
						}, -- [34]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791351,
							["arg1"] = "god",
							["clColor"] = "ff006fdc",
						}, -- [35]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553791364,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [36]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553791396,
							["arg1"] = "fiuu",
							["clColor"] = "ff006fdc",
						}, -- [37]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791432,
							["arg1"] = "Die, vermin!",
						}, -- [38]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791455,
							["arg1"] = "Break them, Adderis!",
						}, -- [39]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791460,
							["arg1"] = "Thunder crash!",
						}, -- [40]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791475,
							["arg1"] = "Arcing slash!",
						}, -- [41]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791493,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [42]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791515,
							["arg1"] = "Break them, Adderis!",
						}, -- [43]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791520,
							["arg1"] = "Thunder crash!",
						}, -- [44]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791534,
							["arg1"] = "What will become... of the empire...",
						}, -- [45]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791534,
							["arg1"] = "Arcing slash!",
						}, -- [46]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791537,
							["arg1"] = "The sands... take me...",
						}, -- [47]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791647,
							["arg1"] = "Rise, fallen ones!",
						}, -- [48]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553791649,
							["arg1"] = "reaping soon",
							["clColor"] = "fffef367",
						}, -- [49]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553791819,
							["arg1"] = "1% :_D ",
							["clColor"] = "ffa9d271",
						}, -- [50]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553791843,
							["arg1"] = "reaping",
							["clColor"] = "ffa22fc8",
						}, -- [51]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791860,
							["arg1"] = "Rise, fallen ones!",
						}, -- [52]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553792039,
							["arg1"] = "FREE HUNT",
							["clColor"] = "ff006fdc",
						}, -- [53]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792043,
							["arg1"] = "cant",
							["clColor"] = "fffef367",
						}, -- [54]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792050,
							["arg1"] = "he was in dust",
							["clColor"] = "fffef367",
						}, -- [55]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553792053,
							["arg1"] = "he was under smoke i think",
							["clColor"] = "fff38bb9",
						}, -- [56]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553792053,
							["arg1"] = "yeah ",
							["clColor"] = "ffa9d271",
						}, -- [57]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792054,
							["arg1"] = "we cant hit",
							["clColor"] = "fffef367",
						}, -- [58]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553792055,
							["arg1"] = "unlucky",
							["clColor"] = "ffa9d271",
						}, -- [59]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553792056,
							["arg1"] = "rofl",
							["clColor"] = "ff006fdc",
						}, -- [60]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792108,
							["arg1"] = "shroud?",
							["clColor"] = "ffa22fc8",
						}, -- [61]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792112,
							["arg1"] = "this pack and then shroud after orbs",
							["clColor"] = "fffef367",
						}, -- [62]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553792150,
							["arg1"] = "2%",
							["clColor"] = "ffa9d271",
						}, -- [63]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792160,
							["arg1"] = "shroud",
							["clColor"] = "fffef367",
						}, -- [64]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553792164,
							["arg1"] = "k",
							["clColor"] = "ffa9d271",
						}, -- [65]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792178,
							["arg1"] = "pull stairs",
							["clColor"] = "fffef367",
						}, -- [66]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792223,
							["arg1"] = "Rise, fallen ones!",
						}, -- [67]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792280,
							["arg1"] = "t4ank 4h4ere4",
							["clColor"] = "ffa22fc8",
						}, -- [68]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792282,
							["arg1"] = "tank here",
							["clColor"] = "ffa22fc8",
						}, -- [69]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792310,
							["arg1"] = "mean boss",
							["clColor"] = "ffa22fc8",
						}, -- [70]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792318,
							["arg1"] = "hero?",
							["clColor"] = "ffa22fc8",
						}, -- [71]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553792321,
							["arg1"] = "yes",
							["clColor"] = "ff006fdc",
						}, -- [72]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792325,
							["arg1"] = "greate :D",
							["clColor"] = "ffa22fc8",
						}, -- [73]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553792356,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [74]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792359,
							["arg1"] = "well",
							["clColor"] = "fffef367",
						}, -- [75]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553792359,
							["arg1"] = "you kidding ?",
							["clColor"] = "ff006fdc",
						}, -- [76]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553792371,
							["arg1"] = "thought that dh gonna tke the first one ",
							["clColor"] = "ffa9d271",
						}, -- [77]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792374,
							["arg1"] = "no shroud",
							["clColor"] = "fffef367",
						}, -- [78]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553792377,
							["arg1"] = "yh same",
							["clColor"] = "fff38bb9",
						}, -- [79]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553792381,
							["arg1"] = "since he was there :D ",
							["clColor"] = "ffa9d271",
						}, -- [80]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792387,
							["arg1"] = "sry :D",
							["clColor"] = "ffa22fc8",
						}, -- [81]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792405,
							["arg1"] = "we can skip the others",
							["clColor"] = "fffef367",
						}, -- [82]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792412,
							["arg1"] = "they don'T aggro if we hug the left wall",
							["clColor"] = "fffef367",
						}, -- [83]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553792435,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [84]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792658,
							["arg1"] = "Rise, fallen ones!",
						}, -- [85]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553792752,
							["arg1"] = "rog can you solo the other orb?",
							["clColor"] = "fff38bb9",
						}, -- [86]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792830,
							["arg1"] = "cleare them",
							["clColor"] = "fffef367",
						}, -- [87]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792833,
							["arg1"] = "and then shroud",
							["clColor"] = "fffef367",
						}, -- [88]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792834,
							["arg1"] = "to boss",
							["clColor"] = "fffef367",
						}, -- [89]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792916,
							["arg1"] = "we can hero",
							["clColor"] = "ffa22fc8",
						}, -- [90]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792917,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [91]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553792918,
							["arg1"] = "on heal",
							["clColor"] = "ffa22fc8",
						}, -- [92]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792919,
							["arg1"] = "btw hunter, my bad about before",
							["clColor"] = "fffef367",
						}, -- [93]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792921,
							["arg1"] = "you are doing",
							["clColor"] = "fffef367",
						}, -- [94]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792928,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [95]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792930,
							["arg1"] = "we had a hunter before in the group who just left",
							["clColor"] = "fffef367",
						}, -- [96]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553792935,
							["arg1"] = "was still pissed",
							["clColor"] = "fffef367",
						}, -- [97]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793010,
							["arg1"] = "hero",
							["clColor"] = "fffef367",
						}, -- [98]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553793074,
							["arg1"] = "use heal pal",
							["clColor"] = "ff006fdc",
						}, -- [99]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793086,
							["arg1"] = "I hold dominion over all!",
						}, -- [100]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793130,
							["arg1"] = "The storm has broken, and I am myself again. Thank you.",
						}, -- [101]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793132,
							["arg1"] = "gj",
							["clColor"] = "fffef367",
						}, -- [102]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793140,
							["arg1"] = "rly dosrry for the start ",
							["clColor"] = "ffa9d271",
						}, -- [103]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793143,
							["arg1"] = "sorry \"",
							["clColor"] = "ffa9d271",
						}, -- [104]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793143,
							["arg1"] = "np",
							["clColor"] = "fffef367",
						}, -- [105]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793146,
							["arg1"] = "sorry myself",
							["clColor"] = "fffef367",
						}, -- [106]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793148,
							["arg1"] = "gj dude",
							["clColor"] = "fffef367",
						}, -- [107]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553793151,
							["arg1"] = "|cffa335ee|Hkeystone:158923:244:11:9:5:3:117|h[Keystone: Atal'Dazar (11)]|h|r",
							["clColor"] = "ffa22fc8",
						}, -- [108]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "PARTY_LEADER",
							["time"] = 1553793155,
							["arg1"] = "?",
							["clColor"] = "ffa22fc8",
						}, -- [109]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553793165,
							["arg1"] = "you need the ring idä ?",
							["clColor"] = "ff006fdc",
						}, -- [110]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793172,
							["arg1"] = "it",
							["clColor"] = "ffa9d271",
						}, -- [111]
						{
							["arg2"] = "Hølymøly-Pozzodell'Eternità",
							["type"] = "PARTY",
							["time"] = 1553793173,
							["arg1"] = "I gotta go now, maybe later this evening",
							["clColor"] = "fff38bb9",
						}, -- [112]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793176,
							["arg1"] = "it",
							["clColor"] = "ffa9d271",
						}, -- [113]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793181,
							["arg1"] = "is higher itl :/",
							["clColor"] = "ffa9d271",
						}, -- [114]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793183,
							["arg1"] = "cant trade",
							["clColor"] = "ffa9d271",
						}, -- [115]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553793185,
							["arg1"] = "oh fuck",
							["clColor"] = "ff006fdc",
						}, -- [116]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793186,
							["arg1"] = "oh, we got raid in 30 min",
							["clColor"] = "fffef367",
						}, -- [117]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553793187,
							["arg1"] = "ok",
							["clColor"] = "ff006fdc",
						}, -- [118]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793188,
							["arg1"] = "stupide blizz",
							["clColor"] = "ffa9d271",
						}, -- [119]
						{
							["arg2"] = "Gougniafier-Dalaran",
							["type"] = "PARTY",
							["time"] = 1553793193,
							["arg1"] = "gg all , bye",
							["clColor"] = "ff006fdc",
						}, -- [120]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793193,
							["arg1"] = "nvm",
							["clColor"] = "fffef367",
						}, -- [121]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793195,
							["arg1"] = "gl hf guys",
							["clColor"] = "fffef367",
						}, -- [122]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "PARTY",
							["time"] = 1553793198,
							["arg1"] = "thx for run",
							["clColor"] = "fffef367",
						}, -- [123]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793211,
							["arg1"] = "cya",
							["clColor"] = "ffa9d271",
						}, -- [124]
						{
							["arg2"] = "Idä-Drak'thul",
							["type"] = "PARTY",
							["time"] = 1553793218,
							["arg1"] = "gotta go raid to :/",
							["clColor"] = "ffa9d271",
						}, -- [125]
						{
							["arg2"] = "Nivus",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793621,
							["arg1"] = "I am not some simple jester! I am Nielas Aran!",
							["clColor"] = "ff8686ec",
						}, -- [126]
						{
							["arg1"] = " ",
						}, -- [127]
						{
							["arg1"] = " ",
						}, -- [128]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [129]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795769,
							["arg1"] = "Your heartbeat is... music to my ears.",
							["clColor"] = "ff00fe95",
						}, -- [130]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795859,
							["arg1"] = "You will pay for invading our lands!",
						}, -- [131]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795923,
							["arg1"] = "Da Amani empire cannot be stopped!",
							["clColor"] = "ffc59a6c",
						}, -- [132]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795929,
							["arg1"] = "You face not Malchezaar alone, but the legions I command!",
							["clColor"] = "ff8686ec",
						}, -- [133]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795929,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "fffefefe",
						}, -- [134]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795939,
							["arg1"] = "Skill with a weapon is but a physical manifestation of one's martial strength. Let me show you what spiritual power is!",
							["clColor"] = "ffc31d39",
						}, -- [135]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795964,
							["arg1"] = "Who dares interrupt--What is this; what have you done? You'll ruin everything!",
							["clColor"] = "fffe7b09",
						}, -- [136]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795966,
							["arg1"] = "Charrrrrge!",
							["clColor"] = "ff00fe95",
						}, -- [137]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795969,
							["arg1"] = "I have tried to be an accommodating host, but you simply will not die! Time to throw all pretense aside and just... KILL YOU ALL!",
							["clColor"] = "fff38bb9",
						}, -- [138]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795969,
							["arg1"] = "Have you vermin ever witnessed such raw power? I think not.",
							["clColor"] = "ffa22fc8",
						}, -- [139]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795977,
							["arg1"] = "Bjorn of the Black Storm! Honor me now with your presence!",
							["clColor"] = "fffe7b09",
						}, -- [140]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795984,
							["arg1"] = "HERETICS! You will suffer for this interruption!",
							["clColor"] = "ff8686ec",
						}, -- [141]
						{
							["arg2"] = "Samîsu",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796037,
							["arg1"] = "Time shifts again, and your doom draws near!",
							["clColor"] = "ffa9d271",
						}, -- [142]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796318,
							["arg1"] = "For Zandalar!",
						}, -- [143]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796320,
							["arg1"] = "I am a conduit of the Nightwell's glorious power! I am NIGHTBORNE!",
							["clColor"] = "ffa22fc8",
						}, -- [144]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796321,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [145]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796321,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [146]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796332,
							["arg1"] = "De Light judges all!",
						}, -- [147]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796335,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [148]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796350,
							["arg1"] = "Defeat has never tasted so bitter...",
							["clColor"] = "fff38bb9",
						}, -- [149]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796357,
							["arg1"] = "De Light judges all!",
						}, -- [150]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796370,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [151]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796383,
							["arg1"] = "De reckoning is at hand!",
						}, -- [152]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796389,
							["arg1"] = "To arms! Drive dese outsiders from Zuldazar!",
						}, -- [153]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796396,
							["arg1"] = "De Light judges all!",
						}, -- [154]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796426,
							["arg1"] = "De Light judges all!",
						}, -- [155]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796437,
							["arg1"] = "Retribution for de fallen!",
						}, -- [156]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "De Light judges all!",
						}, -- [157]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "Light guide me... to de... Other Side...",
						}, -- [158]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796523,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [159]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796525,
							["arg1"] = "All realities, all dimensions are open to me!",
							["clColor"] = "ff8686ec",
						}, -- [160]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796536,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [161]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796540,
							["arg1"] = "Never heard my blade coming!",
							["clColor"] = "ffa22fc8",
						}, -- [162]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796546,
							["arg1"] = "HAH!",
							["clColor"] = "fff38bb9",
						}, -- [163]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796550,
							["arg1"] = "AG VWYQ ZA AN'ZIG ",
							["clColor"] = "fffefefe",
						}, -- [164]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796553,
							["arg1"] = "Your greed, your foolishness has brought you to this end.",
							["clColor"] = "ff8686ec",
						}, -- [165]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796564,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [166]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796572,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [167]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796647,
							["arg1"] = "Mortal minds... So easily manipulated.",
							["clColor"] = "fff38bb9",
						}, -- [168]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796649,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [169]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796651,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [170]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796653,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [171]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796682,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [172]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796696,
							["arg1"] = "Incoming!",
							["clColor"] = "ffc59a6c",
						}, -- [173]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796702,
							["arg1"] = "Your technique needs work.",
							["clColor"] = "ffc31d39",
						}, -- [174]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796735,
							["arg1"] = "Just as you deserve!",
							["clColor"] = "fffe7b09",
						}, -- [175]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796752,
							["arg1"] = "If only you understood!",
							["clColor"] = "ffa9d271",
						}, -- [176]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796767,
							["arg1"] = "I thank you for coming, but you really all must die now!",
							["clColor"] = "fff38bb9",
						}, -- [177]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796773,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [178]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796774,
							["arg1"] = "Out da way!",
							["clColor"] = "ffc59a6c",
						}, -- [179]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796776,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [180]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796778,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [181]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796844,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [182]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796845,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [183]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796847,
							["arg1"] = "A taste... just a small taste... of the Spell-Weaver's power!",
							["clColor"] = "ffa9d271",
						}, -- [184]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796848,
							["arg1"] = "Ha! I have fought goren that proved more of a challenge!",
						}, -- [185]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796849,
							["arg1"] = "You will burn to ashes!",
						}, -- [186]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796854,
							["arg1"] = "You see? I told you they were nothing to worry about.",
						}, -- [187]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796913,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [188]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796914,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [189]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796915,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [190]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796918,
							["arg1"] = "You will burn to ashes!",
						}, -- [191]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796919,
							["arg1"] = "Brawl... with Rook.",
							["clColor"] = "fff38bb9",
						}, -- [192]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796923,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [193]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796925,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [194]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796929,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [195]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796940,
							["arg1"] = "Better watch your step!",
						}, -- [196]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796943,
							["arg1"] = "Your defense is feeble!",
						}, -- [197]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796961,
							["arg1"] = "Time to test your mettle!",
						}, -- [198]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796967,
							["arg1"] = "The elements will break you!",
						}, -- [199]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796971,
							["arg1"] = "The phoenix takes many forms!",
						}, -- [200]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796977,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [201]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796978,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [202]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796982,
							["arg1"] = "What... awaits me... now?",
							["clColor"] = "fffe7b09",
						}, -- [203]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "You really have to want it!",
							["clColor"] = "fff38bb9",
						}, -- [204]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "There is only one true path of enlightenment! DEATH!",
							["clColor"] = "ff8686ec",
						}, -- [205]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796993,
							["arg1"] = "Better watch your step!",
						}, -- [206]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797003,
							["arg1"] = "Guess I... be off... ta the locker...",
							["clColor"] = "ff00fe95",
						}, -- [207]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797010,
							["arg1"] = "Your defense is feeble!",
						}, -- [208]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797028,
							["arg1"] = "Time to test your mettle!",
						}, -- [209]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797031,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [210]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797041,
							["arg1"] = "Better watch your step!",
						}, -- [211]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Your defense is feeble!",
						}, -- [212]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Better watch your step!",
						}, -- [213]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797106,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [214]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797123,
							["arg1"] = "Time to test your mettle!",
						}, -- [215]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797146,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [216]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797152,
							["arg1"] = "Better watch your step!",
						}, -- [217]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [218]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Better watch your step!",
						}, -- [219]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797198,
							["arg1"] = "Better watch your step!",
						}, -- [220]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797210,
							["arg1"] = "Better watch your step!",
						}, -- [221]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797212,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [222]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797220,
							["arg1"] = "Better watch your step!",
						}, -- [223]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799231,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "ffc59a6c",
						}, -- [224]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799318,
							["arg1"] = "The waters whisper to me... enemies approach.",
							["clColor"] = "ffa9d271",
						}, -- [225]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799325,
							["arg1"] = "Avast, ye bilge suckers!",
							["clColor"] = "fffefefe",
						}, -- [226]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799752,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [227]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799875,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [228]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800176,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [229]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800349,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [230]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800753,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [231]
						{
							["arg2"] = "Isery",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800804,
							["arg1"] = "None may challenge the Brotherhood!",
							["clColor"] = "fffe7b09",
						}, -- [232]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800822,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [233]
						{
							["arg2"] = "Ðaisuke",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800831,
							["arg1"] = "Pay for your crimes!",
							["clColor"] = "ffa22fc8",
						}, -- [234]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800943,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [235]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800963,
							["arg1"] = "W'OQ ZA ",
							["clColor"] = "fffefefe",
						}, -- [236]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801085,
							["arg1"] = "YOUR SOUL IS MINE!",
							["clColor"] = "fffe7b09",
						}, -- [237]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801117,
							["arg1"] = "Oh thank GOODNESS! Don't you worry, my precious baby boy. I'm gonna take good care of you.",
						}, -- [238]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801189,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [239]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801328,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [240]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801416,
							["arg1"] = "Class... dismissed.",
							["clColor"] = "fffe7b09",
						}, -- [241]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801420,
							["arg1"] = "Well... done, heh. But I wonder if you're good enough... to best him.",
							["clColor"] = "fffefefe",
						}, -- [242]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801516,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [243]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801636,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [244]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801637,
							["arg1"] = "You! You need more practice.",
							["clColor"] = "ffc59a6c",
						}, -- [245]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801640,
							["arg1"] = "Yogg-Saron! Grant me your power!",
							["clColor"] = "ffa22fc8",
						}, -- [246]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801762,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [247]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801861,
							["arg1"] = "Serves ya right!",
						}, -- [248]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801930,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [249]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553802146,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [250]
					},
				}, -- [3]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Say",
					["logs"] = {
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800894,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffa9d271",
						}, -- [1]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800894,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [2]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800899,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [3]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800899,
							["arg1"] = "Volatile Charge on Nelwyn",
							["clColor"] = "fffe7b09",
						}, -- [4]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800899,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [5]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800904,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [6]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800904,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffe7b09",
						}, -- [7]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800904,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [8]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800905,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [9]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800905,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffe7b09",
						}, -- [10]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800905,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [11]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800906,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [12]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800906,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffe7b09",
						}, -- [13]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800906,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [14]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800968,
							["arg1"] = "Hex of Lethargy on Inánná",
							["clColor"] = "fff38bb9",
						}, -- [15]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800968,
							["arg1"] = "Verhexung der Lethargie auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [16]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553800990,
							["arg1"] = "Hex of Lethargy on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [17]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801011,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffc59a6c",
						}, -- [18]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801011,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [19]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801011,
							["arg1"] = "2",
							["clColor"] = "fffe7b09",
						}, -- [20]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801012,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [21]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801012,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffc59a6c",
						}, -- [22]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801012,
							["arg1"] = "1",
							["clColor"] = "fffe7b09",
						}, -- [23]
						{
							["arg2"] = "Aspern-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801017,
							["arg1"] = "Unstete Ladung auf Aspern",
							["clColor"] = "ff3ec5e9",
						}, -- [24]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801017,
							["arg1"] = "Volatile Charge on Nelwyn",
							["clColor"] = "fffe7b09",
						}, -- [25]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801017,
							["arg1"] = "Volatile Charge on Alleycut",
							["clColor"] = "ffa22fc8",
						}, -- [26]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801022,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffe7b09",
						}, -- [27]
						{
							["arg2"] = "Aspern-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801022,
							["arg1"] = "3",
							["clColor"] = "ff3ec5e9",
						}, -- [28]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801022,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [29]
						{
							["arg2"] = "Aspern-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801023,
							["arg1"] = "2",
							["clColor"] = "ff3ec5e9",
						}, -- [30]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801023,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffe7b09",
						}, -- [31]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801023,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [32]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801024,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [33]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801034,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [34]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801034,
							["arg1"] = "Volatile Charge on Alleycut",
							["clColor"] = "ffa22fc8",
						}, -- [35]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801034,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [36]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801039,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [37]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801039,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [38]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801039,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [39]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801040,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [40]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801040,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [41]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801040,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffa9d271",
						}, -- [42]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801041,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [43]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801041,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffa9d271",
						}, -- [44]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801041,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [45]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801046,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [46]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801046,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [47]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801046,
							["arg1"] = "Volatile Charge on Alleycut",
							["clColor"] = "ffa22fc8",
						}, -- [48]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801051,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [49]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801051,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [50]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801051,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [51]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801052,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [52]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801052,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffa9d271",
						}, -- [53]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801052,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [54]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801053,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [55]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801053,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [56]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801053,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffa9d271",
						}, -- [57]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801070,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [58]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801070,
							["arg1"] = "Volatile Charge on Isery",
							["clColor"] = "fffe7b09",
						}, -- [59]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801071,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [60]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801076,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [61]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801077,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [62]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801078,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [63]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801083,
							["arg1"] = "Volatile Charge on Inánná",
							["clColor"] = "fff38bb9",
						}, -- [64]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801083,
							["arg1"] = "Unstete Ladung auf Laki",
							["clColor"] = "fffe7b09",
						}, -- [65]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801083,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [66]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801088,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fff38bb9",
						}, -- [67]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801088,
							["arg1"] = "3",
							["clColor"] = "fffe7b09",
						}, -- [68]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801088,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [69]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801089,
							["arg1"] = "2",
							["clColor"] = "fffe7b09",
						}, -- [70]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801089,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [71]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801090,
							["arg1"] = "1",
							["clColor"] = "fffe7b09",
						}, -- [72]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801095,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [73]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801095,
							["arg1"] = "Volatile Charge on Inánná",
							["clColor"] = "fff38bb9",
						}, -- [74]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801100,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fff38bb9",
						}, -- [75]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801100,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [76]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801101,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fff38bb9",
						}, -- [77]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801101,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [78]
						{
							["arg2"] = "Isery-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801113,
							["arg1"] = "Volatile Charge on Isery",
							["clColor"] = "fffe7b09",
						}, -- [79]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801113,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [80]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_EMOTE",
							["time"] = 1553801123,
							["arg1"] = "Laki prepares a Sanguinated Feast!",
							["clColor"] = "fffe7b09",
						}, -- [81]
						{
							["arg2"] = "Gnimo",
							["type"] = "MONSTER_SAY",
							["time"] = 1553801140,
							["arg1"] = "Time for Gnimo to shut down.",
						}, -- [82]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801317,
							["arg1"] = "Verhexung der Lethargie auf Almîna",
							["clColor"] = "ff006fdc",
						}, -- [83]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801318,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [84]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801318,
							["arg1"] = "Unstete Ladung auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [85]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801318,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [86]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801323,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [87]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801323,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [88]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801323,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffc59a6c",
						}, -- [89]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801324,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [90]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801324,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [91]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801324,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffc59a6c",
						}, -- [92]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801325,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [93]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801325,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffc59a6c",
						}, -- [94]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801325,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [95]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801330,
							["arg1"] = "Unstete Ladung auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [96]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801330,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [97]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801330,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [98]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801335,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [99]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801335,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffc59a6c",
						}, -- [100]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801335,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [101]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801336,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffc59a6c",
						}, -- [102]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801336,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [103]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801336,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [104]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801337,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffc59a6c",
						}, -- [105]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801337,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [106]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801337,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [107]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801339,
							["arg1"] = "Hex of Lethargy on Inánná",
							["clColor"] = "fff38bb9",
						}, -- [108]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801357,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [109]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801357,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [110]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801357,
							["arg1"] = "Unstete Ladung auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [111]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801362,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [112]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801362,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffc59a6c",
						}, -- [113]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801362,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [114]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801363,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffa9d271",
						}, -- [115]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801363,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffc59a6c",
						}, -- [116]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801364,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffc59a6c",
						}, -- [117]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801369,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [118]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801369,
							["arg1"] = "Unstete Ladung auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [119]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801374,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [120]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801374,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffc59a6c",
						}, -- [121]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801375,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffc59a6c",
						}, -- [122]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801394,
							["arg1"] = "Unstete Ladung auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [123]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801394,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [124]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801394,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [125]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801399,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [126]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801399,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [127]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801400,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [128]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801401,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [129]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_EMOTE",
							["time"] = 1553801459,
							["arg1"] = "Laki prepares a Sanguinated Feast!",
							["clColor"] = "fffe7b09",
						}, -- [130]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801555,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [131]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801555,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffa9d271",
						}, -- [132]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801556,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffa9d271",
						}, -- [133]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801586,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ff8686ec",
						}, -- [134]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801587,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ff8686ec",
						}, -- [135]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801658,
							["arg1"] = "Hex of Lethargy on Ðaisuke",
							["clColor"] = "ffa22fc8",
						}, -- [136]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801658,
							["arg1"] = "Verhexung der Lethargie auf Soely",
							["clColor"] = "ff006fdc",
						}, -- [137]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801680,
							["arg1"] = "Verhexung der Lethargie auf Soely",
							["clColor"] = "ff006fdc",
						}, -- [138]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801705,
							["arg1"] = "Unstete Ladung auf Almîna",
							["clColor"] = "ff006fdc",
						}, -- [139]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801705,
							["arg1"] = "Unstete Ladung auf Laki",
							["clColor"] = "fffe7b09",
						}, -- [140]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801705,
							["arg1"] = "Unstete Ladung auf Metó",
							["clColor"] = "ff8686ec",
						}, -- [141]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801710,
							["arg1"] = "3",
							["clColor"] = "fffe7b09",
						}, -- [142]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801711,
							["arg1"] = "2",
							["clColor"] = "fffe7b09",
						}, -- [143]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801711,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ff8686ec",
						}, -- [144]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801712,
							["arg1"] = "1",
							["clColor"] = "fffe7b09",
						}, -- [145]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801712,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ff8686ec",
						}, -- [146]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801722,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [147]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801722,
							["arg1"] = "Unstete Ladung auf Laki",
							["clColor"] = "fffe7b09",
						}, -- [148]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801722,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [149]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801727,
							["arg1"] = "3",
							["clColor"] = "fffe7b09",
						}, -- [150]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801727,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [151]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801727,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [152]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801728,
							["arg1"] = "2",
							["clColor"] = "fffe7b09",
						}, -- [153]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801728,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [154]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801728,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [155]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801729,
							["arg1"] = "1",
							["clColor"] = "fffe7b09",
						}, -- [156]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801729,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [157]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801750,
							["arg1"] = "Volatile Charge on Ðaisuke",
							["clColor"] = "ffa22fc8",
						}, -- [158]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801750,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [159]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801751,
							["arg1"] = "Unstete Ladung auf Almîna",
							["clColor"] = "ff006fdc",
						}, -- [160]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801755,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "ffa22fc8",
						}, -- [161]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801755,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [162]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801756,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "ffa22fc8",
						}, -- [163]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801756,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [164]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801758,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [165]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801758,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "ffa22fc8",
						}, -- [166]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801762,
							["arg1"] = "Volatile Charge on Ðaisuke",
							["clColor"] = "ffa22fc8",
						}, -- [167]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801762,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [168]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801762,
							["arg1"] = "Unstete Ladung auf Metó",
							["clColor"] = "ff8686ec",
						}, -- [169]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801767,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [170]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801774,
							["arg1"] = "Volatile Charge on Inánná",
							["clColor"] = "fff38bb9",
						}, -- [171]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801774,
							["arg1"] = "Unstete Ladung auf Dovomir",
							["clColor"] = "ffc59a6c",
						}, -- [172]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801774,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [173]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801779,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [174]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801780,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [175]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801781,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [176]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801789,
							["arg1"] = "Unstete Ladung auf Metó",
							["clColor"] = "ff8686ec",
						}, -- [177]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801789,
							["arg1"] = "Unstete Ladung auf Laki",
							["clColor"] = "fffe7b09",
						}, -- [178]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801789,
							["arg1"] = "Unstete Ladung auf Almîna",
							["clColor"] = "ff006fdc",
						}, -- [179]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801794,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ff8686ec",
						}, -- [180]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801795,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ff8686ec",
						}, -- [181]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801796,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ff8686ec",
						}, -- [182]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801804,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [183]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801805,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [184]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801805,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [185]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801810,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [186]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801810,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [187]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801811,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [188]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801811,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [189]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801812,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [190]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801812,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [191]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801820,
							["arg1"] = "Volatile Charge on Inánná",
							["clColor"] = "fff38bb9",
						}, -- [192]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801820,
							["arg1"] = "Unstete Ladung auf Laki",
							["clColor"] = "fffe7b09",
						}, -- [193]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801820,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [194]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801824,
							["arg1"] = "Gütiges Strahlen! auf Metó",
							["clColor"] = "ff8686ec",
						}, -- [195]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801826,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fff38bb9",
						}, -- [196]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801836,
							["arg1"] = "Unstete Ladung auf Almîna",
							["clColor"] = "ff006fdc",
						}, -- [197]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801836,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [198]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801836,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [199]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801841,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [200]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801843,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [201]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553801843,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [202]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_EMOTE",
							["time"] = 1553801871,
							["arg1"] = "Laki prepares a Sanguinated Feast!",
							["clColor"] = "fffe7b09",
						}, -- [203]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802030,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [204]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802030,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [205]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802030,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [206]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802036,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [207]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802036,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [208]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802036,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [209]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802036,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [210]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802036,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffa9d271",
						}, -- [211]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802037,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [212]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802038,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "ffa9d271",
						}, -- [213]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802038,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [214]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802038,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [215]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802043,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [216]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802043,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [217]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802043,
							["arg1"] = "Volatile Charge on Tyrellan",
							["clColor"] = "ffa22fc8",
						}, -- [218]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802048,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [219]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802048,
							["arg1"] = "Volatile Charge fading in 3",
							["clColor"] = "fffef367",
						}, -- [220]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802048,
							["arg1"] = "3",
							["clColor"] = "ffa22fc8",
						}, -- [221]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802049,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [222]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802049,
							["arg1"] = "Volatile Charge fading in 2",
							["clColor"] = "fffef367",
						}, -- [223]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802049,
							["arg1"] = "2",
							["clColor"] = "ffa22fc8",
						}, -- [224]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802050,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [225]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802050,
							["arg1"] = "Volatile Charge fading in 1",
							["clColor"] = "fffef367",
						}, -- [226]
						{
							["arg2"] = "Tyrellan-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802050,
							["arg1"] = "1",
							["clColor"] = "ffa22fc8",
						}, -- [227]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802085,
							["arg1"] = "Verhexung der Lethargie auf Soely",
							["clColor"] = "ff006fdc",
						}, -- [228]
						{
							["arg2"] = "Nelwyn-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802085,
							["arg1"] = "Hex of Lethargy on Nelwyn",
							["clColor"] = "fffe7b09",
						}, -- [229]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802090,
							["arg1"] = "Verhexung der Lethargie auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [230]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802100,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [231]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802100,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [232]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802100,
							["arg1"] = "Unstete Ladung auf Neferupitou",
							["clColor"] = "ffa9d271",
						}, -- [233]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802105,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [234]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802105,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [235]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802105,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "ffa9d271",
						}, -- [236]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802106,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [237]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802106,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [238]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802106,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "ffa9d271",
						}, -- [239]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802107,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [240]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802112,
							["arg1"] = "Unstete Ladung auf Salanâ",
							["clColor"] = "fffefefe",
						}, -- [241]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802112,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [242]
						{
							["arg2"] = "Qyix-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802112,
							["arg1"] = "Zuq'nish Yu'gaz za Ryiu",
							["clColor"] = "fffefefe",
						}, -- [243]
						{
							["arg2"] = "Qyix-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802117,
							["arg1"] = "I",
							["clColor"] = "fffefefe",
						}, -- [244]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802117,
							["arg1"] = "Unstete Ladung endet in 3",
							["clColor"] = "fffefefe",
						}, -- [245]
						{
							["arg2"] = "Qyix-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802119,
							["arg1"] = "I",
							["clColor"] = "fffefefe",
						}, -- [246]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802119,
							["arg1"] = "Unstete Ladung endet in 2",
							["clColor"] = "fffefefe",
						}, -- [247]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802119,
							["arg1"] = "Unstete Ladung endet in 1",
							["clColor"] = "fffefefe",
						}, -- [248]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802134,
							["arg1"] = "Unstete Ladung auf Kalissta",
							["clColor"] = "fffefefe",
						}, -- [249]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "SAY",
							["time"] = 1553802146,
							["arg1"] = "Volatile Charge on Noxiâ",
							["clColor"] = "fffef367",
						}, -- [250]
					},
				}, -- [4]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Yell",
					["logs"] = {
						{
							["arg1"] = " ",
						}, -- [1]
						{
							["arg1"] = " ",
						}, -- [2]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [3]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775583,
							["arg1"] = "Don't look so smug! I know what you're thinking, but Tempest Keep was merely a setback. Did you honestly believe I would trust the future to some blind, half-night elf mongrel? Oh no, he was merely an instrument, a stepping stone to a much larger plan! It has all led to this... and this time you will not interfere!",
							["clColor"] = "ff00fe95",
						}, -- [4]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775587,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [5]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775611,
							["arg1"] = "Don't value your life very much, do you?",
							["clColor"] = "ff006fdc",
						}, -- [6]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775695,
							["arg1"] = "Vengeance burns!",
							["clColor"] = "ff00fe95",
						}, -- [7]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775695,
							["arg1"] = "Do not get... too comfortable.",
							["clColor"] = "ff00fe95",
						}, -- [8]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775698,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [9]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775709,
							["arg1"] = "Anar'endal dracon!",
							["clColor"] = "ff006fdc",
						}, -- [10]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775762,
							["arg1"] = "Ee-nok Kryul!",
							["clColor"] = "fffe7b09",
						}, -- [11]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775810,
							["arg1"] = "",
							["clColor"] = "ff006fdc",
						}, -- [12]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775816,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [13]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775820,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [14]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775830,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [15]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775859,
							["arg1"] = "Rise, fallen ones!",
						}, -- [16]
						{
							["arg2"] = "Whigham-Ravencrest",
							["type"] = "YELL",
							["time"] = 1553775859,
							["arg1"] = "Reaping time!",
							["clColor"] = "ff00fe95",
						}, -- [17]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775893,
							["arg1"] = "Shadows engulf.",
							["clColor"] = "fffe7b09",
						}, -- [18]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775909,
							["arg1"] = "Felomin Ashal! ",
							["clColor"] = "ff00fe95",
						}, -- [19]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775939,
							["arg1"] = "Master, grant me strength.",
							["clColor"] = "ff00fe95",
						}, -- [20]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775957,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [21]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775963,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [22]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775967,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [23]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775991,
							["arg1"] = "Break them, Adderis!",
						}, -- [24]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775995,
							["arg1"] = "Thunder crash!",
						}, -- [25]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776010,
							["arg1"] = "Arcing slash!",
						}, -- [26]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776029,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [27]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776052,
							["arg1"] = "Break them, Adderis!",
						}, -- [28]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776056,
							["arg1"] = "Thunder crash!",
						}, -- [29]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776064,
							["arg1"] = "Do not get... too comfortable.",
							["clColor"] = "ff00fe95",
						}, -- [30]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776072,
							["arg1"] = "Severed!",
						}, -- [31]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776086,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [32]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776086,
							["arg1"] = "Anar'endal dracon!",
							["clColor"] = "ff006fdc",
						}, -- [33]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776091,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [34]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776093,
							["arg1"] = "The sands... take me...",
						}, -- [35]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776105,
							["arg1"] = "What will become... of the empire...",
						}, -- [36]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776187,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [37]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776208,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [38]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776227,
							["arg1"] = "Rise, fallen ones!",
						}, -- [39]
						{
							["arg2"] = "Whigham-Ravencrest",
							["type"] = "YELL",
							["time"] = 1553776228,
							["arg1"] = "Reaping time!",
							["clColor"] = "ff00fe95",
						}, -- [40]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776235,
							["arg1"] = "Vengeance burns!",
							["clColor"] = "ff00fe95",
						}, -- [41]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776238,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [42]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776242,
							["arg1"] = "Shadows engulf.",
							["clColor"] = "fffe7b09",
						}, -- [43]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776252,
							["arg1"] = "",
							["clColor"] = "ff006fdc",
						}, -- [44]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776319,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [45]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776329,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [46]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776442,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [47]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776451,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [48]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776454,
							["arg1"] = "Rise, fallen ones!",
						}, -- [49]
						{
							["arg2"] = "Whigham-Ravencrest",
							["type"] = "YELL",
							["time"] = 1553776454,
							["arg1"] = "Reaping time!",
							["clColor"] = "ff00fe95",
						}, -- [50]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776477,
							["arg1"] = "",
							["clColor"] = "ff006fdc",
						}, -- [51]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776480,
							["arg1"] = "Anar'endal dracon!",
							["clColor"] = "ff006fdc",
						}, -- [52]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776483,
							["arg1"] = "Ee-nok Kryul!",
							["clColor"] = "fffe7b09",
						}, -- [53]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776496,
							["arg1"] = "Vengeance burns!",
							["clColor"] = "ff00fe95",
						}, -- [54]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776564,
							["arg1"] = "Master, grant me strength.",
							["clColor"] = "ff00fe95",
						}, -- [55]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776576,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [56]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776622,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [57]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776684,
							["arg1"] = "Do not get... too comfortable.",
							["clColor"] = "ff00fe95",
						}, -- [58]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776708,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [59]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776753,
							["arg1"] = "Aaahhhh...",
							["clColor"] = "fffe7b09",
						}, -- [60]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776767,
							["arg1"] = "Anu... bala belore...alon.",
							["clColor"] = "ff006fdc",
						}, -- [61]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776774,
							["arg1"] = "Felomin Ashal! ",
							["clColor"] = "ff00fe95",
						}, -- [62]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776855,
							["arg1"] = "Rise, fallen ones!",
						}, -- [63]
						{
							["arg2"] = "Whigham-Ravencrest",
							["type"] = "YELL",
							["time"] = 1553776855,
							["arg1"] = "Reaping time!",
							["clColor"] = "ff00fe95",
						}, -- [64]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777366,
							["arg1"] = "Rise, fallen ones!",
						}, -- [65]
						{
							["arg2"] = "Whigham-Ravencrest",
							["type"] = "YELL",
							["time"] = 1553777366,
							["arg1"] = "Reaping time!",
							["clColor"] = "ff00fe95",
						}, -- [66]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777605,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [67]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777616,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [68]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777801,
							["arg1"] = "Oh, poor little thing, ya be needin' some help from old Bwonsamdi?",
						}, -- [69]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777805,
							["arg1"] = "You must not fall!",
						}, -- [70]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777816,
							["arg1"] = "This cannot be the end.",
						}, -- [71]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778033,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [72]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778044,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [73]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778246,
							["arg1"] = "I hold dominion over all!",
						}, -- [74]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778302,
							["arg1"] = "The storm has broken, and I am myself again. Thank you.",
						}, -- [75]
						{
							["arg1"] = " ",
						}, -- [76]
						{
							["arg1"] = " ",
						}, -- [77]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [78]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790107,
							["arg1"] = "For de glory of G'huun!",
						}, -- [79]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790115,
							["arg1"] = "G'huun's power take you!",
						}, -- [80]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790121,
							["arg1"] = "Rot and wither!",
						}, -- [81]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790124,
							["arg1"] = "G'huun be everywhere!",
						}, -- [82]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790136,
							["arg1"] = "Rot and wither!",
						}, -- [83]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790145,
							["arg1"] = "G'huun's power take you!",
						}, -- [84]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790149,
							["arg1"] = "Praise be G'huun!",
						}, -- [85]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790152,
							["arg1"] = "Rot and wither!",
						}, -- [86]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790165,
							["arg1"] = "My blood for G'huun...",
						}, -- [87]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791346,
							["arg1"] = "Rise, fallen ones!",
						}, -- [88]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791432,
							["arg1"] = "Die, vermin!",
						}, -- [89]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791455,
							["arg1"] = "Break them, Adderis!",
						}, -- [90]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791460,
							["arg1"] = "Thunder crash!",
						}, -- [91]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791475,
							["arg1"] = "Arcing slash!",
						}, -- [92]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791493,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [93]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791515,
							["arg1"] = "Break them, Adderis!",
						}, -- [94]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791520,
							["arg1"] = "Thunder crash!",
						}, -- [95]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791534,
							["arg1"] = "What will become... of the empire...",
						}, -- [96]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791534,
							["arg1"] = "Arcing slash!",
						}, -- [97]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791537,
							["arg1"] = "The sands... take me...",
						}, -- [98]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791647,
							["arg1"] = "Rise, fallen ones!",
						}, -- [99]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791860,
							["arg1"] = "Rise, fallen ones!",
						}, -- [100]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792223,
							["arg1"] = "Rise, fallen ones!",
						}, -- [101]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792658,
							["arg1"] = "Rise, fallen ones!",
						}, -- [102]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792917,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [103]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792928,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [104]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793086,
							["arg1"] = "I hold dominion over all!",
						}, -- [105]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793130,
							["arg1"] = "The storm has broken, and I am myself again. Thank you.",
						}, -- [106]
						{
							["arg2"] = "Nivus",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793621,
							["arg1"] = "I am not some simple jester! I am Nielas Aran!",
							["clColor"] = "ff8686ec",
						}, -- [107]
						{
							["arg1"] = " ",
						}, -- [108]
						{
							["arg1"] = " ",
						}, -- [109]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [110]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553795659,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [111]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553795680,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [112]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795769,
							["arg1"] = "Your heartbeat is... music to my ears.",
							["clColor"] = "ff00fe95",
						}, -- [113]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795859,
							["arg1"] = "You will pay for invading our lands!",
						}, -- [114]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553795883,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [115]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795923,
							["arg1"] = "Da Amani empire cannot be stopped!",
							["clColor"] = "ffc59a6c",
						}, -- [116]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795929,
							["arg1"] = "You face not Malchezaar alone, but the legions I command!",
							["clColor"] = "ff8686ec",
						}, -- [117]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795929,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "fffefefe",
						}, -- [118]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795939,
							["arg1"] = "Skill with a weapon is but a physical manifestation of one's martial strength. Let me show you what spiritual power is!",
							["clColor"] = "ffc31d39",
						}, -- [119]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795964,
							["arg1"] = "Who dares interrupt--What is this; what have you done? You'll ruin everything!",
							["clColor"] = "fffe7b09",
						}, -- [120]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795966,
							["arg1"] = "Charrrrrge!",
							["clColor"] = "ff00fe95",
						}, -- [121]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795969,
							["arg1"] = "I have tried to be an accommodating host, but you simply will not die! Time to throw all pretense aside and just... KILL YOU ALL!",
							["clColor"] = "fff38bb9",
						}, -- [122]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795969,
							["arg1"] = "Have you vermin ever witnessed such raw power? I think not.",
							["clColor"] = "ffa22fc8",
						}, -- [123]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795977,
							["arg1"] = "Bjorn of the Black Storm! Honor me now with your presence!",
							["clColor"] = "fffe7b09",
						}, -- [124]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795984,
							["arg1"] = "HERETICS! You will suffer for this interruption!",
							["clColor"] = "ff8686ec",
						}, -- [125]
						{
							["arg2"] = "Samîsu",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796037,
							["arg1"] = "Time shifts again, and your doom draws near!",
							["clColor"] = "ffa9d271",
						}, -- [126]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553796300,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [127]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796318,
							["arg1"] = "For Zandalar!",
						}, -- [128]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796320,
							["arg1"] = "I am a conduit of the Nightwell's glorious power! I am NIGHTBORNE!",
							["clColor"] = "ffa22fc8",
						}, -- [129]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796321,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [130]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796321,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [131]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796332,
							["arg1"] = "De Light judges all!",
						}, -- [132]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796335,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [133]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796350,
							["arg1"] = "Defeat has never tasted so bitter...",
							["clColor"] = "fff38bb9",
						}, -- [134]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796357,
							["arg1"] = "De Light judges all!",
						}, -- [135]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796370,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [136]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796383,
							["arg1"] = "De reckoning is at hand!",
						}, -- [137]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796389,
							["arg1"] = "To arms! Drive dese outsiders from Zuldazar!",
						}, -- [138]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796396,
							["arg1"] = "De Light judges all!",
						}, -- [139]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796426,
							["arg1"] = "De Light judges all!",
						}, -- [140]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796437,
							["arg1"] = "Retribution for de fallen!",
						}, -- [141]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "De Light judges all!",
						}, -- [142]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "Light guide me... to de... Other Side...",
						}, -- [143]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796523,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [144]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796525,
							["arg1"] = "All realities, all dimensions are open to me!",
							["clColor"] = "ff8686ec",
						}, -- [145]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796536,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [146]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796540,
							["arg1"] = "Never heard my blade coming!",
							["clColor"] = "ffa22fc8",
						}, -- [147]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796546,
							["arg1"] = "HAH!",
							["clColor"] = "fff38bb9",
						}, -- [148]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796550,
							["arg1"] = "AG VWYQ ZA AN'ZIG ",
							["clColor"] = "fffefefe",
						}, -- [149]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796553,
							["arg1"] = "Your greed, your foolishness has brought you to this end.",
							["clColor"] = "ff8686ec",
						}, -- [150]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796564,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [151]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796572,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [152]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796647,
							["arg1"] = "Mortal minds... So easily manipulated.",
							["clColor"] = "fff38bb9",
						}, -- [153]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796649,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [154]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796651,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [155]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796653,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [156]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796682,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [157]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796696,
							["arg1"] = "Incoming!",
							["clColor"] = "ffc59a6c",
						}, -- [158]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796702,
							["arg1"] = "Your technique needs work.",
							["clColor"] = "ffc31d39",
						}, -- [159]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796735,
							["arg1"] = "Just as you deserve!",
							["clColor"] = "fffe7b09",
						}, -- [160]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796752,
							["arg1"] = "If only you understood!",
							["clColor"] = "ffa9d271",
						}, -- [161]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796767,
							["arg1"] = "I thank you for coming, but you really all must die now!",
							["clColor"] = "fff38bb9",
						}, -- [162]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796773,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [163]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796774,
							["arg1"] = "Out da way!",
							["clColor"] = "ffc59a6c",
						}, -- [164]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796776,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [165]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796778,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [166]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796844,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [167]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796845,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [168]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796847,
							["arg1"] = "A taste... just a small taste... of the Spell-Weaver's power!",
							["clColor"] = "ffa9d271",
						}, -- [169]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796848,
							["arg1"] = "Ha! I have fought goren that proved more of a challenge!",
						}, -- [170]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796849,
							["arg1"] = "You will burn to ashes!",
						}, -- [171]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796854,
							["arg1"] = "You see? I told you they were nothing to worry about.",
						}, -- [172]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796913,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [173]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796914,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [174]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796915,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [175]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796918,
							["arg1"] = "You will burn to ashes!",
						}, -- [176]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796919,
							["arg1"] = "Brawl... with Rook.",
							["clColor"] = "fff38bb9",
						}, -- [177]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796923,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [178]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796925,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [179]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796929,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [180]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796940,
							["arg1"] = "Better watch your step!",
						}, -- [181]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796943,
							["arg1"] = "Your defense is feeble!",
						}, -- [182]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796961,
							["arg1"] = "Time to test your mettle!",
						}, -- [183]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796967,
							["arg1"] = "The elements will break you!",
						}, -- [184]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796971,
							["arg1"] = "The phoenix takes many forms!",
						}, -- [185]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796977,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [186]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796978,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [187]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796982,
							["arg1"] = "What... awaits me... now?",
							["clColor"] = "fffe7b09",
						}, -- [188]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "You really have to want it!",
							["clColor"] = "fff38bb9",
						}, -- [189]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "There is only one true path of enlightenment! DEATH!",
							["clColor"] = "ff8686ec",
						}, -- [190]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796993,
							["arg1"] = "Better watch your step!",
						}, -- [191]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797003,
							["arg1"] = "Guess I... be off... ta the locker...",
							["clColor"] = "ff00fe95",
						}, -- [192]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797010,
							["arg1"] = "Your defense is feeble!",
						}, -- [193]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797028,
							["arg1"] = "Time to test your mettle!",
						}, -- [194]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797031,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [195]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797041,
							["arg1"] = "Better watch your step!",
						}, -- [196]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Your defense is feeble!",
						}, -- [197]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Better watch your step!",
						}, -- [198]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797106,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [199]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797123,
							["arg1"] = "Time to test your mettle!",
						}, -- [200]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797146,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [201]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797152,
							["arg1"] = "Better watch your step!",
						}, -- [202]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [203]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Better watch your step!",
						}, -- [204]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797198,
							["arg1"] = "Better watch your step!",
						}, -- [205]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797210,
							["arg1"] = "Better watch your step!",
						}, -- [206]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797212,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [207]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797220,
							["arg1"] = "Better watch your step!",
						}, -- [208]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553798061,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [209]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553798362,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [210]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "YELL",
							["time"] = 1553799174,
							["arg1"] = "BONESTORM ON",
							["clColor"] = "ffc31d39",
						}, -- [211]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799231,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "ffc59a6c",
						}, -- [212]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799318,
							["arg1"] = "The waters whisper to me... enemies approach.",
							["clColor"] = "ffa9d271",
						}, -- [213]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799325,
							["arg1"] = "Avast, ye bilge suckers!",
							["clColor"] = "fffefefe",
						}, -- [214]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799752,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [215]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799875,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [216]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800176,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [217]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553800318,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [218]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "YELL",
							["time"] = 1553800327,
							["arg1"] = "NITRO JUNGE!",
							["clColor"] = "fff38bb9",
						}, -- [219]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800349,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [220]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553800579,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [221]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800753,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [222]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "YELL",
							["time"] = 1553800788,
							["arg1"] = "Int",
							["clColor"] = "ff00fe95",
						}, -- [223]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "YELL",
							["time"] = 1553800794,
							["arg1"] = "DANKE",
							["clColor"] = "ff00fe95",
						}, -- [224]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553800803,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [225]
						{
							["arg2"] = "Isery",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800804,
							["arg1"] = "None may challenge the Brotherhood!",
							["clColor"] = "fffe7b09",
						}, -- [226]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800822,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [227]
						{
							["arg2"] = "Ðaisuke",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800831,
							["arg1"] = "Pay for your crimes!",
							["clColor"] = "ffa22fc8",
						}, -- [228]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800943,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [229]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800963,
							["arg1"] = "W'OQ ZA ",
							["clColor"] = "fffefefe",
						}, -- [230]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801085,
							["arg1"] = "YOUR SOUL IS MINE!",
							["clColor"] = "fffe7b09",
						}, -- [231]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801117,
							["arg1"] = "Oh thank GOODNESS! Don't you worry, my precious baby boy. I'm gonna take good care of you.",
						}, -- [232]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553801142,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [233]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553801164,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [234]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801189,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [235]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801328,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [236]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801416,
							["arg1"] = "Class... dismissed.",
							["clColor"] = "fffe7b09",
						}, -- [237]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801420,
							["arg1"] = "Well... done, heh. But I wonder if you're good enough... to best him.",
							["clColor"] = "fffefefe",
						}, -- [238]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "YELL",
							["time"] = 1553801466,
							["arg1"] = "REKILL <3 xD",
							["clColor"] = "ff00fe95",
						}, -- [239]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553801479,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [240]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801516,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [241]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801636,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [242]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801637,
							["arg1"] = "You! You need more practice.",
							["clColor"] = "ffc59a6c",
						}, -- [243]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801640,
							["arg1"] = "Yogg-Saron! Grant me your power!",
							["clColor"] = "ffa22fc8",
						}, -- [244]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801762,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [245]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801861,
							["arg1"] = "Serves ya right!",
						}, -- [246]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553801893,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [247]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "YELL",
							["time"] = 1553801909,
							["arg1"] = "TURBO JUNGE!",
							["clColor"] = "ffc59a6c",
						}, -- [248]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801930,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [249]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553802146,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [250]
					},
				}, -- [5]
				{
					["enabled"] = true,
					["name"] = "Officer",
					["logs"] = {
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [1]
					},
				}, -- [6]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Guild",
					["logs"] = {
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553456876,
							["arg1"] = "|cffa335ee|Hkeystone:158923:245:13:10:7:2:117|h[Schlüsselstein: Freihafen (13)]|h|r oder Kronsteiganwesen +13, Tank und DD gesucht",
							["clColor"] = "fffefefe",
						}, -- [1]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553456908,
							["arg1"] = "jo ich tanke",
							["clColor"] = "ffc31d39",
						}, -- [2]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553456961,
							["arg1"] = "ein DD noch für |cffa335ee|Hkeystone:158923:245:13:10:7:2:117|h[Schlüsselstein: Freihafen (13)]|h|r ODER Kronsteig +13",
							["clColor"] = "fffefefe",
						}, -- [3]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553457114,
							["arg1"] = "icke",
							["clColor"] = "ff006fdc",
						}, -- [4]
						{
							["arg1"] = " ",
						}, -- [5]
						{
							["arg1"] = " ",
						}, -- [6]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/24/2019 at 21:41:40.",
						}, -- [7]
						{
							["arg2"] = "Lyoli-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553460131,
							["arg1"] = "noch wer nen key ? :D",
							["clColor"] = "fff38bb9",
						}, -- [8]
						{
							["arg1"] = " ",
						}, -- [9]
						{
							["arg1"] = " ",
						}, -- [10]
						{
							["arg1"] = "Logging started on 03/25/2019 at 12:16:35.",
							["type"] = "SYSTEM",
						}, -- [11]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513345,
							["arg1"] = "wer lust? |cffa335ee|Hkeystone:158923:252:11:10:7:2:117|h[Keystone: Shrine of the Storm (11)]|h|r",
							["clColor"] = "fffef367",
						}, -- [12]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513381,
							["arg1"] = "nhh",
							["clColor"] = "ff006fdc",
						}, -- [13]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513385,
							["arg1"] = "könnte man überlegen",
							["clColor"] = "ff006fdc",
						}, -- [14]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513401,
							["arg1"] = "ich glaub unser TS ist kaputt",
							["clColor"] = "ff006fdc",
						}, -- [15]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513433,
							["arg1"] = "kann das sein, dass das schon ausgelaufen ist phil?=",
							["clColor"] = "ff006fdc",
						}, -- [16]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513452,
							["arg1"] = "hmm, wobei, lass den key später machen. Muss erst mal meinen score mit dem hier pushen",
							["clColor"] = "fffef367",
						}, -- [17]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513458,
							["arg1"] = "xD",
							["clColor"] = "ff006fdc",
						}, -- [18]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513462,
							["arg1"] = "reroll inc?",
							["clColor"] = "ff006fdc",
						}, -- [19]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513478,
							["arg1"] = "eventuell, ja",
							["clColor"] = "fffef367",
						}, -- [20]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513482,
							["arg1"] = "cool",
							["clColor"] = "ff006fdc",
						}, -- [21]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513494,
							["arg1"] = "catch up momentan geht ja auch so schnell",
							["clColor"] = "ff006fdc",
						}, -- [22]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513508,
							["arg1"] = "ich spiele den schamie jetzt effektiv wieder seit 1,5 wochen und der hat gleich 43 punkte im hals xD",
							["clColor"] = "ff006fdc",
						}, -- [23]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513518,
							["arg1"] = "nice :)",
							["clColor"] = "fffef367",
						}, -- [24]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513526,
							["arg1"] = "bin auch bald bei 40^^",
							["clColor"] = "fffef367",
						}, -- [25]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513554,
							["arg1"] = "ne TS ist eigentlich verlängert",
							["clColor"] = "fffe7b09",
						}, -- [26]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513562,
							["arg1"] = "versuch mal. also bei mir gehts nicht",
							["clColor"] = "ff006fdc",
						}, -- [27]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513562,
							["arg1"] = "geht bis august oder so",
							["clColor"] = "fffe7b09",
						}, -- [28]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513615,
							["arg1"] = "ts geht grad wirklich nicht",
							["clColor"] = "ff006fdc",
						}, -- [29]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513629,
							["arg1"] = "stimmt geht nicht ich schreib mal thorsten",
							["clColor"] = "fffe7b09",
						}, -- [30]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553513643,
							["arg1"] = "vl auch wieder nur wartungsarbeiten oder so",
							["clColor"] = "ff006fdc",
						}, -- [31]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553514688,
							["arg1"] = "ts geht wieder",
							["clColor"] = "fffe7b09",
						}, -- [32]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553514812,
							["arg1"] = "ok",
							["clColor"] = "ff006fdc",
						}, -- [33]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515079,
							["arg1"] = "R.I.P",
							["clColor"] = "fffe7b09",
						}, -- [34]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515097,
							["arg1"] = "haha gerade wollte ich drauf xD",
							["clColor"] = "ff006fdc",
						}, -- [35]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515316,
							["arg1"] = ":c",
							["clColor"] = "fffefefe",
						}, -- [36]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515323,
							["arg1"] = "wasn scheiß  xD",
							["clColor"] = "fffefefe",
						}, -- [37]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515357,
							["arg1"] = "einigen wir uns darauf. mana ist schuld",
							["clColor"] = "ff006fdc",
						}, -- [38]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515390,
							["arg1"] = "weil ich grad shadow spiele",
							["clColor"] = "fffefefe",
						}, -- [39]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515394,
							["arg1"] = "genau",
							["clColor"] = "ff006fdc",
						}, -- [40]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515396,
							["arg1"] = "deswegen isses abgeschmiert",
							["clColor"] = "fffefefe",
						}, -- [41]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515397,
							["arg1"] = "erbsünde sozusagen",
							["clColor"] = "ff006fdc",
						}, -- [42]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515498,
							["arg1"] = "macht wer mit mir low m+? :D",
							["clColor"] = "fffefefe",
						}, -- [43]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515519,
							["arg1"] = "nur mit ts :P",
							["clColor"] = "ff006fdc",
						}, -- [44]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515528,
							["arg1"] = "MOBBING",
							["clColor"] = "fffefefe",
						}, -- [45]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515538,
							["arg1"] = "aber wäre dabei. will dps resto testen",
							["clColor"] = "ff006fdc",
						}, -- [46]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515546,
							["arg1"] = "okok",
							["clColor"] = "fffefefe",
						}, -- [47]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515547,
							["arg1"] = "der ist noch OPer als resto dud",
							["clColor"] = "ff006fdc",
						}, -- [48]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515548,
							["arg1"] = "u",
							["clColor"] = "ff006fdc",
						}, -- [49]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515568,
							["arg1"] = "|cffa335ee|Hkeystone:158923:249:6:10:7:0:0|h[Keystone: Kings' Rest (6)]|h|r hab nur den xP",
							["clColor"] = "fffefefe",
						}, -- [50]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515573,
							["arg1"] = "also lowlow",
							["clColor"] = "fffefefe",
						}, -- [51]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515611,
							["arg1"] = "soll mir recht sein. vl haben ja noch mehr lust",
							["clColor"] = "ff006fdc",
						}, -- [52]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515631,
							["arg1"] = "nur per ts",
							["clColor"] = "ffc31d39",
						}, -- [53]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515635,
							["arg1"] = "xD",
							["clColor"] = "ff006fdc",
						}, -- [54]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515644,
							["arg1"] = "</3",
							["clColor"] = "fffefefe",
						}, -- [55]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515671,
							["arg1"] = "hab dich auch lieb mana",
							["clColor"] = "ffc31d39",
						}, -- [56]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515678,
							["arg1"] = "ich dich auch",
							["clColor"] = "fffefefe",
						}, -- [57]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515683,
							["arg1"] = "<3 :*",
							["clColor"] = "fffefefe",
						}, -- [58]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515721,
							["arg1"] = "mache noch wq zuende",
							["clColor"] = "ff006fdc",
						}, -- [59]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515729,
							["arg1"] = "YES SIR",
							["clColor"] = "fffefefe",
						}, -- [60]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515739,
							["arg1"] = "hab grad ein bauchnabelfussel endeckt o.O",
							["clColor"] = "ffc31d39",
						}, -- [61]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515751,
							["arg1"] = "bauchhaare abrasieren",
							["clColor"] = "ff006fdc",
						}, -- [62]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515765,
							["arg1"] = "rekord volumen?",
							["clColor"] = "fffefefe",
						}, -- [63]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515776,
							["arg1"] = "xD",
							["clColor"] = "ffc31d39",
						}, -- [64]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515785,
							["arg1"] = "ne war doch nur nen krümmel :(",
							["clColor"] = "ffc31d39",
						}, -- [65]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515797,
							["arg1"] = "also mittagessen gesichert",
							["clColor"] = "fffefefe",
						}, -- [66]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515801,
							["arg1"] = "yes",
							["clColor"] = "ffc31d39",
						}, -- [67]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515892,
							["arg1"] = "GZ",
							["clColor"] = "fffefefe",
						}, -- [68]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515899,
							["arg1"] = "nurnoch 60lvl",
							["clColor"] = "fffefefe",
						}, -- [69]
						{
							["arg2"] = "Félica-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553515900,
							["arg1"] = "würd aber paar mit dh mitkommen , muss aber einmal um 14 ca mitn hund raus",
							["clColor"] = "ffc31d39",
						}, -- [70]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516128,
							["arg1"] = "ts geht wieder",
							["clColor"] = "ff006fdc",
						}, -- [71]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516214,
							["arg1"] = "phil gogo",
							["clColor"] = "ff006fdc",
						}, -- [72]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516216,
							["arg1"] = "big dick dps",
							["clColor"] = "ff006fdc",
						}, -- [73]
						{
							["arg2"] = "Nirpha-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516247,
							["arg1"] = "xD",
							["clColor"] = "ffa22fc8",
						}, -- [74]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516249,
							["arg1"] = "ernstahft? xD",
							["clColor"] = "ff006fdc",
						}, -- [75]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516279,
							["arg1"] = "habt ihr discord?",
							["clColor"] = "ff006fdc",
						}, -- [76]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516284,
							["arg1"] = "ja",
							["clColor"] = "fffefefe",
						}, -- [77]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516285,
							["arg1"] = "dann können wir dahin gehen",
							["clColor"] = "ff006fdc",
						}, -- [78]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516301,
							["arg1"] = "https://discord.gg/N8zF6s",
							["clColor"] = "ff006fdc",
						}, -- [79]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516302,
							["arg1"] = "soll ich jetzt nen dps einpoacken?",
							["clColor"] = "fffefefe",
						}, -- [80]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516315,
							["arg1"] = "macht ihr nen key?",
							["clColor"] = "fffef367",
						}, -- [81]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516316,
							["arg1"] = "liegt an phil",
							["clColor"] = "ff006fdc",
						}, -- [82]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516321,
							["arg1"] = "ja. aber nen low key",
							["clColor"] = "ff006fdc",
						}, -- [83]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516328,
							["arg1"] = "was für einen?",
							["clColor"] = "fffef367",
						}, -- [84]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516337,
							["arg1"] = "kings rest",
							["clColor"] = "ff006fdc",
						}, -- [85]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516348,
							["arg1"] = "+6",
							["clColor"] = "fffefefe",
						}, -- [86]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516359,
							["arg1"] = "ab +7 wäre ich mit^^",
							["clColor"] = "fffef367",
						}, -- [87]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516362,
							["arg1"] = "xD",
							["clColor"] = "ff006fdc",
						}, -- [88]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516363,
							["arg1"] = "schade :D",
							["clColor"] = "fffef367",
						}, -- [89]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516525,
							["arg1"] = "schick mir mal pls im b-net den discord inv",
							["clColor"] = "ffc59a6c",
						}, -- [90]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516561,
							["arg1"] = "phill tank mal nen low key pls xoxo",
							["clColor"] = "fffefefe",
						}, -- [91]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516561,
							["arg1"] = "das ist dein LUL discord",
							["clColor"] = "ff006fdc",
						}, -- [92]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516568,
							["arg1"] = "xD",
							["clColor"] = "fffefefe",
						}, -- [93]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516590,
							["arg1"] = "hä den ch hab ich gar nicht mehr xD",
							["clColor"] = "ffc59a6c",
						}, -- [94]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553516660,
							["arg1"] = "ok mom",
							["clColor"] = "ff006fdc",
						}, -- [95]
						{
							["arg1"] = " ",
						}, -- [96]
						{
							["arg1"] = " ",
						}, -- [97]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/25/2019 at 14:01:13.",
						}, -- [98]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553519226,
							["arg1"] = "ts down ?",
							["clColor"] = "fffe7b09",
						}, -- [99]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553519234,
							["arg1"] = "jo",
							["clColor"] = "fffefefe",
						}, -- [100]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553519260,
							["arg1"] = "super, danke mana",
							["clColor"] = "fffe7b09",
						}, -- [101]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553519270,
							["arg1"] = ":D",
							["clColor"] = "fffefefe",
						}, -- [102]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553519290,
							["arg1"] = "FeelsBadMan",
							["clColor"] = "fffefefe",
						}, -- [103]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553520458,
							["arg1"] = "hat gerade noch wer probleme aufen ts zu kommen?",
							["clColor"] = "fff38bb9",
						}, -- [104]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553520505,
							["arg1"] = "ja",
							["clColor"] = "ffa22fc8",
						}, -- [105]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553520520,
							["arg1"] = "ok dachte wäre nur bei mir ok",
							["clColor"] = "fff38bb9",
						}, -- [106]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553520564,
							["arg1"] = "an dieser stelle: mein dank gilt mana aka tobias",
							["clColor"] = "fffe7b09",
						}, -- [107]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553521174,
							["arg1"] = "?",
							["clColor"] = "fff38bb9",
						}, -- [108]
						{
							["arg2"] = "Monqyix-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553522248,
							["arg1"] = "hallöl",
							["clColor"] = "ff00fe95",
						}, -- [109]
						{
							["arg2"] = "Thíndra-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553522458,
							["arg1"] = "ts geht grad mal wieder aber ka wie lange noch ^^",
							["clColor"] = "ffc59a6c",
						}, -- [110]
						{
							["arg1"] = " ",
						}, -- [111]
						{
							["arg1"] = " ",
						}, -- [112]
						{
							["arg1"] = "Logging started on 03/25/2019 at 15:41:04.",
							["type"] = "SYSTEM",
						}, -- [113]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553526107,
							["arg1"] = "huhu",
							["clColor"] = "ff006fdc",
						}, -- [114]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553526112,
							["arg1"] = "hi",
							["clColor"] = "fffe7b09",
						}, -- [115]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527346,
							["arg1"] = "ich hab grad ein wenig den Glauben an die Menschheit verloren",
							["clColor"] = "fffef367",
						}, -- [116]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527376,
							["arg1"] = "grad +9 tol dagor gemacht. Musste kurz afk, da es meiner Oma nicht gut ging und meinte ich bin gleich wieder da, es ist wichtig",
							["clColor"] = "fffef367",
						}, -- [117]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527378,
							["arg1"] = "jetzt ersdt?^^",
							["clColor"] = "fffe7b09",
						}, -- [118]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527399,
							["arg1"] = "komme wieder, sag direkt \"sry, oma hatte probleme mit dem Herz\"",
							["clColor"] = "fffef367",
						}, -- [119]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527438,
							["arg1"] = "sehe nur, wie tank und heal schon die gruppe auflösen wollten, weil trash zu viert machen ja zu viel verlangt ist. Wir hatten noch 10 min und nur noch d en letzten boss in tol dagor",
							["clColor"] = "fffef367",
						}, -- [120]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527452,
							["arg1"] = "lol",
							["clColor"] = "fffe7b09",
						}, -- [121]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527469,
							["arg1"] = "wtf",
							["clColor"] = "fff38bb9",
						}, -- [122]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527472,
							["arg1"] = "naja, packen den key dann mit noch 4 min übrig und ich bekommen 395er boots mit sockel gedroppt (hab selber nur 390) und instant handelt der monk heal mich an",
							["clColor"] = "fffef367",
						}, -- [123]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527485,
							["arg1"] = "ich schreib \"?\" und er \"give me boots\"",
							["clColor"] = "fffef367",
						}, -- [124]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527508,
							["arg1"] = "frag halt ob er mich verarschen will, da er die ganze Zeit so ein arschloch war und ich die noch net mal traden kann",
							["clColor"] = "fffef367",
						}, -- [125]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527520,
							["arg1"] = "antwortet nur mit \"fuck you, I hope your grandma dies\"",
							["clColor"] = "fffef367",
						}, -- [126]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527538,
							["arg1"] = "melden",
							["clColor"] = "fffe7b09",
						}, -- [127]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527543,
							["arg1"] = "hab ich",
							["clColor"] = "fffef367",
						}, -- [128]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527559,
							["arg1"] = "ich frag mich halt echt, was das für menschen sein müssen",
							["clColor"] = "fffef367",
						}, -- [129]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527565,
							["arg1"] = "alter manche leute haben se doch noch nicht mehr alle",
							["clColor"] = "fff38bb9",
						}, -- [130]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527587,
							["arg1"] = "*habense",
							["clColor"] = "fff38bb9",
						}, -- [131]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527622,
							["arg1"] = "was der aber auch für ne einbildung haben muss, dass er einfach en anspruch auf meinen loot hat",
							["clColor"] = "fffef367",
						}, -- [132]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527641,
							["arg1"] = "jo",
							["clColor"] = "fff38bb9",
						}, -- [133]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527641,
							["arg1"] = "ist bestimmt so ein bengel, der alles von mama bekommt, was er will",
							["clColor"] = "fffef367",
						}, -- [134]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527659,
							["arg1"] = "kam bestimmt nicht zufällig von silvermoon?",
							["clColor"] = "fffe7b09",
						}, -- [135]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527664,
							["arg1"] = "doch",
							["clColor"] = "fffef367",
						}, -- [136]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527667,
							["arg1"] = ":D",
							["clColor"] = "fffef367",
						}, -- [137]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527672,
							["arg1"] = "Toastmasterr-Silvermoon",
							["clColor"] = "fffef367",
						}, -- [138]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527683,
							["arg1"] = "der typ, falls ihr ihn direkt auf ingore packen wollt^^",
							["clColor"] = "fffef367",
						}, -- [139]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527691,
							["arg1"] = "jo da hab ich auch schon so einige spacken getroffen",
							["clColor"] = "fffe7b09",
						}, -- [140]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553527779,
							["arg1"] = "glaub ich pack silvermoon jetzt auch auf meine no-go liste, genauso wie aegwyn^^",
							["clColor"] = "fffef367",
						}, -- [141]
						{
							["arg2"] = "Aspern-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553528722,
							["arg1"] = "hey",
							["clColor"] = "ff3ec5e9",
						}, -- [142]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553528727,
							["arg1"] = "hi",
							["clColor"] = "fffe7b09",
						}, -- [143]
						{
							["arg1"] = " ",
						}, -- [144]
						{
							["arg1"] = " ",
						}, -- [145]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:48:48.",
						}, -- [146]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553622761,
							["arg1"] = "wer lust auf ersten boss mythic?",
							["clColor"] = "fffef367",
						}, -- [147]
						{
							["arg1"] = " ",
						}, -- [148]
						{
							["arg1"] = " ",
						}, -- [149]
						{
							["arg1"] = "Logging started on 03/27/2019 at 10:46:09.",
							["type"] = "SYSTEM",
						}, -- [150]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553680660,
							["arg1"] = "9er will echt kein schwein gehen wa xD",
							["clColor"] = "fffefefe",
						}, -- [151]
						{
							["arg1"] = " ",
						}, -- [152]
						{
							["arg1"] = " ",
						}, -- [153]
						{
							["arg1"] = "Logging started on 03/27/2019 at 12:10:34.",
							["type"] = "SYSTEM",
						}, -- [154]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686074,
							["arg1"] = "haha, unsere vorherige Gilde Purified hat sich aufgelöst. Da haben wohl noch mehr gerafft, dass es nicht so weiter geht, wenn freundin und co mitgeschlept werden obwohl sie den raid zurück halten^^",
							["clColor"] = "fffef367",
						}, -- [155]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686090,
							["arg1"] = "^^",
							["clColor"] = "ffc59a6c",
						}, -- [156]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686282,
							["arg1"] = "moin",
							["clColor"] = "ffc31d39",
						}, -- [157]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686288,
							["arg1"] = "gude",
							["clColor"] = "fffef367",
						}, -- [158]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686306,
							["arg1"] = "jo",
							["clColor"] = "ffc59a6c",
						}, -- [159]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686334,
							["arg1"] = "und habt ihr was gutes aus den Kisten bekommen",
							["clColor"] = "ffc31d39",
						}, -- [160]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686340,
							["arg1"] = "nope",
							["clColor"] = "ffc59a6c",
						}, -- [161]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686349,
							["arg1"] = "also wie immer",
							["clColor"] = "ffc31d39",
						}, -- [162]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686353,
							["arg1"] = "geht so 1% upgrade mit rogue und nur rotz mit hunter",
							["clColor"] = "fffef367",
						}, -- [163]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686409,
							["arg1"] = "na gut mein pala hat nen 405 SChild bekommen wo er vohrher nen 340er hatt das ist schon was aber die beiden anderen waren müll",
							["clColor"] = "ffc31d39",
						}, -- [164]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686428,
							["arg1"] = "ja, das schon nice",
							["clColor"] = "fffef367",
						}, -- [165]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686468,
							["arg1"] = "hat wer eventuell en AD oder KR key?",
							["clColor"] = "fffef367",
						}, -- [166]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553686479,
							["arg1"] = "hab da noch so +4 und +5 score :D",
							["clColor"] = "fffef367",
						}, -- [167]
						{
							["arg1"] = " ",
						}, -- [168]
						{
							["arg1"] = " ",
						}, -- [169]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 13:55:25.",
						}, -- [170]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553697866,
							["arg1"] = "aye meine bimbos jemand bock auf |cffa335ee|Hkeystone:158923:248:11:9:5:3:117|h[Schlüsselstein: Das Kronsteiganwesen (11)]|h|r?",
							["clColor"] = "ffc59a6c",
						}, -- [171]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553699557,
							["arg1"] = "OMG BIS KOPF |cffa335ee|Hitem:159391::::::::120:262::35:4:5448:1587:4786:5420:::|h[Kapuze des dunklen Schnitters]|h|ro.O",
							["clColor"] = "ff006fdc",
						}, -- [172]
						{
							["arg1"] = " ",
						}, -- [173]
						{
							["arg1"] = " ",
						}, -- [174]
						{
							["arg1"] = "Logging started on 03/27/2019 at 16:55:40.",
							["type"] = "SYSTEM",
						}, -- [175]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553704924,
							["arg1"] = "huhu",
							["clColor"] = "fffefefe",
						}, -- [176]
						{
							["arg1"] = " ",
						}, -- [177]
						{
							["arg1"] = " ",
						}, -- [178]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 17:44:05.",
						}, -- [179]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553705091,
							["arg1"] = "das aber nett von dir salana",
							["clColor"] = "fffef367",
						}, -- [180]
						{
							["arg2"] = "Laki-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553707111,
							["arg1"] = "@ ts |cff0070dd|Hitem:46874::::::::120:102::::::|h[Wappenrock des Argentumkreuzfahrers]|h|r",
							["clColor"] = "fffe7b09",
						}, -- [181]
						{
							["arg1"] = " ",
						}, -- [182]
						{
							["arg1"] = " ",
						}, -- [183]
						{
							["arg1"] = "Logging started on 03/27/2019 at 18:22:22.",
							["type"] = "SYSTEM",
						}, -- [184]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553707868,
							["arg1"] = "Guten Abend",
							["clColor"] = "ff006fdc",
						}, -- [185]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553707891,
							["arg1"] = "hi",
							["clColor"] = "fffef367",
						}, -- [186]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709282,
							["arg1"] = "wer lust? Noch 1 DD und heal + tank |cffa335ee|Hkeystone:158923:250:9:9:5:3:0|h[Keystone: Temple of Sethraliss (9)]|h|r",
							["clColor"] = "fffef367",
						}, -- [187]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709332,
							["arg1"] = "@ts |cffa335ee|Hitem:118874::::::::120:65:::1:3524:::|h[Blackrock Bulwark]|h|r",
							["clColor"] = "fff38bb9",
						}, -- [188]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709359,
							["arg1"] = "|cffa335ee|Hitem:32375::::::::120:65:::1:3524:::|h[Bulwark of Azzinoth]|h|r",
							["clColor"] = "fff38bb9",
						}, -- [189]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709451,
							["arg1"] = "spinnt raider.io bei euch auch grad ?",
							["clColor"] = "ff006fdc",
						}, -- [190]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709462,
							["arg1"] = "jo",
							["clColor"] = "fff38bb9",
						}, -- [191]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709476,
							["arg1"] = "rip",
							["clColor"] = "ff006fdc",
						}, -- [192]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553709532,
							["arg1"] = "huhu",
							["clColor"] = "ff006fdc",
						}, -- [193]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553710010,
							["arg1"] = "mag wer, der HT hat eben mit temple +9?",
							["clColor"] = "fffef367",
						}, -- [194]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553710022,
							["arg1"] = "hab kein ht :( ",
							["clColor"] = "ff006fdc",
						}, -- [195]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553710031,
							["arg1"] = "alles lügen :D",
							["clColor"] = "fffef367",
						}, -- [196]
						{
							["arg2"] = "Almîna-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553710042,
							["arg1"] = ":P",
							["clColor"] = "ff006fdc",
						}, -- [197]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553712322,
							["arg1"] = "|cffa335ee|Hkeystone:158923:252:11:9:5:3:117|h[Keystone: Shrine of the Storm (11)]|h|r Tank Heal und DD will jemand mit?",
							["clColor"] = "ffa22fc8",
						}, -- [198]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716418,
							["arg1"] = "|cffa335ee|Hitem:159614::::::::120:260::16:3:5010:1592:4784:::|h[Galecaller's Boon]|h|r GG würde ich sagen",
							["clColor"] = "fffef367",
						}, -- [199]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716436,
							["arg1"] = "läuft",
							["clColor"] = "ffc59a6c",
						}, -- [200]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716814,
							["arg1"] = "hat jemand lust auf |cffa335ee|Hkeystone:158923:248:11:9:5:3:117|h[Schlüsselstein: Das Kronsteiganwesen (11)]|h|r?",
							["clColor"] = "ffc59a6c",
						}, -- [201]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716835,
							["arg1"] = "wäre dabei",
							["clColor"] = "fffef367",
						}, -- [202]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716861,
							["arg1"] = "noch jemand?",
							["clColor"] = "ffc59a6c",
						}, -- [203]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716879,
							["arg1"] = "denke stevi wäre noch dabei",
							["clColor"] = "fffef367",
						}, -- [204]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716885,
							["arg1"] = "der ist aber grade kurz afk",
							["clColor"] = "fffef367",
						}, -- [205]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716900,
							["arg1"] = "fehlt nur noch ein tank und ein heiler",
							["clColor"] = "ffc59a6c",
						}, -- [206]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553716991,
							["arg1"] = "hm ich geh einmal vorher siege",
							["clColor"] = "ffc59a6c",
						}, -- [207]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553717025,
							["arg1"] = "kk",
							["clColor"] = "fffef367",
						}, -- [208]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553717030,
							["arg1"] = "dann kann ich noch fix was futtenr",
							["clColor"] = "fffef367",
						}, -- [209]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719329,
							["arg1"] = "endlich",
							["clColor"] = "ffc59a6c",
						}, -- [210]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719381,
							["arg1"] = "läuft",
							["clColor"] = "ffa22fc8",
						}, -- [211]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719541,
							["arg1"] = "wann immer du ready bist Dovomir :)",
							["clColor"] = "fffef367",
						}, -- [212]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719547,
							["arg1"] = "jetzt :D",
							["clColor"] = "ffc59a6c",
						}, -- [213]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719590,
							["arg1"] = "seid ihrzwei schon in einer gruppe?",
							["clColor"] = "ffc59a6c",
						}, -- [214]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719610,
							["arg1"] = "ne",
							["clColor"] = "fffef367",
						}, -- [215]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553719671,
							["arg1"] = "ein tank und ein heiler noch lust auf |cffa335ee|Hkeystone:158923:248:11:9:5:3:117|h[Schlüsselstein: Das Kronsteiganwesen (11)]|h|r?",
							["clColor"] = "ffc59a6c",
						}, -- [216]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553722356,
							["arg1"] = "tank und heiler lust auf |cffa335ee|Hkeystone:158923:353:13:9:5:3:117|h[Schlüsselstein: Die Belagerung von Boralus (13)]|h|r?",
							["clColor"] = "ffc59a6c",
						}, -- [217]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553722654,
							["arg1"] = "Nachti",
							["clColor"] = "ff006fdc",
						}, -- [218]
						{
							["arg1"] = " ",
						}, -- [219]
						{
							["arg1"] = " ",
						}, -- [220]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 22:37:44.",
						}, -- [221]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553722680,
							["arg1"] = "nachti",
							["clColor"] = "ffc59a6c",
						}, -- [222]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553726326,
							["arg1"] = "|cff71d5ff|Htalent:22371|h[Schädelspalter]|h|r",
							["clColor"] = "ffc59a6c",
						}, -- [223]
						{
							["arg1"] = " ",
						}, -- [224]
						{
							["arg1"] = " ",
						}, -- [225]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 10:27:05.",
						}, -- [226]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553766418,
							["arg1"] = "moin",
							["clColor"] = "ffc31d39",
						}, -- [227]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553766623,
							["arg1"] = "du ziehst das acuh durch Phil",
							["clColor"] = "fff38bb9",
						}, -- [228]
						{
							["arg1"] = " ",
						}, -- [229]
						{
							["arg1"] = " ",
						}, -- [230]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [231]
						{
							["arg2"] = "Ðaisuke-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553780460,
							["arg1"] = "o/",
							["clColor"] = "ffa22fc8",
						}, -- [232]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553780501,
							["arg1"] = "hi",
							["clColor"] = "fffefefe",
						}, -- [233]
						{
							["arg1"] = " ",
						}, -- [234]
						{
							["arg1"] = " ",
						}, -- [235]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [236]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553790600,
							["arg1"] = "Heal und DD lust auf |cffa335ee|Hkeystone:158923:250:10:9:5:3:117|h[Keystone: Temple of Sethraliss (10)]|h|r?",
							["clColor"] = "ffa22fc8",
						}, -- [237]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553790618,
							["arg1"] = "später",
							["clColor"] = "ff006fdc",
						}, -- [238]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553790987,
							["arg1"] = "richtiger entdecker unter uns",
							["clColor"] = "fffef367",
						}, -- [239]
						{
							["arg2"] = "Salanâ-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553793791,
							["arg1"] = "huhu",
							["clColor"] = "fffefefe",
						}, -- [240]
						{
							["arg2"] = "Soely-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553794809,
							["arg1"] = "Guten Abend",
							["clColor"] = "ff006fdc",
						}, -- [241]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553794848,
							["arg1"] = "hey",
							["clColor"] = "ff006fdc",
						}, -- [242]
						{
							["arg1"] = " ",
						}, -- [243]
						{
							["arg1"] = " ",
						}, -- [244]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [245]
						{
							["arg2"] = "Thíndra-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553796287,
							["arg1"] = "hey",
							["clColor"] = "ffc59a6c",
						}, -- [246]
						{
							["arg2"] = "Alleycut-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553796303,
							["arg1"] = "guck guck",
							["clColor"] = "ffa22fc8",
						}, -- [247]
						{
							["arg2"] = "Andromaché-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553796313,
							["arg1"] = "ola",
							["clColor"] = "ff8686ec",
						}, -- [248]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553800935,
							["arg1"] = "gz",
							["clColor"] = "ff00fe95",
						}, -- [249]
						{
							["arg2"] = "Qyix-Antonidas",
							["type"] = "GUILD",
							["time"] = 1553801037,
							["arg1"] = "ty",
							["clColor"] = "fffefefe",
						}, -- [250]
					},
				}, -- [7]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Item Loot",
					["logs"] = {
						{
							["type"] = "LOOT",
							["time"] = 1553795640,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [1]
						{
							["type"] = "LOOT",
							["time"] = 1553795640,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|rx9.",
						}, -- [2]
						{
							["type"] = "LOOT",
							["time"] = 1553795642,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [3]
						{
							["type"] = "LOOT",
							["time"] = 1553795642,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|rx2.",
						}, -- [4]
						{
							["type"] = "LOOT",
							["time"] = 1553795644,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [5]
						{
							["type"] = "LOOT",
							["time"] = 1553795644,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|r.",
						}, -- [6]
						{
							["type"] = "LOOT",
							["time"] = 1553795646,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [7]
						{
							["type"] = "LOOT",
							["time"] = 1553795647,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|rx2.",
						}, -- [8]
						{
							["type"] = "LOOT",
							["time"] = 1553795648,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [9]
						{
							["type"] = "LOOT",
							["time"] = 1553795649,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|r.",
						}, -- [10]
						{
							["type"] = "LOOT",
							["time"] = 1553795650,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [11]
						{
							["type"] = "LOOT",
							["time"] = 1553795651,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|r.",
						}, -- [12]
						{
							["type"] = "LOOT",
							["time"] = 1553795652,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx5.",
						}, -- [13]
						{
							["type"] = "LOOT",
							["time"] = 1553795653,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|r.",
						}, -- [14]
						{
							["type"] = "LOOT",
							["time"] = 1553795654,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [15]
						{
							["type"] = "LOOT",
							["time"] = 1553795654,
							["arg1"] = "Supersunny receives loot: |cffffffff|Hitem:152576::::::::120:259::::::|h[Tidespray Linen]|h|rx3.",
						}, -- [16]
						{
							["type"] = "LOOT",
							["time"] = 1553795655,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|r.",
						}, -- [17]
						{
							["type"] = "LOOT",
							["time"] = 1553795655,
							["arg1"] = "Salanâ receives loot: |cff1eff00|Hitem:152577::::::::120:259::::::|h[Deep Sea Satin]|h|r.",
						}, -- [18]
						{
							["type"] = "LOOT",
							["time"] = 1553795656,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [19]
						{
							["type"] = "LOOT",
							["time"] = 1553795657,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|r.",
						}, -- [20]
						{
							["type"] = "LOOT",
							["time"] = 1553795659,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [21]
						{
							["type"] = "LOOT",
							["time"] = 1553795659,
							["arg1"] = "Soely creates: |cffffffff|Hitem:163222::::::::120:259::::::|h[Battle Potion of Intellect]|h|rx2.",
						}, -- [22]
						{
							["type"] = "LOOT",
							["time"] = 1553795661,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [23]
						{
							["type"] = "LOOT",
							["time"] = 1553795663,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [24]
						{
							["type"] = "LOOT",
							["time"] = 1553795665,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [25]
						{
							["type"] = "LOOT",
							["time"] = 1553795667,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [26]
						{
							["type"] = "LOOT",
							["time"] = 1553795669,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [27]
						{
							["type"] = "LOOT",
							["time"] = 1553795671,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [28]
						{
							["type"] = "LOOT",
							["time"] = 1553795673,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [29]
						{
							["type"] = "LOOT",
							["time"] = 1553795675,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [30]
						{
							["type"] = "LOOT",
							["time"] = 1553795677,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [31]
						{
							["type"] = "LOOT",
							["time"] = 1553795679,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [32]
						{
							["type"] = "LOOT",
							["time"] = 1553795682,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [33]
						{
							["type"] = "LOOT",
							["time"] = 1553795684,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [34]
						{
							["type"] = "LOOT",
							["time"] = 1553795686,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [35]
						{
							["type"] = "LOOT",
							["time"] = 1553795688,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [36]
						{
							["type"] = "LOOT",
							["time"] = 1553795688,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx3.",
						}, -- [37]
						{
							["type"] = "LOOT",
							["time"] = 1553795690,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [38]
						{
							["type"] = "LOOT",
							["time"] = 1553795692,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [39]
						{
							["type"] = "LOOT",
							["time"] = 1553795694,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [40]
						{
							["type"] = "LOOT",
							["time"] = 1553795696,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [41]
						{
							["type"] = "LOOT",
							["time"] = 1553795698,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [42]
						{
							["type"] = "LOOT",
							["time"] = 1553795700,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [43]
						{
							["type"] = "LOOT",
							["time"] = 1553795702,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [44]
						{
							["type"] = "LOOT",
							["time"] = 1553795705,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [45]
						{
							["type"] = "LOOT",
							["time"] = 1553795707,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [46]
						{
							["type"] = "LOOT",
							["time"] = 1553795709,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [47]
						{
							["type"] = "LOOT",
							["time"] = 1553795711,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [48]
						{
							["type"] = "LOOT",
							["time"] = 1553795713,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [49]
						{
							["type"] = "LOOT",
							["time"] = 1553795715,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [50]
						{
							["type"] = "LOOT",
							["time"] = 1553795717,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx3.",
						}, -- [51]
						{
							["type"] = "LOOT",
							["time"] = 1553795719,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [52]
						{
							["type"] = "LOOT",
							["time"] = 1553795721,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [53]
						{
							["type"] = "MONEY",
							["time"] = 1553795723,
							["arg1"] = "You loot 2 Gold, 96 Silver, 72 Copper",
						}, -- [54]
						{
							["type"] = "LOOT",
							["time"] = 1553795723,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [55]
						{
							["type"] = "LOOT",
							["time"] = 1553795726,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [56]
						{
							["type"] = "LOOT",
							["time"] = 1553795728,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [57]
						{
							["type"] = "LOOT",
							["time"] = 1553795730,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [58]
						{
							["type"] = "LOOT",
							["time"] = 1553795732,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [59]
						{
							["type"] = "LOOT",
							["time"] = 1553795734,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [60]
						{
							["type"] = "LOOT",
							["time"] = 1553795736,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [61]
						{
							["type"] = "LOOT",
							["time"] = 1553795738,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [62]
						{
							["type"] = "LOOT",
							["time"] = 1553795740,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [63]
						{
							["type"] = "LOOT",
							["time"] = 1553795742,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [64]
						{
							["type"] = "LOOT",
							["time"] = 1553795744,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx4.",
						}, -- [65]
						{
							["type"] = "LOOT",
							["time"] = 1553795747,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [66]
						{
							["type"] = "LOOT",
							["time"] = 1553795749,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [67]
						{
							["type"] = "LOOT",
							["time"] = 1553795751,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [68]
						{
							["type"] = "LOOT",
							["time"] = 1553795753,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [69]
						{
							["type"] = "LOOT",
							["time"] = 1553795755,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx3.",
						}, -- [70]
						{
							["type"] = "LOOT",
							["time"] = 1553795757,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [71]
						{
							["type"] = "LOOT",
							["time"] = 1553795759,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [72]
						{
							["type"] = "LOOT",
							["time"] = 1553795761,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [73]
						{
							["type"] = "LOOT",
							["time"] = 1553795763,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx3.",
						}, -- [74]
						{
							["type"] = "LOOT",
							["time"] = 1553795763,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [75]
						{
							["type"] = "LOOT",
							["time"] = 1553795765,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx2.",
						}, -- [76]
						{
							["type"] = "LOOT",
							["time"] = 1553795768,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|r.",
						}, -- [77]
						{
							["type"] = "LOOT",
							["time"] = 1553795770,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx3.",
						}, -- [78]
						{
							["type"] = "LOOT",
							["time"] = 1553795772,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:163224::::::::120:259::::::|h[Battle Potion of Strength]|h|rx6.",
						}, -- [79]
						{
							["type"] = "LOOT",
							["time"] = 1553795821,
							["arg1"] = "Metó receives loot: |cffffffff|Hitem:152576::::::::120:259::::::|h[Tidespray Linen]|h|rx4.",
						}, -- [80]
						{
							["type"] = "LOOT",
							["time"] = 1553795822,
							["arg1"] = "Metó receives loot: |cff1eff00|Hitem:159596::::::::120:259:512::2:4796:1696:120:::|h[Rivermarsh Machete of the Fireflash]|h|r.",
						}, -- [81]
						{
							["type"] = "LOOT",
							["time"] = 1553795822,
							["arg1"] = "Laki receives loot: |cffffffff|Hitem:152576::::::::120:259::::::|h[Tidespray Linen]|h|r.",
						}, -- [82]
						{
							["type"] = "LOOT",
							["time"] = 1553795823,
							["arg1"] = "Daddysenpai receives loot: |cffffffff|Hitem:152576::::::::120:259::::::|h[Tidespray Linen]|h|rx3.",
						}, -- [83]
						{
							["type"] = "LOOT",
							["time"] = 1553795830,
							["arg1"] = "Ðaisuke receives loot: |cffffffff|Hitem:152576::::::::120:259::::::|h[Tidespray Linen]|h|r.",
						}, -- [84]
						{
							["type"] = "LOOT",
							["time"] = 1553795844,
							["arg1"] = "Hornpubmonk receives item: |cffa335ee|Hitem:156634::::::::120:259::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [85]
						{
							["type"] = "LOOT",
							["time"] = 1553795853,
							["arg1"] = "Alleycut receives item: |cffa335ee|Hitem:156632::::::::120:259::13::::|h[Silas' Stone of Transportation]|h|r.",
						}, -- [86]
						{
							["type"] = "LOOT",
							["time"] = 1553795854,
							["arg1"] = "Laki receives item: |cffa335ee|Hitem:156634::::::::120:259::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [87]
						{
							["type"] = "LOOT",
							["time"] = 1553795891,
							["arg1"] = "Soely creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [88]
						{
							["type"] = "LOOT",
							["time"] = 1553795893,
							["arg1"] = "Härridk creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [89]
						{
							["type"] = "LOOT",
							["time"] = 1553795893,
							["arg1"] = "Alleycut creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [90]
						{
							["type"] = "LOOT",
							["time"] = 1553795894,
							["arg1"] = "Daddysenpai creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [91]
						{
							["type"] = "LOOT",
							["time"] = 1553795895,
							["arg1"] = "You create: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [92]
						{
							["type"] = "LOOT",
							["time"] = 1553795895,
							["arg1"] = "Laki creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [93]
						{
							["type"] = "LOOT",
							["time"] = 1553795896,
							["arg1"] = "Supersunny creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [94]
						{
							["type"] = "LOOT",
							["time"] = 1553795896,
							["arg1"] = "Neferupitou creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [95]
						{
							["type"] = "LOOT",
							["time"] = 1553795897,
							["arg1"] = "Kalissta creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [96]
						{
							["type"] = "LOOT",
							["time"] = 1553795899,
							["arg1"] = "Aspern creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [97]
						{
							["type"] = "LOOT",
							["time"] = 1553795901,
							["arg1"] = "Nelwyn creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [98]
						{
							["type"] = "LOOT",
							["time"] = 1553795901,
							["arg1"] = "Supersunny receives item: |cffa335ee|Hitem:167742::::::::120:259::13::::|h[Silas' Decanter of Disguise]|h|r.",
						}, -- [99]
						{
							["type"] = "LOOT",
							["time"] = 1553795903,
							["arg1"] = "Dovomir creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [100]
						{
							["type"] = "LOOT",
							["time"] = 1553795904,
							["arg1"] = "Inánná creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [101]
						{
							["type"] = "LOOT",
							["time"] = 1553795906,
							["arg1"] = "Salanâ creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [102]
						{
							["type"] = "LOOT",
							["time"] = 1553795907,
							["arg1"] = "Ðaisuke creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [103]
						{
							["type"] = "LOOT",
							["time"] = 1553795911,
							["arg1"] = "Andromaché creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [104]
						{
							["type"] = "LOOT",
							["time"] = 1553795913,
							["arg1"] = "You receive item: |cff1eff00|Hitem:166796::::::::120:259::5::::|h[Sunset Amber]|h|r.",
						}, -- [105]
						{
							["type"] = "LOOT",
							["time"] = 1553795915,
							["arg1"] = "Dovomir receives item: |cffa335ee|Hitem:156634::::::::120:259::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [106]
						{
							["type"] = "LOOT",
							["time"] = 1553795934,
							["arg1"] = "Woowa creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [107]
						{
							["type"] = "LOOT",
							["time"] = 1553795950,
							["arg1"] = "Samîsu creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [108]
						{
							["type"] = "LOOT",
							["time"] = 1553795953,
							["arg1"] = "Andromaché receives item: |cffa335ee|Hitem:156634::::::::120:259::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [109]
						{
							["type"] = "LOOT",
							["time"] = 1553795953,
							["arg1"] = "Hornpubmonk creates: |cffffffff|Hitem:152495::::::::120:259::::::|h[Coastal Mana Potion]|h|r.",
						}, -- [110]
						{
							["type"] = "LOOT",
							["time"] = 1553795955,
							["arg1"] = "Hornpubmonk creates: |cffffffff|Hitem:152495::::::::120:259::::::|h[Coastal Mana Potion]|h|r.",
						}, -- [111]
						{
							["type"] = "LOOT",
							["time"] = 1553795958,
							["arg1"] = "Hornpubmonk creates: |cffffffff|Hitem:152495::::::::120:259::::::|h[Coastal Mana Potion]|h|r.",
						}, -- [112]
						{
							["type"] = "LOOT",
							["time"] = 1553796121,
							["arg1"] = "Nelwyn receives item: |cffa335ee|Hitem:156634::::::::120:259::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [113]
						{
							["type"] = "LOOT",
							["time"] = 1553796453,
							["arg1"] = "Härridk receives loot: |cffa335ee|Hitem:165549::::::::120:259::6:3:4800:1537:4786:::|h[Crusade Pummelers]|h|r.",
						}, -- [114]
						{
							["type"] = "LOOT",
							["time"] = 1553796453,
							["arg1"] = "Daddysenpai receives loot: |cffa335ee|Hitem:165549::::::::120:259::6:5:4800:1808:40:1537:4786:::|h[Crusade Pummelers]|h|r.",
						}, -- [115]
						{
							["type"] = "LOOT",
							["time"] = 1553796458,
							["arg1"] = "Salanâ receives loot: |cffa335ee|Hitem:165919::::::::120:259::6:3:4800:1537:4786:::|h[Desecrated Blade of the Disciples]|h|r.",
						}, -- [116]
						{
							["type"] = "LOOT",
							["time"] = 1553796459,
							["arg1"] = "Neferupitou receives loot: |cffa335ee|Hitem:165533::::::::120:259::6:4:4800:1808:1537:4786:::|h[Lightgrace Sabatons]|h|r.",
						}, -- [117]
						{
							["type"] = "LOOT",
							["time"] = 1553796476,
							["arg1"] = "You receive loot: |cffa335ee|Hitem:165703::::::::120:259::::::|h[Breath of Bwonsamdi]|h|rx20.",
						}, -- [118]
						{
							["type"] = "MONEY",
							["time"] = 1553796477,
							["arg1"] = "You loot 60 Gold, 1 Silver, 94 Copper",
						}, -- [119]
						{
							["type"] = "LOOT",
							["time"] = 1553796481,
							["arg1"] = "Nelwyn receives loot: |cffa335ee|Hitem:165517::::::::120:259::6:3:4800:1537:4786:::|h[Bracers of Regal Devotion]|h|r.",
						}, -- [120]
						{
							["type"] = "LOOT",
							["time"] = 1553796591,
							["arg1"] = "Woowa receives loot: |cff9d9d9d|Hitem:158210::::::::120:260::::::|h[Fearsome Claw]|h|rx2.",
						}, -- [121]
						{
							["type"] = "LOOT",
							["time"] = 1553796591,
							["arg1"] = "Woowa receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|rx2.",
						}, -- [122]
						{
							["type"] = "LOOT",
							["time"] = 1553796605,
							["arg1"] = "Metó receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|r.",
						}, -- [123]
						{
							["type"] = "LOOT",
							["time"] = 1553796605,
							["arg1"] = "Härridk receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|rx3.",
						}, -- [124]
						{
							["type"] = "LOOT",
							["time"] = 1553796605,
							["arg1"] = "Härridk receives loot: |cff9d9d9d|Hitem:154793::::::::120:260::6::::|h[Unraveling Cloth Amice]|h|r.",
						}, -- [125]
						{
							["type"] = "LOOT",
							["time"] = 1553796606,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:160926::::::::120:260::6::::|h[Broken Mooring Post]|h|r.",
						}, -- [126]
						{
							["type"] = "LOOT",
							["time"] = 1553796608,
							["arg1"] = "Salanâ receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|rx3.",
						}, -- [127]
						{
							["type"] = "LOOT",
							["time"] = 1553796609,
							["arg1"] = "Neferupitou receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|rx2.",
						}, -- [128]
						{
							["type"] = "LOOT",
							["time"] = 1553796613,
							["arg1"] = "You receive loot: |cff9d9d9d|Hitem:158210::::::::120:260::::::|h[Fearsome Claw]|h|r.",
						}, -- [129]
						{
							["type"] = "MONEY",
							["time"] = 1553796614,
							["arg1"] = "You loot 1 Gold, 28 Silver, 60 Copper",
						}, -- [130]
						{
							["type"] = "LOOT",
							["time"] = 1553796690,
							["arg1"] = "Salanâ receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|rx2.",
						}, -- [131]
						{
							["type"] = "LOOT",
							["time"] = 1553796691,
							["arg1"] = "Nelwyn receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|r.",
						}, -- [132]
						{
							["type"] = "LOOT",
							["time"] = 1553796737,
							["arg1"] = "Laki receives loot: |cff9d9d9d|Hitem:158859::::::::120:260::::::|h[Jagged Fang]|h|r.",
						}, -- [133]
						{
							["type"] = "LOOT",
							["time"] = 1553796739,
							["arg1"] = "Daddysenpai receives loot: |cff9d9d9d|Hitem:158859::::::::120:260::::::|h[Jagged Fang]|h|r.",
						}, -- [134]
						{
							["type"] = "LOOT",
							["time"] = 1553796739,
							["arg1"] = "Salanâ receives loot: |cff9d9d9d|Hitem:158859::::::::120:260::::::|h[Jagged Fang]|h|r.",
						}, -- [135]
						{
							["type"] = "LOOT",
							["time"] = 1553796741,
							["arg1"] = "Nelwyn receives loot: |cff9d9d9d|Hitem:154784::::::::120:260::6::::|h[Ruptured Plate Breastplate]|h|r.",
						}, -- [136]
						{
							["type"] = "LOOT",
							["time"] = 1553796741,
							["arg1"] = "Nelwyn receives loot: |cff9d9d9d|Hitem:158850::::::::120:260::::::|h[Vibrant Plumage]|h|r.",
						}, -- [137]
						{
							["type"] = "LOOT",
							["time"] = 1553796741,
							["arg1"] = "Nelwyn receives loot: |cff9d9d9d|Hitem:158859::::::::120:260::::::|h[Jagged Fang]|h|r.",
						}, -- [138]
						{
							["type"] = "LOOT",
							["time"] = 1553796741,
							["arg1"] = "Nelwyn receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|r.",
						}, -- [139]
						{
							["type"] = "LOOT",
							["time"] = 1553796743,
							["arg1"] = "Ðaisuke receives loot: |cffffffff|Hitem:152576::::::::120:260::::::|h[Tidespray Linen]|h|rx2.",
						}, -- [140]
						{
							["type"] = "LOOT",
							["time"] = 1553796763,
							["arg1"] = "Hornpubmonk receives loot: |cff9d9d9d|Hitem:158210::::::::120:260::::::|h[Fearsome Claw]|h|r.",
						}, -- [141]
						{
							["type"] = "LOOT",
							["time"] = 1553796788,
							["arg1"] = "Supersunny receives loot: |cff9d9d9d|Hitem:158859::::::::120:259::::::|h[Jagged Fang]|h|r.",
						}, -- [142]
						{
							["type"] = "LOOT",
							["time"] = 1553797234,
							["arg1"] = "Woowa receives loot: |cffa335ee|Hitem:165521::::::::120:259::6:4:4800:40:1542:4783:::|h[Cranedancer Leggings]|h|r.",
						}, -- [143]
						{
							["type"] = "LOOT",
							["time"] = 1553797236,
							["arg1"] = "Isery receives loot: |cffa335ee|Hitem:165587::::::::120:259::6:3:4800:1537:4786:::|h[Phoenixfire Staff]|h|r.",
						}, -- [144]
						{
							["type"] = "LOOT",
							["time"] = 1553797237,
							["arg1"] = "Metó receives loot: |cffa335ee|Hitem:165500::::::::120:259::6:4:4824:1537:4786:5420:::|h[Blazewing Hood]|h|r.",
						}, -- [145]
						{
							["type"] = "LOOT",
							["time"] = 1553797237,
							["arg1"] = "Hornpubmonk receives loot: |cffa335ee|Hitem:165587::::::::120:259::6:4:4800:42:1537:4786:::|h[Phoenixfire Staff]|h|r.",
						}, -- [146]
						{
							["type"] = "LOOT",
							["time"] = 1553797247,
							["arg1"] = "Nelwyn receives bonus loot: |cffa335ee|Hitem:165777::::::::120:259::6:4:4824:1537:4786:5421:::|h[Ma'ra's Boneblade Mantle]|h|r.",
						}, -- [147]
						{
							["type"] = "LOOT",
							["time"] = 1553797249,
							["arg1"] = "You receive loot: |cffa335ee|Hitem:165703::::::::120:259::::::|h[Breath of Bwonsamdi]|h|rx20.",
						}, -- [148]
						{
							["type"] = "LOOT",
							["time"] = 1553797249,
							["arg1"] = "You receive loot: |cffa335ee|Hitem:165565::::::::120:259::6:3:4800:1537:4786:::|h[Band of Multi-Sided Strikes]|h|r.",
						}, -- [149]
						{
							["type"] = "MONEY",
							["time"] = 1553797250,
							["arg1"] = "You loot 60 Gold, 9 Silver, 34 Copper",
						}, -- [150]
						{
							["type"] = "LOOT",
							["time"] = 1553797266,
							["arg1"] = "Woowa receives bonus loot: |cffa335ee|Hitem:165565::::::::120:260::6:3:4800:1537:4786:::|h[Band of Multi-Sided Strikes]|h|r.",
						}, -- [151]
						{
							["type"] = "LOOT",
							["time"] = 1553797312,
							["arg1"] = "Inánná receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [152]
						{
							["type"] = "LOOT",
							["time"] = 1553797354,
							["arg1"] = "Alleycut receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [153]
						{
							["type"] = "LOOT",
							["time"] = 1553797354,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [154]
						{
							["type"] = "LOOT",
							["time"] = 1553797358,
							["arg1"] = "Neferupitou receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [155]
						{
							["type"] = "LOOT",
							["time"] = 1553797359,
							["arg1"] = "Soely receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [156]
						{
							["type"] = "LOOT",
							["time"] = 1553797382,
							["arg1"] = "Supersunny receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [157]
						{
							["type"] = "LOOT",
							["time"] = 1553797422,
							["arg1"] = "Härridk receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [158]
						{
							["type"] = "LOOT",
							["time"] = 1553797422,
							["arg1"] = "Härridk receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [159]
						{
							["type"] = "LOOT",
							["time"] = 1553797423,
							["arg1"] = "Laki receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [160]
						{
							["type"] = "LOOT",
							["time"] = 1553797423,
							["arg1"] = "Laki receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [161]
						{
							["type"] = "LOOT",
							["time"] = 1553797423,
							["arg1"] = "Woowa receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [162]
						{
							["type"] = "LOOT",
							["time"] = 1553797423,
							["arg1"] = "Woowa receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [163]
						{
							["type"] = "LOOT",
							["time"] = 1553797423,
							["arg1"] = "Inánná receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [164]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Neferupitou receives loot: |cff9d9d9d|Hitem:158855::::::::120:260::::::|h[Grim Skull Fetish]|h|r.",
						}, -- [165]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Neferupitou receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [166]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "You receive loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [167]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "You receive loot: |cff9d9d9d|Hitem:158855::::::::120:260::::::|h[Grim Skull Fetish]|h|r.",
						}, -- [168]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Alleycut receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [169]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Alleycut receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [170]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [171]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [172]
						{
							["type"] = "LOOT",
							["time"] = 1553797424,
							["arg1"] = "Nelwyn receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [173]
						{
							["type"] = "LOOT",
							["time"] = 1553797425,
							["arg1"] = "Supersunny receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [174]
						{
							["type"] = "LOOT",
							["time"] = 1553797425,
							["arg1"] = "Metó receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [175]
						{
							["type"] = "LOOT",
							["time"] = 1553797425,
							["arg1"] = "Isery receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [176]
						{
							["type"] = "LOOT",
							["time"] = 1553797425,
							["arg1"] = "Metó receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [177]
						{
							["type"] = "LOOT",
							["time"] = 1553797425,
							["arg1"] = "Isery receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [178]
						{
							["type"] = "LOOT",
							["time"] = 1553797426,
							["arg1"] = "Daddysenpai receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx3.",
						}, -- [179]
						{
							["type"] = "LOOT",
							["time"] = 1553797427,
							["arg1"] = "Kalissta receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [180]
						{
							["type"] = "LOOT",
							["time"] = 1553797427,
							["arg1"] = "Kalissta receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [181]
						{
							["type"] = "LOOT",
							["time"] = 1553797428,
							["arg1"] = "Soely receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [182]
						{
							["type"] = "LOOT",
							["time"] = 1553797432,
							["arg1"] = "Härridk receives loot: |cff9d9d9d|Hitem:158865::::::::120:260::::::|h[Ghastly Ooze]|h|r.",
						}, -- [183]
						{
							["type"] = "LOOT",
							["time"] = 1553797432,
							["arg1"] = "Härridk receives loot: |cff9d9d9d|Hitem:158771::::::::120:260::::::|h[Spirit Ichor]|h|r.",
						}, -- [184]
						{
							["type"] = "LOOT",
							["time"] = 1553797432,
							["arg1"] = "Härridk receives loot: |cff1eff00|Hitem:160142::::::::120:259:512::2:4796:1703:120:::|h[Ravascale Legguards of the Feverflare]|h|r.",
						}, -- [185]
						{
							["type"] = "LOOT",
							["time"] = 1553797435,
							["arg1"] = "Dovomir receives loot: |cff9d9d9d|Hitem:158771::::::::120:259::::::|h[Spirit Ichor]|h|rx2.",
						}, -- [186]
						{
							["type"] = "LOOT",
							["time"] = 1553797439,
							["arg1"] = "Salanâ receives loot: |cff9d9d9d|Hitem:158865::::::::120:259::::::|h[Ghastly Ooze]|h|r.",
						}, -- [187]
						{
							["type"] = "LOOT",
							["time"] = 1553797439,
							["arg1"] = "Salanâ receives loot: |cff9d9d9d|Hitem:158771::::::::120:259::::::|h[Spirit Ichor]|h|r.",
						}, -- [188]
						{
							["type"] = "LOOT",
							["time"] = 1553797447,
							["arg1"] = "Andromaché receives loot: |cff9d9d9d|Hitem:158771::::::::120:259::::::|h[Spirit Ichor]|h|rx2.",
						}, -- [189]
						{
							["type"] = "LOOT",
							["time"] = 1553797449,
							["arg1"] = "Aspern receives loot: |cff9d9d9d|Hitem:158865::::::::120:259::::::|h[Ghastly Ooze]|h|rx2.",
						}, -- [190]
						{
							["type"] = "LOOT",
							["time"] = 1553797458,
							["arg1"] = "Inánná receives loot: |cff9d9d9d|Hitem:158771::::::::120:259::::::|h[Spirit Ichor]|h|r.",
						}, -- [191]
						{
							["type"] = "LOOT",
							["time"] = 1553797458,
							["arg1"] = "Inánná receives loot: |cff9d9d9d|Hitem:158865::::::::120:259::::::|h[Ghastly Ooze]|h|r.",
						}, -- [192]
						{
							["type"] = "LOOT",
							["time"] = 1553797604,
							["arg1"] = "Hornpubmonk receives loot: |cff9d9d9d|Hitem:158855::::::::120:259::::::|h[Grim Skull Fetish]|h|r.",
						}, -- [193]
						{
							["type"] = "LOOT",
							["time"] = 1553797608,
							["arg1"] = "Hornpubmonk receives loot: |cff9d9d9d|Hitem:158865::::::::120:259::::::|h[Ghastly Ooze]|h|r.",
						}, -- [194]
						{
							["type"] = "LOOT",
							["time"] = 1553797608,
							["arg1"] = "Hornpubmonk receives loot: |cff9d9d9d|Hitem:158771::::::::120:259::::::|h[Spirit Ichor]|h|r.",
						}, -- [195]
						{
							["type"] = "LOOT",
							["time"] = 1553798044,
							["arg1"] = "Metó creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [196]
						{
							["type"] = "LOOT",
							["time"] = 1553798045,
							["arg1"] = "Isery creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [197]
						{
							["type"] = "LOOT",
							["time"] = 1553798048,
							["arg1"] = "Tyrellan creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [198]
						{
							["type"] = "LOOT",
							["time"] = 1553798051,
							["arg1"] = "Laki creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [199]
						{
							["type"] = "LOOT",
							["time"] = 1553798076,
							["arg1"] = "Daddysenpai creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [200]
						{
							["type"] = "LOOT",
							["time"] = 1553798079,
							["arg1"] = "Supersunny receives item: |cff1eff00|Hitem:166801::::::::120:259::5::::|h[Sapphire of Brilliance]|h|r.",
						}, -- [201]
						{
							["type"] = "LOOT",
							["time"] = 1553798371,
							["arg1"] = "Neferupitou receives item: |cffa335ee|Hitem:156633::::::::120:259::13::::|h[Silas' Potion of Prosperity]|h|r.",
						}, -- [202]
						{
							["type"] = "LOOT",
							["time"] = 1553798764,
							["arg1"] = "You receive loot: |cffa335ee|Hitem:165703::::::::120:259::::::|h[Breath of Bwonsamdi]|h|rx20.",
						}, -- [203]
						{
							["type"] = "LOOT",
							["time"] = 1553798765,
							["arg1"] = "Aspern receives bonus loot: |cffa335ee|Hitem:165582::::::::120:259::6:3:4800:1547:4783:::|h[Cursed Monkey Palm]|h|r.",
						}, -- [204]
						{
							["type"] = "MONEY",
							["time"] = 1553798765,
							["arg1"] = "You loot 60 Gold, 29 Silver, 65 Copper",
						}, -- [205]
						{
							["type"] = "LOOT",
							["time"] = 1553798776,
							["arg1"] = "Kalissta receives loot: |cffa335ee|Hitem:165582::::::::120:259::6:3:4800:1537:4786:::|h[Cursed Monkey Palm]|h|r.",
						}, -- [206]
						{
							["type"] = "LOOT",
							["time"] = 1553798781,
							["arg1"] = "Supersunny receives loot: |cffa335ee|Hitem:165513::::::::120:259::6:3:4800:1537:4786:::|h[Silverback Cloak]|h|r.",
						}, -- [207]
						{
							["type"] = "LOOT",
							["time"] = 1553798781,
							["arg1"] = "Laki receives loot: |cffa335ee|Hitem:165525::::::::120:259::6:3:4800:1537:4786:::|h[Stretched Sinew Waistcord]|h|r.",
						}, -- [208]
						{
							["type"] = "LOOT",
							["time"] = 1553798797,
							["arg1"] = "Salanâ receives loot: |cffa335ee|Hitem:165582::::::::120:259::6:3:4800:1537:4786:::|h[Cursed Monkey Palm]|h|r.",
						}, -- [209]
						{
							["type"] = "LOOT",
							["time"] = 1553798798,
							["arg1"] = "Hornpubmonk creates: |cffffffff|Hitem:5512::::::::120:259::6::::|h[Healthstone]|h|r.",
						}, -- [210]
						{
							["type"] = "LOOT",
							["time"] = 1553798825,
							["arg1"] = "Andromaché receives loot: |cffa335ee|Hitem:165582::::::::120:259::6:4:4800:42:1537:4786:::|h[Cursed Monkey Palm]|h|r.",
						}, -- [211]
						{
							["type"] = "LOOT",
							["time"] = 1553798989,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [212]
						{
							["type"] = "LOOT",
							["time"] = 1553799002,
							["arg1"] = "Aspern receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [213]
						{
							["type"] = "LOOT",
							["time"] = 1553799003,
							["arg1"] = "You receive loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [214]
						{
							["type"] = "LOOT",
							["time"] = 1553799005,
							["arg1"] = "Metó receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [215]
						{
							["type"] = "LOOT",
							["time"] = 1553799006,
							["arg1"] = "Tyrellan receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [216]
						{
							["type"] = "LOOT",
							["time"] = 1553799006,
							["arg1"] = "Kalissta receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [217]
						{
							["type"] = "LOOT",
							["time"] = 1553799006,
							["arg1"] = "Daddysenpai receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|rx3.",
						}, -- [218]
						{
							["type"] = "LOOT",
							["time"] = 1553799007,
							["arg1"] = "Neferupitou receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [219]
						{
							["type"] = "LOOT",
							["time"] = 1553799024,
							["arg1"] = "Soely receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|rx2.",
						}, -- [220]
						{
							["type"] = "LOOT",
							["time"] = 1553799041,
							["arg1"] = "Supersunny receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [221]
						{
							["type"] = "LOOT",
							["time"] = 1553799042,
							["arg1"] = "Supersunny receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [222]
						{
							["type"] = "LOOT",
							["time"] = 1553799042,
							["arg1"] = "Supersunny receives loot: |cff1eff00|Hitem:159821::::::::120:260:512::2:4796:1713:120:::|h[Rivermarsh Juju of the Harmonious]|h|r.",
						}, -- [223]
						{
							["type"] = "LOOT",
							["time"] = 1553799065,
							["arg1"] = "Aspern receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [224]
						{
							["type"] = "LOOT",
							["time"] = 1553799067,
							["arg1"] = "Kalissta receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [225]
						{
							["type"] = "LOOT",
							["time"] = 1553799121,
							["arg1"] = "Hornpubmonk receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [226]
						{
							["type"] = "LOOT",
							["time"] = 1553799130,
							["arg1"] = "Salanâ receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [227]
						{
							["type"] = "LOOT",
							["time"] = 1553799133,
							["arg1"] = "Dovomir receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [228]
						{
							["type"] = "LOOT",
							["time"] = 1553799137,
							["arg1"] = "Laki receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [229]
						{
							["type"] = "LOOT",
							["time"] = 1553799138,
							["arg1"] = "Hornpubmonk receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [230]
						{
							["type"] = "LOOT",
							["time"] = 1553799187,
							["arg1"] = "Kalissta receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [231]
						{
							["type"] = "LOOT",
							["time"] = 1553799187,
							["arg1"] = "Kalissta receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [232]
						{
							["type"] = "LOOT",
							["time"] = 1553799188,
							["arg1"] = "Kalissta receives loot: |cffa335ee|Hitem:165765::::::::120:260::6:3:4800:1537:4786:::|h[Cord of Zandalari Resolve]|h|r.",
						}, -- [233]
						{
							["type"] = "LOOT",
							["time"] = 1553799192,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [234]
						{
							["type"] = "LOOT",
							["time"] = 1553799192,
							["arg1"] = "Ðaisuke receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [235]
						{
							["type"] = "LOOT",
							["time"] = 1553799192,
							["arg1"] = "Alleycut receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [236]
						{
							["type"] = "LOOT",
							["time"] = 1553799192,
							["arg1"] = "Neferupitou receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [237]
						{
							["type"] = "LOOT",
							["time"] = 1553799193,
							["arg1"] = "Soely receives loot: |cff9d9d9d|Hitem:158862::::::::120:260::::::|h[Ancient Grave Dust]|h|r.",
						}, -- [238]
						{
							["type"] = "LOOT",
							["time"] = 1553799195,
							["arg1"] = "Laki receives loot: |cff9d9d9d|Hitem:155608::::::::120:260::::::|h[Defiled Bone]|h|r.",
						}, -- [239]
						{
							["type"] = "LOOT",
							["time"] = 1553799476,
							["arg1"] = "Soely receives item: |cffa335ee|Hitem:156634::::::::120:260::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [240]
						{
							["type"] = "LOOT",
							["time"] = 1553799483,
							["arg1"] = "Metó receives item: |cffa335ee|Hitem:156634::::::::120:260::13::::|h[Silas' Vial of Continuous Curing]|h|r.",
						}, -- [241]
						{
							["type"] = "LOOT",
							["time"] = 1553799511,
							["arg1"] = "Hornpubmonk receives item: |cffa335ee|Hitem:156633::::::::120:260::13::::|h[Silas' Potion of Prosperity]|h|r.",
						}, -- [242]
						{
							["type"] = "LOOT",
							["time"] = 1553799526,
							["arg1"] = "Dovomir receives item: |cffa335ee|Hitem:156633::::::::120:260::13::::|h[Silas' Potion of Prosperity]|h|r.",
						}, -- [243]
						{
							["type"] = "LOOT",
							["time"] = 1553799968,
							["arg1"] = "Ðaisuke creates: |cffffffff|Hitem:5512::::::::120:260::6::::|h[Healthstone]|h|r.",
						}, -- [244]
						{
							["type"] = "LOOT",
							["time"] = 1553799981,
							["arg1"] = "Qyix creates: |cffffffff|Hitem:5512::::::::120:260::6::::|h[Healthstone]|h|r.",
						}, -- [245]
						{
							["type"] = "LOOT",
							["time"] = 1553799981,
							["arg1"] = "Andromaché receives item: |cffa335ee|Hitem:156632::::::::120:260::13::::|h[Silas' Stone of Transportation]|h|r.",
						}, -- [246]
						{
							["type"] = "LOOT",
							["time"] = 1553799992,
							["arg1"] = "Qyix receives item: |cffa335ee|Hitem:156633::::::::120:260::13::::|h[Silas' Potion of Prosperity]|h|r.",
						}, -- [247]
						{
							["type"] = "LOOT",
							["time"] = 1553801140,
							["arg1"] = "Laki creates: |cffffffff|Hitem:5512::::::::120:260::6::::|h[Healthstone]|h|r.",
						}, -- [248]
						{
							["type"] = "LOOT",
							["time"] = 1553801144,
							["arg1"] = "Almîna creates: |cffffffff|Hitem:5512::::::::120:260::6::::|h[Healthstone]|h|r.",
						}, -- [249]
						{
							["type"] = "LOOT",
							["time"] = 1553802177,
							["arg1"] = "Almîna creates: |cffffffff|Hitem:5512::::::::120:260::6::::|h[Healthstone]|h|r.",
						}, -- [250]
					},
				}, -- [8]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "System Messages",
					["logs"] = {
						{
							["type"] = "SYSTEM",
							["time"] = 1553725692,
							["arg1"] = "Dovomir has died.",
						}, -- [1]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725753,
							["arg1"] = "Demoniq has died.",
						}, -- [2]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725849,
							["arg1"] = "Guild Mythic Keystone Challenge complete! Guild has earned 750 gold.",
						}, -- [3]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725876,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:310|h[Glowing Azerite]|h|r.",
						}, -- [4]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725876,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:260::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 310 Artifact Power.",
						}, -- [5]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725877,
							["arg1"] = "|cffff80ff|Htransmogappearance:98465|h[Besieger's Deckstalkers]|h|r has been added to your appearance collection.",
						}, -- [6]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725915,
							["arg1"] = "Dovomir leaves the party.",
						}, -- [7]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725918,
							["arg1"] = "Emayâ-Blackmoore leaves the party.",
						}, -- [8]
						{
							["type"] = "SYSTEM",
							["time"] = 1553725918,
							["arg1"] = "You leave the group.",
						}, -- [9]
						{
							["type"] = "SYSTEM",
							["time"] = 1553727096,
							["arg1"] = "Received 220 Gold, 94 Silver, 40 Copper.",
						}, -- [10]
						{
							["type"] = "SYSTEM",
							["time"] = 1553727330,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:234|h[Glowing Azerite Crystal]|h|r.",
						}, -- [11]
						{
							["type"] = "SYSTEM",
							["time"] = 1553727330,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:260::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 234 Artifact Power.",
						}, -- [12]
						{
							["type"] = "SYSTEM",
							["time"] = 1553727667,
							["arg1"] = "|cffff80ff|Htransmogappearance:94106|h[Gravethorn Wristwraps]|h|r has been added to your appearance collection.",
						}, -- [13]
						{
							["arg1"] = " ",
						}, -- [14]
						{
							["arg1"] = " ",
						}, -- [15]
						{
							["arg1"] = "Logging started on 03/28/2019 at 00:02:53.",
							["type"] = "SYSTEM",
						}, -- [16]
						{
							["type"] = "SYSTEM",
							["time"] = 1553727790,
							["arg1"] = "Cev-ArgentDawn is already being ignored.",
						}, -- [17]
						{
							["type"] = "SYSTEM",
							["time"] = 1553727790,
							["arg1"] = "Sukai-ArgentDawn is already being ignored.",
						}, -- [18]
						{
							["type"] = "SYSTEM",
							["time"] = 1553728012,
							["arg1"] = "Order of Embers completed.",
						}, -- [19]
						{
							["type"] = "SYSTEM",
							["time"] = 1553728012,
							["arg1"] = "You receive item: |cffa335ee|Hcurrency:1553:1900|h[Radiant Azerite Matrix]|h|r.",
						}, -- [20]
						{
							["type"] = "SYSTEM",
							["time"] = 1553728012,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:260::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 1,900 Artifact Power.",
						}, -- [21]
						{
							["type"] = "SYSTEM",
							["time"] = 1553728236,
							["arg1"] = "|Hplayer:Fíren|h[Fíren]|h: Level 120 Human Mage <Sacred Chao> - Boralus Harbor",
						}, -- [22]
						{
							["type"] = "SYSTEM",
							["time"] = 1553728236,
							["arg1"] = "1 |4player:players; total",
						}, -- [23]
						{
							["arg1"] = " ",
						}, -- [24]
						{
							["arg1"] = " ",
						}, -- [25]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 10:27:05.",
						}, -- [26]
						{
							["type"] = "SYSTEM",
							["time"] = 1553765263,
							["arg1"] = "Loot Specialization set to: Assassination",
						}, -- [27]
						{
							["type"] = "SYSTEM",
							["time"] = 1553765773,
							["arg1"] = "You are now Away: AFK",
						}, -- [28]
						{
							["type"] = "SYSTEM",
							["time"] = 1553766898,
							["arg1"] = "You are no longer Away.",
						}, -- [29]
						{
							["type"] = "SYSTEM",
							["time"] = 1553767609,
							["arg1"] = "You are now Away: AFK",
						}, -- [30]
						{
							["type"] = "SYSTEM",
							["time"] = 1553769973,
							["arg1"] = "You have been inactive for some time and will be logged out of the game. If you wish to remain logged in, hit the cancel button.",
						}, -- [31]
						{
							["arg1"] = " ",
						}, -- [32]
						{
							["arg1"] = " ",
						}, -- [33]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [34]
						{
							["type"] = "SYSTEM",
							["time"] = 1553775274,
							["arg1"] = "Dungeon Difficulty set to Mythic.",
						}, -- [35]
						{
							["type"] = "SYSTEM",
							["time"] = 1553775292,
							["arg1"] = "Obolosch-Frostmourne joins the party.",
						}, -- [36]
						{
							["type"] = "SYSTEM",
							["time"] = 1553775308,
							["arg1"] = "Loot Specialization set to: Outlaw",
						}, -- [37]
						{
							["type"] = "SYSTEM",
							["time"] = 1553775334,
							["arg1"] = "Relha-DunModr joins the party.",
						}, -- [38]
						{
							["type"] = "SYSTEM",
							["time"] = 1553775368,
							["arg1"] = "Tzüky-Auchindoun joins the party.",
						}, -- [39]
						{
							["type"] = "SYSTEM",
							["time"] = 1553775619,
							["arg1"] = "Whigham-Ravencrest has initiated a ready check.",
						}, -- [40]
						{
							["type"] = "SYSTEM",
							["time"] = 1553776480,
							["arg1"] = "Obolosch has died.",
						}, -- [41]
						{
							["type"] = "SYSTEM",
							["time"] = 1553776742,
							["arg1"] = "Obolosch has died.",
						}, -- [42]
						{
							["type"] = "SYSTEM",
							["time"] = 1553776753,
							["arg1"] = "Tzüky has died.",
						}, -- [43]
						{
							["type"] = "SYSTEM",
							["time"] = 1553776767,
							["arg1"] = "Relha has died.",
						}, -- [44]
						{
							["type"] = "SYSTEM",
							["time"] = 1553776836,
							["arg1"] = "Obolosch has died.",
						}, -- [45]
						{
							["type"] = "SYSTEM",
							["time"] = 1553776999,
							["arg1"] = "Obolosch has died.",
						}, -- [46]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777283,
							["arg1"] = "|cff71d5ff|Hdeath:1|h[You died.]|h",
						}, -- [47]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777743,
							["arg1"] = "Tzüky has died.",
						}, -- [48]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777779,
							["arg1"] = "|cff71d5ff|Hdeath:2|h[You died.]|h",
						}, -- [49]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777805,
							["arg1"] = "Whigham has died.",
						}, -- [50]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777807,
							["arg1"] = "Obolosch has died.",
						}, -- [51]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777809,
							["arg1"] = "Relha has died.",
						}, -- [52]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777977,
							["arg1"] = "Whigham has died.",
						}, -- [53]
						{
							["type"] = "SYSTEM",
							["time"] = 1553777980,
							["arg1"] = "Obolosch has died.",
						}, -- [54]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778163,
							["arg1"] = "Whigham has died.",
						}, -- [55]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778311,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:300|h[Glowing Azerite]|h|r.",
						}, -- [56]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778311,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:260::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 300 Artifact Power.",
						}, -- [57]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778343,
							["arg1"] = "Whigham-Ravencrest leaves the party.",
						}, -- [58]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778343,
							["arg1"] = "You are now the group leader.",
						}, -- [59]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778346,
							["arg1"] = "Obolosch-Frostmourne leaves the party.",
						}, -- [60]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778350,
							["arg1"] = "You leave the group.",
						}, -- [61]
						{
							["type"] = "SYSTEM",
							["time"] = 1553778373,
							["arg1"] = "Relha-DunModr is now being ignored.",
						}, -- [62]
						{
							["type"] = "SYSTEM",
							["time"] = 1553779113,
							["arg1"] = "Kabuza-Aegwynn has defeated Insaneomg-Aegwynn in a duel",
						}, -- [63]
						{
							["type"] = "SYSTEM",
							["time"] = 1553779168,
							["arg1"] = "Zomben seems to be sobering up.",
						}, -- [64]
						{
							["type"] = "SYSTEM",
							["time"] = 1553779297,
							["arg1"] = "Insaneomg-Aegwynn has defeated Kabuza-Aegwynn in a duel",
						}, -- [65]
						{
							["type"] = "SYSTEM",
							["time"] = 1553779871,
							["arg1"] = "You are now Away: AFK",
						}, -- [66]
						{
							["type"] = "SYSTEM",
							["time"] = 1553779976,
							["arg1"] = "Kabuza-Aegwynn has defeated Insaneomg-Aegwynn in a duel",
						}, -- [67]
						{
							["type"] = "SYSTEM",
							["time"] = 1553780585,
							["arg1"] = "You are no longer Away.",
						}, -- [68]
						{
							["type"] = "SYSTEM",
							["time"] = 1553780680,
							["arg1"] = "Kabuza-Aegwynn has defeated Insaneomg-Aegwynn in a duel",
						}, -- [69]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781225,
							["arg1"] = "Auction created.",
						}, -- [70]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781225,
							["arg1"] = "Auction created.",
						}, -- [71]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781225,
							["arg1"] = "Auction created.",
						}, -- [72]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781226,
							["arg1"] = "Auction created.",
						}, -- [73]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781226,
							["arg1"] = "Auction created.",
						}, -- [74]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781226,
							["arg1"] = "Auction created.",
						}, -- [75]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781226,
							["arg1"] = "Auction created.",
						}, -- [76]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781226,
							["arg1"] = "Auction created.",
						}, -- [77]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781227,
							["arg1"] = "Auction created.",
						}, -- [78]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781227,
							["arg1"] = "Auction created.",
						}, -- [79]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781227,
							["arg1"] = "Auction created.",
						}, -- [80]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781227,
							["arg1"] = "Auction created.",
						}, -- [81]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781227,
							["arg1"] = "Auction created.",
						}, -- [82]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781228,
							["arg1"] = "Auction created.",
						}, -- [83]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781228,
							["arg1"] = "Auction created.",
						}, -- [84]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781228,
							["arg1"] = "Auction created.",
						}, -- [85]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781228,
							["arg1"] = "Auction created.",
						}, -- [86]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781228,
							["arg1"] = "Auction created.",
						}, -- [87]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781229,
							["arg1"] = "Auction created.",
						}, -- [88]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781229,
							["arg1"] = "Auction created.",
						}, -- [89]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781229,
							["arg1"] = "Auction created.",
						}, -- [90]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781229,
							["arg1"] = "Auction created.",
						}, -- [91]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781229,
							["arg1"] = "Auction created.",
						}, -- [92]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781272,
							["arg1"] = "Loot Specialization set to: Assassination",
						}, -- [93]
						{
							["type"] = "SYSTEM",
							["time"] = 1553781503,
							["arg1"] = "Ultradog-Sylvanas is now being ignored.",
						}, -- [94]
						{
							["arg1"] = " ",
						}, -- [95]
						{
							["arg1"] = " ",
						}, -- [96]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [97]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789252,
							["arg1"] = "Relha-DunModr is already being ignored.",
						}, -- [98]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789252,
							["arg1"] = "Vdefregona-DunModr is already being ignored.",
						}, -- [99]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789288,
							["arg1"] = "Dungeon Difficulty set to Mythic.",
						}, -- [100]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789288,
							["arg1"] = "You have invited Demoniq to join your group.",
						}, -- [101]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789288,
							["arg1"] = "Demoniq joins the party.",
						}, -- [102]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789331,
							["arg1"] = "A role check has been initiated. Your group will be queued when all members have selected a role.",
						}, -- [103]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789421,
							["arg1"] = "A role check has been initiated. Your group will be queued when all members have selected a role.",
						}, -- [104]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789446,
							["arg1"] = "Dungeon Difficulty set to Mythic.",
						}, -- [105]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789559,
							["arg1"] = "Walfred-DunModr joins the party.",
						}, -- [106]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789608,
							["arg1"] = "Marno joins the party.",
						}, -- [107]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789935,
							["arg1"] = "Hølymøly-Pozzodell'Eternità has initiated a ready check.",
						}, -- [108]
						{
							["type"] = "SYSTEM",
							["time"] = 1553789997,
							["arg1"] = "Walfred has died.",
						}, -- [109]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790149,
							["arg1"] = "Walfred has died.",
						}, -- [110]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790196,
							["arg1"] = "Walfred has died.",
						}, -- [111]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790198,
							["arg1"] = "Marno has died.",
						}, -- [112]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790277,
							["arg1"] = "Marno leaves the party.",
						}, -- [113]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790308,
							["arg1"] = "|Hplayer:Marno|h[Marno]|h: Level 120 Human Hunter <pure rising> - Boralus Harbor",
						}, -- [114]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790308,
							["arg1"] = "1 |4player:players; total",
						}, -- [115]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790329,
							["arg1"] = "Walfred-DunModr leaves the party.",
						}, -- [116]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790381,
							["arg1"] = "Marno is now being ignored.",
						}, -- [117]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790421,
							["arg1"] = "Demoniq is now the group leader.",
						}, -- [118]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790707,
							["arg1"] = "You are now the group leader.",
						}, -- [119]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790855,
							["arg1"] = "Idä-Drak'thul joins the party.",
						}, -- [120]
						{
							["type"] = "SYSTEM",
							["time"] = 1553790869,
							["arg1"] = "Gougniafier-Dalaran joins the party.",
						}, -- [121]
						{
							["type"] = "SYSTEM",
							["time"] = 1553791159,
							["arg1"] = "Demoniq is now the group leader.",
						}, -- [122]
						{
							["type"] = "SYSTEM",
							["time"] = 1553791163,
							["arg1"] = "Demoniq has initiated a ready check.",
						}, -- [123]
						{
							["type"] = "SYSTEM",
							["time"] = 1553791364,
							["arg1"] = "|cff71d5ff|Hdeath:1|h[You died.]|h",
						}, -- [124]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792074,
							["arg1"] = "Gougniafier has died.",
						}, -- [125]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792341,
							["arg1"] = "Gougniafier has died.",
						}, -- [126]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792355,
							["arg1"] = "Hølymøly has died.",
						}, -- [127]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792356,
							["arg1"] = "|cff71d5ff|Hdeath:2|h[You died.]|h",
						}, -- [128]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792359,
							["arg1"] = "Demoniq has died.",
						}, -- [129]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792362,
							["arg1"] = "Idä has died.",
						}, -- [130]
						{
							["type"] = "SYSTEM",
							["time"] = 1553792435,
							["arg1"] = "|cff71d5ff|Hdeath:3|h[You died.]|h",
						}, -- [131]
						{
							["type"] = "SYSTEM",
							["time"] = 1553793136,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:280|h[Glowing Azerite Crystal]|h|r.",
						}, -- [132]
						{
							["type"] = "SYSTEM",
							["time"] = 1553793136,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:260::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 280 Artifact Power.",
						}, -- [133]
						{
							["type"] = "SYSTEM",
							["time"] = 1553793217,
							["arg1"] = "Gougniafier-Dalaran leaves the party.",
						}, -- [134]
						{
							["type"] = "SYSTEM",
							["time"] = 1553793223,
							["arg1"] = "You leave the group.",
						}, -- [135]
						{
							["type"] = "SYSTEM",
							["time"] = 1553793223,
							["arg1"] = "You aren't in a party.",
						}, -- [136]
						{
							["type"] = "SYSTEM",
							["time"] = 1553793927,
							["arg1"] = "You are now Away: AFK",
						}, -- [137]
						{
							["type"] = "SYSTEM",
							["time"] = 1553794754,
							["arg1"] = "You are no longer Away.",
						}, -- [138]
						{
							["arg1"] = " ",
						}, -- [139]
						{
							["arg1"] = " ",
						}, -- [140]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [141]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795381,
							["arg1"] = "|Hplayer:Laki|h[Laki]|h has invited you to join a group.",
						}, -- [142]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795381,
							["arg1"] = "Party converted to Raid",
						}, -- [143]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795381,
							["arg1"] = "You have joined a raid group. |cffff2020(While in a raid, you cannot earn credit towards most non-raid quests.)|r",
						}, -- [144]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795381,
							["arg1"] = "Raid Difficulty set to Mythic.",
						}, -- [145]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795381,
							["arg1"] = "Legacy Raid Difficulty set to 25 Player (Heroic).",
						}, -- [146]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795393,
							["arg1"] = "Woowa has joined the raid group.",
						}, -- [147]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795435,
							["arg1"] = "Hornpubmonk has joined the raid group.",
						}, -- [148]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795560,
							["arg1"] = "Kalissta has joined the raid group.",
						}, -- [149]
						{
							["type"] = "SYSTEM",
							["time"] = 1553795775,
							["arg1"] = "Dovomir has joined the raid group.",
						}, -- [150]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796093,
							["arg1"] = "Samîsu has left the raid group.",
						}, -- [151]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796252,
							["arg1"] = "Isery has joined the raid group.",
						}, -- [152]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796297,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [153]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796350,
							["arg1"] = "|cff71d5ff|Hdeath:1|h[You died.]|h",
						}, -- [154]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796437,
							["arg1"] = "Kalissta has died.",
						}, -- [155]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796451,
							["arg1"] = "Guild Raid Challenge complete! Guild has earned 1500 gold.",
						}, -- [156]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796451,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:450|h[Glowing Azerite Geode]|h|r.",
						}, -- [157]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796451,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:259::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 450 Artifact Power.",
						}, -- [158]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796861,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [159]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796892,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [160]
						{
							["type"] = "SYSTEM",
							["time"] = 1553796982,
							["arg1"] = "Woowa has died.",
						}, -- [161]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797001,
							["arg1"] = "|cff71d5ff|Hdeath:2|h[You died.]|h",
						}, -- [162]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797003,
							["arg1"] = "Hornpubmonk has died.",
						}, -- [163]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797230,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:450|h[Glowing Azerite Geode]|h|r.",
						}, -- [164]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797230,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:259::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 450 Artifact Power.",
						}, -- [165]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797240,
							["arg1"] = "Tyrellan has joined the raid group.",
						}, -- [166]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797473,
							["arg1"] = "Nelwyn has left the raid group.",
						}, -- [167]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797636,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [168]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797860,
							["arg1"] = "Dovomir has died.",
						}, -- [169]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797905,
							["arg1"] = "Kalissta has died.",
						}, -- [170]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797962,
							["arg1"] = "Woowa has died.",
						}, -- [171]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797980,
							["arg1"] = "Dovomir has died.",
						}, -- [172]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797994,
							["arg1"] = "|cff71d5ff|Hdeath:3|h[You died.]|h",
						}, -- [173]
						{
							["type"] = "SYSTEM",
							["time"] = 1553797995,
							["arg1"] = "Hornpubmonk has died.",
						}, -- [174]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798063,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [175]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798295,
							["arg1"] = "Hornpubmonk has died.",
						}, -- [176]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798296,
							["arg1"] = "Woowa has died.",
						}, -- [177]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798303,
							["arg1"] = "Dovomir has died.",
						}, -- [178]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798319,
							["arg1"] = "Kalissta has died.",
						}, -- [179]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798320,
							["arg1"] = "|cff71d5ff|Hdeath:4|h[You died.]|h",
						}, -- [180]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798353,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [181]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798614,
							["arg1"] = "Kalissta has died.",
						}, -- [182]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798758,
							["arg1"] = "Dovomir has died.",
						}, -- [183]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798761,
							["arg1"] = "You receive item: |cff0070dd|Hcurrency:1553:450|h[Glowing Azerite Geode]|h|r.",
						}, -- [184]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798761,
							["arg1"] = "|cffe6cc80|Hitem:158075::::::::120:259::11:4:4936:4929:5814:1550:::|h[Heart of Azeroth]|h|r gains 450 Artifact Power.",
						}, -- [185]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798765,
							["arg1"] = "Kalissta has died.",
						}, -- [186]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798839,
							["arg1"] = "Samîsu has joined the raid group.",
						}, -- [187]
						{
							["type"] = "SYSTEM",
							["time"] = 1553798914,
							["arg1"] = "Nelwyn has joined the raid group.",
						}, -- [188]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799156,
							["arg1"] = "Kalissta has died.",
						}, -- [189]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799286,
							["arg1"] = "Woowa has left the raid group.",
						}, -- [190]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799337,
							["arg1"] = "Qyix has joined the raid group.",
						}, -- [191]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799376,
							["arg1"] = "Andromaché has left the raid group.",
						}, -- [192]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799378,
							["arg1"] = "Härridk has left the raid group.",
						}, -- [193]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799484,
							["arg1"] = "Andromaché has joined the raid group.",
						}, -- [194]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799495,
							["arg1"] = "Härridk has joined the raid group.",
						}, -- [195]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799568,
							["arg1"] = "Daddysenpai has left the raid group.",
						}, -- [196]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799570,
							["arg1"] = "Supersunny has left the raid group.",
						}, -- [197]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799667,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [198]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799735,
							["arg1"] = "Härridk has initiated a ready check.",
						}, -- [199]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799924,
							["arg1"] = "Tyrellan has died.",
						}, -- [200]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799933,
							["arg1"] = "Dovomir has died.",
						}, -- [201]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799935,
							["arg1"] = "Laki has died.",
						}, -- [202]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799938,
							["arg1"] = "|cff71d5ff|Hdeath:5|h[You died.]|h",
						}, -- [203]
						{
							["type"] = "SYSTEM",
							["time"] = 1553799946,
							["arg1"] = "Samîsu has died.",
						}, -- [204]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800001,
							["arg1"] = "Daddysenpai has joined the raid group.",
						}, -- [205]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800003,
							["arg1"] = "Supersunny has joined the raid group.",
						}, -- [206]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800039,
							["arg1"] = "Andromaché has left the raid group.",
						}, -- [207]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800067,
							["arg1"] = "Härridk has left the raid group.",
						}, -- [208]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800079,
							["arg1"] = "Almîna has joined the raid group.",
						}, -- [209]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800101,
							["arg1"] = "Samîsu has left the raid group.",
						}, -- [210]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800143,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [211]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800262,
							["arg1"] = "Dovomir has died.",
						}, -- [212]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800265,
							["arg1"] = "Alleycut has died.",
						}, -- [213]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800266,
							["arg1"] = "Laki has died.",
						}, -- [214]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800281,
							["arg1"] = "|cff71d5ff|Hdeath:6|h[You died.]|h",
						}, -- [215]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800286,
							["arg1"] = "Tyrellan has died.",
						}, -- [216]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800313,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [217]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800515,
							["arg1"] = "Dovomir has died.",
						}, -- [218]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800515,
							["arg1"] = "Laki has died.",
						}, -- [219]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800517,
							["arg1"] = "Alleycut has died.",
						}, -- [220]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800520,
							["arg1"] = "Tyrellan has died.",
						}, -- [221]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800522,
							["arg1"] = "|cff71d5ff|Hdeath:7|h[You died.]|h",
						}, -- [222]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800563,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [223]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800592,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [224]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800637,
							["arg1"] = "Laki has died.",
						}, -- [225]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800714,
							["arg1"] = "Laki has died.",
						}, -- [226]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800733,
							["arg1"] = "Alleycut has died.",
						}, -- [227]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800738,
							["arg1"] = "|cff71d5ff|Hdeath:8|h[You died.]|h",
						}, -- [228]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800740,
							["arg1"] = "Dovomir has died.",
						}, -- [229]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800751,
							["arg1"] = "Tyrellan has died.",
						}, -- [230]
						{
							["type"] = "SYSTEM",
							["time"] = 1553800770,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [231]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801081,
							["arg1"] = "Tyrellan has died.",
						}, -- [232]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801098,
							["arg1"] = "Dovomir has died.",
						}, -- [233]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801099,
							["arg1"] = "Alleycut has died.",
						}, -- [234]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801116,
							["arg1"] = "Isery has died.",
						}, -- [235]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801121,
							["arg1"] = "|cff71d5ff|Hdeath:9|h[You died.]|h",
						}, -- [236]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801142,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [237]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801435,
							["arg1"] = "Dovomir has died.",
						}, -- [238]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801437,
							["arg1"] = "Alleycut has died.",
						}, -- [239]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801446,
							["arg1"] = "Tyrellan has died.",
						}, -- [240]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801452,
							["arg1"] = "|cff71d5ff|Hdeath:10|h[You died.]|h",
						}, -- [241]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801473,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [242]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801831,
							["arg1"] = "Isery has died.",
						}, -- [243]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801837,
							["arg1"] = "Tyrellan has died.",
						}, -- [244]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801840,
							["arg1"] = "Dovomir has died.",
						}, -- [245]
						{
							["type"] = "SYSTEM",
							["time"] = 1553801888,
							["arg1"] = "Laki has initiated a ready check.",
						}, -- [246]
						{
							["type"] = "SYSTEM",
							["time"] = 1553802111,
							["arg1"] = "Tyrellan has died.",
						}, -- [247]
						{
							["type"] = "SYSTEM",
							["time"] = 1553802127,
							["arg1"] = "Dovomir has died.",
						}, -- [248]
						{
							["type"] = "SYSTEM",
							["time"] = 1553802132,
							["arg1"] = "Alleycut has died.",
						}, -- [249]
						{
							["type"] = "SYSTEM",
							["time"] = 1553802145,
							["arg1"] = "Isery has died.",
						}, -- [250]
					},
				}, -- [9]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Achievements",
					["logs"] = {
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552479669,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12560:Player-3686-069E6F20:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Explore Vol'dun]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [1]
						{
							["arg1"] = " ",
						}, -- [2]
						{
							["arg1"] = " ",
						}, -- [3]
						{
							["arg1"] = "Logging started on 03/13/2019 at 13:26:12.",
							["type"] = "SYSTEM",
						}, -- [4]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552481489,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:508:Player-3686-069E6F20:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[1500 Quests Completed]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [5]
						{
							["arg2"] = "Sêrachan-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552481784,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13467:Player-3686-0664ED26:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Tides of Vengeance]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [6]
						{
							["arg2"] = "Yanaizu-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552482033,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13163:Player-3686-052F9210:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Allied Races: Kul Tiran]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [7]
						{
							["arg1"] = " ",
						}, -- [8]
						{
							["arg1"] = " ",
						}, -- [9]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 14:04:30.",
						}, -- [10]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552484723,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12510:Player-3686-069E6F20:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Ready for War]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [11]
						{
							["arg2"] = "Neferupitou-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552486050,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13163:Player-3686-046A4814:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Allied Races: Kul Tiran]|h|r!",
							["clColor"] = "ffa9d271",
						}, -- [12]
						{
							["arg2"] = "Sêrachan-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552486078,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13163:Player-3686-0664ED26:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Allied Races: Kul Tiran]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [13]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552486322,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13384:Player-3686-069E6F20:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Kul Tirans Don't Look at Explosions]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [14]
						{
							["arg2"] = "Supersunny-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552486621,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13186:Player-3686-063376E7:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[You Are Not Your $#*@! Legplates]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [15]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552490892,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13163:Player-3686-057CFF0B:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Allied Races: Kul Tiran]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [16]
						{
							["arg1"] = " ",
						}, -- [17]
						{
							["arg1"] = " ",
						}, -- [18]
						{
							["arg1"] = "Logging started on 03/13/2019 at 16:52:38.",
							["type"] = "SYSTEM",
						}, -- [19]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552497372,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:1873:Player-3686-057CFF0B:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Lodi Dodi We Loves the Skadi]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [20]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552497633,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:499:Player-3686-057CFF0B:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Utgarde Pinnacle]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [21]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552497633,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:2157:Player-3686-057CFF0B:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[King's Bane]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [22]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552498200,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13292:Player-3686-069E6F20:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Champion of the Light]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [23]
						{
							["arg2"] = "Laky-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552498200,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13292:Player-3686-06335E9D:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Champion of the Light]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [24]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552498200,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13292:Player-3686-069DED4C:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Champion of the Light]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [25]
						{
							["arg2"] = "Härridot-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552498200,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13292:Player-3686-06997365:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Champion of the Light]|h|r!",
							["clColor"] = "ff8686ec",
						}, -- [26]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552498200,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13292:Player-3686-06A01A22:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Champion of the Light]|h|r!",
							["clColor"] = "fffef367",
						}, -- [27]
						{
							["arg2"] = "Thíndra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552499142,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13163:Player-3686-05D77873:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[Allied Races: Kul Tiran]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [28]
						{
							["arg2"] = "Misanthroop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552499173,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13251:Player-3686-06214B99:1:3:13:19:4294967295:4294967295:4294967295:4294967295|h[In Teldrassil's Shadow]|h|r!",
							["clColor"] = "ffa9d271",
						}, -- [29]
						{
							["arg1"] = " ",
						}, -- [30]
						{
							["arg1"] = " ",
						}, -- [31]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/14/2019 at 14:09:21.",
						}, -- [32]
						{
							["arg2"] = "Balôô-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552569382,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12504:Player-3686-06719DFC:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[The Temple of Sethraliss]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [33]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12590:Player-3686-069E6F20:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Un'gol Ruins]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [34]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12589:Player-3686-069E6F20:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Un'gol Ruins]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [35]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12591:Player-3686-069E6F20:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Un'gol Ruins]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [36]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12590:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Un'gol Ruins]|h|r!",
							["clColor"] = "fffef367",
						}, -- [37]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12589:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Un'gol Ruins]|h|r!",
							["clColor"] = "fffef367",
						}, -- [38]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12591:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Un'gol Ruins]|h|r!",
							["clColor"] = "fffef367",
						}, -- [39]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570026,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13142:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Archipelago Explorer]|h|r!",
							["clColor"] = "fffef367",
						}, -- [40]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570046,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13123:Player-3686-069E6F20:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[My Dubs]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [41]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570908,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13396:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Havenswood]|h|r!",
							["clColor"] = "fffef367",
						}, -- [42]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570908,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13397:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Havenswood]|h|r!",
							["clColor"] = "fffef367",
						}, -- [43]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570908,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13398:Player-3686-06A01A22:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Havenswood]|h|r!",
							["clColor"] = "fffef367",
						}, -- [44]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552570908,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13398:Player-3686-069E6F20:1:3:14:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Havenswood]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [45]
						{
							["arg1"] = " ",
						}, -- [46]
						{
							["arg1"] = " ",
						}, -- [47]
						{
							["arg1"] = "Logging started on 03/17/2019 at 16:23:12.",
							["type"] = "SYSTEM",
						}, -- [48]
						{
							["arg2"] = "Dhin-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552836304,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:5794:Player-3686-069D0F45:1:3:17:19:4294967295:4294967295:4294967295:4294967295|h[Time Flies When You're Having Fun]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [49]
						{
							["arg1"] = " ",
						}, -- [50]
						{
							["arg1"] = " ",
						}, -- [51]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/17/2019 at 18:15:38.",
						}, -- [52]
						{
							["arg2"] = "Lakiz-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552843968,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12497:Player-3686-067D9D86:1:3:17:19:4294967295:4294967295:4294967295:4294967295|h[Drust Do It.]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [53]
						{
							["arg2"] = "Lakiz-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552844163,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12941:Player-3686-067D9D86:1:3:17:19:4294967295:4294967295:4294967295:4294967295|h[Adventurer of Drustvar]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [54]
						{
							["arg2"] = "Lakiz-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1552844410,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12557:Player-3686-067D9D86:1:3:17:19:4294967295:4294967295:4294967295:4294967295|h[Explore Drustvar]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [55]
						{
							["arg1"] = " ",
						}, -- [56]
						{
							["arg1"] = " ",
						}, -- [57]
						{
							["arg1"] = "Logging started on 03/19/2019 at 16:01:28.",
							["type"] = "SYSTEM",
						}, -- [58]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553010722,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:1176:Player-3686-06A18383:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [59]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553013167,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:238:Player-3686-06A18383:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[An Honorable Kill]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [60]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553013212,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:973:Player-3686-06A18383:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[5 Daily Quests Completed]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [61]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553013891,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12497:Player-3686-06A18383:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Drust Do It.]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [62]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553015201,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:505:Player-3686-06A18383:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[250 Quests Completed]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [63]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553017601,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:1834:Player-3686-057CFF0B:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Lightning Struck]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [64]
						{
							["arg2"] = "Balôô-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553018119,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12731:Player-3686-06719DFC:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Professional Kul Tiran Master]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [65]
						{
							["arg2"] = "Kalissta-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553018364,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:2756:Player-3686-06313401:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Argent Aspiration]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [66]
						{
							["arg1"] = " ",
						}, -- [67]
						{
							["arg1"] = " ",
						}, -- [68]
						{
							["arg1"] = "Logging started on 03/19/2019 at 20:39:44.",
							["type"] = "SYSTEM",
						}, -- [69]
						{
							["arg2"] = "Hornpubmonk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553024415,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12594:Player-3686-057CFF0B:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Competent Captain]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [70]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553025084,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12734:Player-3686-069A074E:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Working in Kul Tiras]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [71]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553027470,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12840:Player-3686-06A18383:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Tol Dagor]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [72]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553028972,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12847:Player-3686-069A074E:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Siege of Boralus]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [73]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553028972,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13075:Player-3686-069A074E:1:3:19:19:4294967295:4294967295:4294967295:4294967295|h[Battle for Azeroth Keymaster]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [74]
						{
							["arg1"] = " ",
						}, -- [75]
						{
							["arg1"] = " ",
						}, -- [76]
						{
							["arg1"] = "Logging started on 03/20/2019 at 09:57:36.",
							["type"] = "SYSTEM",
						}, -- [77]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553072988,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12826:Player-3686-06A18383:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Atal'Dazar]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [78]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553072988,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12825:Player-3686-06A18383:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Atal'Dazar]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [79]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553072988,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12824:Player-3686-06A18383:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Atal'Dazar]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [80]
						{
							["arg1"] = " ",
						}, -- [81]
						{
							["arg1"] = " ",
						}, -- [82]
						{
							["arg1"] = "Logging started on 03/20/2019 at 11:22:30.",
							["type"] = "SYSTEM",
						}, -- [83]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553077625,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12881:Player-3686-06A18383:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[War is Hell]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [84]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553081423,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11185:Player-3686-06A01A22:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Keystone Conqueror]|h|r!",
							["clColor"] = "fffef367",
						}, -- [85]
						{
							["arg2"] = "Inánná-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553081423,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11185:Player-3686-069A074E:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Keystone Conqueror]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [86]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553081674,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13286:Player-3686-06A18383:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Siege of Dazar'alor]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [87]
						{
							["arg2"] = "Daddysenpai-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553083293,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12888:Player-3686-0655767C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Strike Hard]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [88]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553084944,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12854:Player-3686-06A01A22:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Ready for Raiding VI]|h|r!",
							["clColor"] = "fffef367",
						}, -- [89]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553084944,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12844:Player-3686-069DED4C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[The MOTHERLODE!!]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [90]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553084944,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12845:Player-3686-069DED4C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: The MOTHERLODE!!]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [91]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553084944,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12846:Player-3686-069DED4C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: The MOTHERLODE!!]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [92]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553085014,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11185:Player-3686-069DED4C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Keystone Conqueror]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [93]
						{
							["arg2"] = "Demoniq-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553085014,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13075:Player-3686-069DED4C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Battle for Azeroth Keymaster]|h|r!",
							["clColor"] = "ffa22fc8",
						}, -- [94]
						{
							["arg1"] = " ",
						}, -- [95]
						{
							["arg1"] = " ",
						}, -- [96]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/20/2019 at 21:22:54.",
						}, -- [97]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553113825,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12596:Player-3686-069E6F20:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[No Tourist]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [98]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553115139,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12741:Player-3686-06A18D93:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Giving a Scrap]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [99]
						{
							["arg2"] = "Aspern-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553115150,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13251:Player-3686-069DBB1C:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[In Teldrassil's Shadow]|h|r!",
							["clColor"] = "ff3ec5e9",
						}, -- [100]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553115318,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12848:Player-3686-061F2C9E:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Kings' Rest]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [101]
						{
							["arg2"] = "Balôô-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553115446,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12888:Player-3686-06719DFC:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Strike Hard]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [102]
						{
							["arg2"] = "Kadzu-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553116049,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13322:Player-3686-05697F30:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[Ahead of the Curve: Lady Jaina Proudmoore]|h|r!",
							["clColor"] = "ff00fe95",
						}, -- [103]
						{
							["arg2"] = "Balôô-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553116465,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12881:Player-3686-06719DFC:1:3:20:19:4294967295:4294967295:4294967295:4294967295|h[War is Hell]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [104]
						{
							["arg1"] = " ",
						}, -- [105]
						{
							["arg1"] = " ",
						}, -- [106]
						{
							["arg1"] = "Logging started on 03/21/2019 at 11:21:20.",
							["type"] = "SYSTEM",
						}, -- [107]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553164656,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13123:Player-3686-05C922F4:1:3:21:19:4294967295:4294967295:4294967295:4294967295|h[My Dubs]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [108]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553165429,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13396:Player-3686-05C922F4:1:3:21:19:4294967295:4294967295:4294967295:4294967295|h[Havenswood]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [109]
						{
							["arg1"] = " ",
						}, -- [110]
						{
							["arg1"] = " ",
						}, -- [111]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/24/2019 at 19:32:10.",
						}, -- [112]
						{
							["arg2"] = "Minervaa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553452973,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:10795:Player-3686-056EB369:1:3:24:19:4294967295:4294967295:4294967295:4294967295|h[Neltharion's Lair]|h|r!",
							["clColor"] = "fffef367",
						}, -- [113]
						{
							["arg2"] = "Lyoli-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553453689,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13287:Player-3686-063138C4:1:3:24:19:4294967295:4294967295:4294967295:4294967295|h[Empire's Fall]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [114]
						{
							["arg1"] = " ",
						}, -- [115]
						{
							["arg1"] = " ",
						}, -- [116]
						{
							["arg1"] = "Logging started on 03/24/2019 at 20:43:07.",
							["type"] = "SYSTEM",
						}, -- [117]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553459593,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:649:Player-3686-06A204F7:1:3:24:19:4294967295:4294967295:4294967295:4294967295|h[The Slave Pens]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [118]
						{
							["arg1"] = " ",
						}, -- [119]
						{
							["arg1"] = " ",
						}, -- [120]
						{
							["arg1"] = "Logging started on 03/25/2019 at 12:16:35.",
							["type"] = "SYSTEM",
						}, -- [121]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553515605,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:508:Player-3686-061F2C9E:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[1500 Quests Completed]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [122]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553515713,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12506:Player-3686-06A01A22:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: The Temple of Sethraliss]|h|r!",
							["clColor"] = "fffef367",
						}, -- [123]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553515713,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13075:Player-3686-06A01A22:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Battle for Azeroth Keymaster]|h|r!",
							["clColor"] = "fffef367",
						}, -- [124]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553515882,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11:Player-3686-06A28626:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Level 60]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [125]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553515921,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:779:Player-3686-06A28626:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Explore Loch Modan]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [126]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553516201,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:890:Player-3686-06A28626:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Into the Wild Blue Yonder]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [127]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553518773,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12848:Player-3686-05C922F4:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Kings' Rest]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [128]
						{
							["arg1"] = " ",
						}, -- [129]
						{
							["arg1"] = " ",
						}, -- [130]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/25/2019 at 14:01:13.",
						}, -- [131]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553521804,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:478:Player-3686-06A28626:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[The Nexus]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [132]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553522488,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12573:Player-3686-06311811:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Band of Brothers]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [133]
						{
							["arg1"] = " ",
						}, -- [134]
						{
							["arg1"] = " ",
						}, -- [135]
						{
							["arg1"] = "Logging started on 03/25/2019 at 15:41:04.",
							["type"] = "SYSTEM",
						}, -- [136]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553526935,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:666:Player-3686-06A204F7:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Auchenai Crypts]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [137]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553527332,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13287:Player-3686-06A18383:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Empire's Fall]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [138]
						{
							["arg2"] = "Uglyklaus-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553528477,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:1176:Player-3686-06A204F7:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[Got My Mind On My Money]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [139]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553529401,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:561:Player-3686-06A28626:1:3:25:19:4294967295:4294967295:4294967295:4294967295|h[D.E.H.T.A's Little P.I.T.A.]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [140]
						{
							["arg1"] = " ",
						}, -- [141]
						{
							["arg1"] = " ",
						}, -- [142]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:15:18.",
						}, -- [143]
						{
							["arg2"] = "Misanthroop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553620694,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13288:Player-3686-06214B99:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Might of the Alliance]|h|r!",
							["clColor"] = "ffa9d271",
						}, -- [144]
						{
							["arg1"] = " ",
						}, -- [145]
						{
							["arg1"] = " ",
						}, -- [146]
						{
							["arg1"] = "Logging started on 03/26/2019 at 18:41:45.",
							["type"] = "SYSTEM",
						}, -- [147]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553622177,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11787:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[The Gates of Hell]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [148]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553622177,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11776:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Mistress Sassz'ine]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [149]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553622388,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11777:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Sisters of the Moon]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [150]
						{
							["arg1"] = " ",
						}, -- [151]
						{
							["arg1"] = " ",
						}, -- [152]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:48:48.",
						}, -- [153]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553622552,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11788:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Wailing Halls]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [154]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553622552,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11778:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: The Desolate Host]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [155]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553622912,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11779:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Maiden of Vigilance]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [156]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553623155,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11789:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Chamber of the Avatar]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [157]
						{
							["arg2"] = "Zekorash-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553623155,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11780:Player-3686-062DE4E2:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Fallen Avatar]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [158]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553624374,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12544:Player-3686-06A18D93:1:3:26:19:4294967295:4294967295:4294967295:4294967295|h[Level 120]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [159]
						{
							["arg1"] = " ",
						}, -- [160]
						{
							["arg1"] = " ",
						}, -- [161]
						{
							["arg1"] = "Logging started on 03/27/2019 at 10:46:09.",
							["type"] = "SYSTEM",
						}, -- [162]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553682150,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:2256:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Northern Exposure]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [163]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553684556,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Level 80]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [164]
						{
							["arg1"] = " ",
						}, -- [165]
						{
							["arg1"] = " ",
						}, -- [166]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 12:09:01.",
						}, -- [167]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553684974,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:5180:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Breaking the Sound Barrier]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [168]
						{
							["arg1"] = " ",
						}, -- [169]
						{
							["arg1"] = " ",
						}, -- [170]
						{
							["arg1"] = "Logging started on 03/27/2019 at 12:10:34.",
							["type"] = "SYSTEM",
						}, -- [171]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553686811,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:31:Player-3686-06A18383:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[A Simple Re-Quest]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [172]
						{
							["arg1"] = " ",
						}, -- [173]
						{
							["arg1"] = " ",
						}, -- [174]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 13:55:25.",
						}, -- [175]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553694444,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:4826:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Level 85]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [176]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553694526,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:4959:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Beware of the 'Unbeatable?' Pterodactyl]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [177]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553696417,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:4863:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Explore Hyjal]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [178]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553699703,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12560:Player-3686-05C922F4:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Explore Vol'dun]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [179]
						{
							["arg2"] = "Sarazea-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553699975,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:10750:Player-3686-05C922F4:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Fighting with Style: Hidden]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [180]
						{
							["arg1"] = " ",
						}, -- [181]
						{
							["arg1"] = " ",
						}, -- [182]
						{
							["arg1"] = "Logging started on 03/27/2019 at 16:55:40.",
							["type"] = "SYSTEM",
						}, -- [183]
						{
							["arg2"] = "Metó-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553702277,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11780:Player-3686-046A6453:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Fallen Avatar]|h|r!",
							["clColor"] = "ff8686ec",
						}, -- [184]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553702512,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11767:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Goroth]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [185]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553702606,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11774:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Demonic Inquisition]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [186]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553702735,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11775:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Harjatan]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [187]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553702889,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11787:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[The Gates of Hell]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [188]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553702889,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11776:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Mistress Sassz'ine]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [189]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553703087,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11777:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Sisters of the Moon]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [190]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553703355,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11788:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Wailing Halls]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [191]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553703355,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11778:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: The Desolate Host]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [192]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553703858,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11779:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Maiden of Vigilance]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [193]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553704095,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:4870:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Coming Down the Mountain]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [194]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553704137,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11789:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Chamber of the Avatar]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [195]
						{
							["arg2"] = "Härridk-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553704137,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11780:Player-3686-06311811:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Fallen Avatar]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [196]
						{
							["arg1"] = " ",
						}, -- [197]
						{
							["arg1"] = " ",
						}, -- [198]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 17:44:05.",
						}, -- [199]
						{
							["arg2"] = "Estephania-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553705257,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:10706:Player-3686-069D80F6:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Training the Troops]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [200]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553705967,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:11629:Player-3686-06A18383:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Untamed Beauty]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [201]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553706398,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:7437:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[A Worthy Opponent]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [202]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553706476,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:7994:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Treasure of Pandaria]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [203]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553706596,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:6193:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Level 90]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [204]
						{
							["arg1"] = " ",
						}, -- [205]
						{
							["arg1"] = " ",
						}, -- [206]
						{
							["arg1"] = "Logging started on 03/27/2019 at 18:22:22.",
							["type"] = "SYSTEM",
						}, -- [207]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553712412,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13298:Player-3686-061F2C9E:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Jadefire Masters]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [208]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553712971,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13111:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Verdant Wilds]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [209]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553712971,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13112:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Verdant Wilds]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [210]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553713181,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13125:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Azerite Admiral]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [211]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553713407,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12590:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Un'gol Ruins]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [212]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553713407,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12589:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Un'gol Ruins]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [213]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553713454,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13123:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[My Dubs]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [214]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553713962,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13396:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Havenswood]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [215]
						{
							["arg2"] = "Phenra-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553713962,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13397:Player-3686-06A18D93:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Havenswood]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [216]
						{
							["arg2"] = "Nekosera-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553716829,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12826:Player-3686-0631ABFC:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Atal'Dazar]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [217]
						{
							["arg2"] = "Nekosera-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553716829,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12825:Player-3686-0631ABFC:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Atal'Dazar]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [218]
						{
							["arg2"] = "Nekosera-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553716829,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12824:Player-3686-0631ABFC:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Atal'Dazar]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [219]
						{
							["arg2"] = "Estephania-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553718457,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:238:Player-3686-069D80F6:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[An Honorable Kill]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [220]
						{
							["arg2"] = "Nekosera-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553719079,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12848:Player-3686-0631ABFC:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Kings' Rest]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [221]
						{
							["arg2"] = "Dovomir-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553719319,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13448:Player-3686-04657C87:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Battle for Azeroth Keystone Conqueror: Season Two]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [222]
						{
							["arg2"] = "Nekosera-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553720682,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12833:Player-3686-0631ABFC:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Freehold]|h|r!",
							["clColor"] = "ffc31d39",
						}, -- [223]
						{
							["arg1"] = " ",
						}, -- [224]
						{
							["arg1"] = " ",
						}, -- [225]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 22:37:44.",
						}, -- [226]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553722998,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:8921:Player-3686-06A28626:1:3:27:19:4294967295:4294967295:4294967295:4294967295|h[Welcome to Draenor]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [227]
						{
							["arg1"] = " ",
						}, -- [228]
						{
							["arg1"] = " ",
						}, -- [229]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 10:27:05.",
						}, -- [230]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553767404,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:9726:Player-3686-06A28626:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Treasure Hunter]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [231]
						{
							["arg2"] = "Härripala-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553768424,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:245:Player-3686-06A18383:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[That Takes Class]|h|r!",
							["clColor"] = "fff38bb9",
						}, -- [232]
						{
							["arg2"] = "Lakip-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553768603,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:9602:Player-3686-06A28626:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Shoot For the Moon]|h|r!",
							["clColor"] = "ffc59a6c",
						}, -- [233]
						{
							["arg2"] = "Härikini-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553769867,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:9423:Player-3686-065BDAAB:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Goliaths of Gorgrond]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [234]
						{
							["arg1"] = " ",
						}, -- [235]
						{
							["arg1"] = " ",
						}, -- [236]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [237]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553790962,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13111:Player-3686-061F2C9E:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Verdant Wilds]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [238]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553790962,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13112:Player-3686-061F2C9E:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Heroic: Verdant Wilds]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [239]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553790962,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13142:Player-3686-061F2C9E:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Archipelago Explorer]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [240]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553791724,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13126:Player-3686-061F2C9E:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Give Me The Energy]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [241]
						{
							["arg2"] = "Schwoop-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553792527,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:12596:Player-3686-061F2C9E:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[No Tourist]|h|r!",
							["clColor"] = "ff006fdc",
						}, -- [242]
						{
							["arg1"] = " ",
						}, -- [243]
						{
							["arg1"] = " ",
						}, -- [244]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [245]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553797230,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13298:Player-3686-069E6F20:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Jadefire Masters]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [246]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553797230,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13298:Player-3686-06A01A22:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Jadefire Masters]|h|r!",
							["clColor"] = "fffef367",
						}, -- [247]
						{
							["arg2"] = "Woowa-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553798761,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13293:Player-3686-069E6F20:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Grong]|h|r!",
							["clColor"] = "fffe7b09",
						}, -- [248]
						{
							["arg2"] = "Noxiâ-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553798761,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:13293:Player-3686-06A01A22:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Mythic: Grong]|h|r!",
							["clColor"] = "fffef367",
						}, -- [249]
						{
							["arg2"] = "Tandro-Antonidas",
							["type"] = "GUILD_ACHIEVEMENT",
							["time"] = 1553800903,
							["arg1"] = "%s has earned the achievement |cffffff00|Hachievement:10:Player-3686-069D735B:1:3:28:19:4294967295:4294967295:4294967295:4294967295|h[Level 50]|h|r!",
							["clColor"] = "fffefefe",
						}, -- [250]
					},
				}, -- [10]
				{
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Instance",
					["logs"] = {
						{
							["arg2"] = "Taelia",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725143,
							["arg1"] = "You've done it! Without their giant, Ashvane's forces will be pushed out of the city.",
						}, -- [1]
						{
							["arg2"] = "Priscilla Ashvane",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725148,
							["arg1"] = "Enjoy your hollow victory, fools! Without the Kul Tiran fleet, you have no hope of defeating me.",
						}, -- [2]
						{
							["arg2"] = "Priscilla Ashvane",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725159,
							["arg1"] = "Allow me to demonstrate.",
						}, -- [3]
						{
							["arg2"] = "Priscilla Ashvane",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725164,
							["arg1"] = "Their gate has fallen! Breach the city and slay all who oppose me!",
						}, -- [4]
						{
							["arg2"] = "Taelia",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725176,
							["arg1"] = "Ashvane's beast is destroying our ships!",
						}, -- [5]
						{
							["arg2"] = "Taelia",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725179,
							["arg1"] = "Looks like there are still artillery pieces in the wreckage!",
						}, -- [6]
						{
							["arg2"] = "Taelia",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725182,
							["arg1"] = "Reassemble them and kill her pet before we have nothing left to repel Ashvane's fleet!",
						}, -- [7]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725351,
							["arg1"] = "Oh, poor little thing, ya be needin' some help from old Bwonsamdi?",
						}, -- [8]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553725451,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [9]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553725630,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [10]
						{
							["arg2"] = "Priscilla Ashvane",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725785,
							["arg1"] = "You dare scar my beautiful pet!?",
						}, -- [11]
						{
							["arg2"] = "Priscilla Ashvane",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725789,
							["arg1"] = "I tire of this game. I'll reduce Boralus to cinders before I allow you to win!",
						}, -- [12]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553725849,
							["arg1"] = "Rise, fallen ones!",
						}, -- [13]
						{
							["arg1"] = " ",
						}, -- [14]
						{
							["arg1"] = " ",
						}, -- [15]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 10:27:05.",
						}, -- [16]
						{
							["arg2"] = "Xeto",
							["type"] = "MONSTER_YELL",
							["time"] = 1553767564,
							["arg1"] = "None may challenge the Brotherhood!",
							["clColor"] = "fffefefe",
						}, -- [17]
						{
							["arg2"] = "Xeto",
							["type"] = "MONSTER_YELL",
							["time"] = 1553767591,
							["arg1"] = "None may challenge the Brotherhood!",
							["clColor"] = "fffefefe",
						}, -- [18]
						{
							["arg2"] = "Xeto",
							["type"] = "MONSTER_YELL",
							["time"] = 1553767591,
							["arg1"] = "Lap dogs, all of you!",
							["clColor"] = "fffefefe",
						}, -- [19]
						{
							["arg1"] = " ",
						}, -- [20]
						{
							["arg1"] = " ",
						}, -- [21]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [22]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775583,
							["arg1"] = "Don't look so smug! I know what you're thinking, but Tempest Keep was merely a setback. Did you honestly believe I would trust the future to some blind, half-night elf mongrel? Oh no, he was merely an instrument, a stepping stone to a much larger plan! It has all led to this... and this time you will not interfere!",
							["clColor"] = "ff00fe95",
						}, -- [23]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775587,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [24]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775611,
							["arg1"] = "Don't value your life very much, do you?",
							["clColor"] = "ff006fdc",
						}, -- [25]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775695,
							["arg1"] = "Vengeance burns!",
							["clColor"] = "ff00fe95",
						}, -- [26]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775695,
							["arg1"] = "Do not get... too comfortable.",
							["clColor"] = "ff00fe95",
						}, -- [27]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775698,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [28]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775709,
							["arg1"] = "Anar'endal dracon!",
							["clColor"] = "ff006fdc",
						}, -- [29]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775762,
							["arg1"] = "Ee-nok Kryul!",
							["clColor"] = "fffe7b09",
						}, -- [30]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775810,
							["arg1"] = "",
							["clColor"] = "ff006fdc",
						}, -- [31]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775816,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [32]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775820,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [33]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775830,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [34]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775859,
							["arg1"] = "Rise, fallen ones!",
						}, -- [35]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775893,
							["arg1"] = "Shadows engulf.",
							["clColor"] = "fffe7b09",
						}, -- [36]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775909,
							["arg1"] = "Felomin Ashal! ",
							["clColor"] = "ff00fe95",
						}, -- [37]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775939,
							["arg1"] = "Master, grant me strength.",
							["clColor"] = "ff00fe95",
						}, -- [38]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775957,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [39]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775963,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [40]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775967,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [41]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775991,
							["arg1"] = "Break them, Adderis!",
						}, -- [42]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553775995,
							["arg1"] = "Thunder crash!",
						}, -- [43]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776010,
							["arg1"] = "Arcing slash!",
						}, -- [44]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776029,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [45]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776052,
							["arg1"] = "Break them, Adderis!",
						}, -- [46]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776056,
							["arg1"] = "Thunder crash!",
						}, -- [47]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776064,
							["arg1"] = "Do not get... too comfortable.",
							["clColor"] = "ff00fe95",
						}, -- [48]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776072,
							["arg1"] = "Severed!",
						}, -- [49]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776086,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [50]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776086,
							["arg1"] = "Anar'endal dracon!",
							["clColor"] = "ff006fdc",
						}, -- [51]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776091,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [52]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776093,
							["arg1"] = "The sands... take me...",
						}, -- [53]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776105,
							["arg1"] = "What will become... of the empire...",
						}, -- [54]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776187,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [55]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776208,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [56]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776227,
							["arg1"] = "Rise, fallen ones!",
						}, -- [57]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776235,
							["arg1"] = "Vengeance burns!",
							["clColor"] = "ff00fe95",
						}, -- [58]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776238,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [59]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776242,
							["arg1"] = "Shadows engulf.",
							["clColor"] = "fffe7b09",
						}, -- [60]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776252,
							["arg1"] = "",
							["clColor"] = "ff006fdc",
						}, -- [61]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776319,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [62]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776329,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [63]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776442,
							["arg1"] = "I'll turn your world... upside... down.",
							["clColor"] = "ff00fe95",
						}, -- [64]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776451,
							["arg1"] = "Shadow to the aid of fire!",
							["clColor"] = "fffe7b09",
						}, -- [65]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776454,
							["arg1"] = "Rise, fallen ones!",
						}, -- [66]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776477,
							["arg1"] = "",
							["clColor"] = "ff006fdc",
						}, -- [67]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776480,
							["arg1"] = "Anar'endal dracon!",
							["clColor"] = "ff006fdc",
						}, -- [68]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776483,
							["arg1"] = "Ee-nok Kryul!",
							["clColor"] = "fffe7b09",
						}, -- [69]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776496,
							["arg1"] = "Vengeance burns!",
							["clColor"] = "ff00fe95",
						}, -- [70]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776564,
							["arg1"] = "Master, grant me strength.",
							["clColor"] = "ff00fe95",
						}, -- [71]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776576,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [72]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776622,
							["arg1"] = "Think you can take the heat?",
							["clColor"] = "ff006fdc",
						}, -- [73]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776684,
							["arg1"] = "Do not get... too comfortable.",
							["clColor"] = "ff00fe95",
						}, -- [74]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776708,
							["arg1"] = "Alythess! Your fire burns within me!",
							["clColor"] = "fffe7b09",
						}, -- [75]
						{
							["arg2"] = "Tzüky",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776753,
							["arg1"] = "Aaahhhh...",
							["clColor"] = "fffe7b09",
						}, -- [76]
						{
							["arg2"] = "Relha",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776767,
							["arg1"] = "Anu... bala belore...alon.",
							["clColor"] = "ff006fdc",
						}, -- [77]
						{
							["arg2"] = "Whigham",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776774,
							["arg1"] = "Felomin Ashal! ",
							["clColor"] = "ff00fe95",
						}, -- [78]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553776855,
							["arg1"] = "Rise, fallen ones!",
						}, -- [79]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553777283,
							["arg1"] = "Let me guess... ya got in over ya head?",
						}, -- [80]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777366,
							["arg1"] = "Rise, fallen ones!",
						}, -- [81]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777605,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [82]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777616,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [83]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553777779,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [84]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777801,
							["arg1"] = "Oh, poor little thing, ya be needin' some help from old Bwonsamdi?",
						}, -- [85]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777805,
							["arg1"] = "You must not fall!",
						}, -- [86]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553777816,
							["arg1"] = "This cannot be the end.",
						}, -- [87]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778033,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [88]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778044,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [89]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778246,
							["arg1"] = "I hold dominion over all!",
						}, -- [90]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553778302,
							["arg1"] = "The storm has broken, and I am myself again. Thank you.",
						}, -- [91]
						{
							["arg1"] = " ",
						}, -- [92]
						{
							["arg1"] = " ",
						}, -- [93]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [94]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790107,
							["arg1"] = "For de glory of G'huun!",
						}, -- [95]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790115,
							["arg1"] = "G'huun's power take you!",
						}, -- [96]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790121,
							["arg1"] = "Rot and wither!",
						}, -- [97]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790124,
							["arg1"] = "G'huun be everywhere!",
						}, -- [98]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790136,
							["arg1"] = "Rot and wither!",
						}, -- [99]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790145,
							["arg1"] = "G'huun's power take you!",
						}, -- [100]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790149,
							["arg1"] = "Praise be G'huun!",
						}, -- [101]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790152,
							["arg1"] = "Rot and wither!",
						}, -- [102]
						{
							["arg2"] = "Elder Leaxa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553790165,
							["arg1"] = "My blood for G'huun...",
						}, -- [103]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791346,
							["arg1"] = "Rise, fallen ones!",
						}, -- [104]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553791364,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [105]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791432,
							["arg1"] = "Die, vermin!",
						}, -- [106]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791455,
							["arg1"] = "Break them, Adderis!",
						}, -- [107]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791460,
							["arg1"] = "Thunder crash!",
						}, -- [108]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791475,
							["arg1"] = "Arcing slash!",
						}, -- [109]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791493,
							["arg1"] = "I will enjoy watching you fry!",
						}, -- [110]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791515,
							["arg1"] = "Break them, Adderis!",
						}, -- [111]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791520,
							["arg1"] = "Thunder crash!",
						}, -- [112]
						{
							["arg2"] = "Aspix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791534,
							["arg1"] = "What will become... of the empire...",
						}, -- [113]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791534,
							["arg1"] = "Arcing slash!",
						}, -- [114]
						{
							["arg2"] = "Adderis",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791537,
							["arg1"] = "The sands... take me...",
						}, -- [115]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791647,
							["arg1"] = "Rise, fallen ones!",
						}, -- [116]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553791860,
							["arg1"] = "Rise, fallen ones!",
						}, -- [117]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792223,
							["arg1"] = "Rise, fallen ones!",
						}, -- [118]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553792356,
							["arg1"] = "Ya can't be hidin' from Bwonsamdi, little ting.",
						}, -- [119]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_WHISPER",
							["time"] = 1553792435,
							["arg1"] = "Sooner or later... everyone comes to me.",
						}, -- [120]
						{
							["arg2"] = "Bwonsamdi",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792658,
							["arg1"] = "Rise, fallen ones!",
						}, -- [121]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792917,
							["arg1"] = "The hex is shattered, but the temple's defenses have awakened!",
						}, -- [122]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553792928,
							["arg1"] = "Restore me and I will disable them!",
						}, -- [123]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793086,
							["arg1"] = "I hold dominion over all!",
						}, -- [124]
						{
							["arg2"] = "Avatar of Sethraliss",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793130,
							["arg1"] = "The storm has broken, and I am myself again. Thank you.",
						}, -- [125]
						{
							["arg2"] = "Nivus",
							["type"] = "MONSTER_YELL",
							["time"] = 1553793621,
							["arg1"] = "I am not some simple jester! I am Nielas Aran!",
							["clColor"] = "ff8686ec",
						}, -- [126]
						{
							["arg1"] = " ",
						}, -- [127]
						{
							["arg1"] = " ",
						}, -- [128]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [129]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795769,
							["arg1"] = "Your heartbeat is... music to my ears.",
							["clColor"] = "ff00fe95",
						}, -- [130]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795859,
							["arg1"] = "You will pay for invading our lands!",
						}, -- [131]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795923,
							["arg1"] = "Da Amani empire cannot be stopped!",
							["clColor"] = "ffc59a6c",
						}, -- [132]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795929,
							["arg1"] = "You face not Malchezaar alone, but the legions I command!",
							["clColor"] = "ff8686ec",
						}, -- [133]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795929,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "fffefefe",
						}, -- [134]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795939,
							["arg1"] = "Skill with a weapon is but a physical manifestation of one's martial strength. Let me show you what spiritual power is!",
							["clColor"] = "ffc31d39",
						}, -- [135]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795964,
							["arg1"] = "Who dares interrupt--What is this; what have you done? You'll ruin everything!",
							["clColor"] = "fffe7b09",
						}, -- [136]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795966,
							["arg1"] = "Charrrrrge!",
							["clColor"] = "ff00fe95",
						}, -- [137]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795969,
							["arg1"] = "I have tried to be an accommodating host, but you simply will not die! Time to throw all pretense aside and just... KILL YOU ALL!",
							["clColor"] = "fff38bb9",
						}, -- [138]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795969,
							["arg1"] = "Have you vermin ever witnessed such raw power? I think not.",
							["clColor"] = "ffa22fc8",
						}, -- [139]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795977,
							["arg1"] = "Bjorn of the Black Storm! Honor me now with your presence!",
							["clColor"] = "fffe7b09",
						}, -- [140]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553795984,
							["arg1"] = "HERETICS! You will suffer for this interruption!",
							["clColor"] = "ff8686ec",
						}, -- [141]
						{
							["arg2"] = "Samîsu",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796037,
							["arg1"] = "Time shifts again, and your doom draws near!",
							["clColor"] = "ffa9d271",
						}, -- [142]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796318,
							["arg1"] = "For Zandalar!",
						}, -- [143]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796320,
							["arg1"] = "I am a conduit of the Nightwell's glorious power! I am NIGHTBORNE!",
							["clColor"] = "ffa22fc8",
						}, -- [144]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796321,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [145]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796321,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [146]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796332,
							["arg1"] = "De Light judges all!",
						}, -- [147]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796335,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [148]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796350,
							["arg1"] = "Defeat has never tasted so bitter...",
							["clColor"] = "fff38bb9",
						}, -- [149]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796357,
							["arg1"] = "De Light judges all!",
						}, -- [150]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796370,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [151]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796383,
							["arg1"] = "De reckoning is at hand!",
						}, -- [152]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796389,
							["arg1"] = "To arms! Drive dese outsiders from Zuldazar!",
						}, -- [153]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796396,
							["arg1"] = "De Light judges all!",
						}, -- [154]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796426,
							["arg1"] = "De Light judges all!",
						}, -- [155]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796437,
							["arg1"] = "Retribution for de fallen!",
						}, -- [156]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "De Light judges all!",
						}, -- [157]
						{
							["arg2"] = "Ra'wani Kanae",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796451,
							["arg1"] = "Light guide me... to de... Other Side...",
						}, -- [158]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796523,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [159]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796525,
							["arg1"] = "All realities, all dimensions are open to me!",
							["clColor"] = "ff8686ec",
						}, -- [160]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796536,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [161]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796540,
							["arg1"] = "Never heard my blade coming!",
							["clColor"] = "ffa22fc8",
						}, -- [162]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796546,
							["arg1"] = "HAH!",
							["clColor"] = "fff38bb9",
						}, -- [163]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796550,
							["arg1"] = "AG VWYQ ZA AN'ZIG ",
							["clColor"] = "fffefefe",
						}, -- [164]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796553,
							["arg1"] = "Your greed, your foolishness has brought you to this end.",
							["clColor"] = "ff8686ec",
						}, -- [165]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796564,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [166]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796572,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [167]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796647,
							["arg1"] = "Mortal minds... So easily manipulated.",
							["clColor"] = "fff38bb9",
						}, -- [168]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796649,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [169]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796651,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [170]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796653,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [171]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796682,
							["arg1"] = "As my master once said, \"You cannot truly know someone until you fight them.\"",
							["clColor"] = "ffc31d39",
						}, -- [172]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796696,
							["arg1"] = "Incoming!",
							["clColor"] = "ffc59a6c",
						}, -- [173]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796702,
							["arg1"] = "Your technique needs work.",
							["clColor"] = "ffc31d39",
						}, -- [174]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796735,
							["arg1"] = "Just as you deserve!",
							["clColor"] = "fffe7b09",
						}, -- [175]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796752,
							["arg1"] = "If only you understood!",
							["clColor"] = "ffa9d271",
						}, -- [176]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796767,
							["arg1"] = "I thank you for coming, but you really all must die now!",
							["clColor"] = "fff38bb9",
						}, -- [177]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796773,
							["arg1"] = "Rook fight!",
							["clColor"] = "fff38bb9",
						}, -- [178]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796774,
							["arg1"] = "Out da way!",
							["clColor"] = "ffc59a6c",
						}, -- [179]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796776,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [180]
						{
							["arg2"] = "Metó",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796778,
							["arg1"] = "How can you hope to stand against such overwhelming power?",
							["clColor"] = "ff8686ec",
						}, -- [181]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796844,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [182]
						{
							["arg2"] = "Laki",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796845,
							["arg1"] = "Closer! Come closer... and burn!",
							["clColor"] = "fffe7b09",
						}, -- [183]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796847,
							["arg1"] = "A taste... just a small taste... of the Spell-Weaver's power!",
							["clColor"] = "ffa9d271",
						}, -- [184]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796848,
							["arg1"] = "Ha! I have fought goren that proved more of a challenge!",
						}, -- [185]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796849,
							["arg1"] = "You will burn to ashes!",
						}, -- [186]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796854,
							["arg1"] = "You see? I told you they were nothing to worry about.",
						}, -- [187]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796913,
							["arg1"] = "You face the dragon of Draenor!",
						}, -- [188]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796914,
							["arg1"] = "Shocking!",
							["clColor"] = "ffc59a6c",
						}, -- [189]
						{
							["arg2"] = "Alleycut",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796915,
							["arg1"] = "Enough! You little beasts are getting out of hand!",
							["clColor"] = "ffa22fc8",
						}, -- [190]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796918,
							["arg1"] = "You will burn to ashes!",
						}, -- [191]
						{
							["arg2"] = "Supersunny",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796919,
							["arg1"] = "Brawl... with Rook.",
							["clColor"] = "fff38bb9",
						}, -- [192]
						{
							["arg2"] = "Härridk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796923,
							["arg1"] = "Hold nothing back, for I will not!",
							["clColor"] = "ffc31d39",
						}, -- [193]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796925,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [194]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796929,
							["arg1"] = "Flesh turns to ash!",
							["clColor"] = "fff38bb9",
						}, -- [195]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796940,
							["arg1"] = "Better watch your step!",
						}, -- [196]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796943,
							["arg1"] = "Your defense is feeble!",
						}, -- [197]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796961,
							["arg1"] = "Time to test your mettle!",
						}, -- [198]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796967,
							["arg1"] = "The elements will break you!",
						}, -- [199]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796971,
							["arg1"] = "The phoenix takes many forms!",
						}, -- [200]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796977,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [201]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796978,
							["arg1"] = "So much unstable energy... but worth the risk to destroy you!",
							["clColor"] = "ffa9d271",
						}, -- [202]
						{
							["arg2"] = "Woowa",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796982,
							["arg1"] = "What... awaits me... now?",
							["clColor"] = "fffe7b09",
						}, -- [203]
						{
							["arg2"] = "Inánná",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "You really have to want it!",
							["clColor"] = "fff38bb9",
						}, -- [204]
						{
							["arg2"] = "Andromaché",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796984,
							["arg1"] = "There is only one true path of enlightenment! DEATH!",
							["clColor"] = "ff8686ec",
						}, -- [205]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553796993,
							["arg1"] = "Better watch your step!",
						}, -- [206]
						{
							["arg2"] = "Hornpubmonk",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797003,
							["arg1"] = "Guess I... be off... ta the locker...",
							["clColor"] = "ff00fe95",
						}, -- [207]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797010,
							["arg1"] = "Your defense is feeble!",
						}, -- [208]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797028,
							["arg1"] = "Time to test your mettle!",
						}, -- [209]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797031,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [210]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797041,
							["arg1"] = "Better watch your step!",
						}, -- [211]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Your defense is feeble!",
						}, -- [212]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797104,
							["arg1"] = "Better watch your step!",
						}, -- [213]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797106,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [214]
						{
							["arg2"] = "Ma'ra Grimfang",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797123,
							["arg1"] = "Time to test your mettle!",
						}, -- [215]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797146,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [216]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797152,
							["arg1"] = "Better watch your step!",
						}, -- [217]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [218]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797187,
							["arg1"] = "Better watch your step!",
						}, -- [219]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797198,
							["arg1"] = "Better watch your step!",
						}, -- [220]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797210,
							["arg1"] = "Better watch your step!",
						}, -- [221]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797212,
							["arg1"] = "Behold the flames of the phoenix!",
						}, -- [222]
						{
							["arg2"] = "Anathos Firecaller",
							["type"] = "MONSTER_YELL",
							["time"] = 1553797220,
							["arg1"] = "Better watch your step!",
						}, -- [223]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799231,
							["arg1"] = "I will burn you from the inside out!",
							["clColor"] = "ffc59a6c",
						}, -- [224]
						{
							["arg2"] = "Neferupitou",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799318,
							["arg1"] = "The waters whisper to me... enemies approach.",
							["clColor"] = "ffa9d271",
						}, -- [225]
						{
							["arg2"] = "Kalissta",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799325,
							["arg1"] = "Avast, ye bilge suckers!",
							["clColor"] = "fffefefe",
						}, -- [226]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799752,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [227]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553799875,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [228]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800176,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [229]
						{
							["arg2"] = "Dovomir",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800349,
							["arg1"] = "BY FIRE BE... BURNED!",
							["clColor"] = "ffc59a6c",
						}, -- [230]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800753,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [231]
						{
							["arg2"] = "Isery",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800804,
							["arg1"] = "None may challenge the Brotherhood!",
							["clColor"] = "fffe7b09",
						}, -- [232]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800822,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [233]
						{
							["arg2"] = "Ðaisuke",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800831,
							["arg1"] = "Pay for your crimes!",
							["clColor"] = "ffa22fc8",
						}, -- [234]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800943,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [235]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553800963,
							["arg1"] = "W'OQ ZA ",
							["clColor"] = "fffefefe",
						}, -- [236]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801085,
							["arg1"] = "YOUR SOUL IS MINE!",
							["clColor"] = "fffe7b09",
						}, -- [237]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801117,
							["arg1"] = "Oh thank GOODNESS! Don't you worry, my precious baby boy. I'm gonna take good care of you.",
						}, -- [238]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801189,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [239]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801328,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [240]
						{
							["arg2"] = "Nelwyn",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801416,
							["arg1"] = "Class... dismissed.",
							["clColor"] = "fffe7b09",
						}, -- [241]
						{
							["arg2"] = "Qyix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801420,
							["arg1"] = "Well... done, heh. But I wonder if you're good enough... to best him.",
							["clColor"] = "fffefefe",
						}, -- [242]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801516,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [243]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801636,
							["arg1"] = "Hammer of the Righteous!",
							["clColor"] = "ffc59a6c",
						}, -- [244]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801637,
							["arg1"] = "You! You need more practice.",
							["clColor"] = "ffc59a6c",
						}, -- [245]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801640,
							["arg1"] = "Yogg-Saron! Grant me your power!",
							["clColor"] = "ffa22fc8",
						}, -- [246]
						{
							["arg2"] = "Tyrellan",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801762,
							["arg1"] = "Master, a gift for you!",
							["clColor"] = "ffa22fc8",
						}, -- [247]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801861,
							["arg1"] = "Serves ya right!",
						}, -- [248]
						{
							["arg2"] = "Daddysenpai",
							["type"] = "MONSTER_YELL",
							["time"] = 1553801930,
							["arg1"] = "Prepare yourselves!",
							["clColor"] = "ffc59a6c",
						}, -- [249]
						{
							["arg2"] = "Trade Prince Gallywix",
							["type"] = "MONSTER_YELL",
							["time"] = 1553802146,
							["arg1"] = "HAHAHA! Those Alliance goons will never learn! Who's a good golden golem? You are!",
						}, -- [250]
					},
				}, -- [11]
				["worlddefense"] = {
					["enabled"] = true,
					["name"] = "World defense",
					["logs"] = {
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [1]
					},
				},
				["guildrecruitment"] = {
					["enabled"] = true,
					["name"] = "Guild recruitment",
					["logs"] = {
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [1]
					},
				},
				["general"] = {
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "General",
					["logs"] = {
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [1]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [2]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [3]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [4]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [5]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [6]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [7]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [8]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [9]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [10]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [11]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [12]
						{
							["arg1"] = " ",
						}, -- [13]
						{
							["arg1"] = " ",
						}, -- [14]
						{
							["arg1"] = "Logging started on 03/19/2019 at 20:39:44.",
							["type"] = "SYSTEM",
						}, -- [15]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553025249,
							["arg1"] = "suchen tank für |cffa335ee|Hkeystone:158923:247:12:9:6:4:117|h[Schlüsselstein: Das RIESENFLÖZ!! (12)]|h|r",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Nicsheal-Antonidas",
						}, -- [16]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553025911,
							["arg1"] = "bei wemm trit dieser Fehler:Interface\\FrameXML\\ItemButtonTemplate.lua65:attempt to index loca`icon`(a nil value) - auch auf beim addon AdiBagd ???",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Lolitane-Antonidas",
						}, -- [17]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553026050,
							["arg1"] = "*AdiBags",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Lolitane-Antonidas",
						}, -- [18]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [19]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [20]
						{
							["arg1"] = " ",
						}, -- [21]
						{
							["arg1"] = " ",
						}, -- [22]
						{
							["arg1"] = "Logging started on 03/20/2019 at 09:57:36.",
							["type"] = "SYSTEM",
						}, -- [23]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [24]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [25]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [26]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [27]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [28]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [29]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [30]
						{
							["arg1"] = " ",
						}, -- [31]
						{
							["arg1"] = " ",
						}, -- [32]
						{
							["arg1"] = "Logging started on 03/20/2019 at 11:22:30.",
							["type"] = "SYSTEM",
						}, -- [33]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [34]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [35]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [36]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [37]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [38]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [39]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [40]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [41]
						{
							["arg1"] = " ",
						}, -- [42]
						{
							["arg1"] = " ",
						}, -- [43]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/20/2019 at 21:22:54.",
						}, -- [44]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [45]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [46]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [47]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [48]
						{
							["arg1"] = " ",
						}, -- [49]
						{
							["arg1"] = " ",
						}, -- [50]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/24/2019 at 19:32:10.",
						}, -- [51]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553454790,
							["arg1"] = "WHAT IS LOVE?",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Schailu-Antonidas",
						}, -- [52]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553454798,
							["arg1"] = "BABY DONT HURT ME",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Yehua-Antonidas",
						}, -- [53]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553454798,
							["arg1"] = "BABY DONT HURT ME",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Norobashi-Antonidas",
						}, -- [54]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553454805,
							["arg1"] = "No MORE",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Syløx-Antonidas",
						}, -- [55]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553454806,
							["arg1"] = "NO MORE",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Attexx-Antonidas",
						}, -- [56]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553454844,
							["arg1"] = "So langweilig im lfr?",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Siçko-Antonidas",
						}, -- [57]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553455176,
							["arg1"] = "wts |cff9d9d9d|Hitem:140755::::::::120:66::::::|h[Lebensechte Magistrixpuppe]|h|r :)",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Vylania-Antonidas",
						}, -- [58]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553455189,
							["arg1"] = "10 g ",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Xambro-Antonidas",
						}, -- [59]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553455194,
							["arg1"] = " ^^",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Xambro-Antonidas",
						}, -- [60]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553455199,
							["arg1"] = "VERKAUFT!!!",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Vylania-Antonidas",
						}, -- [61]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553455209,
							["arg1"] = "11g, aber nur wenn sie gefühlsecht ist",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Réckléss-Antonidas",
						}, -- [62]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553455210,
							["arg1"] = "20 !",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Anotherdh-Antonidas",
						}, -- [63]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553455215,
							["arg1"] = "What is Love ?",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Pêterzwegat-Antonidas",
						}, -- [64]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553455234,
							["arg1"] = "baby dont hurt me",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Kümmelzwerg-Antonidas",
						}, -- [65]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553455247,
							["arg1"] = "dont hurt me",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Blackroxo-Antonidas",
						}, -- [66]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553455247,
							["arg1"] = "no morrrre ",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Xambro-Antonidas",
						}, -- [67]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553455258,
							["arg1"] = "Klappt immer xD",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Pêterzwegat-Antonidas",
						}, -- [68]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553455277,
							["arg1"] = "Aber immer :3",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Mawei-Antonidas",
						}, -- [69]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553455281,
							["arg1"] = "alles hat ein ende nur die ..... ?",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Xambro-Antonidas",
						}, -- [70]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553455290,
							["arg1"] = "banane hat 2",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Schailu-Antonidas",
						}, -- [71]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553455292,
							["arg1"] = "xambro hat zwei",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Néahla-Antonidas",
						}, -- [72]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553455301,
							["arg1"] = "xD",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Xambro-Antonidas",
						}, -- [73]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553455301,
							["arg1"] = "hihi :* ",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Lyniâ-Antonidas",
						}, -- [74]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553455462,
							["arg1"] = "@Everyone  HT/BL/KR/SUPERDUPERDMG am Anfang!",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Anotherdh-Antonidas",
						}, -- [75]
						{
							["clColor"] = "fffef367",
							["time"] = 1553455476,
							["arg1"] = "over 9000!",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Stueck-Antonidas",
						}, -- [76]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553455477,
							["arg1"] = "OKAY!",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Shakora-Antonidas",
						}, -- [77]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553455497,
							["arg1"] = "am anfang von was?",
							["arg9"] = "General - Battle of Dazar'alor",
							["arg2"] = "Mutenroshie-Antonidas",
						}, -- [78]
						{
							["arg1"] = " ",
						}, -- [79]
						{
							["arg1"] = " ",
						}, -- [80]
						{
							["arg1"] = "Logging started on 03/24/2019 at 20:43:07.",
							["type"] = "SYSTEM",
						}, -- [81]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [82]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [83]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [84]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [85]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [86]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [87]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [88]
						{
							["arg1"] = " ",
						}, -- [89]
						{
							["arg1"] = " ",
						}, -- [90]
						{
							["arg1"] = "Logging started on 03/25/2019 at 12:16:35.",
							["type"] = "SYSTEM",
						}, -- [91]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [92]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [93]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [94]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [95]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [96]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [97]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [98]
						{
							["arg1"] = " ",
						}, -- [99]
						{
							["arg1"] = " ",
						}, -- [100]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/25/2019 at 14:01:13.",
						}, -- [101]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [102]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [103]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [104]
						{
							["arg1"] = " ",
						}, -- [105]
						{
							["arg1"] = " ",
						}, -- [106]
						{
							["arg1"] = "Logging started on 03/25/2019 at 15:41:04.",
							["type"] = "SYSTEM",
						}, -- [107]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [108]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [109]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [110]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [111]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [112]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553527685,
							["arg1"] = "LFM BOD 1.BOSS MYTHIC, nur mit xp",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Zakkum-Aegwynn",
						}, -- [113]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553527761,
							["arg1"] = "LFM BOD 1.BOSS MYTHIC, nur mit xp ",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Zakkum-Aegwynn",
						}, -- [114]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553527844,
							["arg1"] = "LFM BOD 1.BOSS MYTHIC nur mit exp",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Zakkum-Aegwynn",
						}, -- [115]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553528458,
							["arg1"] = "LFM 1.BOSS MYTH nur noch heiler und r dds /im tool anmelden",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Zakkum-Aegwynn",
						}, -- [116]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553529052,
							["arg1"] = "LFM BOD 1.BOSS MYTHIC anmelden im tool",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Zakkum-Aegwynn",
						}, -- [117]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553529193,
							["arg1"] = "LFM 1.BOSS MYTHIC nur mit exp im tool anmelden",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Zakkum-Aegwynn",
						}, -- [118]
						{
							["arg1"] = " ",
						}, -- [119]
						{
							["arg1"] = " ",
						}, -- [120]
						{
							["arg1"] = "Logging started on 03/26/2019 at 18:41:45.",
							["type"] = "SYSTEM",
						}, -- [121]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [122]
						{
							["arg1"] = " ",
						}, -- [123]
						{
							["arg1"] = " ",
						}, -- [124]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:48:48.",
						}, -- [125]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [126]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553623538,
							["arg1"] = "ghibts hier ne gilde die mythic raidet",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Bloodnhonour-Blackhand",
						}, -- [127]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [128]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [129]
						{
							["arg1"] = " ",
						}, -- [130]
						{
							["arg1"] = " ",
						}, -- [131]
						{
							["arg1"] = "Logging started on 03/27/2019 at 10:46:09.",
							["type"] = "SYSTEM",
						}, -- [132]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [133]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [134]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [135]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [136]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [137]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [138]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [139]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [140]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [141]
						{
							["arg1"] = " ",
						}, -- [142]
						{
							["arg1"] = " ",
						}, -- [143]
						{
							["arg1"] = "Logging started on 03/27/2019 at 12:10:34.",
							["type"] = "SYSTEM",
						}, -- [144]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [145]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [146]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [147]
						{
							["arg1"] = " ",
						}, -- [148]
						{
							["arg1"] = " ",
						}, -- [149]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 13:55:25.",
						}, -- [150]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553691794,
							["arg1"] = "AH please",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Belogy-Aegwynn",
						}, -- [151]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553697992,
							["arg1"] = "LFM 1st Boss Mythic BOD TANKS!",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Andelu-Antonidas",
						}, -- [152]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [153]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [154]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [155]
						{
							["arg1"] = " ",
						}, -- [156]
						{
							["arg1"] = " ",
						}, -- [157]
						{
							["arg1"] = "Logging started on 03/27/2019 at 18:22:22.",
							["type"] = "SYSTEM",
						}, -- [158]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [159]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [160]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [161]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [162]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [163]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [164]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [165]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [166]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [167]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [168]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [169]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [170]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [171]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [172]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [173]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [174]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [175]
						{
							["arg1"] = " ",
						}, -- [176]
						{
							["arg1"] = " ",
						}, -- [177]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 22:37:44.",
						}, -- [178]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [179]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [180]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [181]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [182]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [183]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [184]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [185]
						{
							["arg1"] = " ",
						}, -- [186]
						{
							["arg1"] = " ",
						}, -- [187]
						{
							["arg1"] = "Logging started on 03/28/2019 at 00:02:53.",
							["type"] = "SYSTEM",
						}, -- [188]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [189]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [190]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [191]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [192]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [193]
						{
							["arg1"] = " ",
						}, -- [194]
						{
							["arg1"] = " ",
						}, -- [195]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [196]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553774854,
							["arg1"] = "WTS M+10 für eure Weekly /w me für Infos",
							["arg9"] = "General - Boralus Harbor",
							["arg2"] = "Egnatius-Antonidas",
						}, -- [197]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [198]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [199]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [200]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [201]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553781227,
							["arg1"] = "kann mir jemand alchi posten?",
							["arg9"] = "General - Stormwind City",
							["arg2"] = "Thrëshy-Antonidas",
						}, -- [202]
						{
							["clColor"] = "fffef367",
							["time"] = 1553781241,
							["arg1"] = "|cffffd000|Htrade:Player-3686-068201CC:2259:171|h[Alchemy]|h|r",
							["arg9"] = "General - Stormwind City",
							["arg2"] = "Qvantum-Antonidas",
						}, -- [203]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553781244,
							["arg1"] = "ty",
							["arg9"] = "General - Stormwind City",
							["arg2"] = "Thrëshy-Antonidas",
						}, -- [204]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [205]
						{
							["arg1"] = " ",
						}, -- [206]
						{
							["arg1"] = " ",
						}, -- [207]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [208]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [209]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [210]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553789804,
							["arg1"] = "any horde around?",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Luclun-Ravencrest",
						}, -- [211]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553789823,
							["arg1"] = "Underrot entrance",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Walfred-DunModr",
						}, -- [212]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553789829,
							["arg1"] = "yes",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Ener-Outland",
						}, -- [213]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553789834,
							["arg1"] = "come to the entrance",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Ener-Outland",
						}, -- [214]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553789843,
							["arg1"] = "omw",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Luclun-Ravencrest",
						}, -- [215]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553789846,
							["arg1"] = "Sounds like a trap!",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Tony-GrimBatol",
						}, -- [216]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553789862,
							["arg1"] = "gone",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Walfred-DunModr",
						}, -- [217]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553789869,
							["arg1"] = "ye well the worst that can happen me pixels die",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Luclun-Ravencrest",
						}, -- [218]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553789872,
							["arg1"] = "No, that's guys pretending to be girls.",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Drunkpotato-Sylvanas",
						}, -- [219]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553789897,
							["arg1"] = "But then someone will think that their pixels are stronger than your pixels",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Tony-GrimBatol",
						}, -- [220]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553789926,
							["arg1"] = "my pixelsd are king",
							["arg9"] = "General - Nazmir",
							["arg2"] = "Luclun-Ravencrest",
						}, -- [221]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [222]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [223]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [224]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [225]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [226]
						{
							["arg1"] = " ",
						}, -- [227]
						{
							["arg1"] = " ",
						}, -- [228]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [229]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [230]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [231]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [232]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553801577,
							["arg1"] = "forsen1 bajs?",
							["arg2"] = "Critlain-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [233]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553801583,
							["arg1"] = "Amazinga",
							["arg2"] = "Raull-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [234]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553801588,
							["arg1"] = "forsen1",
							["arg2"] = "Grewold-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [235]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553801590,
							["arg1"] = "forsen1 forsen2 COMBO ME BOIS",
							["arg2"] = "Yshtolah-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [236]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553801597,
							["arg1"] = "forsen3 forsen4",
							["arg2"] = "Critlain-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [237]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553801608,
							["arg1"] = "RicardoFlick",
							["arg2"] = "Grewold-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [238]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553801629,
							["arg1"] = "Eisenbanner!",
							["arg2"] = "Pinaý-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [239]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553801668,
							["arg1"] = "Suche einen süßen Boy für gemeinsame Nächte",
							["arg2"] = "Yshtolah-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [240]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553801677,
							["arg1"] = "nice",
							["arg2"] = "Healpotx-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [241]
						{
							["clColor"] = "fffef367",
							["time"] = 1553801679,
							["arg1"] = "Eljakim bietet sich gerne an",
							["arg2"] = "Xoyoxoyo-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [242]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553801683,
							["arg1"] = "hab interesse :>",
							["arg2"] = "Healpotx-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [243]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553801700,
							["arg1"] = "ich kenne da einen dk",
							["arg2"] = "Nemíra-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [244]
						{
							["clColor"] = "fffef367",
							["time"] = 1553801701,
							["arg1"] = "bist du denn auch ein hot gurl?",
							["arg2"] = "Ezymoney-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [245]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553801704,
							["arg1"] = "Um gottes Willen",
							["arg2"] = "Amdee-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [246]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553801715,
							["arg1"] = "Zeig ihm dein goldenen Hammer @plox",
							["arg2"] = "Lèox-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [247]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553801718,
							["arg1"] = "amdee biete sich an",
							["arg2"] = "Schattengraf-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [248]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553801719,
							["arg1"] = "Kann dir nur  nen verranzten  Sack anbieten, süßer boy ist leider aus",
							["arg2"] = "Aralaya-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [249]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553801728,
							["arg1"] = "schnauze, cutszene",
							["arg2"] = "Desdemônâ-Antonidas",
							["arg9"] = "General - Battle of Dazar'alor",
						}, -- [250]
					},
				},
				["trade"] = {
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Trade",
					["logs"] = {
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553790601,
							["arg1"] = "Verkaufen Mythic+10 Key für deine Weekly, Sichere dir dein 410+ Item am Mittwoch in der Kiste und jeglichen Loot den wir nicht benötigen! /wme bei Interesse",
							["arg9"] = "Trade - City",
							["arg2"] = "Avøra-Antonidas",
						}, -- [1]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553790610,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [2]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553790611,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [3]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553790654,
							["arg1"] = "WTS freehold boost 110-120 dh 111 4/5 min freehold 15/20 min lvl up  w/ me",
							["arg9"] = "Trade - City",
							["arg2"] = "Qwzzert-Antonidas",
						}, -- [4]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553790668,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [5]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553790668,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [6]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553790697,
							["arg1"] = "verkaufe |cffa335ee|Hitem:161134::::::::120:254::13::::|h[Mecha-Mogul Mk2]|h|r 320k gold",
							["arg9"] = "Trade - City",
							["arg2"] = "Lîîluu-Antonidas",
						}, -- [7]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553790701,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [8]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553790713,
							["arg1"] = "NARCOTIC (4/9Mythic) sucht derzeit Range DD´s, 1 Diszi/Holy-Priest/ 1 weiterer Heal & 1 Tank .Raidzeiten: Do+Di 19.30-22.30. Unsere Anforderung: GS von min 400 und eine nahezu 100%ige Anwesenheit an den Raidtagen. Bei Interesse wsp me",
							["arg9"] = "Trade - City",
							["arg2"] = "Shinnon-Antonidas",
						}, -- [9]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553790741,
							["arg1"] = "Verkaufen Mythic+10 Key für deine Weekly! Sichere dir dein 410+ Item am Mittwoch in der Kiste und jeglichen Loot den wir abgeben können! /w me bei Interesse",
							["arg9"] = "Trade - City",
							["arg2"] = "Cearann-Antonidas",
						}, -- [10]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553790781,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [11]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553790792,
							["arg1"] = "NARCOTIC (4/9Mythic) sucht derzeit Range DD´s ein Tank..Raidzeiten: Do+Di 19.30-22.30. Unsere Anforderung: GS von min 400 und eine nahezu 100%ige Anwesenheit an den Raidtagen. Bei Interesse schreib mich einfach an!",
							["arg9"] = "Trade - City",
							["arg2"] = "Oshi-Antonidas",
						}, -- [12]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553790803,
							["arg1"] = "!! EOA !! Du raidest gern  UND  machst  m+    DANN bist hier GENAU richtig !!! ALLE anderen sind auch willkommen  für mehr infos w/me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [13]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553790809,
							["arg1"] = "oh man, war in 4 dungeons aber er zählt nur 3, wtf? ",
							["arg9"] = "Trade - City",
							["arg2"] = "Käsejunge-Antonidas",
						}, -- [14]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553790810,
							["arg1"] = "WTS freehold boost 110-120 dh 111 4/5 min freehold 15/20 min lvl up  w/ me",
							["arg9"] = "Trade - City",
							["arg2"] = "Qwzzert-Antonidas",
						}, -- [15]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553790845,
							["arg1"] = "ja Käsejunge afk zeit von dks wird abgezogen",
							["arg9"] = "Trade - City",
							["arg2"] = "Remø-Antonidas",
						}, -- [16]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553790869,
							["arg1"] = "verkaufe |cffa335ee|Hitem:161134::::::::120:254::13::::|h[Mecha-Mogul Mk2]|h|r 320k   / |cffa335ee|Hitem:95416::::::::120:254::::::|h[Himmelsgolem]|h|r 45 K ",
							["arg9"] = "Trade - City",
							["arg2"] = "Lîîluu-Antonidas",
						}, -- [17]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553790879,
							["arg1"] = "mahlzeit, suche für meinen tank kireger gs 398 eine aktive gilde mit hc raid ",
							["arg9"] = "Trade - City",
							["arg2"] = "Marschý-Antonidas",
						}, -- [18]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553790889,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [19]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553790890,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [20]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553790901,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [21]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [22]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793218,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [23]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793220,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [24]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793220,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [25]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793224,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [26]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793235,
							["arg1"] = "Wir die Gilde \"Slytherin\" suchen für den aktuellen Content (9\\9 NHC - 3/9 HC) noch aktive Mitstreiter. Unsere Raidtage sind Donnerstag & Sonntag von 19:15- 22.00 Uhr. Sind auch gerne in M+ zusammen unterwegs. Einfach bei uns melden!",
							["arg9"] = "Trade - City",
							["arg2"] = "Chiriga-Antonidas",
						}, -- [27]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793239,
							["arg1"] = "Die Gilde Alerox sucht für Ihren HC Raid (4/9) noch aktive und zuverlässiege DD´s. Unsere Raidtage sind Mi. und So. von 19 bis 22..Bei Interesse oder Fragen, einfach schreiben",
							["arg9"] = "Trade - City",
							["arg2"] = "Adrástéá-Antonidas",
						}, -- [28]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553793241,
							["arg1"] = "ein tank für underrot+0 :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Finaly-Antonidas",
						}, -- [29]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793247,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [30]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553793247,
							["arg1"] = "Wir, die Gilde Kinder von Sturmwind, suchen für unseren Neuaufbau zu BFA aktive, erwachsene Mitglieder mit Interesse am Raid. Ein freundlicher Umgang, Spaß am Spiel und Hilfsbereitschaft ist  uns besonders wichtig. Du hast Interesse, dann melde dich",
							["arg9"] = "Trade - City",
							["arg2"] = "Akihla-Antonidas",
						}, -- [31]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793272,
							["arg1"] = "LFM 1. Boss Myth / 3 Heal! / link ach",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [32]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793283,
							["arg1"] = "Verkaufen Mythic+10 Key für deine Weekly, Sichere dir dein 410+ Item am Mittwoch in der Kiste und jeglichen Loot den wir nicht benötigen! /wme bei Interesse",
							["arg9"] = "Trade - City",
							["arg2"] = "Avøra-Antonidas",
						}, -- [33]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793296,
							["arg1"] = "Suche Leute, die gegen Taschengeld meine Gildensatzung unterschreiben...",
							["arg9"] = "Trade - City",
							["arg2"] = "Blutstahl-Antonidas",
						}, -- [34]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793329,
							["arg1"] = "Die Gilde Alerox sucht für Ihren HC Raid (4/9) noch aktive und zuverlässiege DD´s. Unsere Raidtage sind Mi. und So. von 19 bis 22..Bei Interesse oder Fragen, einfach schreiben",
							["arg9"] = "Trade - City",
							["arg2"] = "Adrástéá-Antonidas",
						}, -- [35]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793355,
							["arg1"] = "NARCOTIC (4/9Mythic) sucht derzeit Range DD´s ein Tank..Raidzeiten: Do+Di 19.30-22.30. Unsere Anforderung: GS von min 400 und eine nahezu 100%ige Anwesenheit an den Raidtagen. Bei Interesse schreib mich einfach an!",
							["arg9"] = "Trade - City",
							["arg2"] = "Oshi-Antonidas",
						}, -- [36]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793358,
							["arg1"] = "LFM Myth 1. Boss 1 Heal",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [37]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793360,
							["arg1"] = "Die Gilde Alerox sucht für Ihren HC Raid (4/9) noch aktive und zuverlässiege DD´s. Unsere Raidtage sind Mi. und So. von 19 bis 22..Bei Interesse oder Fragen, einfach schreiben",
							["arg9"] = "Trade - City",
							["arg2"] = "Adrástéá-Antonidas",
						}, -- [38]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793371,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [39]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793371,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [40]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793383,
							["arg1"] = "Gildengruppe sucht für gleich einenTank ab Mekka HC. Raidbeginn:18:45",
							["arg9"] = "Trade - City",
							["arg2"] = "Tînnie-Antonidas",
						}, -- [41]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793396,
							["arg1"] = "LFM BoD Myth 1. Boss / 1 Heal 1rDD / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [42]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793408,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [43]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793410,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [44]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793411,
							["arg1"] = "LFM BoD Myth 1. Boss /  1rDD / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [45]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793459,
							["arg1"] = "Bestellt jetzt euer |cffffffff|Hitem:126936::::::::113:63:::1:3524:::|h[Zuckerglasiertes Fischfestmahl]|h|r vor. Jeder der vorbestellt (Lieferung ab dem 07.04.) profitiert von einem günstigen Preis. /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [46]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793459,
							["arg1"] = "Suche für heute Abend  Schlacht von Dazar'alor (Neue ID HC ) (9/9 Nhc Down), noch Unterstützung von DDs, 1-2 Heals und 1 Tank, Ab 19.45 bis 22:30 Uhr. Gerne auch regelmäßig, mit TS Stammplatz möglich. /w me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Ewenia-Antonidas",
						}, -- [47]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793464,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [48]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793466,
							["arg1"] = "LFM BoD Myth 1. Boss /1rDD / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [49]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793481,
							["arg1"] = "<< Blood Court sucht für den Stamm/Gilde (9/9 nHC + 8/9 HC +1/9 M), 1 Tank + 2 DD´s, Raidtage: Do/So 19:00 - 22:00. wenn du mit uns durch Dazar'alor \"stolpern\" willst, dann melde dich unter www.bloodcourt.de oder ingame >>",
							["arg9"] = "Trade - City",
							["arg2"] = "Lênovos-Antonidas",
						}, -- [50]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553793481,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [51]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553793483,
							["arg1"] = "biete zum moggen|cff1eff00|Hitem:164448::::::::120:267::31::::|h[Geisterzweigbrustschutz]|h|r",
							["arg9"] = "Trade - City",
							["arg2"] = "Lanfrog-Antonidas",
						}, -- [52]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793491,
							["arg1"] = "Devour Hope sucht Dich für den Raidkader und M+ zu laufen. Raidzeiten sind Donnerstag und Montag 19:30 - 22 hc u. Sonntag 18 - 22 nhc. Gern gesehen auch Anfänger und Erfahrene Spieler. Für weiter Info w/me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Wilairat-Antonidas",
						}, -- [53]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793516,
							["arg1"] = "LFM BoD Myth 1. Boss /  1rDD / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [54]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553793517,
							["arg1"] = "Biete Level 110 bis 120 Freihafen-Boost [ca. 12 Minuten pro Level ab 20k bei 70% Bonus-EXP (Erbstücke, Trank, Gem)], Level 100 bis 110 Legion-Dungeon-Boost und Insel-Cap-Boost für 7k pro Insel. 110 DH mit 264 Itemlevel. Einfach anflüstern. :]",
							["arg9"] = "Trade - City",
							["arg2"] = "Arwelda-Antonidas",
						}, -- [55]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793570,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [56]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793571,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [57]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793572,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [58]
						{
							["clColor"] = "fffef367",
							["time"] = 1553793577,
							["arg1"] = "Safe Call (1m  9hc) möchte für den aktuellen Content und den  Mythicbereich den Raid aufstocken. Besonders gesucht Warry Dps + Range DDs aller Art ( Hunter, Lock, Shadow, Mage etc. ) und ein Palaheal. Raidzeit: Mi./Mo. 19.30-22.30Uhr. /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Djari-Antonidas",
						}, -- [59]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553793580,
							["arg1"] = "verschenke sofort 1500 mal |cff1eff00|Hitem:108996::::::::1:64::::::|h[Alchemischer Katalysator]|h|r",
							["arg9"] = "Trade - City",
							["arg2"] = "Barbybank-Antonidas",
						}, -- [60]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553793587,
							["arg1"] = "Wir die Gilde LuxAeterna, suchen für unseren Raid noch Member. Zuverlässigkeit und min. GS 390. Raidzeiten: Do  und SO ab 19:50 Stand 9/9+6/9HC + 1/9M BoD Alles weitere  /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Bigandy-Antonidas",
						}, -- [61]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793596,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [62]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793598,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [63]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793601,
							["arg1"] = "Gildengruppe sucht einen Tank ab Mekka HC.",
							["arg9"] = "Trade - City",
							["arg2"] = "Tînnie-Antonidas",
						}, -- [64]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793607,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [65]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793617,
							["arg1"] = "die Gilde \"Purge of Mal´Ganis\" sucht für heute Abend von 18:45-21:30 noch einen tank ab Mekka HC, Flask und Food werden gestellt",
							["arg9"] = "Trade - City",
							["arg2"] = "Lámidi-Antonidas",
						}, -- [66]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793636,
							["arg1"] = "LFM BoD Myth 1. Boss /  1rDD / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [67]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793684,
							["arg1"] = "Wir die Gilde \"Klingen der Zeit\"(BOD Nhc 9/9 hc 4/9 ) Suchen Aktuell noch zur Erweiterung unseres Raidstammes DD´s sowie Heile und einen Tankr. Unsere Raidzeiten sind Sa 19 bis 23 Uhr. Bei Interesse und Fragen einfach anschreiben.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leutherion-Antonidas",
						}, -- [68]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793699,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [69]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793699,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [70]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553793781,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [71]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793792,
							["arg1"] = "[18:20] [2] [Lámidi]: die Gilde \"Purge of Mal´Ganis\" sucht für heute Abend von 18:45-21:30 noch einen tank ab Mekka HC, Flask und Food werden gestellt",
							["arg9"] = "Trade - City",
							["arg2"] = "Tînnie-Antonidas",
						}, -- [72]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553793795,
							["arg1"] = "verkaufen |cffa335ee|Hitem:161134::::::::120:254::13::::|h[Mecha-Mogul Mk2]|h|r 320k ",
							["arg9"] = "Trade - City",
							["arg2"] = "Lîîluu-Antonidas",
						}, -- [73]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793800,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [74]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793802,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [75]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793810,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [76]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793810,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [77]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553793823,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [78]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793834,
							["arg1"] = "Die kürzlich gegründete Gilde <Cookie Crumbles> nimmt gerne neue Mitglieder auf. Twinks oder Mains, neue oder wiederkehrende Spieler sind willkommen. Meldet euch bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Yraell-Antonidas",
						}, -- [79]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793853,
							["arg1"] = "LFM BoD Myth 1. Boss / 1 Heal / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [80]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793856,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [81]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793859,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [82]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793869,
							["arg1"] = "<Tötet was Trötet> BoD 9/9HC  4/9 M rekrutiert! Gesucht wird VORALLEM ein WL,Heal und ein Tank. Andere Klassen sind natürlich trotzdem gern gesehen bei entsprechender Leistung! Raidzeiten Mittwoch & Sonntag 18:45 - 22 Uhr. Für weitere Fragen /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Youlica-Antonidas",
						}, -- [83]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793901,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [84]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793901,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [85]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793906,
							["arg1"] = "LFM BoD Myth 1. Boss / 1 Heal / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [86]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793912,
							["arg1"] = "<< Blood Court sucht für den Stamm/Gilde (9/9 nHC + 8/9 HC +1/9 M), 1 Tank + 2 DD´s, Raidtage: Do/So 19:00 - 22:00. wenn du mit uns durch Dazar'alor \"stolpern\" willst, dann melde dich unter www.bloodcourt.de oder ingame >>",
							["arg9"] = "Trade - City",
							["arg2"] = "Lênovos-Antonidas",
						}, -- [87]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793929,
							["arg1"] = "suche einen mage der mich von Sturmwind nach Boralus porten kann",
							["arg9"] = "Trade - City",
							["arg2"] = "Rejewenation-Antonidas",
						}, -- [88]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553793930,
							["arg1"] = "AleroX sucht  für BoD HC noch einige DD´s. Erfahrung sollte vorhanden sein!(mind.NHC clear) Wir selbst haben 9/9 Nhc ; 4/9 Hc down.Zuverlässigkeit setzen wir vorraus!Mi+So 19:00-22:00 Uhr.Weitere Info´s per wisper :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [89]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553793931,
							["arg1"] = "verkaufe |cffffffff|Hitem:165692::::::::120:64::::::|h[Vantusrune: Schlacht von Dazar'alor]|h|r",
							["arg9"] = "Trade - City",
							["arg2"] = "Bûtan-Antonidas",
						}, -- [90]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793934,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [91]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793934,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [92]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793935,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [93]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553793936,
							["arg1"] = "kaufe windwollstoff in massen w me!:)",
							["arg9"] = "Trade - City",
							["arg2"] = "Prinztartus-Antonidas",
						}, -- [94]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553793937,
							["arg1"] = "AleroX sucht  für BoD HC noch einige DD´s. Erfahrung sollte vorhanden sein!(mind.NHC clear) Wir selbst haben 9/9 Nhc ; 4/9 Hc down.Zuverlässigkeit setzen wir vorraus!Mi+So 19:00-22:00 Uhr.Weitere Info´s per wisper :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [95]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553793950,
							["arg1"] = "weiß je,mand ob man nur 1000 haustiere haben kann?",
							["arg9"] = "Trade - City",
							["arg2"] = "Barbybank-Antonidas",
						}, -- [96]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553793959,
							["arg1"] = "Die Unbeugsamen suchen zuverlässige Verstärkung für ihre HC Raids. Zeiten: Do + Mo 19:45 Uhr bis 22:30 Uhr. 6/9 HC Down. GS ab 385+. /w me oder schaut auf www.die-unbeugsamen.eu vorbei, um unser Regelwerk zu lesen und euch zu bewerben.",
							["arg9"] = "Trade - City",
							["arg2"] = "Akikyou-Antonidas",
						}, -- [97]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793976,
							["arg1"] = "< ASIX >( 8/9 HC 1/9 Myth ) sucht noch  Range DDs für unseren  HC / Mythic Raid ! Mittwoch u. Sonntag (ab 19:30-22:30) !! w Apox oder Aqøxx an  ",
							["arg9"] = "Trade - City",
							["arg2"] = "Aqøxx-Antonidas",
						}, -- [98]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793979,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [99]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793979,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [100]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553793980,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [101]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553793982,
							["arg1"] = "Verschenke Gilde mit 6 Bankfächern",
							["arg9"] = "Trade - City",
							["arg2"] = "Arphendia-Antonidas",
						}, -- [102]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553793989,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [103]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553793990,
							["arg1"] = "Biete Level 110 bis 120 Freihafen-Boost [ca. 12 Minuten pro Level ab 20k bei 70% Bonus-EXP (Erbstücke, Trank, Gem)], Level 100 bis 110 Legion-Dungeon-Boost und Insel-Cap-Boost für 7k pro Insel. 110 DH mit 264 Itemlevel. Einfach anflüstern. :]",
							["arg9"] = "Trade - City",
							["arg2"] = "Arwelda-Antonidas",
						}, -- [104]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553793996,
							["arg1"] = "Die Gilde Alerox sucht für Ihren HC Raid (4/9) noch aktive und zuverlässiege DD´s. Unsere Raidtage sind Mi. und So. von 19 bis 22..Bei Interesse oder Fragen, einfach schreiben",
							["arg9"] = "Trade - City",
							["arg2"] = "Adrástéá-Antonidas",
						}, -- [105]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553793997,
							["arg1"] = "Wir die Gilde Dragon Souls ( 9/9 HC & 1/9 Myth ) suchen für unseren Raid noch DD´s ( Keine Jäger & Schurken)  & einen Heiler ( Priester  ) Unsere Raidzeiten sind DO & MO von 19:30 Uhr bis 23 Uhr. Für Infos /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Thorrus-Antonidas",
						}, -- [106]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794017,
							["arg1"] = "Die Gilde Phrasing (3/9Mythic 9/9hc, Mi u. So. 18:30-22:30) sucht zur Verstärkung des Raidkaders noch aktive und zuverlässige Spieler! Aktuell benötigen wir 2 DDs bevorzugt werden WW , Warri und Hexer. Du hast Interesse dann /w me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Yahoel-Antonidas",
						}, -- [107]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794035,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [108]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794035,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [109]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794049,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [110]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794067,
							["arg1"] = "AleroX sucht  für BoD HC noch einige DD´s. Erfahrung sollte vorhanden sein!(mind.NHC clear) Wir selbst haben 9/9 Nhc ; 4/9 Hc down.Zuverlässigkeit setzen wir vorraus!Mi+So 19:00-22:00 Uhr.Weitere Info´s per wisper :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [111]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553794077,
							["arg1"] = "<< Blood Court sucht für den Stamm/Gilde (9/9 nHC + 8/9 HC +1/9 M), 1 Tank + 2 DD´s, Raidtage: Do/So 19:00 - 22:00. wenn du mit uns durch Dazar'alor \"stolpern\" willst, dann melde dich unter www.bloodcourt.de oder ingame >>",
							["arg9"] = "Trade - City",
							["arg2"] = "Lênovos-Antonidas",
						}, -- [112]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794081,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [113]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794091,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [114]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794092,
							["arg1"] = "<Tötet was Trötet> BoD 9/9HC  4/9 M rekrutiert! Gesucht wird VORALLEM ein WL,Heal und ein Tank. Andere Klassen sind natürlich trotzdem gern gesehen bei entsprechender Leistung! Raidzeiten Mittwoch & Sonntag 18:45 - 22 Uhr. Für weitere Fragen /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Youlica-Antonidas",
						}, -- [115]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794093,
							["arg1"] = "It's Britney, bitch!",
							["arg9"] = "Trade - City",
							["arg2"] = "Aikira-Antonidas",
						}, -- [116]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794100,
							["arg1"] = "Die Gilde Phrasing (3/9Mythic 9/9hc, Mi u. So. 18:30-22:30) sucht zur Verstärkung des Raidkaders noch aktive und zuverlässige Spieler! Aktuell benötigen wir 2 DDs bevorzugt werden WW , Warri und Hexer. Du hast Interesse dann /w me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Yahoel-Antonidas",
						}, -- [117]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794110,
							["arg1"] = "AleroX sucht  für BoD HC noch einige DD´s. Erfahrung sollte vorhanden sein!(mind.NHC clear) Wir selbst haben 9/9 Nhc ; 4/9 Hc down.Zuverlässigkeit setzen wir vorraus!Mi+So 19:00-22:00 Uhr.Weitere Info´s per wisper :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [118]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794112,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [119]
						{
							["clColor"] = "fffef367",
							["time"] = 1553794120,
							["arg1"] = " Die Gilde <BlackScorpion> sucht noch für den Raidkader DD,s Shadow/Eule (bevorzugt) für Daza´alor HC und kommende Raids. Raidzeiten Di/Do 19:45-22:30. Wir bieten eine angenehme Atmosphäre, hohe TS Aktivität und Myth+ . Bei Interesse /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Terayâ-Antonidas",
						}, -- [120]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794123,
							["arg1"] = "<Tötet was Trötet> BoD 9/9HC  4/9 M rekrutiert! Gesucht wird VORALLEM ein WL,. Andere Klassen sind natürlich trotzdem gern gesehen bei entsprechender Leistung! Raidzeiten Mittwoch & Sonntag 18:45 - 22 Uhr. Für weitere Fragen /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Youlica-Antonidas",
						}, -- [121]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553794139,
							["arg1"] = "Wir die Gilde \"Slytherin\" suchen für den aktuellen Content (9\\9 NHC - 3/9 HC) noch aktive Mitstreiter. Unsere Raidtage sind Donnerstag & Sonntag von 19:15- 22.00 Uhr. Sind auch gerne in M+ zusammen unterwegs. Einfach bei uns melden!",
							["arg9"] = "Trade - City",
							["arg2"] = "Tônx-Antonidas",
						}, -- [122]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794141,
							["arg1"] = "Devour Hope sucht Dich für den Raidkader und M+ zu laufen. Raidzeiten sind Donnerstag und Montag 19:30 - 22 hc u. Sonntag 18 - 22 nhc. Gern gesehen auch Anfänger und Erfahrene Spieler. Für weiter Info w/me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Wilairat-Antonidas",
						}, -- [123]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794144,
							["arg1"] = "Bestellt jetzt euer |cffffffff|Hitem:126936::::::::113:63:::1:3524:::|h[Zuckerglasiertes Fischfestmahl]|h|r vor. Jeder der vorbestellt (Lieferung ab dem 07.04.) profitiert von einem günstigen Preis. /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [124]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794147,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [125]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794148,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [126]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794171,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [127]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794197,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [128]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794198,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [129]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794204,
							["arg1"] = "Du suchst eine nette Gemeinschaft hast Interesse an Questen Myth+ oder BOD (4/9H Mo u. Mi. 19 - 23 Uhr) dann bist du bei uns richtig. Wir suchen noch für alle Bereiche und alle Klassen. TS 3 vorhanden. /w me für mehr Infos",
							["arg9"] = "Trade - City",
							["arg2"] = "Tamíflu-Antonidas",
						}, -- [130]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553794215,
							["arg1"] = "Die kürzlich gegründete Gilde <Cookie Crumbles> nimmt gerne neue Mitglieder auf. Twinks oder Mains, neue oder wiederkehrende Spieler sind willkommen. Meldet euch bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Yraell-Antonidas",
						}, -- [131]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794215,
							["arg1"] = "verkaufe |cffa335ee|Hitem:161134::::::::120:254::13::::|h[Mecha-Mogul Mk2]|h|r 320k",
							["arg9"] = "Trade - City",
							["arg2"] = "Lîîluu-Antonidas",
						}, -- [132]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794220,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [133]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794225,
							["arg1"] = "<Tötet was Trötet> BoD 9/9HC  4/9 M rekrutiert! Gesucht wird VORALLEM ein WL,. Andere Klassen sind natürlich trotzdem gern gesehen bei entsprechender Leistung! Raidzeiten Mittwoch & Sonntag 18:45 - 22 Uhr. Für weitere Fragen /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Youlica-Antonidas",
						}, -- [134]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794226,
							["arg1"] = "AleroX sucht  für BoD HC noch einige DD´s. Erfahrung sollte vorhanden sein!(mind.NHC clear) Wir selbst haben 9/9 Nhc ; 4/9 Hc down.Zuverlässigkeit setzen wir vorraus!Mi+So 19:00-22:00 Uhr.Auch nicht-Raider sind herzlich willkommen :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [135]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794247,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [136]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794247,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [137]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794250,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [138]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794260,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [139]
						{
							["clColor"] = "ff3ec5e9",
							["time"] = 1553794296,
							["arg1"] = "Die Unbeugsamen suchen zuverlässige Verstärkung für ihre HC Raids. Zeiten: Do + Mo 19:45 Uhr bis 22:30 Uhr. 6/9 HC Down. GS ab 385+. /w me oder schaut auf www.die-unbeugsamen.eu vorbei, um unser Regelwerk zu lesen und euch zu bewerben.",
							["arg9"] = "Trade - City",
							["arg2"] = "Akikyou-Antonidas",
						}, -- [140]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794346,
							["arg1"] = "Die Schwarze Festung  sucht noch nach Soldaten für die Verteidigung azeroth. Der Spaß ist in der Gilde im Vordergrund und es besteht keine Raidpflicht. Reallife geht natürlich vor.Meldet Euch bei uns,wir sind ganz schön witzig!!(Schichtarbeiter)",
							["arg9"] = "Trade - City",
							["arg2"] = "Heilpenny-Antonidas",
						}, -- [141]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794366,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [142]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794378,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [143]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794381,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [144]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794384,
							["arg1"] = "Die Gilde Alerox sucht für Ihren HC Raid (4/9) noch aktive und zuverlässiege DD´s. Unsere Raidtage sind Mi. und So. von 19 bis 22..Bei Interesse oder Fragen, einfach schreiben",
							["arg9"] = "Trade - City",
							["arg2"] = "Adrástéá-Antonidas",
						}, -- [145]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794384,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [146]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794385,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [147]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794389,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [148]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794392,
							["arg1"] = "<<<BITTERSWEET>>> 1-Tagesraid, Fr 18-24Uhr, 4/9 Mythic, sucht performancestarke und zuverlässige Spieler (Dringend gesucht: Tank, Mage)! Infos auf WoWProgress oder /w",
							["arg9"] = "Trade - City",
							["arg2"] = "Kyssu-Antonidas",
						}, -- [149]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794392,
							["arg1"] = "kennt sich jmd mit werbt einen freund aus ?",
							["arg9"] = "Trade - City",
							["arg2"] = "Cataaleyá-Antonidas",
						}, -- [150]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794393,
							["arg1"] = "AleroX sucht  für BoD HC noch einige DD´s. Erfahrung sollte vorhanden sein!(mind.NHC clear) Wir selbst haben 9/9 Nhc ; 4/9 Hc down.Zuverlässigkeit setzen wir vorraus!Mi+So 19:00-22:00 Uhr.Auch nicht-Raider sind herzlich willkommen :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [151]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794394,
							["arg1"] = "^^",
							["arg9"] = "Trade - City",
							["arg2"] = "Fantaghíró-Antonidas",
						}, -- [152]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553794401,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [153]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553794401,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [154]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794407,
							["arg1"] = "ALIRA 6/9 My: sucht weiter gute Range dds für unseren 3 Tagesraidkader (Dh auch möglich) und unseren 1 Tagesraidkader 4/9 My Fr 18:45-23:00 optional Mo 19:45 Uhr Hc. Mehr zu uns auf: https://www.alira.eu/",
							["arg9"] = "Trade - City",
							["arg2"] = "Stàrk-Antonidas",
						}, -- [155]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794451,
							["arg1"] = "<Tötet was Trötet> BoD 9/9HC  4/9 M rekrutiert! Gesucht wird VORALLEM ein WL,. Andere Klassen sind natürlich trotzdem gern gesehen bei entsprechender Leistung! Raidzeiten Mittwoch & Sonntag 18:45 - 22 Uhr. Für weitere Fragen /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Youlica-Antonidas",
						}, -- [156]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794458,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [157]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794459,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [158]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794462,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [159]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794469,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [160]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794492,
							["arg1"] = "♪ Unita Matrico sucht DD´s  für den Raid (7/9 HC down).  Raidzeiten sind Dienstags und Donnerstags 20:15 - 23 uhr. Machen auch Mythic + und anderen Quatsch. Du glaubst du passt zu uns? Melde dich! ♪",
							["arg9"] = "Trade - City",
							["arg2"] = "Yasínah-Antonidas",
						}, -- [161]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794503,
							["arg1"] = "Die Gilde \"Vetus Values\" sucht für den weiteren Ausbau aktive Spieler, denen \"die alten Tugenden\" nicht fremd sind und sich gerne über Teamspeak unterhalten. Weitere Infos über https://vetus-values.jimdofree.com",
							["arg9"] = "Trade - City",
							["arg2"] = "Aenãrion-Antonidas",
						}, -- [162]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553794526,
							["arg1"] = "suche Insel booster- günstig",
							["arg9"] = "Trade - City",
							["arg2"] = "Krümêls-Antonidas",
						}, -- [163]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553794529,
							["arg1"] = "\"FameAndGlory\" sucht aktive und nette Member für den Raid (9/9 Nhc // 3/9 Hc - Sa. & So.), M+ Dungeons und/oder für ein gemeinsames Gildenleben. Bei Interesse einfach anflüstern :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Lunarwings-Antonidas",
						}, -- [164]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794565,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [165]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794565,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [166]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794581,
							["arg1"] = "verkaufe über 300 leder greens /w me mit gebot pro stück!",
							["arg9"] = "Trade - City",
							["arg2"] = "Lèyra-Antonidas",
						}, -- [167]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794589,
							["arg1"] = "<Tötet was Trötet> BoD 9/9HC  4/9 M rekrutiert! Gesucht wird VORALLEM ein WL,. Andere Klassen sind natürlich trotzdem gern gesehen bei entsprechender Leistung! Raidzeiten Mittwoch & Sonntag 18:45 - 22 Uhr. Für weitere Fragen /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Youlica-Antonidas",
						}, -- [168]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794590,
							["arg1"] = "Biete Level 110 bis 120 Freihafen-Boost [ca. 12 Minuten pro Level ab 20k bei 70% Bonus-EXP (Erbstücke, Trank, Gem)], Level 100 bis 110 Legion-Dungeon-Boost und Insel-Cap-Boost für 7k pro Insel. 110 DH mit 264 Itemlevel. Einfach anflüstern. :]",
							["arg9"] = "Trade - City",
							["arg2"] = "Arwelda-Antonidas",
						}, -- [169]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794599,
							["arg1"] = "NARCOTIC (4/9Mythic) sucht derzeit RangeDD´s und 1Tank...Raidzeiten: Do+Di 19.30-22.30. Unsere Anforderung: GS von min 400 und eine nahezu 100%ige Anwesenheit an den Raidtagen. Bei Interesse schreib mich einfach an! ",
							["arg9"] = "Trade - City",
							["arg2"] = "Fîreflies-Antonidas",
						}, -- [170]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553794602,
							["arg1"] = "<< Blood Court sucht für den Stamm/Gilde (9/9 nHC + 8/9 HC +1/9 M), 1 Tank + 2 DD´s, Raidtage: Do/So 19:00 - 22:00. wenn du mit uns durch Dazar'alor \"stolpern\" willst, dann melde dich unter www.bloodcourt.de oder ingame >>",
							["arg9"] = "Trade - City",
							["arg2"] = "Lênovos-Antonidas",
						}, -- [171]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794604,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [172]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794604,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [173]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794608,
							["arg1"] = "Die Gilde \"Vetus Values\" sucht für den weiteren Ausbau aktive Spieler, denen \"die alten Tugenden\" nicht fremd sind und sich gerne über Teamspeak unterhalten. Weitere Infos über https://vetus-values.jimdofree.com",
							["arg9"] = "Trade - City",
							["arg2"] = "Aenãrion-Antonidas",
						}, -- [174]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553794637,
							["arg1"] = "\"FameAndGlory\" sucht aktive und nette Member für den Raid (9/9 Nhc // 3/9 Hc - Sa. & So.), M+ Dungeons und/oder für ein gemeinsames Gildenleben. Bei Interesse einfach anflüstern :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Lunarwings-Antonidas",
						}, -- [175]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794639,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [176]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794660,
							["arg1"] = "Boost Community verkauft HEUTE ab 19:00 Uhr BoD Heroisch. Armor Stacking ist optional verfügbar gegen Aufpreis. Sichert euch die Curve sowie die Chance auf 400+ Beute. Bei Interesse /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Fuyugca-Antonidas",
						}, -- [177]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794662,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [178]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794663,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [179]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794681,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [180]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794694,
							["arg1"] = "WIedereinsteiger sucht aktive hilfsbereite +18 Gilde mit Ts3",
							["arg9"] = "Trade - City",
							["arg2"] = "Suterá-Antonidas",
						}, -- [181]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794702,
							["arg1"] = "Vk über 300 BFA Leder Greens /w me mit gebot",
							["arg9"] = "Trade - City",
							["arg2"] = "Lèyra-Antonidas",
						}, -- [182]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794721,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [183]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794722,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [184]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794726,
							["arg1"] = "Keine Lust zu Questen? ziehe dich Freehold, mit Acc.Gear und Destillat der zehn Länder  25K g pro LVL",
							["arg9"] = "Trade - City",
							["arg2"] = "Wôlfsbâne-Antonidas",
						}, -- [185]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794737,
							["arg1"] = "ab wann kann mann einberufen aktiv machen",
							["arg9"] = "Trade - City",
							["arg2"] = "Julîany-Antonidas",
						}, -- [186]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794750,
							["arg1"] = "VK BfA Greens",
							["arg9"] = "Trade - City",
							["arg2"] = "Terodîl-Antonidas",
						}, -- [187]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794760,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [188]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794770,
							["arg1"] = "Boost Community verkauft HEUTE ab 19:00 Uhr BoD Heroisch. Armor Stacking ist optional verfügbar gegen Aufpreis. Sichert euch die Curve sowie die Chance auf 400+ Beute. Bei Interesse /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Fuyugca-Antonidas",
						}, -- [189]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794778,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [190]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794778,
							["arg1"] = "Seid ihr allein, Gildenlos, oder auf der Suche nach Aktivität? Letalis Venia könnte eure Chance sein Wir suchen aktive Spieler egal ob M+, Raids, BGs, oder Arena bei uns ist für jeden was dabei. TS ist für unsere Anhängerschaft auch vorhanden.",
							["arg9"] = "Trade - City",
							["arg2"] = "Etherión-Antonidas",
						}, -- [191]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794778,
							["arg1"] = "ab lvl 20",
							["arg9"] = "Trade - City",
							["arg2"] = "Lineyra-Antonidas",
						}, -- [192]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794778,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [193]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794798,
							["arg1"] = "WIedereinsteiger sucht aktive hilfsbereite +18 Gilde mit Ts3",
							["arg9"] = "Trade - City",
							["arg2"] = "Suterá-Antonidas",
						}, -- [194]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553794804,
							["arg1"] = "LuxAeterna (6/9HC 1/9M), suchen für unseren Raid noch DD´s (Schurke, Krieger, Magier) andere Klassen können sich gerne melden. Zuverlässigkeit und min. GS 390 wird vorausgesetzt. Raidzeiten: DO,SO 19:50 - 22:30. Alles weitere  /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Tnebris-Antonidas",
						}, -- [195]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794810,
							["arg1"] = "NARCOTIC (4/9Mythic) sucht derzeit RangeDD´s und 1Tank...Raidzeiten: Do+Di 19.30-22.30. Unsere Anforderung: GS von min 400 und eine nahezu 100%ige Anwesenheit an den Raidtagen. Bei Interesse schreib mich einfach an! ",
							["arg9"] = "Trade - City",
							["arg2"] = "Fîreflies-Antonidas",
						}, -- [196]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794823,
							["arg1"] = "Die Gilde <Selection> (5/9M) sucht noch gute RangeDDs und Heiler. Wir raiden Mi und Do von 19-22 Uhr. Bei Interesse schreibt mich gerne an.",
							["arg9"] = "Trade - City",
							["arg2"] = "Xulgatur-Antonidas",
						}, -- [197]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553794827,
							["arg1"] = "Die Gilde Blood Court 1/9M 8/9HC sucht verschiedene DD für HC/Mythic Raid, bei Interesse schreibt eine Bewegbung an Lênovos oder über unsere Homepage www.Bloodcourt.de Do19-22 SO19-22 Uhr",
							["arg9"] = "Trade - City",
							["arg2"] = "Líchtschwert-Antonidas",
						}, -- [198]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794834,
							["arg1"] = "Seid ihr allein, Gildenlos, oder auf der Suche nach Aktivität? Letalis Venia könnte eure Chance sein Wir suchen aktive Spieler egal ob M+, Raids, BGs, oder Arena bei uns ist für jeden was dabei. TS ist für unsere Anhängerschaft auch vorhanden.",
							["arg9"] = "Trade - City",
							["arg2"] = "Etherión-Antonidas",
						}, -- [199]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794854,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [200]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794854,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [201]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553794860,
							["arg1"] = "Die Gilde Blood Court 1/9M 8/9HC sucht verschiedene DD für HC/Mythic Raid, bei Interesse schreibt eine Bewegbung an Lênovos oder über unsere Homepage www.Bloodcourt.de Do19-22 SO19-22 Uhr",
							["arg9"] = "Trade - City",
							["arg2"] = "Líchtschwert-Antonidas",
						}, -- [202]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794865,
							["arg1"] = "Die Gilde Blood Court 9/9nhc 8/9hc, 1/9m, sucht 1 heal mit dd spec, pala/ monk und 2 dd´s, ret/ dh/ schurke/ mage/ eule. Raidtage do/so von 18.45-22.00uhr! w me oder www.bloodcourt.de",
							["arg9"] = "Trade - City",
							["arg2"] = "Springfieber-Antonidas",
						}, -- [203]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794870,
							["arg1"] = "!! EOA !! Du raidest gern  UND  machst  m+    DANN bist hier GENAU richtig !!! ALLE anderen sind auch willkommen  für mehr infos w/me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [204]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794873,
							["arg1"] = "tinkiwinkilalalpopo ",
							["arg9"] = "Trade - City",
							["arg2"] = "Hravin-Antonidas",
						}, -- [205]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794873,
							["arg1"] = "WIedereinsteiger sucht aktive hilfsbereite +18 Gilde mit Ts3",
							["arg9"] = "Trade - City",
							["arg2"] = "Suterá-Antonidas",
						}, -- [206]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794874,
							["arg1"] = "fc",
							["arg9"] = "Trade - City",
							["arg2"] = "Hravin-Antonidas",
						}, -- [207]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794900,
							["arg1"] = "Das war doch nicht falscher Chat Hravin >D",
							["arg9"] = "Trade - City",
							["arg2"] = "Havalgir-Antonidas",
						}, -- [208]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553794910,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [209]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794912,
							["arg1"] = "ok :D ",
							["arg9"] = "Trade - City",
							["arg2"] = "Hravin-Antonidas",
						}, -- [210]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794928,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [211]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794929,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [212]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1553794935,
							["arg1"] = "u i u a a ",
							["arg9"] = "Trade - City",
							["arg2"] = "Celyla-Antonidas",
						}, -- [213]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553794958,
							["arg1"] = "what is love ",
							["arg9"] = "Trade - City",
							["arg2"] = "Hravin-Antonidas",
						}, -- [214]
						{
							["clColor"] = "fffef367",
							["time"] = 1553794958,
							["arg1"] = "Die Schwarze Festung sucht neue Mitspieler. Wir sind eine familiäre Gilde mit viel TS Aktivität. Spaß und Reallife stehen an erster Stelle. Geraidet wird am Wochende auf HC sowie Normal.  M+ und ein gelegentliches Schlachtfeld gehen wir ebenfalls. ",
							["arg9"] = "Trade - City",
							["arg2"] = "Tibosa-Antonidas",
						}, -- [215]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794958,
							["arg1"] = "ALIRA  BoD 9/9HC 6/9M sucht aktuell  verstärkt nach RDD´s (Dh als Melee auch möglich).  Du solltest Leistung bringen, gut vorbereitet sein, aber auch Teamgeist haben. Interesse? Dann bewirb dich auf: https://www.alira.eu/",
							["arg9"] = "Trade - City",
							["arg2"] = "Vúltus-Antonidas",
						}, -- [216]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553794959,
							["arg1"] = "LFM BoD Myth 1. Boss / 1 Tank / Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [217]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553794978,
							["arg1"] = "vk |cffa335ee|Hitem:165518::::::::120:70::3:3:4798:1512:4783:::|h[Hüftgurt aus Kriegsbestienhaut]|h|r w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Dodü-Antonidas",
						}, -- [218]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553794981,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [219]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794992,
							["arg1"] = "Die Gilde <Verrottet und Vergeht> (4/9H) sucht zum Ausbau ihres Raidkaders noch DDs aller Art! Bevorzugt Mönche und Hexer  Unsere Raidtage sind Donnerstag und Sonntag 19:30-22:30. Euch erwartet ein reges Gildenleben und ein aktiver Gildendiscord.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [220]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553794995,
							["arg1"] = "Wer Lust hat mitzumachen, meldet sich einfach bei mir.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leeara-Antonidas",
						}, -- [221]
						{
							["clColor"] = "ff00fe95",
							["time"] = 1553795010,
							["arg1"] = "WIedereinsteiger sucht aktive hilfsbereite +18 Gilde mit Ts3",
							["arg9"] = "Trade - City",
							["arg2"] = "Dryas-Antonidas",
						}, -- [222]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795015,
							["arg1"] = "what a jaka ",
							["arg9"] = "Trade - City",
							["arg2"] = "Hravin-Antonidas",
						}, -- [223]
						{
							["clColor"] = "fffef367",
							["time"] = 1553795016,
							["arg1"] = "suche guten schurken für eine gear frage",
							["arg9"] = "Trade - City",
							["arg2"] = "Alyé-Antonidas",
						}, -- [224]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553795043,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [225]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553795044,
							["arg1"] = "LFM BoD Myth 1. Boss /1 tank/ Link",
							["arg9"] = "Trade - City",
							["arg2"] = "Vuxxsclap-Antonidas",
						}, -- [226]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553795057,
							["arg1"] = "ALIRA 6/9 My: sucht weiter gute Range dds für unseren 3 Tagesraidkader (Dh auch möglich) und unseren 1 Tagesraidkader 4/9 My Fr 18:45-23:00 optional Mo 19:45 Uhr Hc. Mehr zu uns auf: https://www.alira.eu/",
							["arg9"] = "Trade - City",
							["arg2"] = "Stàrk-Antonidas",
						}, -- [227]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795067,
							["arg1"] = "frog ich bin schurke ... lasst uns feischen wir piraten aarrrrr ",
							["arg9"] = "Trade - City",
							["arg2"] = "Hravin-Antonidas",
						}, -- [228]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553795069,
							["arg1"] = "Die Gilde <Selection> (5/9M) sucht noch gute RangeDDs und Heiler. Wir raiden Mi und Do von 19-22 Uhr. Bei Interesse schreibt mich gerne an.",
							["arg9"] = "Trade - City",
							["arg2"] = "Xulgatur-Antonidas",
						}, -- [229]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795096,
							["arg1"] = "vk |cffa335ee|Hitem:161134::::::::120:577::13::::|h[Mecha-Mogul Mk2]|h|r 300k",
							["arg9"] = "Trade - City",
							["arg2"] = "Chatic-Antonidas",
						}, -- [230]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553795114,
							["arg1"] = "Die Nachtraid-Gilde “Blutmønd” sucht zur Aufstockung ihres Hero Raidkaders 7/9 down 1 Tank und 1 Heal. Du solltest engagiert und vor allem zuverlässig sein. Raidzeiten sind Di. und Do. || 22:30 Uhr - 0:30 Uhr. /w me bei Interesse",
							["arg9"] = "Trade - City",
							["arg2"] = "Elkarachò-Antonidas",
						}, -- [231]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553795130,
							["arg1"] = "!! EOA !! Du raidest gern  UND  machst  m+    DANN bist hier GENAU richtig !!! ALLE anderen sind auch willkommen  für mehr infos w/me ",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [232]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553795148,
							["arg1"] = "<Wrapped in Fog> (9/9 NHC 9/9 HC) sucht für den Raid ehrgeizige und zuverlässige Spieler. Gesucht: DD´s. Raidtage: Mi & Mo 19:15 - 22.30 Uhr. Bei Interesse /w me.",
							["arg9"] = "Trade - City",
							["arg2"] = "Lillijane-Antonidas",
						}, -- [233]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553795155,
							["arg1"] = "mit wem hab ich gerade geschireben? hatte nen dc xD",
							["arg9"] = "Trade - City",
							["arg2"] = "Yillaria-Antonidas",
						}, -- [234]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553795167,
							["arg1"] = "NARCOTIC (4/9Mythic) sucht derzeit RangeDD´s und 1Tank...Raidzeiten: Do+Di 19.30-22.30. Unsere Anforderung: GS von min 400 und eine nahezu 100%ige Anwesenheit an den Raidtagen. Bei Interesse schreib mich einfach an! ",
							["arg9"] = "Trade - City",
							["arg2"] = "Fîreflies-Antonidas",
						}, -- [235]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553795172,
							["arg1"] = "Vk boa greens 12 stück ",
							["arg9"] = "Trade - City",
							["arg2"] = "Quelta-Antonidas",
						}, -- [236]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795177,
							["arg1"] = "<Tempest Legends> , 6/9 HC BoD noch ",
							["arg9"] = "Trade - City",
							["arg2"] = "Juubeí-Antonidas",
						}, -- [237]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795177,
							["arg1"] = "DD's jeglicher Art. Raidzeiten Do/Mo 19:30-22 Uhr. Bei Interesse /w me",
							["arg9"] = "Trade - City",
							["arg2"] = "Juubeí-Antonidas",
						}, -- [238]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553795225,
							["arg1"] = "Wir die Gilde \"FameAndGlory\"suchen noch Aktive Member für unseren Raid Nhc 9/9 Hc3/9.  Raidtage wären Samstag 20-22uhr Sonntag 18-21uhr.",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [239]
						{
							["clColor"] = "fffe7b09",
							["time"] = 1553795225,
							["arg1"] = "Wir sind eine Arbeiter Gilde daher sind Schichtarbeiter kein Problem. w/me bei Interesse :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Leslíe-Antonidas",
						}, -- [240]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795232,
							["arg1"] = "Wir die\" Geistheiler Ehrfûrchtig\" suchen aktive Mitglieder für Spiel, Spaß und Spannung...Und natürlich Raids! (9/9nHc; 7/9Hc) Unsere Raidtage sind Montag und Mittwoch von 20:00-23:00 Uhr. Wenn wir Dein Interesse geweckt haben, melde dich bei uns!",
							["arg9"] = "Trade - City",
							["arg2"] = "Vaanth-Antonidas",
						}, -- [241]
						{
							["clColor"] = "ffa9d271",
							["time"] = 1553795250,
							["arg1"] = " <<<<< SELLRUN HC 100% Safe und Schnell >>>>> Sway (6/9 Mythic) verkauft HEUTE um 20 Uhr Schlacht um Dazar'Alor 9/9 HC , ihr bekommt die Heldentat \"Der Zeit voraus: Lady Jaina Proudmoore\" sowie jeglichen Loot den wir nicht brauchen. PM für Fragen",
							["arg9"] = "Trade - City",
							["arg2"] = "Melliná-Antonidas",
						}, -- [242]
						{
							["clColor"] = "ff006fdc",
							["time"] = 1553795272,
							["arg1"] = "Die Gilde \"Cervisia\" sucht für interne Nhc und später HC Raids (Do 20-22 und So 19:30 - 22 derzeit 5/9) noch DD's. (Mage, Moonkin, Melees) /w me für Infos",
							["arg9"] = "Trade - City",
							["arg2"] = "Mùgen-Antonidas",
						}, -- [243]
						{
							["clColor"] = "ffc59a6c",
							["time"] = 1553795277,
							["arg1"] = "!!!EOA!!! sucht  für ihren stamm HC trupp noch verstärkung W me für infos  danke",
							["arg9"] = "Trade - City",
							["arg2"] = "Dabest-Antonidas",
						}, -- [244]
						{
							["clColor"] = "fffefefe",
							["time"] = 1553795281,
							["arg1"] = "<Oblivion Boost Community> verkauft BoD Heroic 9/9 und Jaina Hc! Unsere Booster haben keine ID und verrollen den gesamten Loot an euch! M+ 10-15 garantiert INTIME / PvP (2er, 3er, RBG) / Mounts / LvL 110-120 und vieles mehr! Interesse? /w me :)",
							["arg9"] = "Trade - City",
							["arg2"] = "Cadimara-Antonidas",
						}, -- [245]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1553795288,
							["arg1"] = "Keine Lust zu Questen? ziehe dich Freehold, mit Acc.Gear und Destillat der zehn Länder  25K g pro LVL",
							["arg9"] = "Trade - City",
							["arg2"] = "Wôlfsbâne-Antonidas",
						}, -- [246]
						{
							["arg1"] = " ",
						}, -- [247]
						{
							["arg1"] = " ",
						}, -- [248]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [249]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [250]
					},
				},
				["localdefense"] = {
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "Local defense",
					["logs"] = {
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [1]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [2]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [3]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [4]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [5]
						{
							["arg1"] = " ",
						}, -- [6]
						{
							["arg1"] = " ",
						}, -- [7]
						{
							["arg1"] = "Logging started on 03/13/2019 at 12:23:08.",
							["type"] = "SYSTEM",
						}, -- [8]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [9]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [10]
						{
							["arg1"] = " ",
						}, -- [11]
						{
							["arg1"] = " ",
						}, -- [12]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 12:53:51.",
						}, -- [13]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [14]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [15]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [16]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [17]
						{
							["arg1"] = " ",
						}, -- [18]
						{
							["arg1"] = " ",
						}, -- [19]
						{
							["arg1"] = "Logging started on 03/13/2019 at 13:26:12.",
							["type"] = "SYSTEM",
						}, -- [20]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [21]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [22]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [23]
						{
							["arg1"] = " ",
						}, -- [24]
						{
							["arg1"] = " ",
						}, -- [25]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 14:04:30.",
						}, -- [26]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [27]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [28]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [29]
						{
							["arg9"] = "LocalDefense - Tiragarde Sound",
							["time"] = 1552491623,
							["arg1"] = "|cffffff00Bridgeport is under attack!|r",
						}, -- [30]
						{
							["arg1"] = " ",
						}, -- [31]
						{
							["arg1"] = " ",
						}, -- [32]
						{
							["arg1"] = "Logging started on 03/13/2019 at 16:52:38.",
							["type"] = "SYSTEM",
						}, -- [33]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [34]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [35]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [36]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [37]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [38]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [39]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [40]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [41]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [42]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [43]
						{
							["arg1"] = " ",
						}, -- [44]
						{
							["arg1"] = " ",
						}, -- [45]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/14/2019 at 14:09:21.",
						}, -- [46]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [47]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [48]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [49]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [50]
						{
							["arg9"] = "LocalDefense - Stormsong Valley",
							["time"] = 1552570066,
							["arg1"] = "|cffffff00Seekers' Vista is under attack!|r",
						}, -- [51]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [52]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [53]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [54]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [55]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [56]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [57]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [58]
						{
							["arg1"] = " ",
						}, -- [59]
						{
							["arg1"] = " ",
						}, -- [60]
						{
							["arg1"] = "Logging started on 03/17/2019 at 16:23:12.",
							["type"] = "SYSTEM",
						}, -- [61]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [62]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [63]
						{
							["arg1"] = " ",
						}, -- [64]
						{
							["arg1"] = " ",
						}, -- [65]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/17/2019 at 18:15:38.",
						}, -- [66]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [67]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [68]
						{
							["arg1"] = " ",
						}, -- [69]
						{
							["arg1"] = " ",
						}, -- [70]
						{
							["arg1"] = "Logging started on 03/19/2019 at 16:01:28.",
							["type"] = "SYSTEM",
						}, -- [71]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [72]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [73]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [74]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [75]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [76]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [77]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [78]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [79]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [80]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [81]
						{
							["arg1"] = " ",
						}, -- [82]
						{
							["arg1"] = " ",
						}, -- [83]
						{
							["arg1"] = "Logging started on 03/19/2019 at 20:39:44.",
							["type"] = "SYSTEM",
						}, -- [84]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [85]
						{
							["arg1"] = " ",
						}, -- [86]
						{
							["arg1"] = " ",
						}, -- [87]
						{
							["arg1"] = "Logging started on 03/20/2019 at 09:57:36.",
							["type"] = "SYSTEM",
						}, -- [88]
						{
							["time"] = 1553072399,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [89]
						{
							["time"] = 1553072474,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [90]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [91]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [92]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [93]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [94]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [95]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [96]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [97]
						{
							["arg1"] = " ",
						}, -- [98]
						{
							["arg1"] = " ",
						}, -- [99]
						{
							["arg1"] = "Logging started on 03/20/2019 at 11:22:30.",
							["type"] = "SYSTEM",
						}, -- [100]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [101]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [102]
						{
							["time"] = 1553077806,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [103]
						{
							["time"] = 1553079164,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [104]
						{
							["time"] = 1553079263,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [105]
						{
							["time"] = 1553079323,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [106]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [107]
						{
							["time"] = 1553079384,
							["arg9"] = "LocalDefense - Tiragarde Sound",
							["arg1"] = "|cffffff00Mariner's Row is under attack!|r",
						}, -- [108]
						{
							["time"] = 1553079434,
							["arg9"] = "LocalDefense - Tiragarde Sound",
							["arg1"] = "|cffffff00Greystone Keep is under attack!|r",
						}, -- [109]
						{
							["time"] = 1553079460,
							["arg9"] = "LocalDefense - Tiragarde Sound",
							["arg1"] = "|cffffff00Mariner's Row is under attack!|r",
						}, -- [110]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [111]
						{
							["time"] = 1553081584,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [112]
						{
							["time"] = 1553081646,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [113]
						{
							["time"] = 1553081706,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [114]
						{
							["time"] = 1553081917,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [115]
						{
							["time"] = 1553082006,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [116]
						{
							["time"] = 1553082069,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [117]
						{
							["time"] = 1553082139,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [118]
						{
							["time"] = 1553082202,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [119]
						{
							["time"] = 1553082293,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [120]
						{
							["time"] = 1553082534,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [121]
						{
							["time"] = 1553082614,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [122]
						{
							["time"] = 1553082802,
							["arg9"] = "LocalDefense - Boralus Harbor",
							["arg1"] = "|cffffff00Boralus Harbor is under attack!|r",
						}, -- [123]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [124]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [125]
						{
							["arg1"] = " ",
						}, -- [126]
						{
							["arg1"] = " ",
						}, -- [127]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/20/2019 at 21:22:54.",
						}, -- [128]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [129]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [130]
						{
							["arg1"] = " ",
						}, -- [131]
						{
							["arg1"] = " ",
						}, -- [132]
						{
							["arg1"] = "Logging started on 03/24/2019 at 20:43:07.",
							["type"] = "SYSTEM",
						}, -- [133]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [134]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [135]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [136]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [137]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [138]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [139]
						{
							["arg1"] = " ",
						}, -- [140]
						{
							["arg1"] = " ",
						}, -- [141]
						{
							["arg1"] = "Logging started on 03/25/2019 at 12:16:35.",
							["type"] = "SYSTEM",
						}, -- [142]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [143]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [144]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [145]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [146]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [147]
						{
							["time"] = 1553516774,
							["arg9"] = "LocalDefense - Drustvar",
							["arg1"] = "|cffffff00Whitegrove Chapel is under attack!|r",
						}, -- [148]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [149]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [150]
						{
							["arg1"] = " ",
						}, -- [151]
						{
							["arg1"] = " ",
						}, -- [152]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/25/2019 at 14:01:13.",
						}, -- [153]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [154]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [155]
						{
							["arg1"] = " ",
						}, -- [156]
						{
							["arg1"] = " ",
						}, -- [157]
						{
							["arg1"] = "Logging started on 03/25/2019 at 15:41:04.",
							["type"] = "SYSTEM",
						}, -- [158]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [159]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [160]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [161]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [162]
						{
							["arg1"] = " ",
						}, -- [163]
						{
							["arg1"] = " ",
						}, -- [164]
						{
							["arg1"] = "Logging started on 03/26/2019 at 18:41:45.",
							["type"] = "SYSTEM",
						}, -- [165]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [166]
						{
							["arg1"] = " ",
						}, -- [167]
						{
							["arg1"] = " ",
						}, -- [168]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:48:48.",
						}, -- [169]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [170]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [171]
						{
							["arg1"] = " ",
						}, -- [172]
						{
							["arg1"] = " ",
						}, -- [173]
						{
							["arg1"] = "Logging started on 03/27/2019 at 10:46:09.",
							["type"] = "SYSTEM",
						}, -- [174]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [175]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [176]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [177]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [178]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [179]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [180]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [181]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [182]
						{
							["arg1"] = " ",
						}, -- [183]
						{
							["arg1"] = " ",
						}, -- [184]
						{
							["arg1"] = "Logging started on 03/27/2019 at 12:10:34.",
							["type"] = "SYSTEM",
						}, -- [185]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [186]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [187]
						{
							["arg1"] = " ",
						}, -- [188]
						{
							["arg1"] = " ",
						}, -- [189]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 13:55:25.",
						}, -- [190]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [191]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [192]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [193]
						{
							["arg1"] = " ",
						}, -- [194]
						{
							["arg1"] = " ",
						}, -- [195]
						{
							["arg1"] = "Logging started on 03/27/2019 at 18:22:22.",
							["type"] = "SYSTEM",
						}, -- [196]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [197]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [198]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [199]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [200]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [201]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [202]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [203]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [204]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [205]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [206]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [207]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [208]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [209]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [210]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [211]
						{
							["arg1"] = " ",
						}, -- [212]
						{
							["arg1"] = " ",
						}, -- [213]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 22:37:44.",
						}, -- [214]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [215]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [216]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [217]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [218]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [219]
						{
							["arg9"] = "LocalDefense - Drustvar",
							["time"] = 1553727276,
							["arg1"] = "|cffffff00Anyport is under attack!|r",
						}, -- [220]
						{
							["arg1"] = " ",
						}, -- [221]
						{
							["arg1"] = " ",
						}, -- [222]
						{
							["arg1"] = "Logging started on 03/28/2019 at 00:02:53.",
							["type"] = "SYSTEM",
						}, -- [223]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [224]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [225]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [226]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [227]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [228]
						{
							["arg1"] = " ",
						}, -- [229]
						{
							["arg1"] = " ",
						}, -- [230]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [231]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [232]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [233]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [234]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [235]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [236]
						{
							["arg1"] = " ",
						}, -- [237]
						{
							["arg1"] = " ",
						}, -- [238]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [239]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [240]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [241]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [242]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [243]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [244]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [245]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [246]
						{
							["arg1"] = " ",
						}, -- [247]
						{
							["arg1"] = " ",
						}, -- [248]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [249]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [250]
					},
				},
				["lookingforgroup"] = {
					["enabled"] = true,
					["name"] = "Looking for group",
					["logs"] = {
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [1]
					},
				},
				["elvuigvc"] = {
					["enabled"] = true,
					["hasMessage"] = true,
					["name"] = "ElvUIGVC",
					["logs"] = {
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/12/2019 at 13:26:50.",
						}, -- [1]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [2]
						{
							["arg1"] = " ",
						}, -- [3]
						{
							["arg1"] = " ",
						}, -- [4]
						{
							["arg1"] = "Logging started on 03/12/2019 at 14:46:43.",
							["type"] = "SYSTEM",
						}, -- [5]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [6]
						{
							["arg1"] = " ",
						}, -- [7]
						{
							["arg1"] = " ",
						}, -- [8]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/12/2019 at 16:58:31.",
						}, -- [9]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [10]
						{
							["arg1"] = " ",
						}, -- [11]
						{
							["arg1"] = " ",
						}, -- [12]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/12/2019 at 18:48:25.",
						}, -- [13]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [14]
						{
							["clColor"] = "ffff7c0a",
							["time"] = 1552418843,
							["arg1"] = "LFM |cffffff00|Hquest:52163:-1:120:120:0|h[Der geflügelte Taifun]|h|r WQ - flüstere mir \"wq\" für eine Einladung! (World Quest Party)",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Kedouh-Antonidas",
						}, -- [15]
						{
							["arg1"] = " ",
						}, -- [16]
						{
							["arg1"] = " ",
						}, -- [17]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/12/2019 at 22:13:40.",
						}, -- [18]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [19]
						{
							["arg1"] = " ",
						}, -- [20]
						{
							["arg1"] = " ",
						}, -- [21]
						{
							["arg1"] = "Logging started on 03/12/2019 at 23:09:04.",
							["type"] = "SYSTEM",
						}, -- [22]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [23]
						{
							["arg1"] = " ",
						}, -- [24]
						{
							["arg1"] = " ",
						}, -- [25]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/12/2019 at 23:44:25.",
						}, -- [26]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [27]
						{
							["arg1"] = " ",
						}, -- [28]
						{
							["arg1"] = " ",
						}, -- [29]
						{
							["arg1"] = "Logging started on 03/13/2019 at 00:46:57.",
							["type"] = "SYSTEM",
						}, -- [30]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [31]
						{
							["arg1"] = " ",
						}, -- [32]
						{
							["arg1"] = " ",
						}, -- [33]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 11:38:45.",
						}, -- [34]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [35]
						{
							["arg1"] = " ",
						}, -- [36]
						{
							["arg1"] = " ",
						}, -- [37]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 11:51:32.",
						}, -- [38]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [39]
						{
							["arg1"] = " ",
						}, -- [40]
						{
							["arg1"] = " ",
						}, -- [41]
						{
							["arg1"] = "Logging started on 03/13/2019 at 12:20:20.",
							["type"] = "SYSTEM",
						}, -- [42]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [43]
						{
							["arg1"] = " ",
						}, -- [44]
						{
							["arg1"] = " ",
						}, -- [45]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 12:53:51.",
						}, -- [46]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [47]
						{
							["arg1"] = " ",
						}, -- [48]
						{
							["arg1"] = " ",
						}, -- [49]
						{
							["arg1"] = "Logging started on 03/13/2019 at 13:26:12.",
							["type"] = "SYSTEM",
						}, -- [50]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [51]
						{
							["arg1"] = " ",
						}, -- [52]
						{
							["arg1"] = " ",
						}, -- [53]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/13/2019 at 14:04:30.",
						}, -- [54]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552490832,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider.Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt;auch Anfänger und Wiedereinsteiger gern gesehen. Mit Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [55]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552490953,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [56]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552491073,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [57]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552491198,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [58]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552491318,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [59]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552491442,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [60]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552491562,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [61]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552492282,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [62]
						{
							["arg1"] = " ",
						}, -- [63]
						{
							["arg1"] = " ",
						}, -- [64]
						{
							["arg1"] = "Logging started on 03/13/2019 at 16:52:38.",
							["type"] = "SYSTEM",
						}, -- [65]
						{
							["clColor"] = "ffa22fc8",
							["time"] = 1552492405,
							["arg1"] = "Wir, die Gilde InPânic,suchen für unseren aktuellen HC Content(4/9 HC) noch zuverlässige Raider, bevorzugt Range DD´s .Mi+Do 20.15-23.00 Fr optional Twinkraid.Für den HC content 380+angelegt, Wir nutzen ausschließlich Discord",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Lilliyane-Antonidas",
						}, -- [66]
						{
							["arg1"] = " ",
						}, -- [67]
						{
							["arg1"] = " ",
						}, -- [68]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/14/2019 at 13:37:48.",
						}, -- [69]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [70]
						{
							["arg1"] = " ",
						}, -- [71]
						{
							["arg1"] = " ",
						}, -- [72]
						{
							["arg1"] = "Logging started on 03/14/2019 at 14:06:40.",
							["type"] = "SYSTEM",
						}, -- [73]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [74]
						{
							["arg1"] = " ",
						}, -- [75]
						{
							["arg1"] = " ",
						}, -- [76]
						{
							["arg1"] = "Logging started on 03/15/2019 at 22:25:20.",
							["type"] = "SYSTEM",
						}, -- [77]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [78]
						{
							["arg1"] = " ",
						}, -- [79]
						{
							["arg1"] = " ",
						}, -- [80]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/16/2019 at 14:56:52.",
						}, -- [81]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [82]
						{
							["arg1"] = " ",
						}, -- [83]
						{
							["arg1"] = " ",
						}, -- [84]
						{
							["arg1"] = "Logging started on 03/17/2019 at 16:23:12.",
							["type"] = "SYSTEM",
						}, -- [85]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [86]
						{
							["arg1"] = " ",
						}, -- [87]
						{
							["arg1"] = " ",
						}, -- [88]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/17/2019 at 18:15:38.",
						}, -- [89]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [90]
						{
							["clColor"] = "ff8686ec",
							["time"] = 1552844609,
							["arg1"] = "liksasa",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Socie-Antonidas",
						}, -- [91]
						{
							["arg1"] = " ",
						}, -- [92]
						{
							["arg1"] = " ",
						}, -- [93]
						{
							["arg1"] = "Logging started on 03/19/2019 at 16:01:28.",
							["type"] = "SYSTEM",
						}, -- [94]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [95]
						{
							["arg1"] = " ",
						}, -- [96]
						{
							["arg1"] = " ",
						}, -- [97]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/19/2019 at 20:19:23.",
						}, -- [98]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [99]
						{
							["arg1"] = " ",
						}, -- [100]
						{
							["arg1"] = " ",
						}, -- [101]
						{
							["arg1"] = "Logging started on 03/19/2019 at 20:39:44.",
							["type"] = "SYSTEM",
						}, -- [102]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [103]
						{
							["arg1"] = " ",
						}, -- [104]
						{
							["arg1"] = " ",
						}, -- [105]
						{
							["arg1"] = "Logging started on 03/20/2019 at 09:57:36.",
							["type"] = "SYSTEM",
						}, -- [106]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [107]
						{
							["arg1"] = " ",
						}, -- [108]
						{
							["arg1"] = " ",
						}, -- [109]
						{
							["arg1"] = "Logging started on 03/20/2019 at 11:22:30.",
							["type"] = "SYSTEM",
						}, -- [110]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [111]
						{
							["arg1"] = " ",
						}, -- [112]
						{
							["arg1"] = " ",
						}, -- [113]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/20/2019 at 21:22:54.",
						}, -- [114]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [115]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553116448,
							["arg1"] = "Die Gilde Phrasing (6/11m, Mi u. So. 18:30-22:30) sucht zur Verstärkung des Raidkaders noch aktive und zuverlässige Spieler! Aktuell benötigen wir 2 DDs einer mit Tankspecc (Warri, Hunter) und einen Heal (Monk,Diszi). Du hast Interesse dann /w me ",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Yahoel-Antonidas",
						}, -- [116]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553116451,
							["arg1"] = "Die Gilde Phrasing (6/11m, Mi u. So. 18:30-22:30) sucht zur Verstärkung des Raidkaders noch aktive und zuverlässige Spieler! Aktuell benötigen wir 2 DDs einer mit Tankspecc (Warri, Hunter) und einen Heal (Monk,Diszi). Du hast Interesse dann /w me ",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Yahoel-Antonidas",
						}, -- [117]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553116491,
							["arg1"] = "Die Gilde Phrasing (6/11m, Mi u. So. 18:30-22:30) sucht zur Verstärkung des Raidkaders noch aktive und zuverlässige Spieler! Aktuell benötigen wir 2 DDs einer mit Tankspecc (Warri, Hunter) und einen Heal (Monk,Diszi). Du hast Interesse dann /w me ",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Yahoel-Antonidas",
						}, -- [118]
						{
							["arg1"] = " ",
						}, -- [119]
						{
							["arg1"] = " ",
						}, -- [120]
						{
							["arg1"] = "Logging started on 03/21/2019 at 11:21:20.",
							["type"] = "SYSTEM",
						}, -- [121]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [122]
						{
							["arg1"] = " ",
						}, -- [123]
						{
							["arg1"] = " ",
						}, -- [124]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/21/2019 at 11:58:29.",
						}, -- [125]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [126]
						{
							["arg1"] = " ",
						}, -- [127]
						{
							["arg1"] = " ",
						}, -- [128]
						{
							["arg1"] = "Logging started on 03/23/2019 at 13:26:33.",
							["type"] = "SYSTEM",
						}, -- [129]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [130]
						{
							["arg1"] = " ",
						}, -- [131]
						{
							["arg1"] = " ",
						}, -- [132]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/24/2019 at 19:32:10.",
						}, -- [133]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [134]
						{
							["arg1"] = " ",
						}, -- [135]
						{
							["arg1"] = " ",
						}, -- [136]
						{
							["arg1"] = "Logging started on 03/24/2019 at 20:43:07.",
							["type"] = "SYSTEM",
						}, -- [137]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [138]
						{
							["arg1"] = " ",
						}, -- [139]
						{
							["arg1"] = " ",
						}, -- [140]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/24/2019 at 21:41:40.",
						}, -- [141]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [142]
						{
							["arg1"] = " ",
						}, -- [143]
						{
							["arg1"] = " ",
						}, -- [144]
						{
							["arg1"] = "Logging started on 03/25/2019 at 12:16:35.",
							["type"] = "SYSTEM",
						}, -- [145]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [146]
						{
							["arg1"] = " ",
						}, -- [147]
						{
							["arg1"] = " ",
						}, -- [148]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/25/2019 at 14:01:13.",
						}, -- [149]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [150]
						{
							["arg1"] = " ",
						}, -- [151]
						{
							["arg1"] = " ",
						}, -- [152]
						{
							["arg1"] = "Logging started on 03/25/2019 at 15:41:04.",
							["type"] = "SYSTEM",
						}, -- [153]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [154]
						{
							["arg1"] = " ",
						}, -- [155]
						{
							["arg1"] = " ",
						}, -- [156]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/26/2019 at 18:15:18.",
						}, -- [157]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [158]
						{
							["arg1"] = " ",
						}, -- [159]
						{
							["arg1"] = " ",
						}, -- [160]
						{
							["arg1"] = "Logging started on 03/26/2019 at 18:41:45.",
							["type"] = "SYSTEM",
						}, -- [161]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [162]
						{
							["arg1"] = " ",
						}, -- [163]
						{
							["arg1"] = " ",
						}, -- [164]
						{
							["arg1"] = "Logging started on 03/27/2019 at 10:46:09.",
							["type"] = "SYSTEM",
						}, -- [165]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [166]
						{
							["arg1"] = " ",
						}, -- [167]
						{
							["arg1"] = " ",
						}, -- [168]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 12:09:01.",
						}, -- [169]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [170]
						{
							["arg1"] = " ",
						}, -- [171]
						{
							["arg1"] = " ",
						}, -- [172]
						{
							["arg1"] = "Logging started on 03/27/2019 at 12:10:34.",
							["type"] = "SYSTEM",
						}, -- [173]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [174]
						{
							["arg1"] = " ",
						}, -- [175]
						{
							["arg1"] = " ",
						}, -- [176]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 13:55:25.",
						}, -- [177]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [178]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553699395,
							["arg1"] = " N O X  Familien u Schichtarbeiter-freundliche Hc Raidgilde *nhc 9/9 Hc 2/9*, aktuell suchen wir DD´s. Raidtage Sa und So von 19.00 bis 22.00. MFG ",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Liãn-Antonidas",
						}, -- [179]
						{
							["arg1"] = " ",
						}, -- [180]
						{
							["arg1"] = " ",
						}, -- [181]
						{
							["arg1"] = "Logging started on 03/27/2019 at 16:55:40.",
							["type"] = "SYSTEM",
						}, -- [182]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [183]
						{
							["arg1"] = " ",
						}, -- [184]
						{
							["arg1"] = " ",
						}, -- [185]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/27/2019 at 17:44:05.",
						}, -- [186]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [187]
						{
							["arg1"] = " ",
						}, -- [188]
						{
							["arg1"] = " ",
						}, -- [189]
						{
							["arg1"] = "Logging started on 03/27/2019 at 18:22:22.",
							["type"] = "SYSTEM",
						}, -- [190]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [191]
						{
							["clColor"] = "ffc31d39",
							["time"] = 1553708893,
							["arg1"] = "Die Gilde <Selection> (5/9M) sucht noch gute RangeDDs und Heiler. Wir raiden Mi und Do von 19-22 Uhr. Bei Interesse schreibt mich gerne an.",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Zakaron-Antonidas",
						}, -- [192]
						{
							["clColor"] = "fff38bb9",
							["time"] = 1553716099,
							["arg1"] = "M+2k Team verkauft jetzt nen 10er Key intime - jeglicher Loot, der nicht gebraucht wird, geht an Euch /w me :)",
							["arg9"] = "ElvUIGVC",
							["arg2"] = "Kaloqp-Antonidas",
						}, -- [193]
						{
							["arg1"] = " ",
						}, -- [194]
						{
							["arg1"] = " ",
						}, -- [195]
						{
							["arg1"] = "Logging started on 03/28/2019 at 00:02:53.",
							["type"] = "SYSTEM",
						}, -- [196]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [197]
						{
							["arg1"] = " ",
						}, -- [198]
						{
							["arg1"] = " ",
						}, -- [199]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 10:27:05.",
						}, -- [200]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [201]
						{
							["arg1"] = " ",
						}, -- [202]
						{
							["arg1"] = " ",
						}, -- [203]
						{
							["arg1"] = "Logging started on 03/28/2019 at 13:06:47.",
							["type"] = "SYSTEM",
						}, -- [204]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [205]
						{
							["arg1"] = " ",
						}, -- [206]
						{
							["arg1"] = " ",
						}, -- [207]
						{
							["type"] = "SYSTEM",
							["arg1"] = "Logging started on 03/28/2019 at 17:07:09.",
						}, -- [208]
						{
							["type"] = "SYSTEM",
							["arg1"] = "You joined channel.",
						}, -- [209]
						{
							["arg1"] = " ",
						}, -- [210]
						{
							["arg1"] = " ",
						}, -- [211]
						{
							["arg1"] = "Logging started on 03/28/2019 at 18:49:15.",
							["type"] = "SYSTEM",
						}, -- [212]
						{
							["arg1"] = "You joined channel.",
							["type"] = "SYSTEM",
						}, -- [213]
					},
				},
			},
			["currentlogindex"] = 3,
		},
	},
}
