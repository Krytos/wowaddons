
ElvDB = {
	["profileKeys"] = {
		["Artèmis - Antonidas"] = "BM",
		["Arthemias - Blackmoore"] = "BM",
		["Asdasfadfsaf - Blackmoore"] = "Asdasfadfsaf - Blackmoore",
		["Nexana - Blackmoore"] = "Shadow",
		["Nethenâ - Blackmoore"] = "Prot",
		["Nariâ - Blackmoore"] = "Nariâ - Blackmoore",
		["Noxiâ - Antonidas"] = "Nariâ - Blackmoore",
		["Asdafggdaf - Blackmoore"] = "Default DPS",
		["Krytosbank - Blackmoore"] = "Default DPS",
		["Arthemiasd - Ravencrest"] = "Arthemiasd - Ravencrest",
		["Neaxa - Blackmoore"] = "Neaxa - Blackmoore",
	},
	["gold"] = {
		["Ravencrest"] = {
			["Arthemiasd"] = 0,
		},
		["Antonidas"] = {
			["Noxiâ"] = 195081149,
			["Artèmis"] = 1404941932,
		},
		["Blackmoore"] = {
			["Nethenâ"] = 12044696,
			["Nexana"] = 19657724,
			["Krytosbank"] = 62735253,
			["Asdafggdaf"] = 0,
			["Asdasfadfsaf"] = 0,
			["Neaxa"] = 47197000,
			["Arthemias"] = 818212936,
			["Nariâ"] = 317595945,
		},
	},
	["namespaces"] = {
		["LibDualSpec-1.0"] = {
			["char"] = {
				["Nethenâ - Blackmoore"] = {
					"Arms", -- [1]
					"Fury", -- [2]
					"Prot", -- [3]
					["enabled"] = true,
				},
				["Artèmis - Antonidas"] = {
					"BM", -- [1]
					"MM", -- [2]
					"Surv", -- [3]
					["enabled"] = true,
				},
				["Arthemias - Blackmoore"] = {
					"BM", -- [1]
					"MM", -- [2]
					"Surv", -- [3]
					["enabled"] = true,
				},
				["Noxiâ - Antonidas"] = {
					["enabled"] = false,
				},
				["Nexana - Blackmoore"] = {
					"Diszi", -- [1]
					"Holy Priest", -- [2]
					"Shadow", -- [3]
					["enabled"] = true,
				},
			},
		},
	},
	["class"] = {
		["Ravencrest"] = {
			["Arthemiasd"] = "PRIEST",
		},
		["Antonidas"] = {
			["Noxiâ"] = "ROGUE",
			["Artèmis"] = "HUNTER",
		},
		["Blackmoore"] = {
			["Nethenâ"] = "WARRIOR",
			["Krytosbank"] = "MONK",
			["Nexana"] = "PRIEST",
			["Neaxa"] = "MAGE",
			["Arthemias"] = "HUNTER",
			["Nariâ"] = "ROGUE",
		},
	},
	["global"] = {
		["nameplate"] = {
			["filters"] = {
				["Boss"] = {
					["actions"] = {
						["texture"] = {
							["enable"] = false,
							["texture"] = "ElvUI Norm",
						},
						["hide"] = false,
						["color"] = {
							["power"] = false,
							["healthColor"] = {
								["a"] = 1,
								["r"] = 1,
								["g"] = 1,
								["b"] = 1,
							},
							["health"] = false,
							["borderColor"] = {
								["a"] = 1,
								["r"] = 1,
								["g"] = 1,
								["b"] = 1,
							},
							["nameColor"] = {
								["a"] = 1,
								["r"] = 1,
								["g"] = 1,
								["b"] = 1,
							},
							["name"] = false,
							["border"] = false,
							["powerColor"] = {
								["a"] = 1,
								["r"] = 1,
								["g"] = 1,
								["b"] = 1,
							},
						},
						["nameOnly"] = false,
						["alpha"] = -1,
						["flash"] = {
							["speed"] = 4,
							["color"] = {
								["a"] = 1,
								["r"] = 1,
								["g"] = 1,
								["b"] = 1,
							},
							["enable"] = false,
						},
					},
					["triggers"] = {
						["debuffs"] = {
							["minTimeLeft"] = 0,
							["mustHaveAll"] = false,
							["missing"] = false,
							["maxTimeLeft"] = 0,
							["names"] = {
							},
						},
						["instanceType"] = {
							["party"] = false,
							["scenario"] = false,
							["none"] = false,
							["raid"] = false,
							["arena"] = false,
							["pvp"] = false,
						},
						["inCombatUnit"] = false,
						["class"] = {
						},
						["role"] = {
							["tank"] = false,
							["healer"] = false,
							["damager"] = false,
						},
						["maxlevel"] = 0,
						["overHealthThreshold"] = 0,
						["nameplateType"] = {
							["healer"] = false,
							["neutral"] = false,
							["friendlyPlayer"] = false,
							["enemyPlayer"] = false,
							["friendlyNPC"] = false,
						},
						["underHealthThreshold"] = 0,
						["reactionType"] = {
							["enabled"] = false,
							["reputation"] = false,
							["friendly"] = false,
							["revered"] = false,
							["honored"] = false,
							["hostile"] = false,
							["unfriendly"] = false,
							["hated"] = false,
							["neutral"] = false,
							["exalted"] = false,
						},
						["buffs"] = {
							["minTimeLeft"] = 0,
							["mustHaveAll"] = false,
							["missing"] = false,
							["maxTimeLeft"] = 0,
							["names"] = {
							},
						},
						["inCombat"] = false,
						["healthThreshold"] = false,
						["names"] = {
						},
						["isTarget"] = false,
						["priority"] = 1,
						["healthUsePlayer"] = false,
						["targetMe"] = false,
						["classification"] = {
							["elite"] = false,
							["normal"] = false,
							["rareelite"] = false,
							["minus"] = false,
							["worldboss"] = false,
							["trivial"] = false,
							["rare"] = false,
						},
						["underPowerThreshold"] = 0,
						["talent"] = {
							["tier7enabled"] = false,
							["tier7"] = {
								["missing"] = false,
								["column"] = 0,
							},
							["tier2enabled"] = false,
							["tier1"] = {
								["missing"] = false,
								["column"] = 0,
							},
							["tier4"] = {
								["missing"] = false,
								["column"] = 0,
							},
							["enabled"] = false,
							["type"] = "normal",
							["tier2"] = {
								["missing"] = false,
								["column"] = 0,
							},
							["tier4enabled"] = false,
							["tier3"] = {
								["missing"] = false,
								["column"] = 0,
							},
							["tier5enabled"] = false,
							["tier5"] = {
								["missing"] = false,
								["column"] = 0,
							},
							["tier1enabled"] = false,
							["requireAll"] = false,
							["tier6enabled"] = false,
							["tier3enabled"] = false,
							["tier6"] = {
								["missing"] = false,
								["column"] = 0,
							},
						},
						["minlevel"] = 0,
						["notTarget"] = false,
						["instanceDifficulty"] = {
							["dungeon"] = {
								["normal"] = false,
								["mythic+"] = false,
								["heroic"] = false,
								["timewalking"] = false,
								["mythic"] = false,
							},
							["raid"] = {
								["normal"] = false,
								["legacy25normal"] = false,
								["heroic"] = false,
								["legacy10normal"] = false,
								["legacy10heroic"] = false,
								["mythic"] = false,
								["lfr"] = false,
								["timewalking"] = false,
								["legacy25heroic"] = false,
							},
						},
						["outOfCombat"] = false,
						["questBoss"] = false,
						["overPowerThreshold"] = 0,
						["powerThreshold"] = false,
						["cooldowns"] = {
							["mustHaveAll"] = false,
							["names"] = {
							},
						},
						["casting"] = {
							["interruptible"] = false,
							["spells"] = {
							},
						},
						["powerUsePlayer"] = false,
						["outOfCombatUnit"] = false,
					},
				},
			},
		},
		["general"] = {
			["AceGUI"] = {
				["top"] = 936.9,
				["left"] = 409.43,
			},
			["WorldMapCoordinates"] = {
				["enable"] = false,
			},
			["UIScale"] = 0.71,
		},
		["uiScale"] = "0.7111",
		["unitframe"] = {
			["ChannelTicks"] = {
				["Penance"] = 3,
				[47540] = 3,
			},
		},
		["nameplatesResetInformed"] = true,
		["uiScaleInformed"] = true,
		["userInformedNewChanges1"] = true,
	},
	["profiles"] = {
		["Shadow"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconmouseover"] = true,
						["spacing"] = 2,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,282",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["auraBarBuff"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["health"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
				},
				["units"] = {
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
					},
					["boss"] = {
						["height"] = 40,
						["growthDirection"] = "UP",
						["castbar"] = {
							["enable"] = false,
						},
						["width"] = 130,
					},
					["focus"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["aurabar"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["width"] = 170,
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["pet"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["b"] = 0.054,
					["g"] = 0.054,
					["r"] = 0.054,
				},
				["valuecolor"] = {
					["b"] = 0.819,
					["g"] = 0.513,
					["r"] = 0.09,
				},
				["afk"] = false,
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
			},
		},
		["ROGUE"] = {
			["chat"] = {
				["panelColorConverted"] = true,
			},
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1078",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,428",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,433",
			},
		},
		["Surv"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Noxiâ - Antonidas"] = {
			["chat"] = {
				["panelColorConverted"] = true,
			},
			["currentTutorial"] = 2,
			["hideTutorial"] = true,
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,433",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1078",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,428",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
			},
		},
		["Diszi"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconmouseover"] = true,
						["spacing"] = 2,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,754,308",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-292,281",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,754,303",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,961,445",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-293,305",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-250,267",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,584,248",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,839,445",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,584,267",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,775,236",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-582,268",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,293,305",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["auraBarBuff"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["health"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
				},
				["units"] = {
					["party"] = {
						["width"] = 95,
						["debuffs"] = {
							["sizeOverride"] = 12,
						},
						["showPlayer"] = false,
						["growthDirection"] = "RIGHT_DOWN",
					},
					["boss"] = {
						["height"] = 40,
						["width"] = 130,
						["castbar"] = {
							["enable"] = false,
						},
						["growthDirection"] = "UP",
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["focus"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["width"] = 170,
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["pet"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["width"] = 170,
						["aurabar"] = {
							["enable"] = false,
						},
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["b"] = 0.054,
					["g"] = 0.054,
					["r"] = 0.054,
				},
				["valuecolor"] = {
					["b"] = 0.819,
					["g"] = 0.513,
					["r"] = 0.09,
				},
				["afk"] = false,
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
			},
		},
		["BM"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["honor"] = {
					["enable"] = false,
					["height"] = 230,
				},
				["experience"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 230,
				},
			},
			["currentTutorial"] = 2,
			["general"] = {
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["altPowerBar"] = {
					["enable"] = false,
				},
				["bottomPanel"] = false,
				["afk"] = false,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
			},
			["hideTutorial"] = true,
			["layoutSet"] = "dpsMelee",
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,282",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,4",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
				["AzeriteBarMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-429,4",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-4,4",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
			},
			["v11NamePlateReset"] = true,
			["unitframe"] = {
				["units"] = {
					["targettarget"] = {
						["width"] = 85,
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["castbar"] = {
							["width"] = 170,
							["enable"] = false,
						},
					},
					["focus"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["target"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
						["classicon"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
					},
					["arena"] = {
						["width"] = 100,
						["height"] = 30,
					},
					["boss"] = {
						["growthDirection"] = "UP",
						["castbar"] = {
							["enable"] = false,
						},
						["width"] = 130,
						["height"] = 40,
					},
					["pet"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
				},
				["colors"] = {
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
			},
			["actionbar"] = {
				["desaturateOnCooldown"] = true,
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
				["minimap"] = {
					["coords"] = {
						["position"] = "BOTTOMLEFT",
						["enable"] = true,
					},
					["mapicons"] = {
						["spacing"] = 2,
						["iconperrow"] = 6,
						["iconmouseover"] = true,
					},
				},
			},
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelWidth"] = 423,
				["panelHeight"] = 230,
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
			},
		},
		["Arms"] = {
			["movers"] = {
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Krytosbank - Blackmoore"] = {
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["currentTutorial"] = 2,
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["b"] = 0.054,
					["g"] = 0.054,
					["r"] = 0.054,
				},
				["valuecolor"] = {
					["b"] = 0.819,
					["g"] = 0.513,
					["r"] = 0.09,
				},
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
				["afk"] = false,
			},
			["actionbar"] = {
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
				},
			},
			["layoutSet"] = "dpsMelee",
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["auraBarBuff"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["health"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
				},
				["units"] = {
					["target"] = {
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
						},
					},
				},
			},
			["hideTutorial"] = true,
			["chat"] = {
				["copyChatLines"] = true,
				["panelColorConverted"] = true,
			},
		},
		["MONK"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Blackmoore"] = {
			["chat"] = {
				["panelColorConverted"] = true,
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
			},
		},
		["Neaxa - Blackmoore"] = {
			["v11NamePlateReset"] = true,
			["chat"] = {
				["panelColorConverted"] = true,
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,433",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1078",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,428",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
		},
		["Arthemiasd - Ravencrest"] = {
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Arthemias - Blackmoore"] = {
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
			},
			["currentTutorial"] = 1,
			["hideTutorial"] = true,
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Minimalistic"] = {
			["currentTutorial"] = 2,
			["general"] = {
				["font"] = "Expressway",
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["a"] = 0.80000001192093,
					["r"] = 0.058823529411765,
					["g"] = 0.058823529411765,
					["b"] = 0.058823529411765,
				},
				["reputation"] = {
					["orientation"] = "HORIZONTAL",
					["textFormat"] = "PERCENT",
					["height"] = 16,
					["width"] = 200,
				},
				["bordercolor"] = {
					["r"] = 0.30588235294118,
					["g"] = 0.30588235294118,
					["b"] = 0.30588235294118,
				},
				["valuecolor"] = {
					["a"] = 1,
					["r"] = 1,
					["g"] = 1,
					["b"] = 1,
				},
				["fontSize"] = 11,
			},
			["movers"] = {
				["PetAB"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-428",
				["ElvUF_RaidMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,51,120",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,50",
				["GMMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,250,-50",
				["BossButton"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-117,-298",
				["LootFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,249,-216",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,827",
				["MicrobarMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,4,-52",
				["VehicleSeatMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,51,-87",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,143",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,392,1073",
				["ElvAB_1"] = "BOTTOM,ElvUIParent,BOTTOM,0,50",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvAB_4"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-394",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-186",
				["ElvAB_3"] = "BOTTOM,ElvUIParent,BOTTOM,305,50",
				["ElvAB_5"] = "BOTTOM,ElvUIParent,BOTTOM,-305,50",
				["MinimapMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-50",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,140",
				["ObjectiveFrameMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-122,-393",
				["BNETMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,50,232",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,1150",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,133",
				["ElvUF_PartyMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,184,773",
				["ElvAB_6"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-488,330",
				["TooltipMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,50,995",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,140",
				["TotemBarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,463,50",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,200",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-50,50",
				["AlertFrameMover"] = "TOP,ElvUIParent,TOP,0,-50",
				["ReputationBarMover"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-50,-228",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,51,937",
			},
			["bags"] = {
				["itemLevelFontSize"] = 9,
				["countFontSize"] = 9,
			},
			["hideTutorial"] = true,
			["auras"] = {
				["font"] = "Expressway",
				["buffs"] = {
					["countFontSize"] = 11,
					["maxWraps"] = 2,
					["durationFontSize"] = 11,
				},
				["debuffs"] = {
					["countFontSize"] = 11,
					["durationFontSize"] = 11,
				},
			},
			["unitframe"] = {
				["statusbar"] = "ElvUI Blank",
				["fontOutline"] = "THICKOUTLINE",
				["smoothbars"] = true,
				["font"] = "Expressway",
				["fontSize"] = 9,
				["units"] = {
					["tank"] = {
						["enable"] = false,
					},
					["targettarget"] = {
						["infoPanel"] = {
							["enable"] = true,
						},
						["debuffs"] = {
							["enable"] = false,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["yOffset"] = -2,
							["position"] = "TOP",
						},
						["height"] = 50,
						["width"] = 122,
					},
					["pet"] = {
						["infoPanel"] = {
							["enable"] = true,
							["height"] = 14,
						},
						["debuffs"] = {
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["width"] = 122,
						},
						["height"] = 50,
						["portrait"] = {
							["camDistanceScale"] = 2,
						},
						["width"] = 122,
					},
					["party"] = {
						["horizontalSpacing"] = 3,
						["debuffs"] = {
							["numrows"] = 4,
							["anchorPoint"] = "BOTTOM",
							["perrow"] = 1,
						},
						["power"] = {
							["text_format"] = "",
							["height"] = 5,
						},
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
						["growthDirection"] = "RIGHT_DOWN",
						["infoPanel"] = {
							["enable"] = true,
						},
						["roleIcon"] = {
							["position"] = "TOPRIGHT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["orientation"] = "VERTICAL",
							["text_format"] = "[healthcolor][health:current]",
							["position"] = "RIGHT",
						},
						["healPrediction"] = true,
						["height"] = 59,
						["verticalSpacing"] = 0,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name:short]",
							["position"] = "LEFT",
						},
						["width"] = 110,
					},
					["player"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["combatfade"] = true,
						["infoPanel"] = {
							["enable"] = true,
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
						["height"] = 80,
						["castbar"] = {
							["iconAttached"] = false,
							["iconSize"] = 54,
							["height"] = 35,
							["width"] = 478,
						},
						["classbar"] = {
							["height"] = 15,
							["autoHide"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
					},
					["raid40"] = {
						["enable"] = false,
						["rdebuffs"] = {
							["font"] = "Expressway",
						},
					},
					["focus"] = {
						["infoPanel"] = {
							["height"] = 17,
							["enable"] = true,
						},
						["threatStyle"] = "NONE",
						["castbar"] = {
							["iconSize"] = 26,
							["width"] = 122,
						},
						["height"] = 56,
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["position"] = "LEFT",
						},
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current]",
						},
						["width"] = 189,
					},
					["target"] = {
						["debuffs"] = {
							["perrow"] = 7,
						},
						["power"] = {
							["attachTextTo"] = "InfoPanel",
							["hideonnpc"] = false,
							["text_format"] = "[powercolor][power:current-max]",
							["height"] = 15,
						},
						["infoPanel"] = {
							["enable"] = true,
						},
						["name"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[namecolor][name]",
						},
						["castbar"] = {
							["iconSize"] = 54,
							["iconAttached"] = false,
						},
						["height"] = 80,
						["buffs"] = {
							["perrow"] = 7,
						},
						["smartAuraPosition"] = "DEBUFFS_ON_BUFFS",
						["health"] = {
							["attachTextTo"] = "InfoPanel",
							["text_format"] = "[healthcolor][health:current-max]",
						},
					},
					["raid"] = {
						["roleIcon"] = {
							["position"] = "RIGHT",
						},
						["debuffs"] = {
							["enable"] = true,
							["sizeOverride"] = 27,
							["perrow"] = 4,
						},
						["rdebuffs"] = {
							["enable"] = false,
							["font"] = "Expressway",
						},
						["growthDirection"] = "UP_RIGHT",
						["health"] = {
							["yOffset"] = -6,
						},
						["width"] = 140,
						["height"] = 28,
						["name"] = {
							["position"] = "LEFT",
						},
						["visibility"] = "[nogroup] hide;show",
						["groupsPerRowCol"] = 5,
					},
					["arena"] = {
						["castbar"] = {
							["width"] = 246,
						},
						["spacing"] = 26,
					},
					["assist"] = {
						["enable"] = false,
					},
				},
			},
			["datatexts"] = {
				["minimapPanels"] = false,
				["fontSize"] = 11,
				["leftChatPanel"] = false,
				["goldFormat"] = "SHORT",
				["panelTransparency"] = true,
				["font"] = "Expressway",
				["panels"] = {
					["BottomMiniPanel"] = "Time",
					["RightMiniPanel"] = "",
					["RightChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
					["LeftMiniPanel"] = "",
					["LeftChatDataPanel"] = {
						["right"] = "",
						["left"] = "",
						["middle"] = "",
					},
				},
				["rightChatPanel"] = false,
			},
			["actionbar"] = {
				["bar3"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["fontSize"] = 9,
				["bar2"] = {
					["enabled"] = true,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar1"] = {
					["heightMult"] = 2,
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
				},
				["bar5"] = {
					["inheritGlobalFade"] = true,
					["buttonsize"] = 38,
					["buttonsPerRow"] = 3,
				},
				["globalFadeAlpha"] = 0.87,
				["stanceBar"] = {
					["inheritGlobalFade"] = true,
				},
				["bar6"] = {
					["buttonsize"] = 38,
				},
				["bar4"] = {
					["enabled"] = false,
					["backdrop"] = false,
					["buttonsize"] = 38,
				},
			},
			["layoutSet"] = "dpsMelee",
			["chat"] = {
				["chatHistory"] = false,
				["fontSize"] = 11,
				["tabFont"] = "Expressway",
				["tabFontSize"] = 11,
				["fadeUndockedTabs"] = false,
				["editBoxPosition"] = "ABOVE_CHAT",
				["fadeTabsNoBackdrop"] = false,
				["font"] = "Expressway",
				["panelBackdrop"] = "HIDEBOTH",
			},
			["tooltip"] = {
				["textFontSize"] = 11,
				["font"] = "Expressway",
				["healthBar"] = {
					["font"] = "Expressway",
				},
				["smallTextFontSize"] = 11,
				["fontSize"] = 11,
				["headerFontSize"] = 11,
			},
			["nameplates"] = {
				["filters"] = {
				},
			},
		},
		["Prot"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
				["minimap"] = {
					["mapicons"] = {
						["spacing"] = 2,
						["iconmouseover"] = true,
						["iconperrow"] = 6,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-87,173",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-86,192",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-213,216",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,539,182",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,539,201",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,211,216",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,84,192",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
					},
					["boss"] = {
						["height"] = 40,
						["growthDirection"] = "UP",
						["castbar"] = {
							["enable"] = false,
						},
						["width"] = 130,
					},
					["focus"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["aurabar"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["width"] = 170,
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["pet"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["afk"] = false,
			},
		},
		["Asdasfadfsaf - Blackmoore"] = {
			["actionbar"] = {
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
				},
			},
			["currentTutorial"] = 2,
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["afk"] = false,
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-4",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-285,186",
				["ZoneAbility"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-349,186",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-543,264",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-543,264",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
			},
			["layoutSet"] = "dpsMelee",
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["width"] = 170,
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["focus"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["target"] = {
						["height"] = 60,
						["width"] = 170,
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["boss"] = {
						["height"] = 30,
						["width"] = 100,
						["growthDirection"] = "UP",
					},
				},
			},
			["hideTutorial"] = true,
			["chat"] = {
				["copyChatLines"] = true,
				["panelColorConverted"] = true,
			},
		},
		["Nexana - Blackmoore"] = {
			["chat"] = {
				["panelColorConverted"] = true,
			},
			["currentTutorial"] = 2,
			["hideTutorial"] = true,
			["movers"] = {
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
			},
		},
		["Fury"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["afk"] = false,
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,282",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["boss"] = {
						["height"] = 40,
						["width"] = 130,
						["castbar"] = {
							["enable"] = false,
						},
						["growthDirection"] = "UP",
					},
					["pet"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["focus"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["width"] = 170,
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["width"] = 170,
						["aurabar"] = {
							["enable"] = false,
						},
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconmouseover"] = true,
						["spacing"] = 2,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
			},
		},
		["Nethenâ - Blackmoore"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
			},
			["currentTutorial"] = 2,
			["hideTutorial"] = true,
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Nariâ - Blackmoore"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 230,
				},
				["experience"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 230,
				},
			},
			["currentTutorial"] = 2,
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
				["minimap"] = {
					["mapicons"] = {
						["spacing"] = 2,
						["iconmouseover"] = true,
						["iconperrow"] = 6,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,282",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["LeftChatMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,0,0",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,0",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
			},
			["v11NamePlateReset"] = true,
			["hideTutorial"] = true,
			["chat"] = {
				["copyChatLines"] = true,
				["panelColorConverted"] = true,
				["panelHeight"] = 230,
				["timeStampFormat"] = "%H:%M ",
				["panelWidth"] = 423,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["boss"] = {
						["height"] = 40,
						["width"] = 130,
						["castbar"] = {
							["enable"] = false,
						},
						["growthDirection"] = "UP",
					},
					["pet"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["focus"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["target"] = {
						["debuffs"] = {
							["enable"] = false,
						},
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["width"] = 170,
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["width"] = 170,
						["aurabar"] = {
							["enable"] = false,
						},
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["general"] = {
				["altPowerBar"] = {
					["enable"] = false,
				},
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["afk"] = false,
				["bottomPanel"] = false,
			},
		},
		["Asdafggdaf - Blackmoore"] = {
			["currentTutorial"] = 2,
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["boss"] = {
						["height"] = 30,
						["growthDirection"] = "UP",
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["focus"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["aurabar"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["width"] = 170,
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["pet"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
					},
				},
			},
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
				["afk"] = false,
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-4",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-285,186",
				["ZoneAbility"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-349,186",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-543,264",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-543,264",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
			},
			["layoutSet"] = "dpsMelee",
			["actionbar"] = {
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
				},
			},
			["hideTutorial"] = true,
			["chat"] = {
				["copyChatLines"] = true,
				["panelColorConverted"] = true,
				["panelHeight"] = 210,
			},
		},
		["Default"] = {
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
			},
			["chat"] = {
				["panelColorConverted"] = true,
			},
		},
		["Default DPS"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["afk"] = false,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-4",
				["BossButton"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-285,186",
				["ZoneAbility"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-349,186",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-543,264",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-543,264",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["copyChatLines"] = true,
				["panelColorConverted"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["boss"] = {
						["height"] = 30,
						["growthDirection"] = "UP",
						["width"] = 100,
					},
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
					},
					["focus"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["aurabar"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["width"] = 170,
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["pet"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["targettarget"] = {
						["width"] = 85,
					},
				},
			},
			["actionbar"] = {
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
				},
			},
			["layoutSet"] = "dpsMelee",
		},
		["Artèmis - Antonidas"] = {
			["chat"] = {
				["panelColorConverted"] = true,
			},
			["currentTutorial"] = 2,
			["hideTutorial"] = true,
			["movers"] = {
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,432",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,195",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,427",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["RightChatMover"] = "BOTTOMRIGHT,UIParent,BOTTOMRIGHT,0,19",
			},
		},
		["Holy Priest"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconmouseover"] = true,
						["spacing"] = 2,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,282",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["auraBarBuff"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
					["health"] = {
						["b"] = 0.1,
						["g"] = 0.1,
						["r"] = 0.1,
					},
				},
				["units"] = {
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["aurabar"] = {
							["enable"] = false,
						},
						["width"] = 170,
					},
					["boss"] = {
						["height"] = 40,
						["growthDirection"] = "UP",
						["castbar"] = {
							["enable"] = false,
						},
						["width"] = 130,
					},
					["focus"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["aurabar"] = {
							["enable"] = false,
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["width"] = 170,
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["pet"] = {
						["width"] = 85,
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["b"] = 0.054,
					["g"] = 0.054,
					["r"] = 0.054,
				},
				["valuecolor"] = {
					["b"] = 0.819,
					["g"] = 0.513,
					["r"] = 0.09,
				},
				["afk"] = false,
				["bordercolor"] = {
					["b"] = 0,
					["g"] = 0,
					["r"] = 0,
				},
			},
		},
		["MM"] = {
			["databars"] = {
				["reputation"] = {
					["height"] = 210,
				},
				["honor"] = {
					["height"] = 210,
				},
				["experience"] = {
					["height"] = 210,
				},
				["azerite"] = {
					["height"] = 210,
				},
			},
			["currentTutorial"] = 2,
			["sle"] = {
				["skins"] = {
					["talkinghead"] = {
						["hide"] = true,
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["iconperrow"] = 6,
						["iconmouseover"] = true,
						["spacing"] = 2,
					},
					["coords"] = {
						["enable"] = true,
						["position"] = "BOTTOMLEFT",
					},
				},
				["chat"] = {
					["guildmaster"] = true,
				},
			},
			["movers"] = {
				["ElvUF_Raid40Mover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,485",
				["RaidMarkerBarAnchor"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-1,229",
				["ElvUF_PlayerCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,282",
				["ElvUF_RaidMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,479",
				["ElvAB_2"] = "BOTTOM,ElvUIParent,BOTTOM,0,38",
				["TalkingHeadFrameMover"] = "TOP,ElvUIParent,TOP,0,-67",
				["AltPowerBarMover"] = "TOP,ElvUIParent,TOP,0,-228",
				["BossButton"] = "BOTTOM,ElvUIParent,BOTTOM,169,72",
				["ElvUF_AssistMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,545",
				["ZoneAbility"] = "BOTTOM,ElvUIParent,BOTTOM,-169,72",
				["LeftChatMover"] = "BOTTOMLEFT,UIParent,BOTTOMLEFT,0,19",
				["ElvUF_PlayerMover"] = "BOTTOM,ElvUIParent,BOTTOM,-230,300",
				["ObjectiveFrameMover"] = "TOPLEFT,ElvUIParent,TOPLEFT,89,-4",
				["ElvUF_RaidpetMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,736",
				["ShiftAB"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,1076",
				["RightChatMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,0,19",
				["ElvUF_FocusMover"] = "BOTTOM,ElvUIParent,BOTTOM,-188,265",
				["ArenaHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetCastbarMover"] = "BOTTOM,ElvUIParent,BOTTOM,-265,246",
				["ElvUF_TankMover"] = "TOPLEFT,ElvUIParent,BOTTOMLEFT,4,607",
				["BossHeaderMover"] = "BOTTOMRIGHT,ElvUIParent,BOTTOMRIGHT,-485,395",
				["ElvUF_PetMover"] = "BOTTOM,ElvUIParent,BOTTOM,-273,265",
				["SquareMinimapBar"] = "TOPRIGHT,ElvUIParent,TOPRIGHT,-4,-202",
				["ElvUF_PartyMover"] = "BOTTOMLEFT,ElvUIParent,BOTTOMLEFT,4,248",
				["AlertFrameMover"] = "BOTTOM,ElvUIParent,BOTTOM,0,90",
				["ElvUF_TargetTargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,273,265",
				["ElvUF_TargetMover"] = "BOTTOM,ElvUIParent,BOTTOM,230,300",
			},
			["hideTutorial"] = true,
			["chat"] = {
				["timeStampFormat"] = "%H:%M ",
				["panelColorConverted"] = true,
				["copyChatLines"] = true,
				["panelHeight"] = 210,
			},
			["unitframe"] = {
				["colors"] = {
					["castColor"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["auraBarBuff"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
					["health"] = {
						["r"] = 0.1,
						["g"] = 0.1,
						["b"] = 0.1,
					},
				},
				["units"] = {
					["player"] = {
						["debuffs"] = {
							["attachTo"] = "BUFFS",
						},
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["height"] = 60,
						["buffs"] = {
							["attachTo"] = "FRAME",
							["enable"] = true,
						},
						["width"] = 170,
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["pet"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["focus"] = {
						["castbar"] = {
							["enable"] = false,
							["width"] = 85,
						},
						["width"] = 85,
					},
					["target"] = {
						["classicon"] = {
							["enable"] = false,
						},
						["height"] = 60,
						["width"] = 170,
						["castbar"] = {
							["enable"] = false,
							["width"] = 170,
						},
						["aurabar"] = {
							["enable"] = false,
						},
					},
					["arena"] = {
						["height"] = 30,
						["width"] = 100,
					},
					["targettarget"] = {
						["width"] = 85,
					},
					["boss"] = {
						["height"] = 40,
						["width"] = 130,
						["castbar"] = {
							["enable"] = false,
						},
						["growthDirection"] = "UP",
					},
				},
			},
			["actionbar"] = {
				["bar1"] = {
					["visibility"] = "[vehicleui] show; [overridebar]show;[petbattle]hide;show",
				},
				["desaturateOnCooldown"] = true,
				["bar2"] = {
					["enabled"] = true,
					["visibility"] = "[vehicleui] show; [overridebar]hide;[petbattle]hide;show",
				},
			},
			["layoutSet"] = "dpsMelee",
			["general"] = {
				["bottomPanel"] = false,
				["backdropfadecolor"] = {
					["r"] = 0.054,
					["g"] = 0.054,
					["b"] = 0.054,
				},
				["valuecolor"] = {
					["r"] = 0.09,
					["g"] = 0.513,
					["b"] = 0.819,
				},
				["afk"] = false,
				["bordercolor"] = {
					["r"] = 0,
					["g"] = 0,
					["b"] = 0,
				},
			},
		},
	},
}
ElvPrivateDB = {
	["profileKeys"] = {
		["Artèmis - Antonidas"] = "Artèmis - Antonidas",
		["Arthemias - Blackmoore"] = "Arthemias - Blackmoore",
		["Asdasfadfsaf - Blackmoore"] = "Asdasfadfsaf - Blackmoore",
		["Nexana - Blackmoore"] = "Nexana - Blackmoore",
		["Nethenâ - Blackmoore"] = "Nethenâ - Blackmoore",
		["Nariâ - Blackmoore"] = "Nariâ - Blackmoore",
		["Noxiâ - Antonidas"] = "Noxiâ - Antonidas",
		["Asdafggdaf - Blackmoore"] = "Asdafggdaf - Blackmoore",
		["Krytosbank - Blackmoore"] = "Krytosbank - Blackmoore",
		["Arthemiasd - Ravencrest"] = "Arthemiasd - Ravencrest",
		["Neaxa - Blackmoore"] = "Neaxa - Blackmoore",
	},
	["profiles"] = {
		["Artèmis - Antonidas"] = {
			["tooltip"] = {
				["enable"] = false,
			},
			["nameplates"] = {
				["enable"] = false,
			},
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["install_complete"] = "3.5",
				["characterGoldsSorting"] = {
					["Antonidas"] = {
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["barenable"] = true,
						["enable"] = true,
					},
				},
			},
			["install_complete"] = "10.86",
		},
		["Arthemias - Blackmoore"] = {
			["nameplates"] = {
				["enable"] = false,
			},
			["sle"] = {
				["characterGoldsSorting"] = {
					["Blackmoore"] = {
					},
				},
				["pvpreadydialogreset"] = true,
				["minimap"] = {
					["mapicons"] = {
						["enable"] = true,
						["barenable"] = true,
					},
				},
				["skins"] = {
					["merchant"] = {
						["enable"] = true,
					},
				},
				["install_complete"] = "3.5",
			},
			["general"] = {
				["minimapbar"] = {
					["mouseover"] = true,
				},
			},
			["install_complete"] = "10.85",
		},
		["Asdasfadfsaf - Blackmoore"] = {
			["nameplates"] = {
				["enable"] = false,
			},
			["install_complete"] = "10.85",
		},
		["Nexana - Blackmoore"] = {
			["nameplates"] = {
				["enable"] = false,
			},
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["install_complete"] = "3.5",
				["characterGoldsSorting"] = {
					["Blackmoore"] = {
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["enable"] = true,
						["barenable"] = true,
					},
				},
			},
			["install_complete"] = "10.85",
		},
		["Nethenâ - Blackmoore"] = {
			["nameplates"] = {
				["enable"] = false,
			},
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["install_complete"] = "3.5",
				["characterGoldsSorting"] = {
					["Blackmoore"] = {
					},
				},
				["minimap"] = {
					["mapicons"] = {
						["enable"] = true,
						["barenable"] = true,
					},
				},
			},
			["install_complete"] = "10.85",
		},
		["Nariâ - Blackmoore"] = {
			["nameplates"] = {
				["enable"] = false,
			},
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["minimap"] = {
					["mapicons"] = {
						["enable"] = true,
						["barenable"] = true,
					},
				},
				["characterGoldsSorting"] = {
					["Blackmoore"] = {
					},
				},
				["install_complete"] = "3.5",
			},
			["install_complete"] = "10.85",
		},
		["Noxiâ - Antonidas"] = {
			["nameplates"] = {
				["enable"] = false,
			},
			["tooltip"] = {
				["enable"] = false,
			},
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["minimap"] = {
					["mapicons"] = {
						["enable"] = true,
						["barenable"] = true,
					},
				},
				["characterGoldsSorting"] = {
					["Antonidas"] = {
					},
				},
				["install_complete"] = "3.511",
			},
			["install_complete"] = "10.92",
		},
		["Asdafggdaf - Blackmoore"] = {
			["install_complete"] = "10.85",
		},
		["Krytosbank - Blackmoore"] = {
			["general"] = {
				["minimapbar"] = {
					["mouseover"] = true,
				},
			},
			["sle"] = {
				["pvpreadydialogreset"] = true,
				["characterGoldsSorting"] = {
					["Blackmoore"] = {
					},
				},
				["install_complete"] = "3.492",
			},
			["bags"] = {
				["enable"] = false,
			},
			["nameplates"] = {
				["enable"] = false,
			},
			["tooltip"] = {
				["enable"] = false,
			},
			["theme"] = "default",
			["install_complete"] = "10.85",
		},
		["Arthemiasd - Ravencrest"] = {
			["sle"] = {
				["characterGoldsSorting"] = {
					["Ravencrest"] = {
					},
				},
				["pvpreadydialogreset"] = true,
			},
		},
		["Neaxa - Blackmoore"] = {
			["sle"] = {
				["characterGoldsSorting"] = {
					["Blackmoore"] = {
					},
				},
				["pvpreadydialogreset"] = true,
			},
		},
	},
}
